#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <math.h>
#include <limits.h>
#include <regex.h>
#define TRUE 1
#define FALSE 0
#define INIT_FIELDWIDTH 100
#define INIT_FIELDHEIGHT 100
#define COLOUROFFSET (short)256
#define FIELD_TYPE short

typedef struct field
{
	int Width;
	int Height;
	FIELD_TYPE **memory;
}
field;

typedef struct Point
{
	FIELD_TYPE colour;
	int xcoord;
	char is_eof;
}
Point;

int initialize_gamefield(int width, int height, field *f);
Point *getNextPoint(field *f);
void freeFieldPointer(field *f);
void failedAllocationExit(char *msg, field *f);
int insertPoint(Point *p, field *f);
int checkIllegalFormat(char *line);
int checkAgainstRegularExpression(char *line);
int increaseHeight(field *f);
int increaseWidth(field *f);
int checkScore(field *f);
int checkY(field *f, int xpos);
int checkX(field *f, int xpos, int ypos);
int checkDiagPoint(field *f, int xpos, int ypos);
int checkStartdiag(field *f);
int checkDiag(field *f);
int collapseField(field *f);
void printField(field *f);
void debug(char *msg);


int main(int argc, char **argv)
{
	if (argc > 1)
	{
		fprintf(stderr, "[-]Too many arguments for function \"%s\"n", argv[0]);
		exit(EXIT_FAILURE);
	}

	field *gamefield = malloc(sizeof(field));
	initialize_gamefield(INIT_FIELDWIDTH, INIT_FIELDHEIGHT, gamefield);

	Point *new_point;
	while (TRUE)
	{
		new_point = getNextPoint(gamefield);
		if (new_point->is_eof)
		{
			break;
		}

		insertPoint(new_point, gamefield);
		free(new_point);

		int has_changed = checkScore(gamefield);
		while (has_changed)
		{
			collapseField(gamefield);
			has_changed = checkScore(gamefield);
		}
	}
	printField(gamefield);
	free(new_point);
	freeFieldPointer(gamefield);
	exit(EXIT_SUCCESS);
}

int initialize_gamefield(int width, int height, field *f)
{
	f->Height = height;
	f->Width = width;

	f->memory = (FIELD_TYPE **) malloc(sizeof(FIELD_TYPE*) *f->Width);
	if (!f->memory)
	{
		failedAllocationExit("@initialize_gamefield, initializing FIELD_TYPE**", f);
	}

	for (int i = 0; i < f->Width; i++)
	{
		f->memory[i] = (FIELD_TYPE*) calloc(f->Height, sizeof(FIELD_TYPE));
		if (!f->memory[i])
		{
			failedAllocationExit("@initialize_gamefield, initializing FIELD_TYPE*", f);
		}
	}
	return TRUE;
}

void failedAllocationExit(char *msg, field *f)
{
	fprintf(stderr, "[-]Memory Allocation Error: %s", msg);
	freeFieldPointer(f);
	exit(EXIT_FAILURE);
}

void freeFieldPointer(field *f)
{
	for (int i = 0; i < f->Width; i++)
	{
		free(f->memory[i]);
	}
	free(f->memory);
	free(f);
}

Point *getNextPoint(field *f)
{
	char line[32];
	char xcoordstr[128];
	char colourstr[128];
	Point *p = malloc(sizeof(Point));
	p->is_eof = FALSE;

	if (fgets(line, sizeof(line), stdin))
	{
		if (checkAgainstRegularExpression(line))
		{
			debug("Illegal input. Shutting down.\n");
			freeFieldPointer(f);
			free(p);
			exit(EXIT_FAILURE);
		}
		if (2 == sscanf(line, "%s %s", colourstr, xcoordstr))
		{
			char *strBuf;
			long ximport = strtol(xcoordstr, &strBuf, 10);
			if (ximport > (long) pow(2, 20) || ximport < INT_MIN)
			{
				fprintf(stderr, "X-Coordinate is above integer limit.\n");
				freeFieldPointer(f);
				free(p);
				exit(EXIT_FAILURE);
			}
			int xcoord = ximport;

			long colourimport = strtol(colourstr, &strBuf, 10);
			if (colourimport > 254 || colourimport < 0)
			{
				fprintf(stderr, "Invalid colour value.\n");
				freeFieldPointer(f);
				free(p);
				exit(EXIT_FAILURE);
			}
			p->xcoord = xcoord;
			p->colour = (short) colourimport + 1;	//All colours are increased by 1 to allow for uniform memory allocation &memset
		}
		else
		{
			debug("Illegal input. Shutting down.\n");
			freeFieldPointer(f);
			free(p);
			exit(EXIT_FAILURE);
		}
	}
	else
	{
		p->xcoord = 999;
		p->colour = 999;
		p->is_eof = TRUE;
		return p;
	}

	return p;
}

int checkAgainstRegularExpression(char *line)
{
	regex_t regex;
	int regexRet;
	char msgbuf[128];

	regexRet = regcomp(&regex, "^[0-9]+ +-?[0-9]+$\n", REG_EXTENDED);

	regexRet = regexec(&regex, line, 0, NULL, 0);
	if (!regexRet)
	{
		regfree(&regex);
		return FALSE;
	}
	else if (regexRet == REG_NOMATCH)
	{
		regfree(&regex);
		return TRUE;
	}
	else
	{
		regerror(regexRet, &regex, msgbuf, sizeof(msgbuf));
		fprintf(stderr, "Regex match failed: %s\n", msgbuf);
		regfree(&regex);
		return TRUE;
	}
}

void debug(char *msg)
{
	fprintf(stderr, "[-]DEBUG: %s", msg);
}

int insertPoint(Point *p, field *f)
{
	int maxFieldXCoord = f->Width / 2 - 1;
	int minFieldXCoord = -(f->Width / 2);

	while ((p->xcoord > maxFieldXCoord) || (p->xcoord < minFieldXCoord))
	{
		int increaseWidthSuccess = increaseWidth(f);
		if (!increaseWidthSuccess)
		{
			freeFieldPointer(f);
			free(p);
			debug("Increasing Width failed exiting\n");
			exit(EXIT_FAILURE);
		}
		maxFieldXCoord = f->Width / 2 - 1;
		minFieldXCoord = -(f->Width / 2);
	}

	int fieldOffset = f->Width / 2;
	int new_xcoord = p->xcoord + fieldOffset;

	int count = 0;
	FIELD_TYPE current = f->memory[new_xcoord][count];

	while (current > 0)
	{
		count++;

		if (count >= f->Height - 1)
		{
			int increaseHeightSuccess = increaseHeight(f);

			if (!increaseHeightSuccess)
			{
				freeFieldPointer(f);
				free(p);
				debug("Increasing Height failed");
				exit(EXIT_FAILURE);
			}
		}
		current = f->memory[new_xcoord][count];
	}
	f->memory[new_xcoord][count] = p->colour;

	return TRUE;
}

int increaseWidth(field *f)
{
	int oldWidth = f->Width;
	int offset = oldWidth / 2;

	int newWidth = oldWidth * 2;

	FIELD_TYPE **new = realloc(f->memory, newWidth* sizeof(FIELD_TYPE*));

	if (!new)
	{
		return FALSE;
	}
	memmove(new + offset, new, oldWidth* sizeof(FIELD_TYPE*));

	for (int i = 0; i < offset; i++)
	{
		new[i] = calloc(f->Height, sizeof(FIELD_TYPE));
		if (!new[i])
		{
			return FALSE;
		}
	}
	for (int i = 3 * offset; i < newWidth; i++)
	{
		new[i] = calloc(f->Height, sizeof(FIELD_TYPE));
		if (!new[i])
		{
			return FALSE;
		}
	}
	f->memory = new;
	f->Width = newWidth;
	return TRUE;
}

int increaseHeight(field *f)
{
	int oldHeight = f->Height;
	f->Height = f->Height * 2;
	for (int i = 0; i < f->Width; i++)
	{
		FIELD_TYPE *new = realloc(f->memory[i], f->Height* sizeof(FIELD_TYPE));
		if (!new)
		{
			return FALSE;
		}
		memset(new + oldHeight, 0, sizeof(FIELD_TYPE) *oldHeight);
		for (int j = oldHeight; j < f->Height; j++) {}
		f->memory[i] = new;
	}

	return TRUE;
}

int checkScore(field *f)
{
	int xpos;
	int has_changed = 0;
	for (xpos = 0; xpos < f->Width; xpos++)
	{
		if (f->memory[xpos][0] != 0)
		{
			has_changed += checkY(f, xpos);
		}
	}
	return has_changed;
}

int checkDiagPoint(field *f, int xpos, int ypos)
{
	FIELD_TYPE newval;

	char count = 1;
	int has_changed = FALSE;
	FIELD_TYPE oldval = f->memory[xpos][ypos];
	FIELD_TYPE rp_val = oldval % COLOUROFFSET + COLOUROFFSET;

	if (f->Width - xpos >= 4)
	{
		if (f->Height - ypos >= 4)
		{
			for (int upticker = 1; upticker < 4; upticker++)
			{

				newval = f->memory[xpos + upticker][ypos + upticker];
				if ((newval != oldval) && (newval + COLOUROFFSET != oldval))
				{
					break;
				}
			}
			if (count == 4)
			{
				for (int upticker = 0; upticker < 4; upticker++)
				{
					f->memory[xpos + upticker][ypos + upticker] = rp_val;
				}
				has_changed = TRUE;
			}
			count = 1;
		}
	}
	if (xpos >= 3)
	{
		if (f->Height - ypos >= 4)
		{
			for (int upticker = 1; upticker < 4; upticker++)
			{

				newval = f->memory[xpos - upticker][ypos + upticker];
				if ((newval != oldval) && (newval + COLOUROFFSET != oldval))
				{
					break;
				}
			}
			if (count == 4)
			{
				for (int upticker = 0; upticker < 4; upticker++)
				{
					f->memory[xpos - upticker][ypos + upticker] = rp_val;
				}
				has_changed = TRUE;
			}
			count = 1;
		}
	}
	return has_changed;
}

int checkY(field *f, int xpos)
{
	FIELD_TYPE *current = f->memory[xpos];

	FIELD_TYPE newval;
	FIELD_TYPE oldval = 999;
	int total = 1;
	int has_changed = FALSE;
	int ypos;

	for (ypos = 0; ypos < f->Height; ypos++)
	{
		newval = current[ypos];
		if (newval == 0)
		{
			break;
		}
		has_changed += checkX(f, xpos, ypos);
		has_changed += checkDiagPoint(f, xpos, ypos);

		if (((newval == oldval) || (newval == oldval + COLOUROFFSET)) && (oldval != 0))
		{
			total++;
		}
		else
		{
			if (total >= 4)
			{
				has_changed = TRUE;
				for (int i = total; i >= 1; i--)
				{
					current[ypos - i] = oldval % COLOUROFFSET + COLOUROFFSET;
				}
				total = 1;
				oldval = newval;
			}
			else
			{
				total = 1;
				oldval = newval;
			}
		}
	}
	if (total >= 4)
	{
		has_changed = TRUE;
		for (int i = total; i >= 1; i--)
		{
			current[ypos - i] = oldval % COLOUROFFSET + COLOUROFFSET;
		}
	}
	return has_changed;
}

int checkX(field *f, int xpos, int ypos)
{

	int total = 1;
	FIELD_TYPE compare_val = f->memory[xpos][ypos];
	FIELD_TYPE newval;

	if (xpos < f->Width - 4)
	{
		while (xpos <= f->Width - 1)
		{
			xpos++;
			newval = f->memory[xpos][ypos];
			if (newval == 0)
			{
				break;
			}
			if (((newval != compare_val) && (newval - COLOUROFFSET != compare_val)))
			{
				if (total >= 4)
				{
					for (int i = total; i >= 1; i--)
					{
						f->memory[xpos - i][ypos] = compare_val % COLOUROFFSET + COLOUROFFSET;
					}
					return total - 1;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				total++;
			}
		}
		if (total >= 4)
		{
			for (int i = total; i >= 1; i--)
			{
				f->memory[xpos - i][ypos] = compare_val % COLOUROFFSET + COLOUROFFSET;
			}
			return total - 1;
		}
	}
	else
	{
		return 0;
	}
	return 0;

}

int collapseField(field *f)
{
	for (int xpos = 0; xpos < f->Width - 1; xpos++)
	{
		FIELD_TYPE content = f->memory[xpos][0];

		if (content != 0)
		{
			for (int ypos = 0; ypos < f->Height - 1; ypos++)
			{
				FIELD_TYPE currval = f->memory[xpos][ypos];
				if (currval >= COLOUROFFSET)
				{
					if (ypos < (f->Height - 1))
					{
						memmove(f->memory[xpos] + ypos, f->memory[xpos] + (ypos + 1), (f->Height - ypos) *sizeof(FIELD_TYPE));
					}
					memset(f->memory[xpos] + (f->Height - 1), 0, sizeof(FIELD_TYPE));
					ypos--;
				}
			}
		}
	}
	return TRUE;
}

void printField(field *f)
{
	int fieldOffset = f->Width / 2;
	for (int xpos = f->Width - 1; xpos >= 0; xpos--)
	{
		if (f->memory[xpos][0] != 0)
		{
			for (int ypos = 0; ypos < f->Height; ypos++)
			{
				FIELD_TYPE colour = f->memory[xpos][ypos];
				if (colour == 0)
				{
					break;
				}
				printf("%hu %d %d\n", colour - (short) 1, xpos - fieldOffset, ypos);
			}
		}
	}
}
