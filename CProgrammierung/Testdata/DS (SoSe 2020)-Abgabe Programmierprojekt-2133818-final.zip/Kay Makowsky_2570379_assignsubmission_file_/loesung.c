#include <stdio.h>
#include <stdlib.h>

#define COLOR_OBJECT 1
#define AVL_TREE 2
#define FIELD_TREE 3

typedef struct colorObject
{
  unsigned char color;
  struct avlNode *node;
} colorObject;

typedef struct avlNode
{
  unsigned long key;
  void *value;
  struct avlTree *tree;
  struct avlNode *parent;
  struct avlNode *left;
  struct avlNode *right;
  struct avlNode *previous;
  struct avlNode *next;
  unsigned long height;
} avlNode;

typedef struct avlTree
{
  avlNode *root;
  avlNode *lastInserted;
  avlNode *node;
  unsigned long size;
} avlTree;

avlNode **sortedTreeNodes(avlTree *tree);
avlTree *newAvlTree();
void insertIntoTree(avlTree *tree, unsigned long key, void *value, char objectType);
void removeFromTree(avlTree *tree, unsigned long key, char objectType);
void freeAvlNode(avlNode *node, char objectType);
void freeAvlTree(avlTree *tree, char objectType);
void freeColorObject(colorObject *object);
void print2D(avlTree *tree);
avlNode *getFromAvlTree(avlTree *tree, unsigned long key);
colorObject *insertIntoField(avlTree *field, long x, char color);
colorObject *newColorObject(unsigned char color);
unsigned long getY(colorObject *obj);
long getX(colorObject *obj);
unsigned char getColor(avlNode *node);
void dropRemoveFromAvlTree(avlTree *newColorDrops, avlTree *tree, unsigned long *ys, unsigned long size);

void freeColorObject(colorObject *object)
{
  free(object);
}

void freeAvlNode(avlNode *node, char objectType)
{
  if (objectType == COLOR_OBJECT)
  {
    freeColorObject(node->value);
  }
  if (objectType == FIELD_TREE)
  {
    freeAvlTree(node->value, COLOR_OBJECT);
  }
  free(node);
}

void freeSubTree(avlTree *tree, avlNode *node, char objectType)
{
  if (node->left != NULL)
  {
    freeSubTree(tree, node->left, objectType);
    node->left = NULL;
  }
  if (node->right != NULL)
  {
    freeSubTree(tree, node->right, objectType);
    node->right = NULL;
  }
  freeAvlNode(node, objectType);
  tree->size -= 1;
}

void freeAvlTree(avlTree *tree, char objectType)
{
  if (tree->root != NULL)
  {
    freeSubTree(tree, tree->root, objectType);
    tree->root = NULL;
  }
  free(tree);
}

unsigned long storeSortedIntoArray(avlNode *node, avlNode **arr, unsigned long i)
{
  unsigned long tmp = 0;
  if (node != NULL)
  {
    tmp = storeSortedIntoArray(node->left, arr, i);
    i = (tmp == 0) ? i : tmp;
    arr[i++] = node;
    tmp = storeSortedIntoArray(node->right, arr, i);
    i = (tmp == 0) ? i : tmp;
    return i;
  }
  return 0;
}

// sorts the nodes of a avl tree by their keys
avlNode **sortedTreeNodes(avlTree *tree)
{
  avlNode **nodes = (avlNode **)malloc(tree->size * sizeof(avlNode *));
  storeSortedIntoArray(tree->root, nodes, 0);
  return nodes;
}

long max(long a, long b)
{
  if (a > b)
  {
    return a;
  }
  return b;
}

unsigned long heightOfNode(avlNode *node)
{
  if (node == NULL)
  {
    return 0;
  }
  return node->height;
}

avlNode *minNode(avlNode *node)
{
  avlNode *tmp = node;
  while (tmp->left != NULL)
  {
    tmp = tmp->left;
  }

  return tmp;
}

colorObject *newColorObject(unsigned char color)
{
  colorObject *object = (colorObject *)malloc(sizeof(colorObject));
  object->color = color;
  return object;
}

// helper function to determine the color of a node faster
unsigned char getColor(avlNode *node)
{
  return ((colorObject *)node->value)->color;
}

// helper function to determine the x coordinate of a node faster
long getX(colorObject *obj)
{
  return (long)obj->node->tree->node->key;
}

// helper function to determine the y coordinate of a node faster
unsigned long getY(colorObject *obj)
{
  return obj->node->key;
}

avlTree *newAvlTree()
{
  avlTree *tree = (avlTree *)malloc(sizeof(avlTree));
  tree->root = NULL;
  tree->lastInserted = NULL;
  tree->node = NULL;
  tree->size = 0;
  return tree;
}

avlNode *newNode(unsigned long key, void *value)
{
  avlNode *node = (avlNode *)malloc(sizeof(avlNode));
  node->key = key;
  node->value = value;
  node->tree = NULL;
  node->parent = NULL;
  node->left = NULL;
  node->right = NULL;
  node->previous = NULL;
  node->next = NULL;
  node->height = 1;
  return node;
}

// performs a avl tree rotation to the right
avlNode *rotateR(avlNode *y)
{
  avlNode *x = y->left;
  avlNode *tmp = x->right;

  x->right = y;
  if (y != NULL)
  {
    y->parent = x;
  }
  y->left = tmp;
  if (tmp != NULL)
  {
    tmp->parent = y;
  }

  y->height = max(heightOfNode(y->left), heightOfNode(y->right)) + 1;
  x->height = max(heightOfNode(x->left), heightOfNode(x->right)) + 1;

  return x;
}

// performs a avl tree rotation to the left
avlNode *rotateL(avlNode *x)
{
  avlNode *y = x->right;
  avlNode *tmp = y->left;

  y->left = x;
  if (x != NULL)
  {
    x->parent = y;
  }
  x->right = tmp;
  if (tmp != NULL)
  {
    tmp->parent = x;
  }

  x->height = max(heightOfNode(x->left), heightOfNode(x->right)) + 1;
  y->height = max(heightOfNode(y->left), heightOfNode(y->right)) + 1;

  return y;
}

// calculates the balance factor
long balanceFactor(avlNode *node)
{
  if (node == NULL)
  {
    return 0;
  }
  return (long)heightOfNode(node->left) - (long)heightOfNode(node->right);
}

// insert a value into the avl tree, and references itself into that value if its desired
avlNode *insert(avlTree *tree, avlNode *node, unsigned long key, void *value, char objectType)
{
  if (node == NULL)
  {
    tree->size++;
    avlNode *new = newNode(key, value);
    new->previous = tree->lastInserted;
    if (tree->lastInserted != NULL)
    {
      tree->lastInserted->next = new;
    }
    tree->lastInserted = new;
    if (objectType == COLOR_OBJECT)
    {
      ((colorObject *)value)->node = new;
    }
    if (objectType == AVL_TREE)
    {
      ((avlTree *)value)->node = new;
    }
    new->tree = tree;
    return new;
  }

  if (key < node->key)
  {
    node->left = insert(tree, node->left, key, value, objectType);
    node->left->parent = node;
  }
  else if (key > node->key)
  {
    node->right = insert(tree, node->right, key, value, objectType);
    node->right->parent = node;
  }
  else
  {
    node->value = value;
    return node;
  }

  node->height = 1 + max(heightOfNode(node->left), heightOfNode(node->right));

  long balance = balanceFactor(node);

  if (balance > 1 && key < node->left->key)
  {
    return rotateR(node);
  }

  if (balance < -1 && key > node->right->key)
  {
    return rotateL(node);
  }

  if (balance > 1 && key > node->left->key)
  {
    node->left = rotateL(node->left);
    node->left->parent = node;
    return rotateR(node);
  }

  if (balance < -1 && key < node->right->key)
  {
    node->right = rotateR(node->right);
    node->right->parent = node;
    return rotateL(node);
  }
  return node;
}

void insertIntoTree(avlTree *tree, unsigned long key, void *value, char objectType)
{
  tree->root = insert(tree, tree->root, key, value, objectType);
  tree->root->parent = NULL;
}

// removes a node from the avl tree and keeps the history valid
avlNode *removeNode(avlTree *tree, avlNode *node, unsigned long key, char initialKey, char objectType)
{
  if (node == NULL)
  {
    return node;
  }

  if (key < node->key)
  {
    node->left = removeNode(tree, node->left, key, initialKey, objectType);
    if (node->left != NULL)
    {
      node->left->parent = node;
    }
  }
  else if (key > node->key)
  {
    node->right = removeNode(tree, node->right, key, initialKey, objectType);
    if (node->right != NULL)
    {
      node->right->parent = node;
    }
  }
  else
  {
    if ((node->left == NULL) || (node->right == NULL))
    {
      avlNode *tmp = (node->left != NULL) ? node->left : node->right;

      if (tmp == NULL)
      {
        tmp = node;
        node = NULL;

        if (initialKey == 1)
        {
          if (tmp->previous != NULL)
          {
            tmp->previous->next = tmp->next;
          }
          if (tmp->next != NULL)
          {
            tmp->next->previous = tmp->previous;
          }
          if (tree->lastInserted == tmp)
          {
            tree->lastInserted = tmp->previous;
          }
        }
      }
      else
      {
        if (initialKey == 1)
        {
          if (node->previous != NULL)
          {
            node->previous->next = node->next;
          }
          if (node->next != NULL)
          {
            node->next->previous = node->previous;
          }
          if (tree->lastInserted == node)
          {
            tree->lastInserted = node->previous;
          }
        }
        tmp->parent = node->parent;
        avlNode *tmp2 = node;
        node = tmp;
        tmp = tmp2;
      }
      if (initialKey == 1)
      {
        if (objectType == COLOR_OBJECT)
        {
          freeColorObject(tmp->value);
          free(tmp);
        }
      }
      tree->size--;
    }
    else
    {
      avlNode *tmp = minNode(node->right);
      if (node->previous != NULL)
      {
        node->previous->next = node->next;
      }
      if (node->next != NULL)
      {
        node->next->previous = node->previous;
      }
      if (tree->lastInserted == node)
      {
        tree->lastInserted = node->previous;
      }
      tmp->parent = node->parent;
      if (node->parent != NULL)
      {
        if (node->parent->left == node)
        {
          node->parent->left = tmp;
        }
        else
        {
          node->parent->right = tmp;
        }
      }
      avlNode *tmp2 = node;
      node = tmp;
      tmp = tmp2;
      node->right = removeNode(tree, tmp->right, node->key, 0, objectType);
      node->left = tmp->left;
      if (tmp->left != NULL)
      {
        tmp->left->parent = node;
      }
      if (node->right != NULL)
      {
        node->right->parent = node;
      }
      if (initialKey == 1)
      {
        if (objectType == COLOR_OBJECT)
        {
          freeColorObject(tmp2->value);
          free(tmp2);
        }
      }
    }
  }

  if (node == NULL)
  {
    return node;
  }

  node->height = 1 + max(heightOfNode(node->left), heightOfNode(node->right));

  long balance = balanceFactor(node);

  if (balance > 1 && balanceFactor(node->left) >= 0)
  {
    return rotateR(node);
  }

  if (balance > 1 && balanceFactor(node->left) < 0)
  {
    node->left = rotateL(node->left);
    if (node->left != NULL)
    {
      node->left->parent = node;
    }
    return rotateR(node);
  }

  if (balance < -1 && balanceFactor(node->right) <= 0)
  {
    return rotateL(node);
  }

  if (balance < -1 && balanceFactor(node->right) > 0)
  {
    node->right = rotateR(node->right);
    if (node->right != NULL)
    {
      node->right->parent = node;
    }
    return rotateL(node);
  }

  return node;
}

void removeFromTree(avlTree *tree, unsigned long key, char objectType)
{
  tree->root = removeNode(tree, tree->root, key, 1, objectType);
  if (tree->root != NULL)
  {
    tree->root->parent = NULL;
  }
}

// searches a value of an avl tree by a key
avlNode *getFromAvlTree(avlTree *tree, unsigned long key)
{
  if (tree->root == NULL)
  {
    return NULL;
  }
  avlNode *tmp = tree->root;
  while (1)
  {
    if (tmp == NULL)
    {
      return NULL;
    }
    if (key > tmp->key)
    {
      if (tmp->right == NULL)
      {
        return NULL;
      }
      else
      {
        tmp = tmp->right;
      }
    }
    else if (key < tmp->key)
    {
      if (tmp->left == NULL)
      {
        return NULL;
      }
      else
      {
        tmp = tmp->left;
      }
    }
    else
    {
      return tmp;
    }
  }
  return NULL;
}

// sorts a array of unsigned longs, which is needed to drop the colors correctly
int compareYs(const void *a, const void *b)
{
  unsigned long long_a = *((unsigned long *)a);
  unsigned long long_b = *((unsigned long *)b);

  if (long_a == long_b)
    return 0;
  else if (long_a < long_b)
    return -1;
  else
    return 1;
}

// removes multiple color nodes from a column tree and adjusts the height of every color above
void dropRemoveFromAvlTree(avlTree *newColorDrops, avlTree *tree, unsigned long *ys, unsigned long size)
{
  if (size == 0)
  {
    return;
  }

  qsort(ys, size, sizeof(unsigned long), compareYs);
  avlNode *tmpNode = getFromAvlTree(tree, ys[0]);
  unsigned long offset = 0;

  unsigned long i = 0;
  while (tmpNode != NULL)
  {
    if (tmpNode->key == ys[i])
    {
      tmpNode = tmpNode->next;
      removeFromTree(tree, ys[i], COLOR_OBJECT);
      offset++;
      if (i < size - 1)
      {
        i++;
      }
      continue;
    }
    else
    {
      insertIntoTree(newColorDrops, (unsigned long)tmpNode->value, tmpNode->value, 0);
      tmpNode->key -= offset;
      tmpNode = tmpNode->next;
    }
  }
}

void exitWithError(char *errorMessage);
void readInput();
void calculateField(avlTree *dropColorSet);
void insertColorToField(avlTree *field, long x, char color);

// prints the colorNodes of a column
void printColumn(avlNode *fieldNode)
{
  avlTree *columnTree = fieldNode->value;
  avlNode *tmp = columnTree->lastInserted;

  while (tmp != NULL)
  {
    printf("%d %ld %lu\n", getColor(tmp), getX(tmp->value), getY(tmp->value) - 1);
    tmp = tmp->previous;
  }
}

// outputs the field
void printFieldNode(avlNode *fieldNode)
{
  if (fieldNode == NULL)
  {
    return;
  }
  printFieldNode(fieldNode->left);
  printFieldNode(fieldNode->right);
  printColumn(fieldNode);
}

void printField(avlTree *field)
{
  printFieldNode(field->root);
}

int main()
{
  readInput();
}

// gets called when an error occurs (e.g. invalid format of the input)
void exitWithError(char *errorMessage)
{
  fprintf(stderr, "%s", errorMessage);
  exit(1);
}

// frees the memory of the field
void freeField(avlTree *field)
{
  freeAvlTree(field, FIELD_TREE);
}

// parses the input
void readInput()
{
  avlTree *field = newAvlTree();
  char c;
  char buffer[100];
  unsigned long bufferSize = 0;
  unsigned long lineCount = 0;
  char lastCharWasSpace = 0;
  char paramCount = 0;

  long preColor = 0;
  unsigned char color = 0;
  long x = 0;

  while (1)
  {
    c = getc(stdin);
    if (c == 0)
    {
      freeField(field);
      exitWithError("Invalid Format (zero byte is not allowed)\n");
    }
    if (bufferSize < 100)
    {
      if (c == ' ' && lastCharWasSpace == 1)
      {
        continue;
      }
      else
      {
        lastCharWasSpace = 0;
      }
      if (c == ' ' || c == '\n' || c == EOF)
      {
        buffer[bufferSize] = 0;
        if (bufferSize > 11)
        {
          freeField(field);
          exitWithError("Invalid Format (values are to high)\n");
        }
        if (paramCount == 0)
        {
          preColor = atol(buffer);
          if (preColor > 254 || preColor < 0)
          {
            freeField(field);
            exitWithError("Invalid Format (color value not allowed)\n");
          }
          color = (unsigned char)preColor;
        }
        if (paramCount == 1)
        {
          x = atol(buffer);
          if (x > 1048576 || x < -1048576)
          {
            freeField(field);
            exitWithError("Invalid Format (x coordinate exceeds 2^20 limit)\n");
          }
        }
        if (paramCount == 2)
        {
          freeField(field);
          exitWithError("Invalid Format (too many params in one line)\n");
        }
        if (bufferSize == 0)
        {
          if (c == EOF)
          {
            break;
          }
          freeField(field);
          exitWithError("Invalid Format (empty line detected)\n");
        }
        bufferSize = 0;
        paramCount++;
        lastCharWasSpace = 1;
        if (c == '\n' || c == EOF)
        {
          if (paramCount != 2)
          {
            exitWithError("Invalid Format (wrong number of params in one line)\n");
          }
          lineCount++;
          // line successfully parsed
          paramCount = 0;
          lastCharWasSpace = 0;

          insertColorToField(field, x, color);
        }
        if (c == EOF)
        {
          break;
        }
      }
      else
      {
        if (c != '-' && (c < '0' || c > '9'))
        {
          freeField(field);
          exitWithError("Invalid Format (invalid characters found)\n");
        }
        buffer[bufferSize++] = c;
      }
    }
    else
    {
      freeField(field);
      exitWithError("Invalid Format (value to high)\n");
    }
  }
  printField(field);
  freeField(field);
}

// returns a avlNode which contains a colorObject by the x and y coordinates
avlNode *getColorNodeFromField(avlTree *field, long x, unsigned long y)
{
  avlNode *columnNode = getFromAvlTree(field, x);
  if (columnNode == NULL)
  {
    return NULL;
  }
  avlTree *columnTree = columnNode->value;
  if (columnTree->size < y)
  {
    return NULL;
  }
  return getFromAvlTree(columnTree, y);
}

// sorts a array of avlNodes which contain colorNodes
int sortAvlNodesByCoordinates(const void *a, const void *b)
{
  const avlNode **A = (const avlNode **)a;
  const avlNode **B = (const avlNode **)b;

  colorObject *colorA = (colorObject *)(*A)->value;
  colorObject *colorB = (colorObject *)(*B)->value;

  if (colorA->node->tree->node->key > colorB->node->tree->node->key) // compare x coordinates
  {
    return 1;
  }
  else if (colorA->node->tree->node->key == colorB->node->tree->node->key) // x coordinates are equal
  {
    if (colorA->node->key < colorB->node->key) // compare y coordinates
    {
      return 1;
    }
  }
  return -1;
}

// inserts a color from the input to the field
void insertColorToField(avlTree *field, long x, char color)
{
  avlTree *dropColorSet = newAvlTree();
  avlNode *columnNode = getFromAvlTree(field, x);
  avlTree *columnTree = NULL;
  if (columnNode == NULL)
  {
    insertIntoTree(field, x, newAvlTree(), AVL_TREE);
    columnNode = getFromAvlTree(field, x);
  }
  columnTree = (avlTree *)columnNode->value;
  colorObject *object = newColorObject(color);
  insertIntoTree(columnTree, columnTree->size + 1, object, COLOR_OBJECT);
  insertIntoTree(dropColorSet, (unsigned long)object, object, 0);

  calculateField(dropColorSet);
  freeAvlTree(dropColorSet, 0);
}

void checkColumn(avlTree *nodesToRemove, avlNode *colorNode);
void checkHorizontal(avlTree *nodesToRemove, avlNode *colorNode);
void checkDiagonal(avlTree *nodesToRemove, avlNode *colorNode);

// calculates changes of the field
void calculateField(avlTree *dropColorSet)
{
  avlTree *newColorDrops = newAvlTree();
  avlTree *nodesToRemove = newAvlTree();
  avlNode **sorted = sortedTreeNodes(dropColorSet);

  for (unsigned long i = 0; i < dropColorSet->size; i++)
  {
    colorObject *object = sorted[i]->value;

    // vertically
    checkColumn(nodesToRemove, object->node);

    // horizontally
    checkHorizontal(nodesToRemove, object->node);

    // diagonal
    checkDiagonal(nodesToRemove, object->node);
  }
  // if there are colorNodes that have to dissolve it drops them from the field
  if (nodesToRemove->size > 0)
  {
    avlNode **sortedColorNodes = sortedTreeNodes(nodesToRemove);

    qsort(sortedColorNodes, nodesToRemove->size, sizeof(avlNode *), sortAvlNodesByCoordinates);

    // sort the colorNodes by column and drops after another
    avlTree *columnTree = ((colorObject *)(sortedColorNodes[0]->value))->node->tree;
    long lastX = getX(sortedColorNodes[0]->value);
    unsigned long height = getY(sortedColorNodes[0]->value);
    unsigned long *ysToDrop = (unsigned long *)malloc(sizeof(unsigned long) * height);
    unsigned long index = 0;
    ysToDrop[index++] = height;

    for (unsigned long j = 1; j < nodesToRemove->size; j++)
    {
      if (getX(sortedColorNodes[j]->value) == lastX)
      {
        ysToDrop[index++] = getY(sortedColorNodes[j]->value);
      }
      else
      {
        dropRemoveFromAvlTree(newColorDrops, columnTree, ysToDrop, index);
        if (columnTree->size == 0)
        {
          removeFromTree(columnTree->node->tree, columnTree->node->key, COLOR_OBJECT);
        }
        free(ysToDrop);

        columnTree = ((colorObject *)(sortedColorNodes[j]->value))->node->tree;
        lastX = getX(sortedColorNodes[j]->value);
        height = getY(sortedColorNodes[j]->value);
        ysToDrop = (unsigned long *)malloc(sizeof(unsigned long) * height);
        index = 0;
        ysToDrop[index++] = height;
      }
    }
    dropRemoveFromAvlTree(newColorDrops, columnTree, ysToDrop, index);
    if (columnTree->size == 0)
    {
      removeFromTree(columnTree->node->tree, columnTree->node->key, COLOR_OBJECT);
    }
    free(ysToDrop);
    free(sortedColorNodes);
    calculateField(newColorDrops);
  }
  freeAvlTree(newColorDrops, 0);
  freeAvlTree(nodesToRemove, 0);
  free(sorted);
}

// check if the four elements below the colorNode have the same color
// if so, they will be added to the nodesToRemove
void checkColumn(avlTree *nodesToRemove, avlNode *colorNode)
{
  if (colorNode->tree->size < 4)
  {
    return;
  }
  colorObject *object = (colorObject *)colorNode->value;

  avlNode *minY = colorNode;
  avlNode *maxY = colorNode;

  char keepGoingUp = 1;
  char keepGoingDown = 1;

  int range = 1;

  for (int i = 0; i < 3; i++)
  {
    if (keepGoingDown == 0 && keepGoingUp == 0)
    {
      break;
    }
    if (keepGoingUp == 1)
    {
      if (maxY->next != NULL && getColor(maxY->next) == object->color)
      {
        maxY = maxY->next;
        range++;
      }
      else
      {
        keepGoingUp = 0;
      }
    }
    if (keepGoingDown == 1)
    {
      if (minY->previous != NULL && getColor(minY->previous) == object->color)
      {
        minY = minY->previous;
        range++;
      }
      else
      {
        keepGoingDown = 0;
      }
    }
  }
  if (range >= 4)
  {
    for (int i = 0; i < range; i++)
    {
      insertIntoTree(nodesToRemove, (long)minY->value, minY->value, 0);
      minY = minY->next;
    }
  }
}

// checks for horizontal lines in the field
void checkHorizontal(avlTree *nodesToRemove, avlNode *colorNode)
{
  avlTree *field = colorNode->tree->node->tree;
  if (field->size < 4)
  {
    return;
  }
  colorObject *object = (colorObject *)colorNode->value;

  avlNode **colorNodes = (avlNode **)malloc(sizeof(avlNode *) * 7);
  int index = 0;
  colorNodes[index++] = colorNode;

  long x = colorNode->tree->node->key;

  char keepGoingLeft = 1;
  char keepGoingRight = 1;

  for (int i = 1; i < 4; i++)
  {
    if (keepGoingLeft == 0 && keepGoingRight == 0)
    {
      break;
    }
    if (keepGoingLeft == 1)
    {
      avlNode *leftNode = getColorNodeFromField(field, x - i, colorNode->key);
      if (leftNode != NULL && getColor(leftNode) == object->color)
      {
        colorNodes[index++] = leftNode;
      }
      else
      {
        keepGoingLeft = 0;
      }
    }
    if (keepGoingRight == 1)
    {
      avlNode *rightNode = getColorNodeFromField(field, x + i, colorNode->key);
      if (rightNode != NULL && getColor(rightNode) == object->color)
      {
        colorNodes[index++] = rightNode;
      }
      else
      {
        keepGoingRight = 0;
      }
    }
  }
  if (index >= 4)
  {
    for (int i = 0; i < index; i++)
    {
      insertIntoTree(nodesToRemove, (long)colorNodes[i]->value, colorNodes[i]->value, 0);
    }
  }
  free(colorNodes);
}

// checks for diagonal lines in the field
void checkDiagonal(avlTree *nodesToRemove, avlNode *colorNode)
{
  avlTree *field = colorNode->tree->node->tree;
  if (field->size < 4)
  {
    return;
  }
  colorObject *object = (colorObject *)colorNode->value;

  // detects ascending and descending lines
  avlNode **colorNodesAsc = (avlNode **)malloc(sizeof(avlNode *) * 7);
  avlNode **colorNodesDesc = (avlNode **)malloc(sizeof(avlNode *) * 7);
  int indexAsc = 0;
  int indexDesc = 0;
  colorNodesAsc[indexAsc++] = colorNode;
  colorNodesDesc[indexDesc++] = colorNode;

  long x = colorNode->tree->node->key;

  char keepGoingLeftAsc = 1;
  char keepGoingRightAsc = 1;

  char keepGoingLeftDesc = 1;
  char keepGoingRightDesc = 1;

  for (int i = 1; i < 4; i++)
  {
    // ascending
    if (keepGoingLeftAsc == 0 && keepGoingRightAsc == 0 && keepGoingLeftDesc == 0 && keepGoingRightDesc == 0)
    {
      break;
    }
    if (keepGoingLeftAsc == 1)
    {
      avlNode *leftNode = getColorNodeFromField(field, x - i, colorNode->key - i);
      if (leftNode != NULL && getColor(leftNode) == object->color)
      {
        colorNodesAsc[indexAsc++] = leftNode;
      }
      else
      {
        keepGoingLeftAsc = 0;
      }
    }
    if (keepGoingRightAsc == 1)
    {
      avlNode *rightNode = getColorNodeFromField(field, x + i, colorNode->key + i);
      if (rightNode != NULL && getColor(rightNode) == object->color)
      {
        colorNodesAsc[indexAsc++] = rightNode;
      }
      else
      {
        keepGoingRightAsc = 0;
      }
    }

    // descending
    if (keepGoingLeftDesc == 0 && keepGoingRightDesc == 0)
    {
      continue;
    }
    if (keepGoingLeftDesc == 1)
    {
      avlNode *leftNode = getColorNodeFromField(field, x - i, colorNode->key + i);

      if (leftNode != NULL && getColor(leftNode) == object->color)
      {
        colorNodesDesc[indexDesc++] = leftNode;
      }
      else
      {
        keepGoingLeftDesc = 0;
      }
    }
    if (keepGoingRightDesc == 1)
    {
      avlNode *rightNode = getColorNodeFromField(field, x + i, colorNode->key - i);

      if (rightNode != NULL && getColor(rightNode) == object->color)
      {
        colorNodesDesc[indexDesc++] = rightNode;
      }
      else
      {
        keepGoingRightDesc = 0;
      }
    }
  }
  if (indexAsc >= 4)
  {
    for (int i = 0; i < indexAsc; i++)
    {
      insertIntoTree(nodesToRemove, (long)colorNodesAsc[i]->value, colorNodesAsc[i]->value, 0);
    }
  }
  if (indexDesc >= 4)
  {
    for (int i = 0; i < indexDesc; i++)
    {
      insertIntoTree(nodesToRemove, (long)colorNodesDesc[i]->value, colorNodesDesc[i]->value, 0);
    }
  }
  free(colorNodesAsc);
  free(colorNodesDesc);
}
