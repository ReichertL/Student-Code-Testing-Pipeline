#include<stdio.h>
#include<stdlib.h>

/*
Von Johannes Franz Felix Rehwinkel - Matrikelnummer 554045

Notizen

- Die gespeicherten Werte entsprechen der Farbe + 1, Farben reichen also von [1,255].
- Wert 0 bedeutet, dass kein Stein an dieser Stelle ist.
- Die Spalte 0 ist immer in der Mitte, egal wie gross das Spielfeld ist.
- Die Spaltenanzahl ist immer ungerade.
- Farbe x + 1000 = Farbe x, nur zum loeschen markiert.
*/

// GLOBALE VARIABLEN
// Spielfeld - Variablen
#define Startwert_Reihen 4							// Startwerte fuer das erste moeglichst kleine Spielfeld
#define Startwert_Spalten 7							// <-- MUSS IMMER UNGERADE SEIN! Spaltenanzahl ist immer = (offset * 2) + 1
int* Spielfeld;										// Pointer auf das Spielfeld, noch nicht initiert
int Spanne_Spalten = -1;							// Der groesste vorkommende Betrag vom X-Wert
int Kapazitaet_Spalten = Startwert_Spalten;			// Der potentiell groesste X-Wert im aktuellen Spielfeld
int Spanne_Reihen = -1;								// Der groesste vorkommende Y-Wert
int Kapazitaet_Reihen = Startwert_Reihen;			// Der potentiell groesste Y-Wert im aktuellen Spielfeld
int Korrektur = (Startwert_Spalten - 1) / 2;		// Wert zur Uebersetzung von negativen X-Werten

// Wechselfelder, falls die Groesse angepasst werden muss
int* Feld_A;
int* Feld_B;
int aktuellesFeld = 'A';

// Ketten und Crush - Variablen
int gefallen = 0;			// Checkt ob Steine gefallen sind, was potentiell die Kettenreaktion weiter fuehrt
int crushed = 0;			// Checkt ob es einen Crush gab
int farbe;					// Farbe des Ausgangssteins
int gefallen_links;			// Spalte am weitestens "links", wo ein Stein gefallen ist
int gefallen_rechts;		// Spalte am weitestens "rechts", wo ein Stein gefallen ist
int gefallen_hoch;			// Reihe am "hoechsten", wo ein Stein gefallen ist
int loesch_links;			// Spalte am weitestens "links", wo ein Stein geloescht wurde
int loesch_rechts;			// Spalte am weitestens "rechts", wo ein Stein geloescht wurde
int loesch_hoch;			// Reihe am "hoechsten", wo ein Stein geloescht wurde

// Generelle Laufvariablen
int reihe;					// Reihenindex
int spalte;					// Spaltenindex
int lauf;					// Laufvariable
int schiefgegangen;			// Fehlervariable
int loesch;					// loesch-Laufvariable
int loesch_in;				// loesch-Laufvariable inverse Richtung

// Exponenten
int wachstum = 1;			// Wachstumsexponent fuer die hoeher Funktion
int wachstum2 = 1;			// Wachstumsexponent fuer die breiter Funktion

// AUSGABE Funktion - Gibt den aktuellen Stand des uebergebenen Spielfeldes aus
void ausgabe() {
	for (reihe = Kapazitaet_Reihen - 1 - Spanne_Reihen; reihe < Kapazitaet_Reihen; reihe++) {
		for (spalte = 0; spalte < Kapazitaet_Spalten; spalte++) {
			if (*(Spielfeld + reihe * Kapazitaet_Spalten + spalte) != 0) {
				fprintf(stdout, "%d", *(Spielfeld + reihe * Kapazitaet_Spalten + spalte) - 1);	// Feld 0,0 ist oben links die Ecke		
				fprintf(stdout, " %d", (spalte - Korrektur));									// Ausgabe muss um offset korrigiert werden
				fprintf(stdout, " %d\n", (Kapazitaet_Reihen - reihe - 1));						// Ausgabe ist zum eigentlichen Spielfeld verdreht
			}
		}
	}
}

// KETTENREAKTION Funktion - Sucht nach einem Crush nach Steinen die runter fallen und dann nach potentiellen neuen Crushes aller moeglichen Farben
void kette(int grenze_links, int grenze_rechts) {
	// Resets zum Start
	gefallen = 0;
	crushed = 0;
	lauf = 0;
	gefallen_links = grenze_rechts;
	gefallen_rechts = grenze_links;
	gefallen_hoch = Kapazitaet_Reihen - 1;
	
	// Feld durchlaufen und nach Steinen suchen, die fallen
	for (reihe = Kapazitaet_Reihen - 1; reihe > 0; reihe--) {		// von unten anfangen und hocharbeiten
		for (spalte = grenze_links; spalte <= grenze_rechts; spalte++) {
			if (*(Spielfeld + reihe * Kapazitaet_Spalten + spalte) == 0 && *(Spielfeld + (reihe - 1) * Kapazitaet_Spalten + spalte) != 0) {

				while (*(Spielfeld + (reihe + lauf) * Kapazitaet_Spalten + spalte) == 0 && reihe + lauf != Kapazitaet_Reihen - 1) {
					lauf++;
				}
				if ((reihe + lauf == Kapazitaet_Reihen - 1) && *(Spielfeld + (reihe + lauf) * Kapazitaet_Spalten + spalte) == 0) {	// faellt auf Boden
					*(Spielfeld + (reihe + lauf) * Kapazitaet_Spalten + spalte) = *(Spielfeld + (reihe - 1) * Kapazitaet_Spalten + spalte);
				}
				else {																												// faellt auf Stein
					*(Spielfeld + (reihe + lauf - 1) * Kapazitaet_Spalten + spalte) = *(Spielfeld + (reihe - 1) * Kapazitaet_Spalten + spalte);
				}
				*(Spielfeld + (reihe - 1) * Kapazitaet_Spalten + spalte) = 0;

				if (spalte < gefallen_links) {
					gefallen_links = spalte;
				}
				if (spalte > gefallen_rechts) {
					gefallen_rechts = spalte;
				}
				if ((reihe - 1) < gefallen_hoch) {
					gefallen_hoch = reihe - 1;
				}

				lauf = 0;
				gefallen = 1;
			}
		}
	}

	if (gefallen > 0) {
		loesch_links = Kapazitaet_Spalten - 1;
		loesch_rechts = 0;
		loesch_hoch = Kapazitaet_Reihen - 1;
		// Crushes suchen
		for (reihe = gefallen_hoch; reihe < Kapazitaet_Reihen; reihe++) {
			for (spalte = gefallen_links - 3; spalte <= gefallen_rechts + 3; spalte++) {
				// horizontal
				if (*(Spielfeld + reihe * Kapazitaet_Spalten + spalte) != 0) {
					farbe = *(Spielfeld + reihe * Kapazitaet_Spalten + spalte) % 1000;

					if (*(Spielfeld + reihe * Kapazitaet_Spalten + (spalte + 1)) % 1000 == farbe) {
						if (*(Spielfeld + reihe * Kapazitaet_Spalten + (spalte + 2)) % 1000 == farbe) {
							if (*(Spielfeld + reihe * Kapazitaet_Spalten + (spalte + 3)) % 1000 == farbe) {
								*(Spielfeld + reihe * Kapazitaet_Spalten + spalte) = farbe + 1000;
								*(Spielfeld + reihe * Kapazitaet_Spalten + spalte + 1) = farbe + 1000;
								*(Spielfeld + reihe * Kapazitaet_Spalten + spalte + 2) = farbe + 1000;
								*(Spielfeld + reihe * Kapazitaet_Spalten + spalte + 3) = farbe + 1000;
								crushed = 1;
								if (spalte + 3 > loesch_rechts) {
									loesch_rechts = spalte + 3;
								}
								if (spalte < loesch_links) {
									loesch_links = spalte;
								}
								if (reihe < loesch_hoch) {
									loesch_hoch = reihe;
								}
							}
						}
					}
				}

				// vertikal
				if (*(Spielfeld + reihe * Kapazitaet_Spalten + spalte) != 0 && reihe + 3 < Kapazitaet_Reihen) {
					farbe = *(Spielfeld + reihe * Kapazitaet_Spalten + spalte) % 1000;

					if (*(Spielfeld + (reihe + 1) * Kapazitaet_Spalten + spalte) % 1000 == farbe) {
						if (*(Spielfeld + (reihe + 2) * Kapazitaet_Spalten + spalte) % 1000 == farbe) {
							if (*(Spielfeld + (reihe + 3) * Kapazitaet_Spalten + spalte) % 1000 == farbe) {
								*(Spielfeld + reihe * Kapazitaet_Spalten + spalte) = farbe + 1000;
								*(Spielfeld + (reihe + 1) * Kapazitaet_Spalten + spalte) = farbe + 1000;
								*(Spielfeld + (reihe + 2) * Kapazitaet_Spalten + spalte) = farbe + 1000;
								*(Spielfeld + (reihe + 3) * Kapazitaet_Spalten + spalte) = farbe + 1000;
								crushed = 1;
								if (spalte > loesch_rechts) {
									loesch_rechts = spalte;
								}
								if (spalte < loesch_links) {
									loesch_links = spalte;
								}
								if (reihe < loesch_hoch) {
									loesch_hoch = reihe;
								}
							}
						}
					}
				}

				// diagonal wachsend
				if (*(Spielfeld + reihe * Kapazitaet_Spalten + spalte) != 0) {
					farbe = *(Spielfeld + reihe * Kapazitaet_Spalten + spalte) % 1000;

					if (*(Spielfeld + (reihe - 1) * Kapazitaet_Spalten + (spalte + 1)) % 1000 == farbe) {
						if (*(Spielfeld + (reihe - 2) * Kapazitaet_Spalten + (spalte + 2)) % 1000 == farbe) {
							if (*(Spielfeld + (reihe - 3) * Kapazitaet_Spalten + (spalte + 3)) % 1000 == farbe) {
								*(Spielfeld + reihe * Kapazitaet_Spalten + spalte) = farbe + 1000;
								*(Spielfeld + (reihe - 1) * Kapazitaet_Spalten + spalte + 1) = farbe + 1000;
								*(Spielfeld + (reihe - 2) * Kapazitaet_Spalten + spalte + 2) = farbe + 1000;
								*(Spielfeld + (reihe - 3) * Kapazitaet_Spalten + spalte + 3) = farbe + 1000;
								crushed = 1;
								if (spalte + 3 > loesch_rechts) {
									loesch_rechts = spalte + 3;
								}
								if (spalte < loesch_links) {
									loesch_links = spalte;
								}
								if (reihe - 3 < loesch_hoch) {
									loesch_hoch = reihe - 3;
								}
							}
						}
					}
				}

				// diagonal fallend
				if (*(Spielfeld + reihe * Kapazitaet_Spalten + spalte) != 0) {
					farbe = *(Spielfeld + reihe * Kapazitaet_Spalten + spalte) % 1000;

					if (*(Spielfeld + (reihe - 1) * Kapazitaet_Spalten + (spalte - 1)) % 1000 == farbe) {
						if (*(Spielfeld + (reihe - 2) * Kapazitaet_Spalten + (spalte - 2)) % 1000 == farbe) {
							if (*(Spielfeld + (reihe - 3) * Kapazitaet_Spalten + (spalte - 3)) % 1000 == farbe) {
								*(Spielfeld + reihe * Kapazitaet_Spalten + spalte) = farbe + 1000;
								*(Spielfeld + (reihe - 1) * Kapazitaet_Spalten + spalte - 1) = farbe + 1000;
								*(Spielfeld + (reihe - 2) * Kapazitaet_Spalten + spalte - 2) = farbe + 1000;
								*(Spielfeld + (reihe - 3) * Kapazitaet_Spalten + spalte - 3) = farbe + 1000;
								crushed = 1;
								if (spalte > loesch_rechts) {
									loesch_rechts = spalte;
								}
								if (spalte - 3 < loesch_links) {
									loesch_links = spalte - 3;
								}
								if (reihe - 3 < loesch_hoch) {
									loesch_hoch = reihe - 3;
								}
							}
						}
					}
				}
			}
		}
	}

	// Checkt ob es einen Crush gab, was potentiell die Kettenreaktion weiter fuehrt
	if (crushed > 0) {
		// Markierte Steine loeschen
		for (reihe = loesch_hoch; reihe < Kapazitaet_Reihen; reihe++) {
			for (spalte = loesch_links; spalte <= loesch_rechts; spalte++) {
				if (*(Spielfeld + reihe * Kapazitaet_Spalten + spalte) > 999) { // Alles ab einer Farbe von 1000 ist markiert
					*(Spielfeld + reihe * Kapazitaet_Spalten + spalte) = 0;
				}
			}
		}
		kette(loesch_links, loesch_rechts);
	}
}

// CRUSH Funktion - Sucht nach einem potentiellen Crush der zuletzt eingeworfenen Farbe
void crush(int farbe, int reihe, int spalte) {
	int zaehler = 0;			// zaehlt mit wie viele in einer Reihe
	int zaehler_in = 0;			// zaehlt mit wie viele in einer Reihe in inverse Richtung
	crushed = 0;				// 0 = kein Crush, 1 = Crush!

	// horizontal suchen
	if (*(Spielfeld + reihe * Kapazitaet_Spalten + (spalte + 1)) == farbe) {
		zaehler++;
		if (*(Spielfeld + reihe * Kapazitaet_Spalten + (spalte + 2)) == farbe) {
			zaehler++;
			if (*(Spielfeld + reihe * Kapazitaet_Spalten + (spalte + 3)) == farbe) {
				zaehler++;
			}
		}
	}
	if (*(Spielfeld + reihe * Kapazitaet_Spalten + (spalte - 1)) == farbe) {
		zaehler_in++;
		if (*(Spielfeld + reihe * Kapazitaet_Spalten + (spalte - 2)) == farbe) {
			zaehler_in++;
			if (*(Spielfeld + reihe * Kapazitaet_Spalten + (spalte - 3)) == farbe) {
				zaehler_in++;
			}
		}
	}
	// horizontal loeschen
	if (zaehler + zaehler_in > 2) {
		crushed = 1;		// Es gab einen Crush
		for (loesch = 1; loesch < zaehler + 1; loesch++) {
			*(Spielfeld + reihe * Kapazitaet_Spalten + (spalte + loesch)) = 0;
		}
		for (loesch_in = 1; loesch_in < zaehler_in + 1; loesch_in++) {
			*(Spielfeld + reihe * Kapazitaet_Spalten + (spalte - loesch_in)) = 0;
		}
	}
	// Reset
	zaehler = 0;
	zaehler_in = 0;

	// vertikal suchen
	if (reihe + 3 < Kapazitaet_Reihen) {
		if (*(Spielfeld + (reihe + 1) * Kapazitaet_Spalten + spalte) == farbe) {
			if (*(Spielfeld + (reihe + 2) * Kapazitaet_Spalten + spalte) == farbe) {
				if (*(Spielfeld + (reihe + 3) * Kapazitaet_Spalten + spalte) == farbe) {
					// vertikal loeschen
					crushed = 1;		// Es gab einen Crush
					*(Spielfeld + (reihe + 1) * Kapazitaet_Spalten + spalte) = 0;
					*(Spielfeld + (reihe + 2) * Kapazitaet_Spalten + spalte) = 0;
					*(Spielfeld + (reihe + 3) * Kapazitaet_Spalten + spalte) = 0;
				}
			}
		}
	}

	// diagonal wachsend suchen
	if (*(Spielfeld + (reihe - 1) * Kapazitaet_Spalten + (spalte + 1)) == farbe) {
		zaehler++;
		if (*(Spielfeld + (reihe - 2) * Kapazitaet_Spalten + (spalte + 2)) == farbe) {
			zaehler++;
			if (*(Spielfeld + (reihe - 3) * Kapazitaet_Spalten + (spalte + 3)) == farbe) {
				zaehler++;
			}
		}
	}
	if (reihe + 1 < Kapazitaet_Reihen) {
		if (*(Spielfeld + (reihe + 1) * Kapazitaet_Spalten + (spalte - 1)) == farbe) {
			zaehler_in++;
			if (reihe + 2 < Kapazitaet_Reihen) {
				if (*(Spielfeld + (reihe + 2) * Kapazitaet_Spalten + (spalte - 2)) == farbe) {
					zaehler_in++;
					if (reihe + 3 < Kapazitaet_Reihen) {
						if (*(Spielfeld + (reihe + 3) * Kapazitaet_Spalten + (spalte - 3)) == farbe) {
							zaehler_in++;
						}
					}
				}
			}
		}
	}
	// diagonal wachsend loeschen
	if (zaehler + zaehler_in > 2) {
		crushed = 1;		// Es gab einen Crush
		for (loesch = 1; loesch < zaehler + 1; loesch++) {
			*(Spielfeld + (reihe - loesch) * Kapazitaet_Spalten + (spalte + loesch)) = 0;
		}
		for (loesch_in = 1; loesch_in < zaehler_in + 1; loesch_in++) {
			*(Spielfeld + (reihe + loesch_in) * Kapazitaet_Spalten + (spalte - loesch_in)) = 0;
		}
	}
	// Reset
	zaehler = 0;
	zaehler_in = 0;

	// diagonal fallend suchen
	if (reihe + 1 < Kapazitaet_Reihen) {
		if (*(Spielfeld + (reihe + 1) * Kapazitaet_Spalten + (spalte + 1)) == farbe) {
			zaehler++;
			if (reihe + 2 < Kapazitaet_Reihen) {
				if (*(Spielfeld + (reihe + 2) * Kapazitaet_Spalten + (spalte + 2)) == farbe) {
					zaehler++;
					if (reihe + 3 < Kapazitaet_Reihen) {
						if (*(Spielfeld + (reihe + 3) * Kapazitaet_Spalten + (spalte + 3)) == farbe) {
							zaehler++;
						}
					}
				}
			}
		}
	}
	if (*(Spielfeld + (reihe - 1) * Kapazitaet_Spalten + (spalte - 1)) == farbe) {
		zaehler_in++;
		if (*(Spielfeld + (reihe - 2) * Kapazitaet_Spalten + (spalte - 2)) == farbe) {
			zaehler_in++;
			if (*(Spielfeld + (reihe - 3) * Kapazitaet_Spalten + (spalte - 3)) == farbe) {
				zaehler_in++;
			}
		}
	}
	// diagonal fallend loeschen
	if (zaehler + zaehler_in > 2) {
		crushed = 1;		// Es gab einen Crush
		for (loesch = 1; loesch < zaehler + 1; loesch++) {
			*(Spielfeld + (reihe + loesch) * Kapazitaet_Spalten + (spalte + loesch)) = 0;
		}
		for (loesch_in = 1; loesch_in < zaehler_in + 1; loesch_in++) {
			*(Spielfeld + (reihe - loesch_in) * Kapazitaet_Spalten + (spalte - loesch_in)) = 0;
		}
	}
	
	// Wenn es einen Crush gab auf Kettenreaktionen ueberpruefen
	if (crushed == 1) {
		*(Spielfeld + reihe * Kapazitaet_Spalten + spalte) = 0;			// Ausgangsstein loeschen
		kette(spalte - 3, spalte + 3); // Kettenfunktion
	}
}

// HOEHER Funktion - Erweitert das Spielfeld um eine neue Reihe
int hoeher() {
	schiefgegangen = 0;	// Beobachtet ob Fehler auftreten

	switch (aktuellesFeld)
	{
	case 'A':
		
		Feld_B = (int*)calloc(Kapazitaet_Spalten * (Kapazitaet_Reihen + wachstum), sizeof(int));	// Speicher reservieren fuer das Spielfeld

		if (Feld_B != NULL) {
			// Alles um X Reihen nach "unten" verschieben
			for (reihe = 0; reihe < Kapazitaet_Reihen; reihe++) {
				for (spalte = 0; spalte < Kapazitaet_Spalten; spalte++) {
					*(Feld_B + (reihe + wachstum) * Kapazitaet_Spalten + spalte) = *(Spielfeld + reihe * Kapazitaet_Spalten + spalte);
				}
			}
			free(Feld_A);
			Spielfeld = Feld_B;
			aktuellesFeld = 'B';
		}
		else {
			fprintf(stderr, "Fehler beim Zuweisen vom Speicher (realloc)\n");
			schiefgegangen++;
		}

		break;
	case 'B':
		
		Feld_A = (int*)calloc(Kapazitaet_Spalten * (Kapazitaet_Reihen + wachstum), sizeof(int));	// Speicher reservieren fuer das Spielfeld

		if (Feld_A != NULL) {
			// Alles um X Reihen nach "unten" verschieben
			for (reihe = 0; reihe < Kapazitaet_Reihen; reihe++) {
				for (spalte = 0; spalte < Kapazitaet_Spalten; spalte++) {
					*(Feld_A + (reihe + wachstum) * Kapazitaet_Spalten + spalte) = *(Spielfeld + reihe * Kapazitaet_Spalten + spalte);
				}
			}
			free(Feld_B);
			Spielfeld = Feld_A;
			aktuellesFeld = 'A';
		}
		else {
			fprintf(stderr, "Fehler beim Zuweisen vom Speicher (realloc)\n");
			schiefgegangen++;
		}

		break;
	}

	Kapazitaet_Reihen = Kapazitaet_Reihen + wachstum;	// Neue Kapazitaet
	wachstum = wachstum * 2;

	return schiefgegangen;
}

// BREITER Funktion - Erweitert das Spielfeld um eine bestimmte Anzahl neuer Spalten
int breiter(int Neu) {
	schiefgegangen = 0;								// Beobachtet ob Fehler auftreten
	int verschiebung = Neu - Korrektur + wachstum2;	// Differenz zwischen neuem und altem Korrekturwert

	switch (aktuellesFeld)
	{
	case 'A':

		Feld_B = (int*)calloc((((Neu + wachstum2) * 2) + 1) * Kapazitaet_Reihen, sizeof(int));	// Speicher reservieren fuer das Spielfeld

		if (Feld_B != NULL) {
			// Alles zur neuen Mitte ausrichten
			for (reihe = 0; reihe < Kapazitaet_Reihen; reihe++) {
				for (spalte = 0; spalte < Kapazitaet_Spalten; spalte++) {
					*(Feld_B + reihe * Kapazitaet_Spalten + spalte + (1 + 2 * reihe) * verschiebung) = *(Spielfeld + reihe * Kapazitaet_Spalten + spalte);
				}
			}
			free(Feld_A);
			Spielfeld = Feld_B;
			aktuellesFeld = 'B';
		}
		else {
			fprintf(stderr, "Fehler beim Zuweisen vom Speicher (realloc)\n");
			schiefgegangen++;
		}

		break;
	case 'B':

		Feld_A = (int*)calloc((((Neu + wachstum2) * 2) + 1) * Kapazitaet_Reihen, sizeof(int));	// Speicher reservieren fuer das Spielfeld

		if (Feld_A != NULL) {
			// Alles zur neuen Mitte ausrichten
			for (reihe = 0; reihe < Kapazitaet_Reihen; reihe++) {
				for (spalte = 0; spalte < Kapazitaet_Spalten; spalte++) {
					*(Feld_A + reihe * Kapazitaet_Spalten + spalte + (1 + 2 * reihe) * verschiebung) = *(Spielfeld + reihe * Kapazitaet_Spalten + spalte);
				}
			}
			free(Feld_B);
			Spielfeld = Feld_A;
			aktuellesFeld = 'A';
		}
		else {
			fprintf(stderr, "Fehler beim Zuweisen vom Speicher (realloc)\n");
			schiefgegangen++;
		}

		break;
	}

	Korrektur = Neu + wachstum2;				// Neuer Korrekturwert
	Kapazitaet_Spalten = (Korrektur * 2) + 1;	// Neue Kapazitaet
	wachstum2 = wachstum2 * 2;

	return schiefgegangen;
}

// EINWURFS Funktion - Wirft einen Stein ins Spielfeld
void einwurf(int negativ, int farbe, int spalte) {
	// aktuelle Spanne der Spalten feststellen
	if (Spanne_Spalten < spalte) {
		Spanne_Spalten = spalte;
	}

	// Spalte uebersetzen
	int stein_farbe = farbe;
	int stein_spalte;
	int stein_index = 0;
	int finale_reihe;

	if (negativ == 0) {
		stein_spalte = spalte + Korrektur;
	}
	else {
		stein_spalte = Korrektur - spalte;
	}

	// Stein fallen lassen
	while (*(Spielfeld + stein_index * Kapazitaet_Spalten + stein_spalte) == 0 && stein_index != (Kapazitaet_Reihen - 1))
	{
		stein_index = stein_index + 1;
	}

	// Stein ganz unten angekommen
	if (stein_index == (Kapazitaet_Reihen - 1) && *(Spielfeld + stein_index * Kapazitaet_Spalten + stein_spalte) == 0) {
		*(Spielfeld + stein_index * Kapazitaet_Spalten + stein_spalte) = stein_farbe + 1;		// +1 da die Null reserviert ist fuer leere Plaetze
		finale_reihe = stein_index;
		if (Spanne_Reihen < 0) {
			Spanne_Reihen = 0; // aktuelle maximale Hoehe anpassen
		}
	}

	// Stein faellt auf Stein
	else {
		*(Spielfeld + (stein_index - 1) * Kapazitaet_Spalten + stein_spalte) = stein_farbe + 1;	// +1 da die Null reserviert ist fuer leere Plaetze
		finale_reihe = stein_index - 1;
		if (Spanne_Reihen < Kapazitaet_Reihen - stein_index) {
			Spanne_Reihen = Kapazitaet_Reihen - stein_index; // aktuelle maximale Hoehe anpassen
		}
	}

	// Ueberpruefen ob ein Crush moeglich ist
	crush((stein_farbe + 1), finale_reihe, stein_spalte);
}

// LESE Funktion - liest die Eingabe
int lesen() {
	schiefgegangen = 0;		// Beobachtet ob Lesefehler auftreten

	// Alles zum Einwurf
	int einwurf_farbe = 0;	// Farbleser
	int einwurf_spalte = 0;	// Spaltenleser
	int negativ = 0;		// Check ob Spalte negativ ist
	int LF_zaehler = 0;		// zaehlt aufeinanderfolgende LF

	int r;					// Lesekopf

	int zustand = 0;		// Zustandsvariable
		// z0 = Anfang der Farbe wird erwartet, akzeptiert 0-9, wechselt auf z1 nach erster eingelesener Zahl
		// z1 = Fortsetzung oder Ende der Farbe wird erwartet, akzeptiert 0-9 und Leerzeichen (32), wechselt auf z2 nach einem Leerzeichen (32)
		// z2 = Leerzeichen der Mitte, akzeptiert Leerzeichen, 0-9 oder ein Minus, wechselt auf z3 bei einer Zahl oder auf z4 bei einem Minus
		// z3 = Fortsetzung oder Ende der nicht negativen Spalte wird erwartet, akzeptiert 0-9 oder LF/CR (10/13), wechselt auf z6 bei LF/CR (10/13)
		// z4 = Anfang der negativen Spalte wird erwartet, akzeptiert 0-9, wechselt auf z5 nach erster eingelesener Zahl
		// z5 = Fortsetzung oder Ende der negativen Spalte wird erwartet, akzeptiert 0-9 oder LF/CR (10/13), wechselt auf z6 bei LF/CR (10/13)
		// z6 = wirft Stein ein und erwartet Anfang der neuen Farbe, wechselt auf z1 nach erster eingelesener Zahl oder z7 bei einer Leerzeile
		// z7 = Die letzte Zeile ist eine Leerzeile ohne Inhalt

	//Lesen des Streams
	while ((r = getchar()) != EOF && schiefgegangen == 0) {

		//printf("Es wurde %d gelesen!\n", r);

		switch (zustand) {

		case 0: // ZUSTAND z0
			switch (r) {
			case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9':
				einwurf_farbe = einwurf_farbe * 10 + (int)r - 48; // Eine gueltige Zahl wird eingelesen
				zustand = 1;
				break;
			case 10: case 13:	// Ende der Zeile
				zustand = 7;
				break;
			default:
				fprintf(stderr, "Ungueltige Farbeingabe! (F01)\n");
				schiefgegangen++;
				break;
			}
			break;

		case 1: // ZUSTAND z1
			switch (r) {
			case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9':
				einwurf_farbe = einwurf_farbe * 10 + (int)r - 48; // Eine gueltige Zahl wird eingelesen
				if (einwurf_farbe > 254) {
					fprintf(stderr, "Ungueltige Farbeingabe! (F09)\n");
					schiefgegangen++;
				}
				break;
			case ' ':
				if (einwurf_farbe > 254) {
					fprintf(stderr, "Ungueltige Farbeingabe! (F09)\n");
					schiefgegangen++;
				}
				zustand = 2;
				break;
			default:
				fprintf(stderr, "Ungueltige Farbeingabe! (F03)\n");
				schiefgegangen++;
				break;
			}
			break;

		case 2: // ZUSTAND z2
			switch (r) {
			case ' ':
				break;
			case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9':
				einwurf_spalte = (int)r - 48;		// Kein Minus, sondern die erste Zahl wurde gelesen
				zustand = 3;
				break;
			case '-':								// Minus wurde gelesen
				negativ = 1;
				zustand = 4;
				break;
			default:
				fprintf(stderr, "Ungueltige Mitte! (F04)\n");
				schiefgegangen++;
				break;
			}
			break;

		case 3: // ZUSTAND z3
			switch (r) {
			case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9':
				einwurf_spalte = einwurf_spalte * 10 + (int)r - 48; // Eine gueltige Zahl wird eingelesen
				if (einwurf_spalte > 1048576) {
					fprintf(stderr, "Betrag der Spalte ueber 2^20, Ergebnis koennte falsch sein!\n");
					schiefgegangen++;
				}
				break;
			case 10: case 13:	// Ende der Zeile
				zustand = 6;
				if (r == 10) {
					LF_zaehler++;
				}

				/*EINWURF START*/
				// Check ob das Spielfeld nach oben hin fast voll ist und um eine neue Reihe erweitert werden muss
				if ((Kapazitaet_Reihen - 3) == Spanne_Reihen) {
					if (hoeher() > 0) { // Fehler beim realloc
						schiefgegangen++;
					}
				}

				// Check ob Spalte im Rahmen ist
				if (einwurf_spalte > 1048576) {
					fprintf(stderr, "Betrag der Spalte ueber 2^20, Ergebnis koennte falsch sein!\n");
					schiefgegangen++;
				}

				if (schiefgegangen == 0) {
					// Check ob die aktuelle Spalte im Spielfeld vorhanden ist oder ob das Spielfeld um neue Spalten erweitert werden muss
					if (Korrektur - 3 < einwurf_spalte) {
						if (breiter(einwurf_spalte + 3) > 0) { // Fehler beim realloc
							schiefgegangen++;
						}
					}


					einwurf(negativ, einwurf_farbe, einwurf_spalte);	// Stein einwerfen
					/*Reset der Werte fuer den Einwurf*/
					einwurf_farbe = 0;
					einwurf_spalte = 0;
					negativ = 0;
				}
				/* EINWURF ENDE*/

				break;
			default:
				fprintf(stderr, "Ungueltige Spalteneingabe! (F05)\n");
				schiefgegangen++;
				break;
			}
			break;

		case 4: // ZUSTAND z4
			switch (r) {
			case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9':
				einwurf_spalte = einwurf_spalte * 10 + (int)r - 48; // Eine gueltige Zahl wird eingelesen
				zustand = 5;
				break;
			default:
				fprintf(stderr, "Ungueltige Spalteneingabe! (F06)\n");
				schiefgegangen++;
				break;
			}
			break;

		case 5: // ZUSTAND z5
			switch (r) {
			case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9':
				einwurf_spalte = einwurf_spalte * 10 + (int)r - 48; // Eine gueltige Zahl wird eingelesen
				if (einwurf_spalte > 1048576) {
					fprintf(stderr, "Betrag der Spalte ueber 2^20, Ergebnis koennte falsch sein!\n");
					schiefgegangen++;
				}
				break;
			case 10: case 13:	// Ende der Zeile
				zustand = 6;
				if (r == 10) {
					LF_zaehler++;
				}

				/*EINWURF START*/
				// Check ob das Spielfeld nach oben hin fast voll ist und um eine neue Reihe erweitert werden muss
				if ((Kapazitaet_Reihen - 3) == Spanne_Reihen) {
					if (hoeher() > 0) { // Fehler beim realloc
						schiefgegangen++;
					}
				}

				// Check ob Spalte im Rahmen ist
				if (einwurf_spalte > 1048576) {
					fprintf(stderr, "Betrag der Spalte ueber 2^20, Ergebnis koennte falsch sein!\n");
					schiefgegangen++;
				}

				if (schiefgegangen == 0) {
					// Check ob die aktuelle Spalte im Spielfeld vorhanden ist oder ob das Spielfeld um neue Spalten erweitert werden muss
					if (Korrektur - 3 < einwurf_spalte) {
						if (breiter(einwurf_spalte + 3) > 0) { // Fehler beim realloc
							schiefgegangen++;
						}
					}


					einwurf(negativ, einwurf_farbe, einwurf_spalte);	// Stein einwerfen
					/*Reset der Werte fuer den Einwurf*/
					einwurf_farbe = 0;
					einwurf_spalte = 0;
					negativ = 0;
				}
				/* EINWURF ENDE*/

				break;
			default:
				fprintf(stderr, "Ungueltige Spalteneingabe! (F07)\n");
				schiefgegangen++;
				break;
			}
			break;

		case 6: // ZUSTAND z6

			switch (r) {
			case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9':
				einwurf_farbe = einwurf_farbe * 10 + (int)r - 48; // Eine gueltige Zahl wird eingelesen
				zustand = 1;
				LF_zaehler = 0;
				break;
			case 13:	// Leerzeile
				zustand = 7;
				LF_zaehler = 0;
				break;
			case 10:
				if (LF_zaehler == 1) {
					fprintf(stderr, "Mehr als eine Leerzeile am Ende oder innerhalb des Programms! (F02)\n");
					schiefgegangen++;
				}
				else
				{
					LF_zaehler++;
				}
				break;
			default:
				fprintf(stderr, "Ungueltige Farbeingabe! (F08)\n");
				schiefgegangen++;
				break;
			}
			break;
		case 7: // ZUSTAND z7

			switch (r) {
			default:
				fprintf(stderr, "Mehr als eine Leerzeile am Ende oder innerhalb des Programms! (F02)\n");
				schiefgegangen++;
				break;
			}
			break;
		}
	}

	return schiefgegangen;
}

// MAIN Funktion - Das eigentliche Programm
int main() {
	int rueckgabe = 0;

	Feld_A = (int*)calloc(Startwert_Reihen * Startwert_Spalten, sizeof(int));		// Speicher reservieren fuer das Spielfeld

	if (Feld_A == NULL) { // Check ob calloc funktioniert hat
		fprintf(stderr, "Fehler beim Zuweisen vom Speicher (calloc)\n");
		rueckgabe = 6;
	}
	else {
		Spielfeld = Feld_A;
		if (lesen() > 0) {		// Eingabe lesen
			rueckgabe = 7;
		}
		else {
			ausgabe();			// Ausgabe schreiben
		}

	}

	// Speicher freigeben
	free(Spielfeld);

	return rueckgabe;
}