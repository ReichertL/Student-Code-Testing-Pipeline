//
// Created by ben on 5/14/20.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>

#define CHUNK 0
#define CHUNK2 0
//#define DEBUG 1

typedef struct {
    long x_value;
    long y_value;
} coord;

typedef struct {
    coord *array;
    long top;
    long max;
}coord_array;

typedef struct {
    long max;
    long top;
    int *array;
} y;

typedef struct {
    y **array;
    long top;
    long bot;
    long max;
    long min;
} x;

x *field;
int endflag;
coord_array *delete;

int compare_coord(void const *ls, void const *rs){
    long l = ((coord *)ls)->y_value;
    long r = ((coord *)rs)->y_value;
    return (r-l);
}

void print_error(char *reason){
    fprintf(stderr, "%s", reason);
    exit(2);
}

void check_memory(void *memory, char *name){
    if(!memory){
        fprintf(stderr, "memory allocation of %s failed", name);
        exit(2);
    }
}

long add_character_long(long number, int chr){
    int i = chr - '0';
    if(((LONG_MAX-1) - i)/10 <= number) print_error("Zahl zu groß für long");
    return (number * 10) + i;
}

int add_character_int(int number, int chr){
    int i = chr - '0';
    if((INT_MAX - i)/10 <= number) print_error("Zahl zu groß für int");
    return (number * 10) + i;
}

void check_colour(int colour){;
    if(colour > 254) print_error("Farbe zu groß");
    if(colour < 0) print_error("Farbe zu klein");
}

void print_field(){
    printf("max : %li; min : %li; top: %li; bot: %li \n", field->max, field->min, field->top, field->bot);
    for(long i = field->min - field->bot; i <= field->bot + field->top; i++){
        printf("x = %2li ** ", i-field->min);
        if(field->array[i]->top == -1) { printf("empty\n"); continue; }
        for(long j = 0; j <= field->array[i]->top; j++){
            printf("colour=%i ", field->array[i]->array[j]);
            if(j == field->array[i]->top) printf(" top=%li max=%li", field->array[i]->top, field->array[i]->max);
        }
        printf("\n");
    };
}

void check_above(long x_value, long y_value);

void delete_stone(long x_value, long y_value){
    if(y_value == field->array[x_value]->top){
        field->array[x_value]->top--;
        return;
    }
    for(long i = y_value + 1; i <= field->array[x_value]->top; i++){
        field->array[x_value]->array[i - 1] = field->array[x_value]->array[i];
    }
    field->array[x_value]->top--;
}


void init_delete(){
    delete = malloc(sizeof(coord_array));
    delete->top = -1;
    delete->max = 0;
    delete->array = malloc(sizeof(coord));
}

int *init_int(int *pointer){
    pointer = malloc(sizeof(int));
    check_memory(pointer, "init int");
    return pointer;
}

y* init_y(y* pointer){
    pointer = malloc(sizeof(y));
    check_memory(pointer, "init_y");
    pointer->max = 0;
    pointer->top = -1;
    pointer->array = init_int(pointer->array);
    return pointer;
}

void init_field(){
    field = malloc(sizeof(x));
    check_memory(field, "field");
    field->top = 0;
    field->bot = 0;
    field->max = 0;
    field->min = 0;
    field->array = malloc(sizeof(y*));
    check_memory(field->array, "field array init");
    field->array[0] = init_y(field->array[0]);
}

void realloc_delete(){
    if(delete->top == delete->max){
        void *tmp = realloc(delete->array, sizeof(coord) * (delete->max + CHUNK2 + 2));
        check_memory(tmp, "realloc delete");
        delete->array = tmp;
        delete->max = delete->max + CHUNK2 + 1;
    }
}

x *realloc_field(x *pointer, long position){
    if(position > 0) {
        void *tmp = realloc(pointer->array, (CHUNK + position + pointer->min + 1) * sizeof(y *));
        check_memory(tmp, "tmp realloc field positive");
        pointer->array = tmp;
        pointer->max = CHUNK + position;
        for(long i = pointer->min + pointer->max; i > pointer->min + pointer->top; i--){
            pointer->array[i] = init_y(pointer->array[i]);
        }
        return pointer;
    }
    if(position < 0){
        void *tmp = realloc(pointer->array, (CHUNK + (position *-1) + pointer->max + 1) * sizeof(y *));
        check_memory(tmp, "tmp realloc field negative");
        pointer->array = tmp;
        long old_min = pointer->min;
        pointer->min = CHUNK + (position * -1);
        for(long i = old_min + pointer->top; i >= 0; i--){
            pointer->array[(pointer->min - old_min) +i] = pointer->array[i];
        }
        for(long i = 0; i < pointer->min - pointer->bot ; i++){
            pointer->array[i] = init_y(pointer->array[i]);
        }
    }else return pointer;
    return NULL;
}

void realloc_y(y *y_pointer){
    int *tmp = realloc(y_pointer->array, sizeof(int) * (y_pointer->max + 2 + CHUNK2));
    check_memory(tmp, "reallloc y 0");
    y_pointer->array = tmp;
    y_pointer->max = y_pointer->max + 1 + CHUNK2;
}

long check_north(long number, long x_value, long y_value){
    if(field->array[x_value]->top == y_value) return number;
    if(field->array[x_value]->array[y_value] == field->array[x_value]->array[y_value + 1] ||
        field->array[x_value]->array[y_value] + 300 == field->array[x_value]->array[y_value + 1] ||
        field->array[x_value]->array[y_value] == field->array[x_value]->array[y_value + 1] + 300){
        return check_north(number+1, x_value, y_value + 1);
    }
    else return number;
}
long check_northeast(long number, long x_value, long y_value){
    if(field->top + field->min == x_value) return number;
    if(field->array[x_value + 1]->top < y_value + 1) return number;
    if(field->array[x_value]->array[y_value] == field->array[x_value + 1]->array[y_value + 1] ||
        field->array[x_value]->array[y_value] + 300 == field->array[x_value + 1]->array[y_value + 1] ||
        field->array[x_value]->array[y_value] == field->array[x_value + 1]->array[y_value + 1] + 300){
        return check_northeast(number + 1, x_value + 1, y_value + 1);
    }
    else return number;
}
long check_east(long number, long x_value, long y_value){
    if(field->top + field->min == x_value) return number;
    if(field->array[x_value + 1]->top < y_value) return number;
    if(field->array[x_value]->array[y_value] == field->array[x_value + 1]->array[y_value] ||
        field->array[x_value]->array[y_value] + 300 == field->array[x_value + 1]->array[y_value] ||
        field->array[x_value]->array[y_value] == field->array[x_value + 1]->array[y_value] + 300){
        return check_east(number + 1, x_value + 1, y_value);
    }
    else return number;
}
long check_southeast(long number, long x_value, long y_value){
    if(0 == y_value) return number;
    if(field->top + field->min == x_value) return number;
    if(field->array[x_value + 1]->top < y_value - 1) return number;
    if(field->array[x_value]->array[y_value] == field->array[x_value + 1]->array[y_value - 1] ||
        field->array[x_value]->array[y_value] + 300 == field->array[x_value + 1]->array[y_value - 1] ||
        field->array[x_value]->array[y_value] == field->array[x_value + 1]->array[y_value - 1] + 300){
        return check_southeast(number + 1, x_value + 1, y_value - 1);
    }
    else return number;
}
long check_south(long number, long x_value, long y_value){
    if(0 == y_value) return number;
    if(field->array[x_value]->array[y_value] == field->array[x_value]->array[y_value - 1] ||
        field->array[x_value]->array[y_value] + 300 == field->array[x_value]->array[y_value - 1] ||
        field->array[x_value]->array[y_value] == field->array[x_value]->array[y_value - 1] + 300){
        return check_south(number + 1, x_value, y_value - 1);
    }
    else return number;
}
long check_southwest(long number, long x_value, long y_value){
    if(0 == y_value) return number;
    if(field->min - field->bot == x_value) return number;
    if(field->array[x_value - 1]->top < y_value - 1) return number;
    if(field->array[x_value]->array[y_value] == field->array[x_value - 1]->array[y_value - 1] ||
        field->array[x_value]->array[y_value] + 300 == field->array[x_value - 1]->array[y_value - 1] ||
        field->array[x_value]->array[y_value] == field->array[x_value - 1]->array[y_value - 1] + 300){
        return check_southwest(number + 1, x_value - 1, y_value - 1);
    }
    else return number;
}
long check_west(long number, long x_value, long y_value){
    if(field->min - field->bot == x_value) return number;
    if(field->array[x_value - 1]->top < y_value) return number;
    if(field->array[x_value]->array[y_value] == field->array[x_value - 1]->array[y_value] ||
        field->array[x_value]->array[y_value] + 300 == field->array[x_value - 1]->array[y_value] ||
        field->array[x_value]->array[y_value] == field->array[x_value - 1]->array[y_value] + 300){
        return check_west(number + 1, x_value - 1, y_value);
    }
    else return number;
}
long check_northwest(long number, long x_value, long y_value){
    if(field->min - field->bot == x_value) return number;
    if(field->array[x_value - 1]->top < y_value + 1) return number;
    if(field->array[x_value]->array[y_value] == field->array[x_value - 1]->array[y_value + 1] ||
        field->array[x_value]->array[y_value] + 300 == field->array[x_value - 1]->array[y_value + 1] ||
        field->array[x_value]->array[y_value] == field->array[x_value - 1]->array[y_value + 1] + 300){
        return check_northwest(number + 1, x_value - 1, y_value + 1);
    }
    else return number;
}

void mark_stone(long x_value, long y_value){
    if(field->array[x_value]->array[y_value] >= 300) return;
    field->array[x_value]->array[y_value] += 300;
    realloc_delete();
    delete->top++;
    delete->array[delete->top].x_value = x_value;
    delete->array[delete->top].y_value = y_value;

}
void mark_stones(long x_value, long y_value){

    long north = check_north(0, x_value, y_value),
    northeast = check_northeast(0, x_value, y_value),
    east = check_east(0, x_value, y_value),
    southeast = check_southeast(0, x_value, y_value),
    south = check_south(0, x_value, y_value),
    southwest = check_southwest(0, x_value, y_value),
    west = check_west(0, x_value, y_value),
    northwest = check_northwest(0, x_value, y_value);

    if(north + south >= 3){
        for(long i = 0; i <= south; i++){
            mark_stone(x_value, y_value - i);
        }
        for(long i = 1; i <= north; i++){
            mark_stone(x_value, y_value + i);
        }

    }
    if(northeast + southwest >= 3){
        for(long i = 0; i <= northeast; i++){
            mark_stone(x_value + i, y_value + i);
        }
        for(long i = 1; i <= southwest; i++){
            mark_stone(x_value - i, y_value - i);
        }
    }
    if(northwest + southeast >= 3){
        for(long i = 0; i <= northwest; i++){
            mark_stone(x_value - i, y_value + i);
        }
        for(long i = 1; i <= southeast; i++){
            mark_stone(x_value + i, y_value - i);
        }
    }
    if(east + west >= 3){
        for(long i = 0; i <= east; i++){
            mark_stone(x_value + i, y_value);
        }
        for(long i = 1; i <= west; i++){
            mark_stone(x_value - i, y_value);
        }
    }

}

void check_above(long x_value, long y_value){
    for(long i = y_value; i <= field->array[x_value]->top; i++){
        mark_stones(x_value, i);
    }
}
void delete_marked(){
    for( int i = 0; i <= delete->top; i++){
        delete_stone(delete->array[i].x_value, delete->array[i].y_value);
    }
}
void mark_above(){
    long top = delete->top + 1;
    coord tmp[top];
    for( int i = 0; i <= delete->top; i++){
        tmp[i] = delete->array[i];
    }
    delete->top = -1;
    for(int i = 0; i <= top -1; i++){
        check_above(tmp[i].x_value, tmp[i].y_value);
    }
}


void add_stone(int colour, long position){
    if(position > field->max || position * -1 > field->min){
        realloc_field(field, position);
    }
    if(field->array[field->min + position]->top == field->array[field->min + position]->max){
        realloc_y(field->array[field->min + position]);
    }
    field->array[field->min + position]->top++;

    //int *tmp = realloc(field->array[field->min + position]->array, sizeof(int) * (field->array[field->min + position]->top + 1));
    //check_memory(tmp, "reallloc y 0");
    //field->array[field->min + position]->array = tmp;
    field->array[field->min + position]->array[field->array[field->min + position]->top] = colour;
    if(position > field->top) field->top = position;
    if(position * -1 > field->bot) field->bot = position * -1;

    mark_stones(position + field->min, field->array[field->min + position]->top);
    while(delete->top >= 0) {
        qsort(delete->array, delete->top + 1, sizeof(coord), compare_coord);
#ifdef DEBUG
        for(int i = 0; i <= delete->top; i++){
            long tmp = delete->array[i].x_value - field->min;
            printf("(%li, %li) ", tmp, delete->array[i].y_value );

        }
        printf("\n");
#endif
        delete_marked();
#ifdef DEBUG
        print_field();
#endif
        mark_above();
#ifdef DEBUG
        print_field();
#endif
    }
}


void parse_line(){
    int chr;
    int sign = 0;
    long position = 0;
    int colour = 0;
    int status = 0; //0 Anfang, 1 Farbe, 2 Leerzeichen, 3 Minus, 4 Position

    int mutated = 0;
    while(1){
        chr = getc(stdin);
        //printf("%i \n", chr);
        if(feof(stdin)){
            if(status != 0 && status !=4){
                print_error("falsches Input Format");
            }
            if(sign){
                position = position * -1;
            }
            endflag = 1;
            break;
        }
        if((chr < 48 || chr > 57) && chr != 32 && chr != 45 && chr != 10){
            printf("-%i-", chr);
            print_error("falsches Zeichen in der Eingabe");
        }
        if(status == 0){
            if(chr >=48 && chr <= 57) {
                colour = add_character_int(colour, chr);
                check_colour(colour);
                status = 1;
                mutated = 1;
                continue;
            } else print_error("Zeile fängt mit einem ungültigen Zeichen an");
        }
        if(status == 1){
            if(chr >=48 && chr <= 57) {
                colour = add_character_int(colour, chr);
                check_colour(colour);
                continue;
            }
            if(chr == 32){
                status = 2;
                continue;
            }else print_error("Nach Farbe steht ein ungültiges Zeichen");
        }
        if(status == 2){
            if(chr == 32) continue;
            if(chr >=48 && chr <= 57) {
                position = add_character_long(position, chr);
                status = 4;
                continue;
            }
            if(chr == 45){
                sign = 1;
                status = 3;
                continue;
            }else print_error("vor der Position steht ein ungültiges Zeichen");
        }
        if(status == 3){
            //printf("---%i---", chr);
            if(chr >= 48 && chr <= 57) {
                position = add_character_long(position, chr);
                status = 4;
                continue;
            }else print_error("ungültiges Zeichen nach dem Minus");
        }
        if(status == 4){
            if(chr >=48 && chr <= 57) {
                position = add_character_long(position, chr);
                continue;
            }
            if(chr == 10){
                if(sign) position = position * -1;

                break;
            }else print_error("ungültiges Zeichen nach der Position");
        }
    }
    if(mutated > 0) add_stone(colour, position);
#ifdef DEBUG
    printf("added %i : %li \n", colour, position);
    print_field();
#endif
}
void print_output(){
    for(int i = field->min - field->bot; i <= field->top + field->min; i++){
        if(field->array[i]->top == -1) continue;
#ifdef DEBUG
        //printf("%li \n", field->array[i]->top);
#endif
        for(int j = 0; j <= field->array[i]->top; j++){
            printf("%i %li %d\n", field->array[i]->array[j], i - field->min, j);
        }
    }
}

void clean_inshallah() {
    for(int i = 0; i <= field->min + field->max; i++){
        free(field->array[i]->array);
        free(field->array[i]);
    }
    free(field->array);
    free(field);
    free(delete->array);
    free(delete);

}

int main(int argc, char **argv) {
    if (argc > 1){
        print_error("Keine Argumente gebraucht");
    }
    //freopen("example10.stdin","r", stdin);
    atexit(clean_inshallah);
    endflag = 0;
    init_field();
    init_delete();
    while(!endflag){
        parse_line();
    }
#ifdef DEBUG
    print_field();
#endif
    print_output();
    //free(field);
    return 0;
}