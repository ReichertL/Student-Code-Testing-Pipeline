#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *array;
char *array_swap;
int height = 20;
int width = 20;
int offset = 10;
int x;
int y;
int farbe;
char farbe_char;
int koordinate;               /* inklusive offset!!! */
int koordinate_h;             /* höhe, auf der Stein abgelegt wurde */
int array_double_h (void);   /*vedoppelt die Höhe des Arrays*/
int Indexx = 0;
int MAX = 50;
char *str;
char *str_swap;

int array_double_w (void);   /*vedoppelt die Breite des Arrays*/

int get_zeile (void);        /*liest Zeile, also Farbe, x-Koordinate und linefeed*/

int einsetzen (void);        /* setzt den "Stein" in das Array ein*/
                                                                                                                                                                                                                                             int test (void);             /*testet erstmalig auf vierer-Reihen*/                                                                                                                                                                                                                                                                                                                                                                                                                       int test_again (void);       /*testet auf vierer-Reihen*/

void nachrutschen (void);     /*lässt Steine, die nicht auf dem Boden oder anderen Steinen liegen nachrutschen*/

void ausgabe (void);

void zahl (int);

void increase (void);

void Ausgabe (void);

int main(){
        int doit;
        //printf("start!\n");
        array = malloc(height * width * sizeof(char));
        if (array == NULL){
                fprintf(stderr, "Error - unable to allocate required memory\n");
                return 1;
        }
        int error;
        for (;;){
                error = get_zeile();
                if (error == 1){
                        fprintf(stderr, "Error - incorrect input\n");
                        return 1;
                }else if (error == 2)
                {
                        Ausgabe();
                        free(array);
                        return 0;
                }
                else if (error ==3){                /*Zeile ist letzte Zeile*/
                        error = einsetzen();
                        if (error){
                                return 1;
                        }
                        doit = test();
                        while (doit == 1){
                                nachrutschen();
                                doit = test_again();
                        }
                        if (doit == 2){
                                return 1;
                        }
                        Ausgabe();
                        free(array);
                        return 0;
                }
                error = einsetzen();
                if(error){
                        return 1;
                }
                doit = test();
                while (doit == 1)
                {
                        nachrutschen();
                        doit = test_again();
                }
                if (doit == 2)
                {
                        return 1;
                }
        }
}
int array_double_h (void){
        array_swap = array;
        array = malloc(2 * height * width * sizeof(char));
        if (array == NULL){
                fprintf(stderr, "Error- unable to allocate required memory\n");
                return 1;
        }
        int i;
        for (i = 0; i<width*height; i++){
                x = i/height;
                y = i%height;
                array[x * height * 2 + y] = array_swap[i];
        }
        height *= 2;
        free(array_swap);
        return 0;
}

int array_double_w (void){
        array_swap = array;
        array = malloc(2 * height * width *sizeof(char));
        if (array == NULL){
                fprintf(stderr, "Error - unable to allocate required memory\n");
                return 1;
        }
        int i;
        for (i = 0; i<width*height; i++){
                /*x = i/height;
                y = i%height;*/
                array[offset * height + i] = array_swap[i];   /* array[offset * height +i] = array_swap[i] */
        }
        width *= 2;
        offset *= 2;
        free(array_swap);
        return 0;
}

int einsetzen (void){
        //printf("einsetzen starten\n");
        int fehler = 0;
        farbe -= 47;                                         /* farbe ist nach Spezifikation in [0,254] */
        farbe_char = farbe + '0';                            /* weil '0' = 48 und farbe_char somit in [1,255] ist */
        while (koordinate < 0 || koordinate >= width){
                koordinate += offset;
                fehler += array_double_w();
                if (fehler) return 1;
        }
        if (array[koordinate * height + height - 1] != 0){
                fehler += array_double_h();
        }
        if (fehler){
                return 1;
        }
        int i;
        for (i = 0; i<height; i++){
                if (array[koordinate * height + i] == 0){
                        array[koordinate * height + i] = farbe_char;
                        koordinate_h = i;
                        //printf("eingesetzt\n");
                        return 0;
                }
        }
        fprintf(stderr, "Error - Zahl konnte nicht eingesetzt werden");
        return 1;
}

int test (void){
        //printf("test starten\n");
        int loeschtabelle [2][2] = {{0,0} , {0,0}};
        int start = koordinate_h, anzahl = 0;
        char c, aktuell = array[koordinate_h];
        int i;
        for (i = 0; i<width; i++){                    /* waagerecht */
                c = array[i * height + koordinate_h];
                if (c){
                        if (c==aktuell){
                                anzahl++;
                        }
                        else{
                                if (anzahl>3){
                                        loeschtabelle[0][0] = start;
                                        loeschtabelle[0][1] = anzahl;
                                }
                                else{}
                                aktuell = c;
                                start = i * height + koordinate_h;
                                anzahl = 1;
                        }
                }else{
                        if (anzahl>3){
                                loeschtabelle[0][0] = start;
                                loeschtabelle[0][1] = anzahl;
                        }else{}
                        aktuell = 0;
                        anzahl = 0;
                }
        }
        aktuell = array[koordinate * height];
        anzahl = 0;
        start = koordinate * height;
        for (i = 0; i<height; i++){                     /* senkrecht */
                c = array[koordinate * height + i];
                if (c){
                        if (c==aktuell){
                                anzahl++;
                        }
                        else{
                                if (anzahl>3){
                                        loeschtabelle[1][0] = start;
                                        loeschtabelle[1][1] = anzahl;
                                }
                                else{}
                                aktuell = c;
                                start = koordinate * height + i;
                                anzahl = 1;
                        }
                }else{
                        if (anzahl>3){
                                loeschtabelle[1][0] = start;
                                loeschtabelle[1][1] = anzahl;
                        }else{}
                        aktuell = 0;
                        anzahl = 0;
                }
        }
        if (loeschtabelle[0][1] >= 4){                      /* loeschen waagerecht */
                for (i = 0; i<loeschtabelle[0][1]; i++){
                        array[loeschtabelle[0][0] + i * height]= 0;
                }
        }
        if (loeschtabelle[1][1] >= 4){                      /* loeschen senkrecht */
                for (i = 0; i<loeschtabelle[1][1]; i++){
                        array[loeschtabelle[1][0] + i] = 0;
                }
        }
        //printf("test beenden\n");
        if (loeschtabelle[0][1]>3 || loeschtabelle[1][1]>3){
                //printf("nachrutsch aufrufen\n");
                return 1;
        }
        return 0;
}

void nachrutschen (void){
        //printf("nachrutschen starten\n");
        int n, i, j;
        for (i = 0; i<width; i++){
                n = 0;
                for (j = 0; j<height; j++){
                        if (array[i * height + j] == 0){
                                n++;
                        }else if (n>0){
                                array[i * height  + j - n ] = array[i * height + j];
                                array[i * height + j] = 0;
                        }else{}
                }
        }
        //printf("test_again aufrufen\n");
}

int test_again (void){
        //printf("test_again starten\n");
        //int deletetable_h[2 * height * width / 5];
        //int deletetable_v[2 * height * width / 5];
        int start, anzahl, index, i, j;
        char c, aktuell;

        int *deletetable_h;
        int *deletetable_v;

        deletetable_h = calloc(2 * width * height / 5, sizeof(int));
        if (deletetable_h == 0){
                fprintf(stderr, "Error - unable to allocate required memory\n");
                return 2;
        }
        deletetable_v = calloc(2 * width * height / 5, sizeof(int));
        if (deletetable_v == 0){
                fprintf(stderr, "Error - unable to allocate required memory\n");
                return 2;
        }
        index = 0;
        for (i = 0; i<height; i++)                      /* horizontal nach vierer-Reihen absuchen */
        {
                aktuell = 0;
                anzahl = 0;
                start = i;
                for (j = 0; j<width; j++)
                {
                        c = array[j * height + i];
                        if (c)
                        {
                                if (c==aktuell)
                                {
                                        anzahl++;
                                }else
                                {
                                        if (anzahl>3)
                                        {
                                                deletetable_h[index*2] = start;
                                                deletetable_h[index*2+1] = anzahl;
                                                index++;
                                        }else{}
                                        aktuell = c;
                                        anzahl = 1;
                                        start = j * height + i;
                                }
                        }else
                        {
                                if (anzahl>3)
                                {
                                        deletetable_h[index*2] = start;
                                        deletetable_h[index*2+1] = anzahl;
                                        index++;
                                        aktuell = c;
                                        anzahl = 0;
                                }else{}
                                aktuell = c;
                                anzahl = 0;
                        }
                }
        }                                                    /* eventuell Problem, weil start noch nicht initialisiert ist */
        index = 0;
        for (i = 0; i<width; i++)                       /* vertikal nach vierer-Reihen absuchen */
        {
                aktuell = 0;
                anzahl = 0;
                start = i * height;
                for (j = 0; j<height; j++)
                {
                        c = array[i * height + j];
                        if (c)
                        {
                                if (c==aktuell)
                                {
                                        anzahl++;
                                }else
                                {
                                        if (anzahl>3)
                                        {
                                                deletetable_v[index*2] = start;
                                                deletetable_v[index*2+1] = anzahl;
                                                index++;
                                        }else{}
                                        aktuell = c;
                                        anzahl = 1;
                                        start = i * height + j;
                                }
                        }else
                        {
                                if (anzahl>3)
                                {
                                        deletetable_v[index*2] = start;
                                        deletetable_v[index*2+1] = anzahl;
                                        index++;
                                }else{}
                                aktuell = c;
                                anzahl = 0;
                        }
                }
        }
        index = 0;
        for (;;)                                            /* horizontal Reihen löschen */
        {
                if (deletetable_h[index*2+1]==0 || index == 2 * height * width / 10)
                {
                        break;
                }else
                {
                        for (i = 0; i<deletetable_h[index*2+1]; i++)
                        {
                                array[deletetable_h[index*2] + i * height] = 0;
                        }
                }
                index++;
        }
        index = 0;
        for (;;)                                             /* vertikal Reihen löschen */
        {
                if (deletetable_v[index*2+1]==0 || index == 2 * height * width / 10)
                {
                        break;
                }else
                {
                        for (i = 0; i<deletetable_v[index*2+1]; i++)
                        {
                                array[deletetable_v[index*2] + i] = 0;
                        }
                }
                index++;
        }
        //printf("test_again beenden\n");
        int nachrutschen_var = 0;
        if (deletetable_h[1] != 0 || deletetable_v[1] != 0)
        {
                nachrutschen_var = 1;
        }
        free(deletetable_h);
        free(deletetable_v);
        return nachrutschen_var;
}

int get_zeile (void){
        //printf("get_zeile starten\n");
        int index = 0;
        char str[100];
        fgets( str, 100, stdin );

/*      printf("%s\n", str);

        printf("str[0] %c <-\n", str[0]);
        printf("char %d\n", str[0]);
        printf("strlen %ld\n", strlen(str));
*/
        int new_char, current_value = 0, vorzeichen = 0;
        while (1)
        {
                new_char = str[index];
                //printf("%d\n", new_char);
                if (new_char == 32)
                {
                        index++;
                }//else if (new_char == 4 || new_char == 0 || new_char == 10)
                else if (new_char == 0)
                {
                        return 2;
                }else if (new_char <= 57 && new_char >= 48)
                {
                        current_value = new_char - 48;
                        index++;
                        break;
                }else
                {
                        //fprintf(stderr, "Error - invalid input: %d\n", new_char);
                        return 1;
                }
        }
        while (1)
        {
                new_char = 0 + str[index];
                //printf("%d\n", new_char);
                if (new_char == 32)
                {
                        if (current_value > 254)
                        {
                                //fprintf(stderr, "Error - invalid input (first number >254)\n");
                                return 1;
                        }else
                        {}
                        farbe = current_value;
                        current_value = 0;
                        index++;
                        break;
                }else if (new_char <= 57 && new_char >=48)
                {
                        current_value = current_value * 10 + new_char - 48;
                        index++;
                }else
                {
                        //fprintf(stderr, "Error - invalid input: %d\n", new_char);
                        return 1;
                }
        }
        while (1)
        {
                new_char = 0 + str[index];
                //printf("%d\n", new_char);
                if (new_char == 32)
                {
                        index++;
                        continue;
                }else if(new_char == 45)
                {
                        vorzeichen = 1;
                        index++;
                        break;
                }else if (new_char <= 57 && new_char >= 48)
                {
                        current_value = new_char - 48;
                        index++;
                        break;
                }else
                {
                        //fprintf(stderr, "Error - invalid input: %d\n", new_char);
                        return 1;
                }
        }
        while (1)
        {
                new_char = 0 + str[index];
                //printf("%d\n", new_char);
                if (new_char <= 57 && new_char >= 48)
                {
                        current_value = current_value * 10 + new_char - 48;
                        index++;
                }else if (new_char == 10 || new_char == 4 || new_char == 0)
                //else if (new_char == 0)
                {
                        if (vorzeichen)
                        {
                                if (current_value == 0)
                                {
                                        //fprintf(stderr, "Error - invalid input: -0\n");
                                        return 1;
                                }else
                                {
                                        koordinate = offset - current_value;
                                }
                        }else
                        {
                                koordinate = offset + current_value;
                        }
                        if (new_char == 0){return 3;}else{return 0;}
                }else if (new_char == 32)
                {
                        if (vorzeichen)
                        {
                                if (current_value == 0)
                                {
                                        //fprintf(stderr, "Error - invalid input: -0\n");
                                        return 1;
                                }else
                                {
                                        koordinate = offset - current_value;
                                        index++;
                                        break;
                                }
                        }else
                        {
                                koordinate = offset + current_value;
                                index++;
                                break;
                        }
                }else
                {
                        //fprintf(stderr, "Error - invalid input: %d\n", new_char);
                        return 1;
                }
        }
        while (1)
        {
                new_char = 0 + str[index];
                //printf("%d\n", new_char);
                if (new_char == 32)
                {
                        index++;
                        continue;
                }else if (new_char == 10 || new_char == 4 || new_char == 0)
                //else if (new_char == 0)
                {
                        return 3;
                }else
                {
                        //fprintf(stderr, "Error - invalid input\n");
                        return 1;
                }
        }
}

void ausgabe (void){
        char c;
        str = malloc(MAX * sizeof(char));
        int x, y, farbe, i;
        int Felder = height * width;
        for (i = 0; i<Felder; i++){
                if (array[i] == 0){
                        continue;
                }else{
                        c = array[i];
                        farbe = 0;
                        x = i / height;
                        y = i % height;
                        farbe = farbe + c - 1;
                        zahl(farbe);                /*Ausgabe von farbe*/
                        //putc(32, stdout);
                        str[Indexx] = 32;
                        increase();
                        zahl(x);                    /*Ausgabe von x*/
                        //putc(32, stdout);
                        str[Indexx] = 32;
                        increase();
                        zahl(y);                    /*Ausgabe von y*/
                        //putc(10, stdout);         /*macht puts() automatisch*/
                        puts(str);
                        Indexx = 0;
                        MAX = 50;
                        str = realloc(str, MAX);
                }
        }
        free(str);
}

void zahl (int x){
        if(x>0){
                zahl(x/10);
                //putc(x%10+48, stdout);
                str[Indexx] = '0' +  x%10;
                increase();
        }
}

void increase (void){
        Indexx++;
        if (Indexx == MAX){
                MAX *= 2;
                str_swap = str;
                str = malloc(MAX * sizeof(char));
                strcpy( str, str_swap );
                free(str_swap);
        }
}

void Ausgabe (void){
        //printf("Ausgabe starten\n");
        int x, y, farbe;
        char c;
        int i;
        for (i = 0; i < height * width; i++)
        {
                c = array[i];
                if (c == 0) continue;
                x = i / height - offset;
                y = i % height;
                farbe = 0 + c - 1;
                printf("%d %d %d\n", farbe, x, y);
        }
}