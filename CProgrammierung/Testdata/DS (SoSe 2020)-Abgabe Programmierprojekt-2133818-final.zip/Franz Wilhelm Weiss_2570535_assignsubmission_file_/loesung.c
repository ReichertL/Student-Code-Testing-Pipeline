#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

struct queue_pruefen
{
	int xwert;
	int ywert;
	int farbe;
	struct queue_pruefen* previous;
};

struct queue_loeschen
{
	int farbenliste[25][2];
	int xwert;
	int ywert;
	struct queue_loeschen* previous;
};


struct queue_pruefen* dummy;
struct queue_loeschen* dummy1;
int auffuellwert = 260;


int queue_init1() {
	if ((dummy1 = malloc(sizeof(struct queue_loeschen))) != NULL) {
		for (int y = 0; y < 25; y++) {
			dummy1->farbenliste[y][0] = 0;
			dummy1->farbenliste[y][1] = 0;
		}
		dummy1->previous = NULL;
		return 1;
	}
	else {
		return -1;
	}
}

// kommentieren und fuer dich erklaeren was es macht
int put1(struct queue_loeschen* neu) {
	struct queue_loeschen* zeiger;
	if (dummy1->previous == NULL) { // Es ist das 1. Element. 
		dummy1->previous = neu;
		neu->previous = NULL;
		return 1;
	}
	else {
		zeiger = dummy1;
		while (zeiger->previous != NULL) {
			zeiger = zeiger->previous;
		}
		zeiger->previous = neu;
		neu->previous = NULL;
		return 1;
	}
}

// kommentieren und fuer dich erklaeren was es macht
void get1(void) {
	struct queue_loeschen* zeiger;

	if (dummy1->previous != NULL) {
		zeiger = dummy1->previous;
		dummy1->previous = zeiger->previous;
		free(zeiger);
	}
}

int queue_init() {
	if ((dummy = malloc(sizeof(struct queue_pruefen))) != NULL) {
		dummy->ywert = 0;
		dummy->xwert = 0;
		dummy->farbe = 0;
		dummy->previous = NULL;
		return 1;
	}
	else {
		return -1;
	}
}
// kommentieren und fuer dich erklaeren was es macht
int put(struct queue_pruefen* neu) {
	struct queue_pruefen* zeiger;
	if (dummy->previous == NULL) { // Es ist das 1. Element. 
		dummy->previous = neu;
		neu->previous = NULL;
		return 1;
	}
	else {
		zeiger = dummy;
		/* Wir suchen das Ende der Schlange. */
		while (zeiger->previous != NULL) {
			zeiger = zeiger->previous;
		}
		zeiger->previous = neu;
		neu->previous = NULL;
		return 1;
	}
}
// kommentieren und fuer dich erklaeren was es macht
void get(void) {
	struct queue_pruefen* zeiger;

	if (dummy->previous != NULL) {
		zeiger = dummy->previous;
		dummy->previous = zeiger->previous;
		free(zeiger);
	}
}

int powtest(int a, int b) {
	int potenz = 1;
	for (int i = 0; i < b; i++) {
		potenz = potenz * a;
	}
	return potenz;
}

void findblock(int* offset, int xwert, int ywert, int highestx, int farbe, int farbenliste[25][2], int* arr, int highesty) { //angepasst


	bool a = true;
	bool b = true;
	bool c = true;
	bool d = true;
	bool e = true;
	bool f = true;
	bool g = true;
	bool h = true;

	int richtung1 = 0;
	int richtung2 = 0;
	int richtung3 = 0;
	int richtung4 = 0;
	int richtung5 = 0;
	int richtung6 = 0;
	int richtung7 = 0;
	int richtung8 = 0;
	farbenliste[24][1] = 1;



	for (int i = 1; i != 4; i++) { // geht in eine richtung und in die jeweils andere und guckt ob ein block die gleiche farbe hat, wenn ein block einer anderen farbe gefunden wird wird nicht weiter in diese richtung geprueft
		if ((b == false) && (a == false) && (c == false) && (d == false) && (e == false) && (f == false) && (g == false) && (h == false)) {
			break;
		}

		// untenrechts
		int tmp = (offset + xwert - arr);
		int differenz3 = highestx - tmp - 1;
		if ((offset + (i + ywert) * highestx + (i + xwert)) >= (arr + highestx * highesty)) { //pruefen ob out of bound unten
			a = false;
		}
		if ((offset + (i + ywert) * highestx + (i + xwert)) > (offset + (differenz3 + ywert) * highestx + (differenz3 + xwert))) {
			a = false;
		}
		if (a == true) {
			if (*(offset + (i + ywert) * highestx + (i + xwert)) == farbe) {
				farbenliste[i + 3 - 1][0] = i + xwert;
				farbenliste[i + 3 - 1][1] = i + ywert;
				richtung1++;
			}
			if (*(offset + (i + ywert) * highestx + (i + xwert)) != farbe) { //ungleich farbe, abbruch in dieser reihe
				a = false;
			}
		}
		differenz3 = 0;
		//obenlinks
		differenz3 = (offset + xwert - arr);
		if ((offset + (ywert - i) * highestx + (xwert - i)) < (arr)) { //pruefen ob out of bound oben
			b = false;
		}
		if ((offset + (ywert - i) * highestx + (xwert - i)) < (offset + (ywert - differenz3) * highestx + (xwert - differenz3))) {
			b = false;
		}
		if (b == true) {
			if (*(offset + (ywert - i) * highestx + (xwert - i)) == farbe) {
				farbenliste[i + 18 - 1][0] = -i + xwert;
				farbenliste[i + 18 - 1][1] = -i + ywert;
				richtung2++;
			}
			if (*(offset + (-i + ywert) * highestx + (-i + xwert)) != farbe) {//ungleich farbe, abbruch in dieser reihe
				b = false;
			}
		}

		// nach unten
		if ((offset + (i + ywert) * highestx + (xwert)) >= ((arr + highestx * highesty))) { //pruefen ob out of bound unten
			c = false;
		}
		if (c == true) {
			if (*(offset + (i + ywert) * highestx + xwert) == farbe) {
				farbenliste[8 - i + 1][0] = xwert;
				farbenliste[8 - i + 1][1] = i + ywert;
				richtung3++;
			}
			if (*(offset + (i + ywert) * highestx + xwert) != farbe) {//ungleich farbe, abbruch in dieser reihe
				c = false;
			}
		}


		differenz3 = 0;
		// nach links 
		differenz3 = (offset + xwert - arr);
		if ((offset + (ywert)*highestx + (-i + xwert)) < (arr)) { //pruefen ob out of bound oben
			d = false;
		}
		if ((offset + (ywert)*highestx + (-i + xwert)) < (offset + (ywert)*highestx + (-differenz3 + xwert))) {
			d = false;
		}
		if (d == true) {
			if (*(offset + (ywert)*highestx + (xwert - i)) == farbe) {
				farbenliste[i + 12 - 1][0] = -i + xwert;
				farbenliste[i + 12 - 1][1] = ywert;
				richtung4++;
			}
			if (*(offset + (ywert)*highestx + (-i + xwert)) != farbe) {//ungleich farbe, abbruch in dieser reihe
				d = false;
			}
		}


		differenz3 = 0;
		// nach rechts 
		tmp = (offset + xwert - arr);
		differenz3 = highestx - tmp - 1;
		if ((offset + (ywert)*highestx + (i + xwert)) >= ((arr + (highestx)*highesty))) {//pruefen ob out of bound unten 
			e = false;
		}
		if ((offset + (ywert)*highestx + (i + xwert)) > (offset + ywert * highestx + (differenz3 + xwert))) {
			e = false;
		}
		if (e == true) {
			if (*(offset + (ywert)*highestx + (i + xwert)) == farbe) {
				farbenliste[i + 9 - 1][0] = i + xwert;
				farbenliste[i + 9 - 1][1] = ywert;
				richtung5++;
			}
			if (*(offset + (ywert)*highestx + (i + xwert)) != farbe) {//ungleich farbe, abbruch in dieser reihe
				e = false;
			}
		}
		differenz3 = 0;
		// nach obenrechts 
		tmp = (offset + xwert - arr); // ueberarbeiten 
		differenz3 = highestx - tmp - 1;
		if ((offset + (ywert - i) * highestx + (i + xwert)) < (arr)) { //pruefen ob out of bound oben
			f = false;
		}
		if ((offset + (ywert - i) * highestx + (i + xwert)) < (offset + (ywert - differenz3) * highestx + (differenz3 + xwert))) {
			f = false;
		}
		if (f == true) {
			if (*(offset + (ywert - i) * highestx + (i + xwert)) == farbe) {
				farbenliste[i + 15 - 1][0] = i + xwert;
				farbenliste[i + 15 - 1][1] = ywert - i;
				richtung6++;
			}
			if (*(offset + (ywert - i) * highestx + (i + xwert)) != farbe) {//ungleich farbe, abbruch in dieser reihe
				f = false;
			}
		}


		differenz3 = 0;
		// nach unten links
		differenz3 = (offset + xwert - arr);
		if ((offset + (ywert + i) * highestx + (-i + xwert)) >= ((arr + (highestx)*highesty))) { //pruefen ob out of bound oben
			g = false;
		}
		if ((offset + (ywert + i) * highestx + (-i + xwert)) > (offset + (ywert + differenz3) * highestx + (-differenz3 + xwert))) { //ueruefen ob zeile verlassen, ueberarbeiten
			g = false;
		}
		if (g == true) {
			if (*(offset + (ywert + i) * highestx + (-i + xwert)) == farbe) {
				farbenliste[i - 1][0] = xwert - i;
				farbenliste[i - 1][1] = ywert + i;
				richtung7++;
			}
			if (*(offset + (ywert + i) * highestx + (-i + xwert)) != farbe) {//ungleich farbe, abbruch in dieser reihe
				g = false;
			}
		}

		//oben
		if ((offset + (ywert - i) * highestx + (xwert)) < (arr)) { //pruefen ob out of bound oben
			h = false;
		}
		if (h == true) {
			if (*(offset + (ywert - i) * highestx + (xwert)) == farbe) {
				farbenliste[i + 21 - 1][0] = xwert;
				farbenliste[i + 21 - 1][1] = ywert - i;
				richtung8++;
			}
			if (*(offset + (ywert - i) * highestx + (xwert)) != farbe) {//ungleich farbe, abbruch in dieser reihe
				h = false;
			}
		}



	}
	int reihe1 = richtung1 + richtung2; //obenlinks nach unten rechts
	int reihe2 = richtung3 + richtung8; // nach unten und oben
	int reihe3 = richtung4 + richtung5; // links nach rechts
	int reihe4 = richtung6 + richtung7; // obenrechts nach untenlinks
	if (reihe1 < 3) {
		for (int i = 0; i != 3; i++) {
			farbenliste[i + 18][1] = -1; //obenlinks
			farbenliste[i + 3][1] = -1; // untenrechts
		}
	}
	if (reihe2 < 3) {
		for (int i = 0; i != 3; i++) {
			farbenliste[i + 6][1] = -1; // unten
			farbenliste[i + 21][1] = -1; //oben
		}
	}
	if (reihe3 < 3) {
		for (int i = 0; i != 3; i++) {
			farbenliste[i + 12][1] = -1; //links
			farbenliste[i + 9][1] = -1; //rechts
		}
	}
	if (reihe4 < 3) {
		for (int i = 0; i != 3; i++) {
			farbenliste[i + 15][1] = -1; //obenrechts
			farbenliste[i][1] = -1; // untenlinks
		}
	}
	if ((reihe1 < 3) && (reihe2 < 3) && (reihe3 < 3) && (reihe4 < 3)) {
		farbenliste[24][1] = 0; // keine reihe gebilden, es wird nichts geloescht
	}

}

void loesche(int farbenliste[25][2], int highestx, int xwert, int ywert, int farbe, int highesty, int* offset) {//ueberpueft
	if (farbenliste[24][1] == 1) {
		if (*(offset + xwert + (highestx * ywert)) != auffuellwert) {
			*(offset + xwert + (highestx * ywert)) = auffuellwert;
			//*(offset2 + xwert) = *(offset2 + xwert) - 1; muss noch eingefuehrt werden
		}

		struct queue_pruefen* neu;

		if ((neu = (struct queue_pruefen*) malloc(sizeof(struct queue_pruefen))) != NULL) { // ueberdenken
			neu->ywert = ywert;
			neu->xwert = xwert;
			neu->farbe = farbe;
			neu->previous = NULL;
			put(neu);
		}
	}
	for (int i = 0; i < 24; i++) {
		if (farbenliste[24][1] == 0) {
			break;
		}
		if (farbenliste[i][1] == -1) {
			continue;
		}
		if (*(offset + farbenliste[i][0] + (highestx * farbenliste[i][1])) != auffuellwert) {
			*(offset + farbenliste[i][0] + (highestx * farbenliste[i][1])) = auffuellwert;
			//*(offset2 + xwert) = *(offset2 + xwert) - 1; muss noch eingefuehrt werden
		}
		*(offset + farbenliste[i][0] + (highestx * farbenliste[i][1])) = auffuellwert;

	}
}

void fallen(int farbenliste[25][2], int highestx, int xwert, int ywert, int farbe, int highesty, int* offset, int* arr) { //angepast
	int y = 0;


	for (int i = 0; i < 24; i++) {
		y = 0;
		if (farbenliste[24][1] == 0) {
			break;
		}
		if (farbenliste[i][1] == -1) {
			continue;
		}
		if (*(offset + farbenliste[i][0] + highestx * farbenliste[i][1]) != 260) {
			continue;
		}
		for (int k = 0; k < farbenliste[i][1] + 1; k++)
		{
			if ((offset + farbenliste[i][0] + highestx * (farbenliste[i][1] - k) < (arr))) {
				y++;
				break;
			}
			if (*(offset + farbenliste[i][0] + highestx * (farbenliste[i][1] - k)) != 260) {
				break;;
			}
			y = k;
		}


		for (int x = 0; x < highesty - 1; x++) {

			if ((offset + farbenliste[i][0] + highestx * (farbenliste[i][1] + x + 1)) >= (arr + highestx * highesty)) {
				for (int l = 0; l < highesty; l++) {
					if ((offset + farbenliste[i][0] + highestx * (highesty - y + l)) >= (arr + highestx * highesty)) {
						break;
					}
					*(offset + farbenliste[i][0] + highestx * (highesty - y + l - 1)) = 260;

				}
				break;
			}

			*(offset + farbenliste[i][0] + highestx * (farbenliste[i][1] - y + x)) = *(offset + farbenliste[i][0] + highestx * (farbenliste[i][1] + 1 + x));

		}

	}
	bool a = true;

	if (*(offset + xwert + highestx * (ywert)) != 260) {
		a = false;
	}
	if (a == true) {
		y = 0;
		for (int x = ywert; x < highesty; x++) {
			if (farbenliste[24][1] == 0) {
				break;
			}
			if ((offset + xwert + highestx * (ywert + y + 1)) >= (arr + highestx * highesty)) {
				break;
			}
			*(offset + xwert + highestx * (ywert + y)) = *(offset + xwert + highestx * (ywert + y + 1));
			y++;
		}
	}

}


void prueferaender(int ywert, int* offset, int highestx, int xwert, int highesty, int* arr, int farbenliste[25][2]) {//angepasst
	int farbe = 0;

	for (int i = highesty - 1; i > ywert - 4; i--) {


		int* differenz3 = (offset + xwert - 3);
		if (differenz3 < (arr)) {
			break;
		}
		if ((offset + i * highestx + (xwert - 3)) < (arr)) { //pruefen ob out of bound oben
			break;
		}
		farbe = *(offset + i * highestx + (xwert - 3));
		if (farbe == auffuellwert) {
			continue;
		}
		for (int x = 0; x < 25; x++) {
			farbenliste[x][0] = -1;
			farbenliste[x][1] = -1;
		}
		findblock(offset, xwert - 3, i, highestx, farbe, farbenliste, arr, highesty);

		if (farbenliste[24][1] == 1) {
			struct queue_loeschen* neu1;

			if ((neu1 = (struct queue_loeschen*) malloc(sizeof(struct queue_loeschen))) != NULL) { // ueberdenken
				for (int y = 0; y < 25; y++) {
					neu1->farbenliste[y][0] = farbenliste[y][0];
					neu1->farbenliste[y][1] = farbenliste[y][1];
				}
				neu1->xwert = xwert - 3;
				neu1->ywert = i;
				neu1->previous = NULL;
				put1(neu1);

			}
		}
		for (int x = 0; x < 25; x++) {
			farbenliste[x][0] = -1;
			farbenliste[x][1] = -1;
		}
	}

	for (int i = highesty - 1; i > ywert - 4; i--) {
		int tmp = (offset + (xwert + 3) - arr);
		int differenz3 = highestx - tmp - 1;

		if ((offset + (ywert)*highestx + (xwert + 3)) > (offset + (ywert)*highestx + (differenz3 + xwert))) {
			break;
		}
		if ((offset + i * highestx + (xwert + 3)) < (arr)) { //pruefen ob out of bound oben
			break;
		}
		farbe = *(offset + (i)*highestx + (xwert + 3));
		if (farbe == auffuellwert) {
			continue;
		}
		findblock(offset, xwert + 3, i, highestx, farbe, farbenliste, arr, highesty);
		if (farbenliste[24][1] == 1) {
			struct queue_loeschen* neu1;

			if ((neu1 = (struct queue_loeschen*) malloc(sizeof(struct queue_loeschen))) != NULL) { // ueberdenken
				for (int y = 0; y < 25; y++) {
					neu1->farbenliste[y][0] = farbenliste[y][0];
					neu1->farbenliste[y][1] = farbenliste[y][1];
				}
				neu1->xwert = xwert + 3;
				neu1->ywert = i;
				neu1->previous = NULL;
				put1(neu1);
			}
		}
		for (int x = 0; x < 25; x++) {
			farbenliste[x][0] = -1;
			farbenliste[x][1] = -1;
		}
	}


	for (int i = highesty - 1; i > ywert - 4; i--) {

		if ((offset + i * highestx + (xwert)) < (arr)) { //pruefen ob out of bound oben
			break;
		}
		farbe = *(offset + i * highestx + (xwert));
		if (farbe == auffuellwert) {
			continue;
		}
		for (int x = 0; x < 25; x++) {
			farbenliste[x][0] = -1;
			farbenliste[x][1] = -1;
		}
		findblock(offset, xwert, i, highestx, farbe, farbenliste, arr, highesty);

		if (farbenliste[24][1] == 1) {
			struct queue_loeschen* neu1;

			if ((neu1 = (struct queue_loeschen*) malloc(sizeof(struct queue_loeschen))) != NULL) { // ueberdenken
				for (int y = 0; y < 25; y++) {
					neu1->farbenliste[y][0] = farbenliste[y][0];
					neu1->farbenliste[y][1] = farbenliste[y][1];
				}
				neu1->xwert = xwert;
				neu1->ywert = i;
				neu1->previous = NULL;
				put1(neu1);

			}
		}
	}

}

void ueberpruefe_quadrat(int* offset, int highestx, int ywert, int xwert, int* arr, int highesty, int farbenliste[25][2]) { //angepasst
	int farbe;


	for (int i = 0; i != 5; i++) {

		for (int y = 0; y != 5; y++) {



			int* differenz3 = (offset + xwert - 2);
			if (differenz3 + y < (arr)) {
				continue;
			}

			int tmp = (offset + (xwert)-arr);
			int differenz4 = highestx - tmp - 1;
			if (2 - y > differenz4) {
				continue;
			}


			if ((offset + (ywert - i + 2) * highestx + (xwert + 2 - y)) >= ((arr + (highestx)*highesty))) {
				continue;
			}
			if ((offset + (ywert - i + 2) * highestx + (xwert + 2 - y)) < (arr)) {

				continue;
			}
			farbe = *(offset + (ywert - i + 2) * highestx + (xwert + 2 - y)); //diagonale obenlinks bis untenrechts
			if (farbe == auffuellwert) {
				continue;
			}
			for (int x = 0; x < 25; x++) {
				farbenliste[x][0] = -1;
				farbenliste[x][1] = -1;
			}
			findblock(offset, xwert + 2 - y, ywert + 2 - i, highestx, farbe, farbenliste, arr, highesty);
			if (farbenliste[24][1] == 1) {
				struct queue_loeschen* neu;

				if ((neu = (struct queue_loeschen*) malloc(sizeof(struct queue_loeschen))) != NULL) { // ueberdenken
					for (int m = 0; m < 25; m++) {
						neu->farbenliste[m][0] = farbenliste[m][0];
						neu->farbenliste[m][1] = farbenliste[m][1];
					}

					neu->xwert = xwert + 2 - y;
					neu->ywert = ywert + 2 - i;
					neu->previous = NULL;

					put1(neu);
				}
			}

			for (int x = 0; x < 25; x++) {
				farbenliste[x][0] = -1;
				farbenliste[x][1] = -1;
			}
		}


	}


}


int main() { // angepast bis auf ausgabe

	int* arr = malloc(9 * sizeof(int));
	if (NULL == arr) {
		fprintf(stderr, "Es konnte kein Speicher assoziiert werden");
		free(arr);
		return -1;
	}
	for (int i = 0; i != 9; i++) {
		*(arr + i) = auffuellwert;
	}

	int* offset = (arr + 1);

	char farbearray[3];
	int farbenliste[25][2];
	char xwertarray[8];
	bool nullen = true;
	bool links = true;
	int zahl = 0;
	int index = 1;
	int index2 = 0;
	int count = 0;
	int count2 = 0;
	int count3 = 0;
	int test;
	int xwert = 0;
	int farbe = 0;
	int highestx = 3;
	int highesty = 3;
	int umwandlung = 0;
	int ywert = 0;
	int* tmp;
	int findy;


	/*fp = fopen(argv[1], "r");
	if (fp == NULL) {
		printf(stderr, "leere datei");
		free(arr);
		return -1; // bricht ab wenn die datei leer ist 
	}*/
	char c;
	while (true)
	{
		while ((c = getc(stdin)) != EOF)
		{
			if ((c == '0') && (nullen == true)) {
				if (links == false) {
					count3++;

				}
				continue;
			}

			if (c == ' ') {
				if (links == true) {
					if (nullen == true) {
						count3++;
					}
					zahl++;
				}
				if (count3 >= 2) {
					zahl++;
				}
				nullen = true;
				links = false;
				continue;
			}
			if (c == '-') {
				xwertarray[0] = c;
				continue;
			}
			if (c == '\n') {
				if ((count3 < 2)) {
					fprintf(stderr, "unguelltige Eingabe.");
					free(arr);
					return -1;
				}
				if (zahl >= 2) {
					fprintf(stderr, "unguelltige Eingabe.");
					free(arr);
					return -1;
				}
				break;

			}
			if (c < '0' || c > '9') {
				fprintf(stderr, "unguelltige Eingabe.");
				free(arr);
				return -1;
			}

			if (c == '0' - '0') {
				fprintf(stderr, "unguelltige Eingabe.");
				free(arr);
				return -1;
			}

			if (c != '0' && nullen == true && links == true) {
				nullen = false;
				if (index2 > 2) {
					fprintf(stderr, "unguelltige Eingabe.");
					free(arr);
					return -1;
				}
				farbearray[index2] = c;
				count2++;
				if (count2 == 1) {
					count3++;
				}
				index2++;
				continue;
			}
			if ((nullen == false) && (links == true)) {
				if (index2 > 2) {
					fprintf(stderr, "unguelltige Eingabe.");
					free(arr);
					return -1;
				}
				farbearray[index2] = c;
				count2++;
				index2++;
				continue;

			}
			if ((c != '0') && (nullen == true) && (links == false)) {
				if (index > 8) {
					fprintf(stderr, "unguelltige Eingabe.");
					free(arr);
					return -1;
				}
				nullen = false;
				xwertarray[index] = c;
				count++;
				if (count == 1) {
					count3++;
				}
				index++;

				continue;
			}
			if ((nullen == false) && (links == false)) {
				if (index > 8) {
					fprintf(stderr, "unguelltige Eingabe.");
					free(arr);
					return -1;
				}
				xwertarray[index] = c;
				count++;
				index++;
				continue;

			}


		}

		for (int x = 0; x != count; x++) {
			test = count - x;
			umwandlung = (int)xwertarray[test] - '0';
			xwert = xwert + umwandlung * powtest(10, x);
		}
		if (xwertarray[0] == '-') {
			xwert = xwert * -1;
		}
		test = 0;
		for (int x = 0; x != count2; x++) {
			test = count2 - x - 1;
			umwandlung = (int)farbearray[test] - '0';
			farbe = farbe + umwandlung * powtest(10, x);
		}
		if ((farbe > 254) || (farbe < 0)) {
			fprintf(stderr, "falsche Farbe");
			free(arr);
			return -1;
		}
		if (xwert > 1048576) {
			fprintf(stderr, "zu grosses x");
			free(arr);
			return -1;
		}
		if (xwert < -1048576) {
			fprintf(stderr, "zu kleines  x");
			free(arr);
			return -1;
		}

		int differenz = offset - arr; //differenz um zu gucken ob und in welche richtung erweitert werden muss, ( rechts richtung )
		if (xwert > (highestx - differenz - 1)) {
			int* ptr;
			int* ptr2;
			int altx1 = highestx;
			highestx = highestx + (xwert - (highestx - differenz - 1));// highestx um das was xwert nach rechts raus zugross ist erhoehen n

			arr = realloc(arr, ((highestx) * (highesty)) * sizeof(int));
			offset = arr + differenz;
			if (NULL == arr) {
				fprintf(stderr, "Es konnte kein Speicher assoziiert werden.");
				free(arr);
				return -1;
			}
			for (int i = 0; i < highesty; i++) {// jede alte zeile wird an das richtige aende verschoben
				ptr = arr + altx1 * (highesty - 1 - i);  // anfang alte zeile 
				ptr2 = arr + highestx * (highesty - 1 - i); // anfang neue zeile 
				memmove(ptr2, ptr, ((altx1)) * sizeof(int));
			}
			for (int f = 0; f < highesty; f++) { // auffuellen der neuen zellen
				for (int a = altx1; a != highestx; a++) {
					*(arr + a + highestx * f) = auffuellwert;
				}
			}


		}


		int differenz1 = arr - offset;
		if (xwert < differenz1) {// gucken ob xwert nach links ausbricht
			int* ptr;
			int* ptr2;
			int altx = highestx;
			highestx = ((xwert - (highestx - differenz))) * -1; //neues highestx 


			arr = realloc(arr, ((highestx) * (highesty)) * sizeof(int));
			offset = (arr + (xwert * -1));
			if (NULL == arr) {
				fprintf(stderr, "Es konnte kein Speicher assoziiert werden.");
				free(arr);
				return -1;
			}

			for (int i = 0; i < highesty; i++) { // jede alte zeile wird an das richtige aende verschoben
				ptr = arr + altx * (highesty - 1 - i);
				ptr2 = arr + highestx * (highesty - 1 - i) + (xwert - differenz1) * -1; // nochmal anschauen
				memmove(ptr2, ptr, ((altx)) * sizeof(int));
			}
			for (int f = 0; f < highesty; f++) {
				for (int a = 0; a != (xwert - differenz1) * -1; a++) {
					*(arr + a + highestx * f) = auffuellwert;
				}
			}
		}

		for (int i = 0; i < 8; i++) {
			xwertarray[i] = 0;
		}
		for (int i = 0; i < 3; i++) {
			farbearray[i] = 0;
		}
		findy = highesty / 2;
		ywert = 0;
		int oben = 0;
		int unten = highesty - 1;
		while (true) {
			if (findy == 0) {
				break;
			}
			if (findy == highesty - 1) {
				break;
			}
			tmp = offset + highestx * findy + xwert;
			if (*tmp == 260) {
				if (*(offset + highestx * (findy - 1) + xwert) == 260) {
					unten = findy;
					findy = oben + ((unten - oben) / 2);
					continue;
				}
				break;
			}
			if (*tmp != 260) {
				if (*(offset + highestx * (findy + 1) + xwert) == 260) {
					findy++;
					break;
				}
				oben = findy;
				findy = oben + ((unten - oben) / 2);
				continue;
			}
		}

		if (findy == highesty - 1) {
			arr = realloc(arr, (highestx * (highesty + 1)) * sizeof(int));
			offset = arr + differenz;
			if (NULL == arr) {
				fprintf(stderr, "Es konnte kein Speicher assoziiert werden");
				free(arr);
				return -1;
			}
			for (int g = 0; g < highestx; g++) {
				*(arr + g + highestx * highesty) = 260;
			}
			highesty++;
		}
		ywert = findy;
		*(offset + xwert + highestx * ywert) = farbe;

		for (int s = 0; s < 25; s++) {
			farbenliste[s][0] = -1;
			farbenliste[s][1] = -1;

		}
		int queue = queue_init();
		if (queue == -1) {
			fprintf(stderr, "es konnte keinen Speicher reserviert werden!\n");
			free(arr);
			return -1;
		}
		queue = queue_init1();
		if (queue == -1) {
			fprintf(stderr, "es konnte keinen Speicher reserviert werden!\n");
			free(arr);
			return -1;
		}


		findblock(offset, xwert, ywert, highestx, farbe, farbenliste, arr, highesty);
		if (farbenliste[24][1] == 1) {

			loesche(farbenliste, highestx, xwert, ywert, farbe, highesty, offset);
			fallen(farbenliste, highestx, xwert, ywert, farbe, highesty, offset, arr);


			while (dummy->previous != NULL) { // solange 1 element in der puefenqueue drinne ist 

				xwert = dummy->previous->xwert;
				ywert = dummy->previous->ywert;
				farbe = dummy->previous->farbe;
				for (int s = 0; s < 25; s++) {
					farbenliste[s][0] = -1;
					farbenliste[s][1] = -1;
				}
				prueferaender(ywert, offset, highestx, xwert, highesty, arr, farbenliste);

				for (int s = 0; s < 25; s++) {
					farbenliste[s][0] = -1;
					farbenliste[s][1] = -1;
				}

				ueberpruefe_quadrat(offset, highestx, ywert, xwert, arr, highesty, farbenliste);
				for (int s = 0; s < 25; s++) {
					farbenliste[s][0] = -1;
					farbenliste[s][1] = -1;
				}
				get();
				if (dummy->previous == NULL) {
					while (dummy1->previous != NULL) {
						struct queue_loeschen* zeiger;
						zeiger = dummy1;

						while (zeiger->previous != NULL) {
							zeiger = zeiger->previous;
							xwert = zeiger->xwert;
							ywert = zeiger->ywert;

							for (int i = 0; i < 25; i++) {
								farbenliste[i][0] = zeiger->farbenliste[i][0];
								farbenliste[i][1] = zeiger->farbenliste[i][1];
							}
							loesche(farbenliste, highestx, xwert, ywert, farbe, highesty, offset);
							for (int s = 0; s < 25; s++) {
								farbenliste[s][0] = -1;
								farbenliste[s][1] = -1;
							}
						}
						while (dummy1->previous != NULL) {
							zeiger = dummy1->previous->previous;
							xwert = dummy1->previous->xwert;
							ywert = dummy1->previous->ywert;

							for (int i = 0; i < 25; i++) {
								farbenliste[i][0] = dummy1->previous->farbenliste[i][0];
								farbenliste[i][1] = dummy1->previous->farbenliste[i][1];
							}

							fallen(farbenliste, highestx, xwert, ywert, farbe, highesty, offset, arr);

							for (int s = 0; s < 25; s++) {
								farbenliste[s][0] = -1;
								farbenliste[s][1] = -1;
							}
							get1();
						}




					}
				}
			}
		}



		if (c == EOF) {
			break;
		}
		zahl = 0;
		nullen = true;
		links = true;
		index = 1;
		index2 = 0;
		count = 0;
		count2 = 0;
		count3 = 0;
		xwert = 0;
		farbe = 0;
		ywert = 0;
		

	}


	int wrerr;
	int wrerr2;

	for (int i = 0; i < highesty; i++) {
		for (int y = 0; y < highestx; y++)
		{
			if (*(arr + y + i * highestx) == 260) {
				continue;
			}
			wrerr = arr - offset;
			wrerr2 = wrerr + y;
			fprintf(stdout, "%i %i %i\n", *(arr + y + i * highestx), wrerr2, i);
		}

	}
	free(arr);
	return 0;
}
