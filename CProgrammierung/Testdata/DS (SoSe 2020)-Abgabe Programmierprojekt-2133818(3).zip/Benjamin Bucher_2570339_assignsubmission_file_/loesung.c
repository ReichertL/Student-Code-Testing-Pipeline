#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h> //_Bool
#include <limits.h>

// Dynamisch wachsendes Array
struct DynArray {
    int len;
    int cap;
    int item_size;
    void* ptr;
};


// Repräsentiert das Spielfeld
struct Game {
    struct DynArray columns; // DynArray von Spalten (auch wieder DynArrays)
    int offset; // Verschiebung, Index 0 -> kleinstes x von Blöcken die eingegeben wurden
};

struct BuffInput {
    int i;
    int len;
    unsigned char buff[131072];
};

struct InputBlock {
    int x;
    unsigned char color;
};


struct Coordinate {
    int x;
    int y;
};

#ifdef STATS
int root_move_count = 0;
int ver = 0;
int hor = 0;
int dial = 0;
int diar = 0;
#endif

// Globale pointer, genutzt für einfache free Anwendung
struct DynArray* columns_ptr = 0;
struct DynArray* to_destroy_ptr = 0; // beinhaltet Koordinaten von zu löschenden Blöcken
struct DynArray* cuts_ptr = 0;
struct DynArray* changed_lines_ptr = 0;
int** columns_first_touched_ptr = 0;
struct DynArray* column_first_touched_ptr = 0;

void free_all() {
    if (columns_ptr != 0) {
	struct DynArray* columns = columns_ptr->ptr;
	for (int i = 0; i < columns_ptr->len; i++) {
	    free(columns[i].ptr);
	}
	free(columns_ptr->ptr);
    }
    if (to_destroy_ptr != 0) {
	free(to_destroy_ptr->ptr);
    }
    if (cuts_ptr != 0) {
	free(cuts_ptr->ptr);
    }
    if (changed_lines_ptr != 0) {
	free(changed_lines_ptr->ptr);
    }
    if (columns_first_touched_ptr != 0) {
	free(*columns_first_touched_ptr);
    }
    if (column_first_touched_ptr != 0) {
	free(column_first_touched_ptr->ptr);
    }
}

void fail_exit() {
    free_all();
    exit(-1);
}

// malloc wrapper zur sicheren Fehlerbehandlung
void* myalloc(int c) {
    void* ptr = malloc(c);
    if (ptr == 0) {
	fprintf(stderr, "malloc failed.\n");
	fail_exit();
    }
    return ptr;
}

// realloc wrapper zur sicheren Fehlerbehandlung
void* mealloc(void* ptr, int c) {
    ptr = realloc(ptr, c);
    if (ptr == 0) {
	fprintf(stderr, "realloc failed.\n");
	fail_exit();
    }
    return ptr;
}

// füllt den input buffer wieder auf
void input_buff_reset(struct BuffInput* input) {
    input->i = 0;
    input->len = fread(input->buff, 1, sizeof(input->buff), stdin);
    if (input->len != sizeof(input->buff)) {
	if (ferror(stdin) != 0) {
	    fail_exit();
	}
    }
}

// ähnlich zu fgetc
int input_buff_next(struct BuffInput* input) {
    if (input->i >= input->len) {
	if (input->len != sizeof(input->buff)) {
	    return EOF;
	}
	input_buff_reset(input);
    }
    return input->buff[input->i++];
}

// Für den Input zuständige Funktion
int get_block(struct InputBlock* block, struct BuffInput* input_buff) {
    char c = input_buff_next(input_buff);
    if (c == EOF) {
	return EOF;
    }
    //printf("first char in line: %c\n", c);
    while (c < '0' || c > '9') {
	if (c != ' ') {
	    fprintf(stderr, "Invalides Symbol vor der Zahl für die Farbe.\n");
	    fail_exit();
	}
	c = input_buff_next(input_buff);
	printf("spacebar skip char: %c\n", c);
    }
    int color = c - '0';
    //printf("color (init): %d\n", color);
    c = input_buff_next(input_buff);
    while (c >= '0' && c <= '9') {
	color *= 10;
	color += c - '0';
	//printf("color: %d\n", color);
	if (color >= 255) {
	    fprintf(stderr, "Die Zahl für die Farbe ist zu hoch.\n");
	    fail_exit();
	}
	c = input_buff_next(input_buff);
    }
    //printf("conversion of color, original: %d, result: %d", color, (unsigned char) color);
    block->color = (unsigned char) color;
    int sign = 1;
    while (c < '0' || c > '9') {
	if (c == '-') {
	    sign = -1;
	    c = input_buff_next(input_buff);
	    break;
	}
	if (c != ' ') {
	    fprintf(stderr, "Invalides Symbol vor der Zahl für die Position.\n");
	    fail_exit();
	}
	c = input_buff_next(input_buff);
    }
    int pos = c - '0';
    c = input_buff_next(input_buff);
    while (c >= '0' && c <= '9') {
	pos *= 10;
	pos += c - '0';
	if (pos > 1048576) { // 2^20
	    fprintf(stderr, "Die Zahl für die Position ist zu hoch.\n");
	    fail_exit();
	}
	c = input_buff_next(input_buff);
    }
    if (c != '\n' && c != EOF) {
	fprintf(stderr, "Invalides Symbol nach der Zahl für die Position, nur Zeilenumbruch und 'EOF' erlaubt.\n");
	fail_exit();
    }
    block->x = sign * pos;
    return 0;
}

void print_block(struct InputBlock block, int offset) {
    printf("\nNew Block: color : %d\n", block.color);
    printf("           pos   : %d\n", block.x);// - offset);
    offset++;
}

void print_column(struct DynArray* c) {
    printf("\nCurrent Column: cap : %d\n", c->cap);
    printf("                len : %d\n", c->len);
}

// Konstruktor für dynamische Arrays
struct DynArray dyn_array_init(int item_size) {
    struct DynArray arr;
    arr.len = 0;
    arr.cap = 8;
    arr.item_size = item_size;
    arr.ptr = myalloc(arr.cap * arr.item_size);
    if (arr.ptr == 0) {
	printf("Allocated null pointer");
    }
    return arr;
}

// zum freeen von dynamischen Arrays
void absolutely_demolish(struct DynArray* arr) {
    free(arr->ptr);
}

// zum Zurücksetzten von dynamischen Arrays
void absolutely_reset(struct DynArray* arr) {
    arr->len = 0;
}

// zum Anfügen von Elementen an dynamische Arrays
int append(struct DynArray* arr, void* new_element) {
    if (arr->len == arr->cap) {
	arr->cap *= 2;
	arr->ptr = mealloc(arr->ptr, arr->cap * arr->item_size);
	if (arr->ptr == 0) {
	    fail_exit();
	}
    }
    unsigned char* ptr = arr->ptr;
    memcpy(ptr + (arr->len * arr->item_size), new_element, arr->item_size);
    arr->len += 1;
    return arr->len - 1;
}

int cmp_int(const void* a, const void* b) {
    return *(const int*)a - *(const int*)b;
}

void sort_ints(struct DynArray* arr) {
    qsort(arr->ptr, arr->len, sizeof(int), cmp_int);
}

// gibt Pointer eines Elementes zurück
void* get_raw(struct DynArray* arr, int index) {
    unsigned char* ptr = arr->ptr;
    return ptr + (index * arr->item_size);
}

// zum Einfügen von Elementen an einen bestimmten Index
int insert_at(struct DynArray* arr, void* new_element, int index) {
    if (index < 0 || index >= arr->cap) {
	printf("Array OOB\n");
	fail_exit();
    }
    memcpy(get_raw(arr, index), new_element, arr->item_size);
    return 0;
}

// zum Erhöhen der Kapazität eines Arrays
void raw_increase_capacity(struct DynArray* arr, int min) {
    while(arr->cap <= min) {
	arr->cap *= 2;
    }
    //printf("pointer: %p\n", arr->ptr); //DEBUG
    //printf("cap: %d, item_size: %d\n", arr->cap, arr->item_size); //DEBUG
    arr->ptr = mealloc(arr->ptr, arr->cap * arr->item_size);
}

// Für leicht lesbare Ausgabe des Spielfeldes
void draw_game(struct Game* game) {
    fprintf(stderr, "\nOffset : %d\n", game->offset);
    fprintf(stderr, "Columns: %d\n", game->columns.len);
    struct DynArray* game_columns = game->columns.ptr;
    for (int i = 0; i < game->columns.len; i++) {
	struct DynArray* column = &game_columns[i];
	unsigned char* blocks = column->ptr;

	fprintf(stderr, "%d|", column->len);
	for (int j = 0; j < column->len; j++) {
	    fprintf(stderr, "%d", blocks[j]);
	}
	fprintf(stderr, "\n");
    }
}

// schreibt eine Zahl an den übergebenen Pointer, gibt Anzahl von geschriebenen Zeichen zurück
int write_int(char* ptr, int n) {
    char buff[8]; // zugeschnitten auf x-Koordinate, diese kann höchstens 8 Zeichen lang sein (mit Vorzeichen)
    int i = 7;
    bool negative = false;
    if (n == 0) {
	ptr[0] = '0';
	return 1;
    }
    if (n < 0) {
	negative = true;
	n = -n;
    }
    while (n != 0) {
	buff[i] = (char)(n % 10) + '0';
	n /= 10;
	i -= 1;
    }
    if (negative) {
	buff[i] = '-';
	i -= 1;
    }
    int len = 7 - i;
    memcpy(ptr, buff + i + 1, len);
    return len;
}

// schreibt eine unsigned char an den übergebenen Pointer, gibt Anzahl von geschriebenen Zeichen zurück
int write_unsigned_char(char* ptr, unsigned char n) {
    char buff[3];
    int i = 2;
    if (n == 0) {
	ptr[0] = '0';
	return 1;
    }
    while (n != 0) {
	buff[i] = (char)(n % 10) + '0';
	n /= 10;
	i -= 1;
    }
    int len = 2 - i;
    memcpy(ptr, buff + i + 1, len);
    return len;
}

// Für Aufgaben-konforme Ausgabe
void output_game(struct Game* game) {
    char buff[16384];
    int len = 0;
    struct DynArray* columns = game->columns.ptr;
    for (int i = 0; i < game->columns.len; i++) {
	struct DynArray* column = &columns[i];
	unsigned char* blocks = column->ptr;
	for (int j = 0; j < column->len; j++) {
	    if (len > 8192) {
		if (fwrite(buff, 8192, 1, stdout) != 1) {
		    fail_exit();
		}
		len -= 8192;
		memcpy(buff, buff + 8192, len);
	    }
	    len += write_unsigned_char(buff + len, blocks[j]);
	    buff[len] = ' ';
	    len += 1;
	    len += write_int(buff + len, i + game->offset);
	    buff[len] = ' ';
	    len += 1;
	    len += write_int(buff + len, j);
	    buff[len] = '\n';
	    len += 1;
	    //printf("%d %d %d\n", blocks[j], i + game->offset, j);
	}
    }
    if (fwrite(buff, len, 1, stdout) != 1) {
	fail_exit();
    }
}

// Erweitert das Spalten-Array nach vorne
//__attribute__ ((noinline))
int expand_game_forwards(struct Game* game, int x) {
    int diff = x - (game->columns.len - 1);
    for (int i = 0; i < diff; i++) {
	struct DynArray new_column = dyn_array_init(sizeof(unsigned char));
	if (append(&game->columns, &new_column) == -1) { // initialisiert alls Spalten
	    fail_exit();
	};
    }
    return 0;
}

// Erweitert das Spalten-Array nach hinten
//__attribute__ ((noinline))
int expand_game_backwards(struct Game* game, int x) {
    int diff = -x;
    raw_increase_capacity(&game->columns, game->columns.len + diff);
    unsigned char* ptr = game->columns.ptr;
    memmove(ptr + ((game->columns.cap - game->columns.len) * game->columns.item_size), ptr, game->columns.len * game->columns.item_size); // verschiebt alle Elemente nach hinten
    for (int i = 0; i < game->columns.cap - game->columns.len; i++) {
	struct DynArray new_column = dyn_array_init(sizeof(unsigned char));
	if (insert_at(&game->columns, &new_column, i) == -1) { // initialisiert alls Spalten
	    printf("unreachable: (expand_game_backwards) oob game column access\n");	
	    fail_exit();
	}
    }
    game->offset += game->columns.len - game->columns.cap;
    game->columns.len = game->columns.cap;
    return 0;
}

// Organisiert das Erweitern des Spalten-Arrays falls nötig
int resize_game(struct Game* game, int x) {
    if (x >= game->columns.len) {
	expand_game_forwards(game, x);
    }
    if (x < 0) {
#ifdef STATS
	root_move_count += 1;
#endif
	expand_game_backwards(game, x);
    }
    return 0;
}

// Schrumpft Spalten, nachdem einzelne Blöcke gelöscht wurden
void flatten(struct DynArray* column, int x, struct DynArray* cuts, struct DynArray* column_first_touched, int first_touched) {
    unsigned char* blocks = column->ptr;
    int skipped = 0;
    bool first_skipped = true;
    for (int i = first_touched; i < column->len; i++) {
	if (blocks[i] == 255) { // 255 -> Hier wurde ein Block gelöscht
	    int cut_pos = i - skipped;
	    append(cuts, &cut_pos);
	    if (first_skipped && i != column->len - 1) {
		struct Coordinate coor;
		coor.x = x;
		coor.y = i;
		append(column_first_touched, &coor);
		first_skipped = false;
	    }
	    skipped++;
	}
	else {
	    blocks[i - skipped] = blocks[i]; // verschiebt die nicht gelöschten Blöcke
	}
    }
    for (int i = column->len - skipped; i < column->len; i++) {
	blocks[i] = 255;
    }
    column->len -= skipped;
}

// Bekommt Koordinaten (to_destroy), an denen Blöcke gelöscht werden sollen, löscht diese
void empty_blocks(struct Game* game, struct DynArray* to_destroy, struct DynArray* changed_lines, int* columns_first_touched) {
    struct DynArray* columns = game->columns.ptr;
    struct Coordinate* coordinates = to_destroy->ptr;
    for (int i = 0; i < to_destroy->len; i++) {
	struct Coordinate* coor = &coordinates[i];
	unsigned char* column_blocks = columns[coor->x].ptr;
	column_blocks[coor->y] = 255;
	append(changed_lines, &coor->x);
	if (coor->y < columns_first_touched[coor->x]) {
	    columns_first_touched[coor->x] = coor->y;
	}
    }
}

// Überprüft ob vertikal gelöscht werden muss bei einem new plazierten Block
//__attribute__ ((noinline))
bool initial_vertical(struct Game* game, struct Coordinate xy, struct DynArray* to_destroy) {
    struct DynArray* columns = game->columns.ptr;
    if (columns[xy.x].len < 4) {
	return false;
    }
    unsigned char* column_blocks = columns[xy.x].ptr;
    unsigned char color = column_blocks[xy.y];
    for (int i = 1; i <= 3; i++) {
	if (column_blocks[xy.y - i] != color) {
	    return false;
	}
    }
#ifdef STATS
    ver += 1;
#endif
    struct Coordinate coor;
    coor.x = xy.x;
    for (int i = 0; i < 4; i++) {
	coor.y = xy.y - i;
	append(to_destroy, &coor);
    }
    return true;
}

// Überprüft ob horizontal gelöscht werden muss bei einem new plazierten Block
bool initial_horizontal(struct Game* game, struct Coordinate xy, struct DynArray* to_destroy) {
    struct DynArray* columns = game->columns.ptr;
    unsigned char* blocks = columns[xy.x].ptr;
    int color = blocks[xy.y];
    int count = 1;
    for (int i = -1; i > -4; i--) {
	if (xy.x + i < 0) {
	    break;
	}
	struct DynArray* column = &columns[xy.x + i];
	if (column->len <= xy.y) {
	    break;
	}
	blocks = column->ptr;
	if (blocks[xy.y] != color) {
	    break;
	}
	count += 1;
    }
    int last = 0;
    for (int i = 1; i < 4; i++) {
	if (xy.x + i >= game->columns.len) {
	    break;
	}
	struct DynArray* column = &columns[xy.x + i];
	if (column->len <= xy.y) {
	    break;
	}
	blocks = column->ptr;
	if (blocks[xy.y] != color) {
	    break;
	}
	count += 1;
	last += 1;
    }
    if (count >= 4) {
#ifdef STATS
	hor += 1;
#endif
	struct Coordinate coor;
	coor.y = xy.y;
	for (int i = 0; i < count; i++) {
	    coor.x = xy.x + last - i;
	    append(to_destroy, &coor);
	}
	return true;
    }
    return false;
}

// Überprüft ob diagonal gelöscht werden muss bei einem new plazierten Block
bool initial_diagonal(struct Game* game, struct Coordinate xy, struct DynArray* to_destroy) {
    bool anything_destroyed = false;
    struct DynArray* columns = game->columns.ptr;
    unsigned char* blocks = columns[xy.x].ptr;
    int color = blocks[xy.y];
    int count = 1;
    int y = 0;
    // up left to down right first
    for (int i = -1; i > -4; i--) {
	y += 1;
	if (xy.x + i < 0) {
	    break;
	}
	struct DynArray* column = &columns[xy.x + i];
	if (column->len <= xy.y + y) {
	    break;
	}
	blocks = column->ptr;
	if (blocks[xy.y + y] != color) {
	    break;
	}
	count += 1;
    }
    int last = 0;
    y = 0;
    for (int i = 1; i < 4; i++) {
	y -= 1;
	if (xy.x + i >= game->columns.len) {
	    break;
	}
	struct DynArray* column = &columns[xy.x + i];
	if (column->len <= xy.y + y) {
	    break;
	}
	if (xy.y + y < 0) {
	    break;
	}
	blocks = column->ptr;
	if (blocks[xy.y + y] != color) {
	    break;
	}
	count += 1;
	last += 1;
    }
    if (count >= 4) {
	anything_destroyed = true;
#ifdef STATS
	diar += 1;
#endif
	struct Coordinate coor;
	y = -last;
	for (int i = 0; i < count; i++) {
	    coor.x = xy.x + last - i;
	    coor.y = xy.y + y;
	    append(to_destroy, &coor);
	    y += 1;
	}
    }
    count = 1;
    y = 0;
    // then down left to up right
    for (int i = -1; i > -4; i--) {
	y -= 1;
	if (xy.x + i < 0) {
	    break;
	}
	struct DynArray* column = &columns[xy.x + i];
	//printf("dynarray len: %d, y: %d\n", column->len, xy.y + y); //DEBUG
	if (column->len <= xy.y + y) {
	    break;
	}
	if (xy.y + y < 0) {
	    break;
	}
	blocks = column->ptr;
	if (blocks[xy.y + y] != color) {
	    break;
	}
	count += 1;
    }
    last = 0;
    y = 0;
    for (int i = 1; i < 4; i++) {
	y += 1;
	if (xy.x + i >= game->columns.len) {
	    break;
	}
	struct DynArray* column = &columns[xy.x + i];
	if (column->len <= xy.y + y) {
	    break;
	}
	blocks = column->ptr;
	if (blocks[xy.y + y] != color) {
	    break;
	}
	count += 1;
	last += 1;
	//printf("\neins nach oben links\n"); //DEBUG
    }
    if (count >= 4) {
	anything_destroyed = true;
#ifdef STATS
	dial += 1;
#endif
	//printf("\n DESTROY 2\n"); //DEBUG
	struct Coordinate coor;
	y = last;
	for (int i = 0; i < count; i++) {
	    coor.x = xy.x + last - i;
	    coor.y = xy.y + y;
	    append(to_destroy, &coor);
	    y -= 1;
	}
    }
    return anything_destroyed;
}

// Zum iterativen Überprüfen, ob vertikal Blöcke gelöscht werden müssen
void general_vertical(struct DynArray* column, int x, struct DynArray* cuts, struct DynArray* to_destroy) {
    if (column->len < 4) {
	return;
    }
    unsigned char* blocks = column->ptr;
    int* cut_positions = cuts->ptr;
    for (int k = 0; k < cuts->len; k++) {
	int cut_pos = cut_positions[k];
	if (cut_pos >= column->len || cut_pos == 0) {
	    continue;
	}
	unsigned char upper_color = blocks[cut_pos];
	unsigned char lower_color = blocks[cut_pos - 1];
	if (upper_color != lower_color) {
	    continue;
	}
	int lower_count = 1;
	for (int y_offset = -2; y_offset >= -3; y_offset--) {
	    int y = cut_pos + y_offset;
	    if (y < 0) {
		break;
	    }
	    if (blocks[y] != lower_color) {
		break;
	    }
	    lower_count += 1;
	}
	int upper_count = 1;
	for (int y_offset = 1; y_offset <= 2; y_offset++) {
	    int y = cut_pos + y_offset;
	    if (y >= column->len) {
		break;
	    }
	    if (blocks[y] != upper_color) {
		break;
	    }
	    upper_count += 1;
	}
	int count = upper_count + lower_count;
	if (count >= 4) {
	    struct Coordinate coor;
	    coor.x = x;
	    for (int y_offset = 0; y_offset < count; y_offset++) {
		coor.y = cut_pos - lower_count + y_offset;
		append(to_destroy, &coor);
	    }
	}
    }
}

// überprüft eine horizontale Linie mit gebenen Startpunkt und Länge auf 4-er Blöcke
void check_horizontal(struct DynArray* columns, int start_x, int y, int len, struct DynArray* to_destroy) {
    int first_x = start_x + 3;
    int count = 1;
    unsigned char color = 255;
    if (y < columns[first_x].len) {
	color = ((unsigned char*)columns[first_x].ptr)[y];
	for (int back_step = 2; back_step >= 0; back_step--) {
	    int x = start_x + back_step;
	    if (y >= columns[x].len) {
		break;
	    }
	    if (color != ((unsigned char*)columns[x].ptr)[y]) {
		break;
	    }
	    count += 1;
	}
    }
    for (int step = 4; step < len; step++) {
	int x = start_x + step;
	if (columns[x].len <= y) {
	    color = 255;
	}
	else {
	    unsigned char new_color = ((unsigned char*)columns[x].ptr)[y];
	    if (new_color != color) {
		color = new_color;
	    }
	    else {
		count += 1;
		continue;
	    }
	}
	if (count >= 4) {
	    struct Coordinate coor;
	    coor.y = y;
	    for (int back_steps = 1; back_steps <= count; back_steps++) {
		coor.x = x - back_steps;
		append(to_destroy, &coor);
	    }
	}
	if (len - step < 4) {
	    return;
	}
	count = 1;
    }
    if (count >= 4) {
	struct Coordinate coor;
	coor.y = y;
	for (int back_steps = 1; back_steps <= count; back_steps++) {
	    coor.x = start_x + len - back_steps;
	    append(to_destroy, &coor);
	}
    }
}

// Zum iterativen Überprüfen, ob horizontal Blöcke gelöscht werden müssen
void general_horizontal(struct Game* game, struct DynArray* to_destroy, int min, int max, int real_first, int real_last) {
    struct DynArray* columns = game->columns.ptr;
    int len = real_last - real_first + 1;

    for (int y = min; y <= max; y++) {
	check_horizontal(columns, real_first, y, len, to_destroy);
    }
}

// überprüft eine diagonale Linie mit gebenen Startpunkt, Länge und Richtung auf 4-er Blöcke
void check_diagonal(struct DynArray* columns, int start_x, int start_y, int step_max, int direction, struct DynArray* to_destroy) {
    //printf("Starting from: x = %d, y = %d, dir = %d, steps: %d\n", start_x, start_y, direction, step_max);
    int first_x = start_x + direction * 3;
    int first_y = start_y - 3;
    int count = 1;
    unsigned char color = 255;
    if (first_y < columns[first_x].len) {
	color = ((unsigned char*)columns[first_x].ptr)[first_y];
	for (int back_step = 2; back_step >= 0; back_step--) {
	    int x = start_x + direction * back_step;
	    int y = start_y - back_step;
	    if (y >= columns[x].len) {
		break;
	    }
	    if (color != ((unsigned char*)columns[x].ptr)[y]) {
		break;
	    }
	    count += 1;
	}
    }
    for (int step = 4; step < step_max; step++) {
	int x = start_x + direction * step;
	int y = start_y - step;
	if (columns[x].len <= y) {
	    color = 255;
	}
	else {
	    unsigned char new_color = ((unsigned char*)columns[x].ptr)[y];
	    if (new_color != color) {
		color = new_color;
	    }
	    else {
		count += 1;
		continue;
	    }
	}
	if (count >= 4) {
	    struct Coordinate coor;
	    for (int back_steps = 1; back_steps <= count; back_steps++) {
		coor.x = x - direction * back_steps;
		coor.y = y + back_steps;
		append(to_destroy, &coor);
	    }
	}
	if (step_max - step < 4) {
	    return;
	}
	count = 1;
    }
    //printf("Final Count: %d\n", count);
    if (count >= 4) {
	struct Coordinate coor;
	for (int back_steps = 1; back_steps <= count; back_steps++) {
	    coor.x = start_x + direction * step_max - direction * back_steps;
	    coor.y = start_y - step_max + back_steps;
	    append(to_destroy, &coor);
	}
    }
}

int calc_min(int a, int b) {
    if (a < b) {
	return a;
    }
    return b;
}

// Zum iterativen Überprüfen, ob horizontal Blöcke gelöscht werden müssen
void general_diagonal(struct Game* game, struct DynArray* to_destroy, int min, int max, int real_first, int real_last, int rect_len) {
    struct DynArray* columns = game->columns.ptr;
    int lowest = min - 3; // beim diagonalen Überprüfen kann es noch 3 Blöcke 
    if (lowest < 0) {
	lowest = 0;
    }
    if (max < 3) {
	return;
    }

    int rect_height = max - min + 1;
    int full_len = real_last - real_first + 1;
    //printf("General Diagonal: first = %d, last = %d, max: %d, lowest: %d\n", real_first, real_last, max, lowest);
    for (int offset_y = 1; offset_y < rect_height; offset_y++) {
	int start_y = max - offset_y;
	int step_count = calc_min(start_y - lowest + 1, full_len);
	if (step_count < 4) {
	    break;
	}
	check_diagonal(columns, real_first, start_y, step_count, 1, to_destroy);
	check_diagonal(columns, real_last, start_y, step_count, -1, to_destroy);
    }
    for (int offset_x = 0; offset_x < full_len; offset_x++) {
	int step_count = calc_min(rect_len - offset_x, max - lowest + 1);
	if (step_count < 4) {
	    break;
	}
	check_diagonal(columns, real_first + offset_x, max, step_count, 1, to_destroy);
	check_diagonal(columns, real_last - offset_x, max, step_count, -1, to_destroy);
    }
}

// Vorbereitungsarbeit für general_horizontal und general_diagonal
void general_not_vertical(struct Game* game, struct DynArray* touched_columns, struct DynArray* to_destroy) {
    struct DynArray* columns = game->columns.ptr;
    struct Coordinate* first_touched = touched_columns->ptr;
    // bestimmt mit first, last, max, min rechteck um veränderte Blöcke
    int last = 0;
    for (int first = 0; first < touched_columns->len; first++) {
	last = first;
	for (int i = first + 1; i < touched_columns->len; i++) {
	    if (first_touched[i].x - first_touched[i - 1].x > 3) {
		break;
	    }
	    last += 1;
	}
	int min = first_touched[first].y;
	for (int i = first; i <= last; i++) {
	    if (first_touched[i].y < min) {
		min = first_touched[i].y;
	    }
	}
	int real_first = first_touched[first].x - 3;
	if (real_first < 0) {
	    real_first = 0;
	}
	int real_last = first_touched[last].x + 3;
	if (real_last >= game->columns.len) {
	    real_last = game->columns.len - 1;
	}
	int max = 0;
	for (int i = real_first; i <= real_last; i++) {
	    if (columns[i].len >= max) { //DEBUG: >= -> >
		//printf("new max on %d: %d\n", i, max); //DEBUG
		max = columns[i].len - 1;
	    }
	}
	/* //DEBUG
	printf("REALFIRST: %d\n", real_first);
	printf("REALLAST: %d\n", real_last);
	printf("MIN: %d\n", min);
	printf("MAX: %d\n", max);
	*/
	general_horizontal(game, to_destroy, min, max, real_first, real_last);
	general_diagonal(game, to_destroy, min, max, real_first, real_last, first_touched[last].x - first_touched[first].x + 1);
	first = last + 1;
    }
}

int main() {
    setvbuf(stdout, 0, _IONBF, 0);
    setvbuf(stdin, 0, _IONBF, 0);
    struct BuffInput buff_input;
    input_buff_reset(&buff_input);

    struct InputBlock new_block;

    int e = get_block(&new_block, &buff_input);
    if (e == EOF) {
	return 0;
    }
    if (e == -1) {
	fail_exit();
	return -1;
    }

    // Initialisierung des Spieles
    // Der erste Block legt den offset fest, wird deshalb seperat ausgelesen
    struct Game game;
    game.offset = new_block.x;
    game.columns = dyn_array_init(sizeof(struct DynArray));
    columns_ptr = &game.columns;
    struct DynArray first_column = dyn_array_init(sizeof(unsigned char));
    append(&game.columns, &first_column);

    // to_destroy beinhaltet die Koordinaten von Blöcken, welche gelöscht werden sollen
    struct DynArray to_destroy = dyn_array_init(sizeof(struct Coordinate));
    to_destroy_ptr = &to_destroy;

    struct DynArray cuts = dyn_array_init(sizeof(int));
    cuts_ptr = &cuts;

    struct DynArray changed_lines = dyn_array_init(sizeof(int));
    changed_lines_ptr = &changed_lines;

    int* columns_first_touched = myalloc(sizeof(int)); // zum mitschreiben des ersten veränderten y-wertes in einer spalte
    columns_first_touched[0] = INT_MAX;
    int columns_first_touched_len = 1;
    columns_first_touched_ptr = &columns_first_touched;
    
    struct DynArray column_first_touched = dyn_array_init(sizeof(struct Coordinate)); // beinhaltet die ersten Positionen (als Koordinaten), an denen in einer Zeile ein Block entfernt wurde
    column_first_touched_ptr = &column_first_touched;

    while (21) {
	// block einfügen
	struct DynArray* columns = game.columns.ptr;
	int corrected_x = new_block.x - game.offset;
	struct DynArray* column = &columns[corrected_x];
	if (column->ptr == 0) {
	    fprintf(stderr, "unreachable: null pointer on column\n");
	    fail_exit();
	}

	int y = append(column, &new_block.color);

	struct Coordinate initial_destroyed; // initial_destroyed ist der eingefügte Block (zugegebenermaßen nicht treffende Namensgebung)
	initial_destroyed.x = corrected_x;
	initial_destroyed.y = y;
	
	absolutely_reset(&to_destroy); // resetted das Array zur Neubenutzung

	// füllen von to_destroy nach dem eingefügten block block
	bool init_vertical = initial_vertical(&game, initial_destroyed, &to_destroy);
	bool init_horizontal = initial_horizontal(&game, initial_destroyed, &to_destroy);
	bool init_diagonal = initial_diagonal(&game, initial_destroyed, &to_destroy);
	//draw_game(&game); //DEBUG
	
	if (columns_first_touched_len != game.columns.len) {
	    columns_first_touched = mealloc(columns_first_touched, sizeof(int) * game.columns.len);
	    for (int i = columns_first_touched_len; i < game.columns.len; i++) {
		columns_first_touched[i] = INT_MAX;
	    }
	    columns_first_touched_len = game.columns.len;
	}
	if (init_vertical && !init_horizontal && !init_diagonal) {
	    ((struct DynArray*)game.columns.ptr)[initial_destroyed.x].len -= 4;
	    absolutely_reset(&to_destroy);
	}
	while (to_destroy.len != 0) { // Schleife die weiterläuft bis bei einem Durchlauf keine Blöcke entfernt wurden
	    //draw_game(&game); //DEBUG
	    absolutely_reset(&changed_lines);
	    empty_blocks(&game, &to_destroy, &changed_lines, columns_first_touched); // ersetzt alle Blöcke die in to_destroy erwähnt werden auf 255
	    sort_ints(&changed_lines);

	    absolutely_reset(&to_destroy); // nach Benutzung mit empty_blocks wieder resetten
	    
	    absolutely_reset(&column_first_touched);

	    struct DynArray* columns = game.columns.ptr;
	    int last = -1;
	    int* changed_lines_nums = changed_lines.ptr;
	    for (int i = 0; i < changed_lines.len; i++) {
		int num = changed_lines_nums[i];
		if (num != last) {
		    struct DynArray* column = &columns[num];
		    absolutely_reset(&cuts);
		    flatten(column, num, &cuts, &column_first_touched, columns_first_touched[num]); // vervollständigt den Lösch-Prozess, den empty_blocks angefangen hat
		    general_vertical(column, num, &cuts, &to_destroy); // Prüfung auf potenzielle vertikale Löschvorgänge, füllen von to_destroy
		    last = num;
		    columns_first_touched[num] = INT_MAX;
		}
	    }
	    general_not_vertical(&game, &column_first_touched, &to_destroy); // Prüfung auf potenzielle horizontale und diagonale Löschvorgänge, füllen von to_destroy
	    //draw_game(&game); //DEBUG
	}
	//draw_game(&game); //DEBUG
	int e = get_block(&new_block, &buff_input);
	//print_block(new_block, game.offset);
	if (e == EOF) { // signalisiert Ende des Datenstroms
	    output_game(&game); // ausgabe der existierenden Blöcke
	    free_all();
#ifdef STATS
	    fprintf(stderr, "VERTICAL: %d, HORIZONTAL: %d, DIAGONAL (left): %d, DIAGONAL (right): %d\n", ver, hor, dial, diar);
	    fprintf(stderr, "Moved the root %d times.\n", root_move_count);
#endif
	    return 0;
	}
	if (e == -1) {
	    fail_exit();
	}
	//print_block(new_block, game.offset); //DEBUG
	if (resize_game(&game, new_block.x - game.offset) == -1) {
	    fail_exit();
	}
    }
} 
