#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// setzen fuer Debug-Ausgaben
//#define DEBUG

#ifndef  FALSE
#define FALSE 0
#endif

#ifndef  TRUE
#define TRUE 1
#endif

// Globale Fehlervariable, kann mit den folgenden Werten belegt werden
int errNumGlobal = 0;
#define INPUT_ERROR 1 // falsches Zeilenformat
#define VALUE_ERROR 2 // Wert ausserhalb des zulaessigen Bereichs
#define MEM_ERROR 3   // Speicher gesprengt
#define FILE_ERROR 4  // nur wichtig fuer Debug-Modus
#define TOO_MUCH_DATA_ERROR 5 // zu viele Steine auf einen Stapel

// Grenzwerte fuer Variablen
#define MAX_LENGTH 80
#define MIN_COLOR 0
#define MAX_COLOR 255
#define MIN_XY    -1048576
#define MAX_XY     1048576

// Struktur eines Spielsteins
struct  Tile {
    unsigned char     color;			// passende Variable fuer den vorgegebenen Wertebereich
    _Bool             isPartOfRow;		// dient zur Markierung der zu loeschenden Spielsteine
};

// Struktur eines Stapels
struct  Pile {
    int         	x;					// passende Variable fuer den vorgegebenen Wertebereich
    struct Tile*	tiles;
    int         	numberOfTiles;
    struct Pile*	next;
};


/*************************************************************************************************************
 * Diese Funktion dient dem Auffinden und ggf. Markieren gleichfarbiger Spielsteine von links nach rechts.
 * Parameter: Farbe und Koordinaten des zu vergleichenden  Steins links
 * 		      Anzahl passender Steine, die ausgehend vom Ausgangsstein bereits gefunden wurden (=1)
 * 		      Die Richtung in der gesucht werden soll: gerade (0) oder diagonal rauf (1)/runter(-1)
 * Rueckgabe: Laenge der Reihe
 **************************************************************************************************************/

int searchOnRightwards(struct Pile* piles, int x, int y, unsigned char color, int rowLength, int direction) {

    struct Pile 	*pos;
    struct Tile		*firstTiles[3];


    pos = piles;

    while ( pos ) {

        // zwischen den zu vergleichenden Stapeln gib es einen Sprung -> Suche abbrechen
        if ( pos->x > (x + 1) ) return rowLength;

        // aendere die y-Koordinate entsprechend der Suchrichtung (gerade bzw in 2 digonale Richtungen)
        y += direction;

        // Beim Suchen diagonal nach unten
        if ( y < 0 ) return rowLength;

        // Der Vergleichsstapel ist zu niedrig -> Suche abbrechen
        if ( pos->numberOfTiles < (y + 1) ) return rowLength;

        // Die Farben stimmen nicht ueberein -> Suche abbrechen
        if ( pos->tiles[y].color != color ) return rowLength;

        // Gleiche Farbe gefunden

        // Die ersten drei Elemnete merken, um sie ggf. spaeter zu markieren
        if ( rowLength > 0 && rowLength < 4 ) {
            firstTiles[rowLength-1] = &pos->tiles[y];
        }
        rowLength++;

        // Reihe hat mindestens 4 Elemente. Zum Loeschen markieren.

        if ( rowLength > 3 ) {
            // Erste drei Elemente markieren
            if ( rowLength == 4 ) {
                for ( int i = 0; i < 3; i++ ) {
                    firstTiles[i]->isPartOfRow = TRUE;
                }
            }
            pos->tiles[y].isPartOfRow = TRUE;
        }

        x = pos->x;
        pos = pos->next;
    }
    return rowLength;
}

/********************************************************************************************
 * Diese Funktion sucht fuer alle Steine nach rechts horizontale bzw. diagonale 4er-Reihen.
 * Parameter: Erstes Listenelement, von dem aus 4er-Reihen starten koennen.
 * 		      Die Richtung in der gesucht werden soll: gerade oder diagonal rauf/runter
 * 		      Hoechster x-Wert, bei dem Reihen starten koennen
 * Ist der Stein Teil einer 4er-Reihe, wird er zum loeschen markiert
 * Rueckgabe: Anzahl gefundender Reihen
 ********************************************************************************************/

int searchRightwards(struct Pile* piles, int direction, int xMax, int yMin) {

    int			numRows = 0,
            rowLength;

    // Alle Stapel
    while ( piles ) {
        if ( piles->x > xMax ) break;

        // for ( int i = 0; i < piles->numberOfTiles; i++ ) {
        for ( int i = yMin; i < piles->numberOfTiles; i++ ) {
            rowLength = 1;
            rowLength = searchOnRightwards(piles->next, piles->x, i, piles->tiles[i].color, rowLength, direction);
            if (rowLength >= 4) {
                piles->tiles[i].isPartOfRow = TRUE;
                numRows++;
            }
        }
        piles = piles->next;
    }
    return numRows;
}

/****************************************************************************************
 * Diese Funktion sucht fuer alle Steine eines Stapels vertikale Reihen.
 * Parameter: Zeiger auf einen Stapel
 * Ist ein Stein Teil einer 4er-Reihe, wird er zum loeschen markiert
 * Rueckgabe: Anzahl gefundener Reihen
 ****************************************************************************************/

int searchUpwards(struct Pile* piles, int yMin) {
    int				numRows = 0,
            rowLength,
            i, j, k;

    for ( i = yMin; i < (piles->numberOfTiles - 3); i++ ) {
        // for ( i = 0; i < (piles->numberOfTiles - 3); i++ ) {
        rowLength = 1;
        for ( j = i + 1; j < piles->numberOfTiles; j++ ) {
            if ( piles->tiles[j].color != piles->tiles[i].color ) break;
            rowLength++;
        }
        if ( rowLength >= 4 ) {
            // flags setzen, wenn Reihe gefunden
            for ( k = i; k < j; k++ ) {
                piles->tiles[k].isPartOfRow = 1;
            }
            numRows++;
            i = j - 1;
        }
    }
    return numRows;
}

/*****************************************************************************
 * Diese Funktion startet die Suche nach Reihen in allen 4 Richtungen,
 * gesucht wird von unten nach oben und 3 mal von links nach rechts
 * Parameter: startPnt = das erste Listenelement, in dem 4er-Reihen
 * 			  anfangen koennen (max 3 links vom ersten veraenderten Stapel)
 * 			  x = hoechster Wert, bei dem Veraenderungen durchgefuehrt wurden.
 * 			  Rechts davon koennen keine 4er-Reihen mehr starten
 *Rueckgabe:  Anzahl gefundener Reihen
 *******************************************************************************/
int findRows(struct Pile *startPnt, int xMax, int yMin) {
    struct Pile		*pos;
    int 			numRows = 0;

    pos = startPnt;
    while ( pos ) {
        if ( pos->x > xMax ) break;
        numRows += searchUpwards(pos, yMin);
        pos = pos->next;
    }
    numRows += searchRightwards(startPnt, 0, xMax, yMin);   // suche horizontal
    numRows += searchRightwards(startPnt, 1, xMax, yMin);   // suche diagonal nach rechts oben
    numRows += searchRightwards(startPnt,-1, xMax, yMin);   // suche diagoal nach rechts unten

    return numRows;
}


/****************************************************************************************************
 * Diese Funktion loescht alle markierten Steine und laesst die darueberliegenden nachrutschen
 * Parameter: Anfang der Stapelreihe
 * Wenn Stapel voellig aufgeloest, wird x aus Liste entfernt
 * Rueckgabewert: (neuer) Listenanfang
 * weitere Ergebnisse: neuer Startpunkt in Liste, ab dem beim erneuten Aufruf Reihen anfangen koennen
 * 						hoechster x-Wert, bei dem beim erneuten Aufruf Reihen anfangen koennen
 ***************************************************************************************************/
struct Pile* deleteRowsAndDefineSearchArea(struct Pile *piles, struct Pile **startPnt, int *xMax, int yMin) {
    int			tilesLeft,
            xMin = MIN_XY;
    struct Tile *newTiles = NULL;
    struct Pile *pos, *prev;
    _Bool		xMinFound = FALSE;

    pos = piles;

    while ( pos ) {

        if ( pos->tiles ) {

            // Zaehle die verbleibenden Eintraege
            tilesLeft = pos->numberOfTiles;
            // for ( int i = 0; i < pos->numberOfTiles; i++ ) {
            for ( int i = yMin; i < pos->numberOfTiles; i++ ) {
                if ( pos->tiles[i].isPartOfRow ) tilesLeft--;
            }
            // Dieser Stapel veraendert sich
            if ( tilesLeft < pos->numberOfTiles ) {
                // zur Bestimmung des neuen Startpunkts fuer weitere Suchen, kleinsten x-Wert merken
                // der Offset - 3 ist notwendig, da an dem veraenderten Stapel eine 4er-Reihe enden kann
                if ( !xMinFound ) {
                    xMin = pos->x - 3;
                    xMinFound = TRUE;
                }
                // zur Bestimmung des neuen Endpunkts fuer weitere Suchen, groessten x-Wert merken
                if ( pos->x > *xMax ) *xMax = pos->x;

                //  Stapel vollst\E4ndig aufgel\F6st
                if ( tilesLeft < 1 ) {
                    free(pos->tiles);
                    pos->tiles = NULL;
                    pos->numberOfTiles = 0;
                    // Stapel verkleinern
                } else {
                    // Speicher verkleinern und gueltige Eintraege umkopieren
                    newTiles = (struct Tile*) malloc(tilesLeft * sizeof(struct Tile));
                    if ( newTiles ) {
                        int j = 0;
                        for ( int i = 0; i < pos->numberOfTiles; i++ ) {
                            if ( pos->tiles[i].isPartOfRow == FALSE ) {
                                newTiles[j].color = pos->tiles[i].color;
                                newTiles[j].isPartOfRow = FALSE;
                                j++;
                            }
                        }
                        free(pos->tiles);
                        pos->tiles = newTiles;
                    }
                    pos->numberOfTiles = tilesLeft;
                }
            }
        }
        pos = pos->next;
    }

    // Alle leeren Stapel loeschen
    // erst die am Anfang...
    while ( piles && piles->tiles == NULL){
        pos = piles;
        piles = piles->next;
        free(pos);
    }
    // ...dann alle anderen
    pos = piles;
    *startPnt = piles;
    prev = NULL;
    while ( pos ){
        if ( pos->tiles == NULL && prev ){
            prev->next = pos->next;
            free(pos);
            pos = prev->next;
        } else {
            if ( pos->x <= xMin ) *startPnt = pos;
            prev = pos;
            pos = pos->next;
        }
    }

    return piles;
}

/*****************************************************************
 *  Freigeben des Speichers
 *****************************************************************/
int memFree (struct Pile* piles) {
    struct Pile* next;

    while (piles) {

        next = piles->next;
        if (piles->tiles) free(piles->tiles);
        free (piles);
        piles = next;
    }
    return 0;
}

/********************************************************************************
 * ein Stein wird oben auf einen Stapel gelegt
 * Parameter: Zeiger auf Stapel
 * Rueckgabe: Zeiger auf neuen Stapel bzw. NULL bei Fehler
 ********************************************************************************/
struct Tile* tileOnTop(struct Tile *tiles, int *numTiles, int color) {
    struct Tile	*newTile;
    int  		newNum;

    // Erster Stein im Stapel
    if ( !tiles ) {
        newTile = malloc(sizeof(struct Tile));
        if ( !newTile ) {
            errNumGlobal = MEM_ERROR;
            return tiles;
        }
        newTile->color = (unsigned char) color;
        newTile->isPartOfRow = FALSE;
        *numTiles = 1;
        return newTile;
    }

    // Der Stapel wird zu hoch
    if ( *numTiles == MAX_XY ) {
        errNumGlobal = TOO_MUCH_DATA_ERROR;
        return tiles;
    }

    newNum = *numTiles + 1;
    newTile = (struct Tile*) realloc(tiles, newNum * sizeof(struct Tile));
    if ( !newTile ) {
        errNumGlobal = MEM_ERROR;
        return tiles;
    }
    newTile[*numTiles].color = (unsigned char) color;
    newTile[*numTiles].isPartOfRow = FALSE;
    *numTiles = newNum;
    return newTile;

    return NULL;
}

/***************************************************************************************
 *  Diese Funktion erweitert das Spielfeld um einen neuen Stein
 * Parameter: Anfang der bisherigen x-Liste bzw NULL beim ersten Stein
 * 			  x-Koordinate und Farbe des einzufuegenden Steins
 * Existiert bereits ein Stapel fuer x, so wird der Stein obenauf gelegt
 * Andernfalls wird ein neuer Stapel angelegt und so in die Liste eingefuegt,
 * dass diese nach x-Koordinaten sortiert ist.
 * Rueckgabewert ist der (neue) Anfang der Liste.
 * Darueberhinaus wird in startPnt der Zeiger auf das Listenelement gesetzt, bei dem
 * die Suche nach Reihen starten soll, maximal 3 nach links von x
 * in y wird die y-Koordinate des abgelegten Stein gespeichert
 ****************************************************************************************/
struct Pile* insertTile(struct Pile *piles, int x, int color, struct Pile **startPnt, int *y){
    struct Pile 	*newPile = NULL,
            *pos, *prev;


    *startPnt = piles;
    *y = 0;

    // Erster Stapel
    if ( !piles ) {
        newPile = (struct Pile*) malloc(sizeof(struct Pile));
        if ( !newPile ) {
            errNumGlobal = MEM_ERROR;
            return piles;
        }
        memset(newPile, 0, sizeof(struct Pile));
        newPile->x = x;
        newPile->tiles = tileOnTop(NULL, &newPile->numberOfTiles, color);
        *startPnt = newPile;
        return newPile;
    }

    // Sonst nach passendem Stapel suchen
    pos = piles;
    prev = NULL;

    while ( pos ) {
        // Startpunkt fuer die Suche nach Reihen setzen
        if ( pos->x <= (x-3) ) *startPnt = pos;

        // Stapel schon vorhanden: vergroessern und y merken, damit die Suche auch vertikal eingeschraenkt werden kann
        if ( pos->x == x ) {
            pos->tiles = tileOnTop(pos->tiles, &pos->numberOfTiles, color);
            *y = pos->numberOfTiles - 1;
            return piles;
        }

        // richtige Stelle zum Einfuegen gefunden
        if ( pos->x > x ) {
            break;
        }
        prev = pos;
        pos = pos->next;
    }

    // Neuer Stapel muss angelegt werden
    if (pos) {

        newPile = (struct Pile*) malloc(sizeof(struct Pile));
        if ( !newPile ) {
            errNumGlobal = MEM_ERROR;
            return piles;
        }
        memset(newPile, 0, sizeof(struct Pile));
        newPile->x = x;
        newPile->tiles = tileOnTop(NULL, &newPile->numberOfTiles, color);

        // An den Anfang der Reihe
        if ( prev == NULL ) {
            newPile->next = piles;
            *startPnt = newPile;
            return newPile;
            // Zwischen zwei Stapel
        } else {
            prev->next = newPile;
            newPile->next = pos;
            return piles;
        }
    }

    // neuer Stapel ans Ende der Liste
    if ( prev ) {
        newPile = (struct Pile*) malloc(sizeof(struct Pile));
        if ( !newPile ) {
            errNumGlobal = MEM_ERROR;
            return piles;
        }
        memset(newPile, 0, sizeof(struct Pile));
        newPile->x = x;
        newPile->tiles = tileOnTop(NULL, &newPile->numberOfTiles, color);

        prev->next = newPile;
    }

    return piles;
}

/********************************************************************************
 *  Ausgabe der Ergebnisse nach stdout bzw. in Datei result.txt im DEBUG-Modus
 ********************************************************************************/

int printResult( struct Pile *piles, int mode ) {
    struct 	Pile  *pos;
    int 	numOut, row;
    FILE	*fpOut = stdout;


#ifdef DEBUG
    fpOut = fopen("ccResult.txt","w");
    if (!fpOut ) return 1;
#endif

    if ( mode == 0 ) {
        // Ausgabe nach Spalten von links nach rechts
        pos = piles;
        while ( pos ) {
            if ( pos->tiles && pos->numberOfTiles > 0 ) {
                for ( int i = 0; i < pos->numberOfTiles; i++ ) {
                    fprintf(fpOut, "%d %d %d\n", (int) pos->tiles[i].color, pos->x, i);
                }
            }
            pos = pos->next;
        }
    } else if ( mode == 1 ) {
        // Ausgabe nach Zeilen von unten nach oben
        row = 0;
        do {
            pos = piles;
            numOut = 0;

            while ( pos ) {
                if ( pos->tiles && pos->numberOfTiles > row ) {
                    fprintf(fpOut, "%d %d %d\n", (int) pos->tiles[row].color, pos->x, row);
                    numOut++;
                }
                pos = pos->next;
            }
            row++;
        } while ( numOut > 0 );

    } else {
        // alphabetische Ausgabe
        char			lineOut[80],
                buffer[80];
        struct Tile 	*tileOut = NULL;

        do {
            pos = piles;
            numOut = 0;
            strcpy(lineOut, "ZZZZZZZZZZ");

            while ( pos ) {
                for ( int i = 0; i < pos->numberOfTiles; i++ ) {
                    // Wenn noch nicht ausgegeben und kleiner als aktuelle Zeile
                    if ( pos->tiles[i].isPartOfRow  == FALSE ) {
                        sprintf(buffer, "%d %d %d", (int) pos->tiles[i].color, pos->x, i);
                        if ( strcmp(buffer, lineOut ) < 0 ) {
                            strcpy(lineOut, buffer);
                            tileOut = &(pos->tiles[i]);
                            numOut = 1;
                        }
                    }
                }
                pos = pos->next;
            }
            // Wenn ein alphabetisch kleinster Eintrag gefunden wurde
            if ( numOut > 0 ) {
                fprintf(fpOut, "%s\n", lineOut);
                if ( tileOut) tileOut->isPartOfRow = TRUE;
            }

        } while ( numOut > 0 );
    }

#ifdef DEBUG
    fclose (fpOut);
#endif
    return 0;
}

/*******************************************************************
 *  Gibt ein Logfile zum Debuggen aus. DEBUG muss definiert sein
 *******************************************************************/

#ifdef DEBUG

int debugOut (struct Pile* piles, int linesRead, int yMin) {

    FILE			*fpOut = NULL;
    int				pCount;
    static int  	numRuns = 0;


    if ( numRuns == 0  )
        fpOut = fopen("ccLogfile.txt", "w");
    else
        fpOut = fopen("ccLogfile.txt", "a");

    if ( !fpOut ) {
        return 1;
    }

    numRuns++;
    // Nur die letzten 10 Tabellen ausgeben, sonst wird die Datei zu gross
    if ( numRuns > 100 ) numRuns = 0;

    fprintf(fpOut, "\nReihe(n) gefunden in Zeile %4d\n\n", linesRead);

    while ( piles ) {

        // tiles kann NULL sein, wenn alle Steine geloescht wurden
        if ( piles->tiles ) {
            _Bool	printTiles;

            // Es sollen nur Stapel mit Reihengliedern ausgegeben werden
            printTiles = FALSE;
            for ( int i = yMin; i < piles->numberOfTiles; i++ ) {
                if ( piles->tiles[i].isPartOfRow  == TRUE) {
                    printTiles = TRUE;
                    break;
                }
            }

            if ( printTiles == TRUE ) {
                fprintf(fpOut, "x %8d Anzahl %8d:", piles->x, piles->numberOfTiles);
                pCount  = 0;
                for ( int i = yMin; i < piles->numberOfTiles; i++ ) {
                    if ( piles->tiles[i].isPartOfRow  == TRUE) {
                        fprintf(fpOut, "  (%3d)", (int) piles->tiles[i].color);
                        pCount++;
                    } else {
                        fprintf(fpOut, "  %5d", (int) piles->tiles[i].color);
                        pCount++;
                    }
                    if (pCount > 19) {
                        fprintf(fpOut, "\n             ");
                        pCount = 0;
                    }
                }
                fprintf(fpOut, "\n");
            }
        }
        piles = piles->next;
    }

    fclose(fpOut);

    return 0;
}

#endif

/*****************************************************************************************
 * Ausgabe eines Fehlertextes, wenn an irgendeiner Stelle ein Fehler aufgetreten ist
 *****************************************************************************************/
void errorOut( char *buffer, int line ) {
    if ( errNumGlobal > 0 ) {

        fprintf(stderr, "Es ist ein Fehler aufgetreten\n");

        switch (errNumGlobal) {
            case MEM_ERROR: fprintf(stderr, "Speicherfehler\n");
                break;
            case INPUT_ERROR:
                fprintf(stderr, "Falsche Eingabe in Zeile %d: %s\n", line, buffer);
                break;
            case VALUE_ERROR:
                fprintf(stderr, "Unzulaessiger Wert in Zeile %d: %s\n", line, buffer);
                break;
            case FILE_ERROR:
                fprintf(stderr, "Kann Datei nicht oeffnen: %s\n", buffer);
                break;
            case TOO_MUCH_DATA_ERROR:
                fprintf(stderr, "Stapel zu hoch");
                break;
            default:
                break;
        }
    }
}

/************************************************************************
 * Einlesen der Parameter aus Zeile mit Ueberpruefung der Eingabe,
 * gibt die Anzahl der erfolgreich gelesenen Parameter zurueck
 *************************************************************************/
int parametersFromString( char *chptr, int *color, int *x ) {
    char	*nextChptr = NULL;
    long	lcolor, lx;

    // Farbe
    lcolor = strtol(chptr, &nextChptr, 10);
    if ( nextChptr == chptr ){
        errNumGlobal = INPUT_ERROR;
        return 0;
    }
    *color = (int) lcolor;

    // x-Wert
    chptr = nextChptr;
    lx = strtol(chptr, &nextChptr, 10);
    if ( nextChptr == chptr ){
        errNumGlobal = INPUT_ERROR;
        return 1;
    }
    *x = (int) lx;

    // gueltiges Zeilenende?
    chptr = nextChptr;
    if (*chptr != '\n' && *chptr != '\0') {
        errNumGlobal = INPUT_ERROR;
        return 3;
    }
    return 2;
}

/***********************************************
 * main: Zeilenweises Einlesen und Verarbeiten *
 ***********************************************/

int main(void) {

    struct Pile     *piles = NULL,
            *startPnt = NULL;	// Element in Liste, ab dem nach Reihen gesucht wird
    int				linesRead = 0;
    int         	color, x, y,		// in y wird gespeichert, auf welcher Hoehe ein neuer Stein abgelegt wurde => yMin
            xMax,				// obere horizontale Grenze, bis zu der Reihen beginnen koennen
            yMin;				// vertikale Untergrenze fuer die Suche nach Reihen
    char        	buffer[MAX_LENGTH],
            *charptr;
    FILE			*fpIn = NULL;


#ifdef DEBUG
    strcpy(buffer, "ccInput.txt");
    fpIn = fopen(buffer, "r");
#else
    strcpy(buffer, "stdin");
		fpIn = stdin;
#endif


    if ( !fpIn ) {
        errNumGlobal = FILE_ERROR;
        errorOut(buffer, 0);
        return 1;
    }

    while ( (charptr = fgets(buffer, (MAX_LENGTH-1), fpIn)) != NULL) {

        linesRead++;
#ifdef DEBUG
        fprintf(stderr, "Lese Zeile %d\n", linesRead); fflush(stderr);
#endif

        x = color = 0;
        if (parametersFromString(charptr, &color, &x) != 2) break;

        // Eingegebene Zahlen ausserhalb der erlaubten Grenzen?
        if (color < MIN_COLOR || color > MAX_COLOR) {
            errNumGlobal = VALUE_ERROR;
            break;
        }
        if (x < MIN_XY || x > MAX_XY) {
            errNumGlobal = VALUE_ERROR;
            break;
        }

        // Alles korrekt, der Stein kann eingefuegt werden
        piles = insertTile(piles, x, color, &startPnt, &y);
        if ( !piles ) break;

        // weitere Variablen zu Einschraenkung des Suchgebiets belegen
        xMax = x;
        yMin = y - 3;	// hier koennen diagonale Reihen beginnen
        if ( yMin < 0 ) yMin = 0;

        // Viererreihen suchen und aufloesen, solange, bis keine mehr gefunden werden

        while (findRows(startPnt, xMax, yMin) > 0) {
            // Logfile zum Debuggen
#ifdef DEBUG
            debugOut(piles, linesRead, yMin);
#endif

            // Reihen werden geloescht. Dabei werden der Startpunkt und der Endpunkt
            // fuer die erneute Suche neu bestimmt.
            piles = deleteRowsAndDefineSearchArea(piles, &startPnt, &xMax, yMin);

            // vertikale Grenzen erweitern
            yMin -= 3;
            if ( yMin < 0 ) yMin = 0;
        }

    } // Ende Einlesen

    // Ergebnis ausgeben
    if ( errNumGlobal == 0 ) printResult(piles, 0);

    // GGf. Fehlermeldungen ausgeben
    errorOut( buffer, linesRead);

#ifdef DEBUG
    if (fpIn) fclose(fpIn);
#endif
    // Speicher freigeben
    memFree(piles);

    return EXIT_SUCCESS;
}