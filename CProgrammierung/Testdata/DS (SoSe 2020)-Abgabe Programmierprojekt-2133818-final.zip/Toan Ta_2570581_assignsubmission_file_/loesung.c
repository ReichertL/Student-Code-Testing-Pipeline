
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TOSM(val) l[val][0]
#define TURMHOEHE(val) ltos[val]
#define VORZEITIG_BEENDEN -10403
#define STR_LENGTH 17
int k = 0, t=0;
enum richtung{OBEN,RECHTS,LINKS};
enum validierung{SPEICHER_ALLOKIERT,SPEICHER_ALLOKIERT2,SPEICHER_ALLOKIERT_CH,SPEICHER_ALLOKIERT_CH2,IST_ZAHL,GUELTIGER_STRING,GUELTIGE_ZAHL,GUELTIGE_FARBE,GUELTIGE_KOORDINATE,GUELTIGER_STEIN,ABBRUCH};
int max=4; // Laufvariabeln
unsigned char **l, **m; // Spielfelder
int *ltos, *mtos; // Index der h�chsten elements+1
int SPALTEN, ZEILEN, _SPALTEN, _ZEILEN;
int offset = 0, farbe;
int istMBelegt = 0;
int I=0,J=0; // Indizes der letzten Stellen der ersten und zweiten zahl
int numIstNull;
char str[STR_LENGTH]; // 17 = 1+ 10 + 1 + 3 + 1 + 1 = Vorzeichen + Erste Zahl + ' ' + Zweite Zahl + Erzwungene NULL
// Wartelisten
#define KILLER_BUFFER_SIZE  100000
#define TRAVERSE_BUFFER_SIZE 1000000
#define DROPPED_TRAVERSE_BUFFER_SIZE 20000
int killListX[KILLER_BUFFER_SIZE], killListY[KILLER_BUFFER_SIZE], killListH[KILLER_BUFFER_SIZE];
int traverseListX[TRAVERSE_BUFFER_SIZE], traverseListY[TRAVERSE_BUFFER_SIZE], traverseListH[TRAVERSE_BUFFER_SIZE];
int droppedTraverseList[DROPPED_TRAVERSE_BUFFER_SIZE];
unsigned char traverseListC[TRAVERSE_BUFFER_SIZE];
// Lese Ops
int lese();
void eingabeZuruecksetzen();
void eingabeAusgeben();
void eingabeAuswerten();
// Spielfeld Ops
void speicherReservieren(int spalten, int zeilen);
void fuellen(int L[][ZEILEN]);
void ausgeben();
void push(int spalte, int farbe);
void vergroessereSpielfeld(int richtung, int diskrepanz);
void spielfeldZwischenspeichern();
void spielfeldReinladen(int ursprung);
void spielfeldBefreien();
void pop(int x, int y);
int koordinatenUebergeben(int x, int y);

void traversiereSenkrechte();
void traversiereWaagerechte();
void traversiereSlashDiagonale();
void traversiereBackslashDiagonale();
void traversiere_traverseList();
void traversiere_gen1(int x, int y);
void add_traverseList(int x, int y);
// System Ops
void beendeSpiel();
void validiere();
void loesung_ausgeben();

unsigned char gibSteinAn(int x, int y);
void traverseList_ausgeben();
void traversiere(int x, int y);
void kill();

struct Koordinate{
    int x; int y;
};
union Variable{
    int INTEGER;
    int *INTEGER_POINTER;
    int **INTEGER_POINTER2;
    unsigned char *CHAR_POINTER;
    unsigned char **CHAR_POINTER2;
    char CHARACTER;
    struct Koordinate KOORDINATE;
}var;

void test1(){
    while(I<10){
        I++; J++; J++;
    }
}
/* Lese die naechste Zeile, falls leer, dann beende mit Ausgabe, sonst ermittle I,J, bei Scheitern, z.B. Nichtzahl, sofort beenden*/
int lese(){

    char str1[10];
    char str2[10];
    int next1=0;
    // erste Zahl
    do{
        if(next1>3) validiere(ABBRUCH, __LINE__);//error
        str1[next1]=getchar();
        //printf("Mein: %d\n", str1[next1]);
        if(str1[next1]==-1 || (str1[next1]==10 && next1==0) ) return 0;
        if( !((str1[next1]<='9' && str1[next1]>='0' )|| (str1[next1]==' ' && next1!=0)) )  validiere(ABBRUCH, __LINE__); //error
    }while(str1[next1++]!=' '); // go next, if space
    // zweite Zahl
    // printf("zweite zahl\n");
    int next2=0;
    do{
        if(next2>8)  validiere(ABBRUCH, __LINE__);//error
        str2[next2]=getchar();
        //printf("Mein: %c\n", str2[next2]);
        if( !((str2[next2]<='9' && str2[next2]>='0' )|| str2[next2]==10 || (str2[next2]=='-' && next2==0)) )
              validiere(ABBRUCH, __LINE__); //error
    }while(str2[next2++]!=10); // go next, if enter
    if(next2==1) validiere(ABBRUCH, __LINE__);
    int num1=atoi(str1); int num2=atoi(str2);
    validiere(GUELTIGE_FARBE, __LINE__, var.INTEGER=num1);
    validiere(GUELTIGE_KOORDINATE, __LINE__, var.INTEGER=num2);
    push(num2, num1);
    return 1;
}
void eingabeZuruecksetzen(){
    for(int i=0;i<STR_LENGTH;i++)
        str[i] = '\0';
}
void eingabeAusgeben(){
    int i = 0;
    while(i<=I){
        printf("%c", str[i]); i++;
    }
    printf(" - "); i++;
    while(i<=J){
        printf("%c", str[i]); i++;
    }
    printf("\n");
}
int offsetOfOffset=0;
int offsetOfOffsetGesetzt=0;
int spezialwert = 0;
void eingabeAuswerten(){
    char num1[I+2], num2[(J+1)-(I+1)+1];
    int i=0;
    // werte erste Zahl aus
    numIstNull=1;
    while(i<=I){
        num1[i] = str[i];
        if(str[i]!='0')
            numIstNull = 0;
        i++;
    }
    num1[i] = '\0'; i++;
    int wert1 = atoi(num1);
    validiere(GUELTIGE_ZAHL, __LINE__, var.INTEGER=wert1);
    validiere(GUELTIGE_FARBE, __LINE__, var.INTEGER=wert1);
    // werte zweite Zahl aus
    numIstNull=1;
    while(i<=J){
        num2[i-I-2] = str[i];
        if(str[i]!='0')
            numIstNull = 0;
        i++;
    }
    num2[i-I-2] = '\0';
    int wert2 = atoi(num2);
    validiere(GUELTIGE_ZAHL, __LINE__, var.INTEGER=wert2);
    validiere(GUELTIGE_KOORDINATE, __LINE__, var.INTEGER=wert2);
    if(!offsetOfOffsetGesetzt){
        offsetOfOffset=wert2+spezialwert;
        offsetOfOffsetGesetzt=1;
    }
    push(wert2+spezialwert,wert1); // (koordinate, farbe);
}
int MEM_REQUESTS = 1;
void vergroessereSpielfeld(int richtung, int diskrepanz){

    spielfeldZwischenspeichern();
    switch(richtung){
        case OBEN:
            speicherReservieren(SPALTEN, ZEILEN*2);
            spielfeldReinladen(0);
            break;
        case RECHTS:
            if(diskrepanz<100)
                MEM_REQUESTS++;
            speicherReservieren(SPALTEN+diskrepanz*2*MEM_REQUESTS*MEM_REQUESTS, ZEILEN);
            spielfeldReinladen(0);
            break;
        case LINKS:
            if(diskrepanz<100)
                MEM_REQUESTS++;
            speicherReservieren(SPALTEN+diskrepanz*2*MEM_REQUESTS*MEM_REQUESTS, ZEILEN);
            spielfeldReinladen(diskrepanz*2*MEM_REQUESTS*MEM_REQUESTS);
            offset += diskrepanz*2*MEM_REQUESTS*MEM_REQUESTS;
            break;
    }
}
#define offset (offset+offsetOfOffset)
void speicherReservieren(int spalten, int zeilen){
    SPALTEN = spalten+1, ZEILEN = zeilen+1, max=ZEILEN;
    l = (unsigned char **)malloc(sizeof(unsigned char *)*SPALTEN);
    validiere(SPEICHER_ALLOKIERT_CH2, __LINE__, var.CHAR_POINTER2=l);
    ltos = (int *)malloc(sizeof(int)*SPALTEN);
    validiere(SPEICHER_ALLOKIERT, __LINE__, var.INTEGER_POINTER=ltos);
    for(int i=0;i<SPALTEN;i++){
        l[i] = (unsigned char *)malloc(sizeof(unsigned char)*ZEILEN);
        validiere(SPEICHER_ALLOKIERT_CH, __LINE__, var.CHAR_POINTER=l[i]);
        ltos[i] = 0;
    }


    //AUSNULLEN
    for(int i=0;i<SPALTEN;i++){
            for(int j=0;j<ZEILEN;j++){
                l[i][j] = 0;
            }
    }
}
void fuellen(int L[][ZEILEN]){
    for(int i=0;i<SPALTEN;i++){
            for(int j=1;j<ZEILEN;j++){
                push(i,j+i);
            }
    }
}
void ausgeben(){
    for(int i=0;i<SPALTEN;i++){
        printf("[%3d] [%3d]",i-offset,ltos[i]);
        for(int j=0;j<ZEILEN;j++){
            printf("%3d ", l[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}
void push(int spalte, int farbe){
    // printf("push: %d %d\n", farbe, spalte);
    if(spalte<-offset)
        vergroessereSpielfeld(LINKS, (SPALTEN-1)-(spalte+offset));
    else if(spalte+offset>SPALTEN-1)
        vergroessereSpielfeld(RECHTS, spalte+offset-(SPALTEN-1));
    else if(TURMHOEHE(spalte+offset)>=max-1)
        vergroessereSpielfeld(OBEN, 0);
    l[spalte+offset][TURMHOEHE(spalte+offset)++] = farbe; // TODO
    /*
    l[][]
    */
    // printf("TARG %d\n", gibSteinAn(spalte, TURMHOEHE(spalte+offset)-1));
    traversiere(spalte, TURMHOEHE(spalte+offset)-1);
}

/* Befreie M und dann M := L*/
void spielfeldZwischenspeichern(){
    if(istMBelegt){
        spielfeldBefreien();
    }
    istMBelegt = 1;
    m = l;
    mtos = ltos;
    _SPALTEN = SPALTEN;
    _ZEILEN = ZEILEN;
}
/* Kopiere Spielfeld M in L rein und verschiebe um Ursprung*/
void spielfeldReinladen(int ursprung){
    for(int i=0;i<_SPALTEN;i++){
        ltos[i+ursprung] = mtos[i];
        for(int j=0;j<_ZEILEN;j++){
            l[i+ursprung][j] = m[i][j];
        }
    }
}
/* Gebe den Speicher vom temporaeren Spielfeld wieder frei*/
void spielfeldBefreien(){
    if(!istMBelegt)   return;
    for(int i=0;i<_SPALTEN;i++){
        free(m[i]);
    }
    free(m);
    free(mtos);
    istMBelegt = 0;
}
void pop(int x, int y){

    //killList_ausgeben();
    //printf("POP NOW %d %d\n", x,y);
    // ausgeben();

    // ausgeben();
    validiere(GUELTIGER_STEIN, __LINE__, koordinatenUebergeben(x,y));
    x = x+offset;
    ltos[x]--;
    while(y<ltos[x]){
        l[x][y] = l[x][y+1];
        y++;
    }
    l[x][y]=0;


}
#define linksGehen --x, y
#define rechtsGehen ++x, y
#define obenGehen x, ++y
#define untenGehen x, --y
#define slashGehen ++x, ++y
#define slashZurueckGehen --x, --y
#define backslashGehen ++x, --y
#define backslashZurueckGehen --x, ++y
#define KILL 255
#define reset x=ursprungX; y=ursprungY
int istXNachbar(int x1, int y1, int x2, int y2){
    if(y1!=y2) return 0;
    return (x1==x2+1 || x1==x2-1);
}
int istYNachbar(int x1, int y1, int x2, int y2){
    if(x1!=x2) return 0;
    return (y1==y2+1 || y1==y2-1);
}
int istSlashNachbar(int x1, int y1, int x2, int y2){
    return ( (x1==x2+1 && y1==y2+1) || (x1==x2-1 && y1==y2-1) );
}
int istBackslashNachbar(int x1, int y1, int x2, int y2){
    return ( (x1==x2+1 && y1==y2-1) || (x1==x2-1 && y1==y2+1) );
}
int istSteinVorhanden(int x, int y){
    if(x>=-offset && x+offset<SPALTEN && y<ltos[x+offset] && y>=0) {
        // printf("VORHANDEN [%d][%d]\n",x,y);
        return 1;
    }
    //printf("NICHT VORHANDEN [%d][%d]\n",x,y);
    return 0;
}
unsigned char gibSteinAn(int x, int y){
    return l[x+offset][y];
}
void swap(int *x, int *y){
    int t = *x;
    *x = *y;
    *y = t;
}
void swapC(unsigned char *x,unsigned char *y){
    unsigned char t = *x;
    *x = *y;
    *y = t;
}
void markiere(int x, int y){
    // printf("%d %d\n",x,y);
    // aufsteigend einfuegen
    // printf("try mark %d %d - %d - %d\n",x,y,l[x+offset][y],k);
    if(l[x+offset][y]==KILL) return;

    // pruefe auf doppelgaenger
    for(int i=0;i<k;i++){
        if(killListX[i]==x && killListY[i]==y) return;
    }
    //printf("now mark %d %d - %d - %d\n",x,y,l[x+offset][y],k);
    l[x+offset][y] = KILL;
    killListX[k] = x;
    killListY[k] = y;
    killListH[k] = TURMHOEHE(x+offset);
    k++;
    // killList_ausgeben();
    if(k>=KILLER_BUFFER_SIZE) validiere(ABBRUCH, __LINE__);
    //for(int i=0;i<k;i++)
      //  printf("%d - %d\n", killListX[i], killListY[i]);
}
void sortiereKillList(){
    int K;
    for(int i=0;i<k;i++){
        K = k-1;
        while(K>0){
            if(killListY[K]<killListY[K-1]){
                swap(&killListX[K], &killListX[K-1]);
            swap(&killListY[K], &killListY[K-1]);
            swap(&killListH[K], &killListH[K-1]);
            }
            K--;
        }
    }
}
int ursprungX, ursprungY;
unsigned char quelle;
int traversierungPositiv=0;
void traversiere(int x, int y){
    // buffer zuruecksetzen
    for(int i=0;i<DROPPED_TRAVERSE_BUFFER_SIZE;i++)
        droppedTraverseList[i] = ZEILEN;

    quelle = gibSteinAn(x,y);

    ursprungX=x, ursprungY=y;

    // printf("traverses %d %d\n",x,y);
    traversiereWaagerechte();
    traversiereSenkrechte();
    traversiereSlashDiagonale();
    traversiereBackslashDiagonale();

    //printf("k2=%d", k);
    kill();
    while(t>0)
        traversiere_traverseList();
}
int fixedY(int x, int y, int h){
    return y; // ignore
    //printf("enter fix: %d %d %d\n",x,*y,h);
    while(h>TURMHOEHE(x+offset)){ // correct new height
            y--; h--;
    }
    //printf("leave fix: %d %d %d\n",x,*y,h);
    return y;
}
/*
    while(T>0){ // traverse each element waagerecht
        T--;
        x=traverseListX[T], y=traverseListY[T], h=traverseListH[T];
        c = traverseListC[T];
        quelle = c;
        ursprungX=x, ursprungY=y;
        y = fixedY(x, y, h);
        traversiereWaagerechte();
        // skip any unnecessary traverses
        while(traversierungPositiv && T>0 && quelle==traverseListC[T-1] && istXNachbar(traverseListX[T-1],traverseListY[T-1],x,y)){
            x -= x-traverseListX[T-1];
            T--;
        }
        int _x=x, _y=y, _T=T;
        // is current traverse skippable? thus there is a connection between current traverse and last node
        if(traversierungPositiv && _T>0 && quelle==traverseListC[_T-1]){
            _T--;
            x=traverseListX[_T], y=traverseListY[_T], h=traverseListH[_T];
            c = traverseListC[_T];
            quelle = c;
            ursprungX=x, ursprungY=y;
        }
    }

    t=0;
*/
// oben auf travers liegt h�chstest
void traversiere_traverseList(){


    int x,y,h;
    unsigned char c;
    int K = k;
    // dropped traverse jetzt einfuegen
    int T=0;
    while(T<t){
        x=traverseListX[T], y=traverseListY[T], h=traverseListH[T];
        c = traverseListC[T];
        while(droppedTraverseList[(x+offset)%DROPPED_TRAVERSE_BUFFER_SIZE]<TURMHOEHE(x+offset)){
            add_traverseList(x,droppedTraverseList[(x+offset)%DROPPED_TRAVERSE_BUFFER_SIZE]++);
        }
        T++;
    }
    // traverse nach Farbe sortieren
    int lastPos=0;
    while(lastPos<t){
            // printf("A\n");
        c=traverseListC[lastPos++];
        for(int search=lastPos;search<t;search++){
            if(traverseListC[search]==c){
                swap(&traverseListX[search], &traverseListX[lastPos]);
                swap(&traverseListY[search], &traverseListY[lastPos]);
                swap(&traverseListH[search], &traverseListH[lastPos]);
                swapC(&traverseListC[search], &traverseListC[lastPos]);
                lastPos++;
            }
        }
    }
    while(t>0){
        // printf("B\n");
        t--;
        x=traverseListX[t], y=traverseListY[t], h=traverseListH[t];
        //printf("here: %d %d",x,y);
        //printf("traverse %d %d %d %d\n",x,y,gibSteinAn(x,y),c);
        // if c anders, dann alles Markierte ummarkieren
        if(gibSteinAn(x,y)!=c){
            // markierung aufheben
            while(K<k){
                // printf("255 reset\n");
                l[killListX[K]+offset][killListY[K]] = c;
                K++;
            }
            c = gibSteinAn(x,y);
        }



        //printf("dada %d %d\n",y,h);
        y = fixedY(x, y, h);
        //printf("dada %d %d\n",y,h);
        if(istSteinVorhanden(x,y)){
            // printf("NCHT PR %d %d",x,y);
             traversiere_gen1(x, y);
        }

    }
    kill();
}
long TRAVERSES=0;
void traversiere_gen1(int x, int y){
    // printf("gen1: %d %d\n",x,y);
    quelle = gibSteinAn(x,y);

    ursprungX=x, ursprungY=y;
    traversiereWaagerechte();
    traversiereSenkrechte();
    traversiereSlashDiagonale();
    traversiereBackslashDiagonale();
    reset;

}

void traversiereWaagerechte(){
    int treffer=1;
    traversierungPositiv=0;
    int x, y;
    reset;
    // printf("URSPRUNG [%d][%d]\n",x,y);
    while(istSteinVorhanden(linksGehen) && treffer<4 && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
        treffer++;
    }
    reset;
    while(istSteinVorhanden(rechtsGehen) && treffer<4 && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
        treffer++;
    }
    // printf("Treffer Waagerechte : %d\n", treffer);
    reset;

    if(treffer>=4){
        traversierungPositiv=1;
        markiere(x,y);
        while(istSteinVorhanden(linksGehen) && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
            markiere(x,y);TRAVERSES++;

        }
        reset;
        while(istSteinVorhanden(rechtsGehen) && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
            markiere(x,y);TRAVERSES++;
        }
    }


}
void traversiereSenkrechte(){
    // printf("SENKRECHTE TRAVERSE: %d %d\n", ursprungX, ursprungY);
    // ausgeben();
    int treffer=1;
    traversierungPositiv=0;
    int x, y;
    reset;
    // printf("URSPRUNG [%d][%d]\n",x,y);
    while(istSteinVorhanden(obenGehen) && treffer<4 && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
        treffer++;
    }
    reset;
    while(istSteinVorhanden(untenGehen) && treffer<4 && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
        treffer++;
    }
    // printf("Treffer Senkrecht : %d\n", treffer);
    reset;

    if(treffer>=4){

        traversierungPositiv=1;
        markiere(x,y);
        while(istSteinVorhanden(obenGehen) && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
            markiere(x,y);
            TRAVERSES++;

        }
        reset;
        while(istSteinVorhanden(untenGehen) && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
            markiere(x,y);
            TRAVERSES++;
        }

        // printf("marked %d %d\n",ursprungX,ursprungY);
        // ausgeben();
    }
}
void traversiereSlashDiagonale(){
    int treffer=1;
    traversierungPositiv=0;
    int x, y;
    reset;
    // printf("URSPRUNG [%d][%d]\n",x,y);
    while(istSteinVorhanden(slashGehen) && treffer<4 && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
        treffer++;
    }
    reset;
    while(istSteinVorhanden(slashZurueckGehen) && treffer<4 && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
        treffer++;
    }
    // printf("Treffer Senkrecht : %d\n", treffer);
    reset;

    if(treffer>=4){

        traversierungPositiv=1;
        markiere(x,y);
        while(istSteinVorhanden(slashGehen) && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
            markiere(x,y);
            TRAVERSES++;

        }
        reset;
        while(istSteinVorhanden(slashZurueckGehen) && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
            markiere(x,y);
            TRAVERSES++;
        }
    }
}
void traversiereBackslashDiagonale(){
    int treffer=1;
    traversierungPositiv=0;
    int x, y;
    reset;
    // printf("begin %d %d\n",x,y);
    while(istSteinVorhanden(backslashGehen) && treffer<4 && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
        treffer++;
        // printf("detected backslash %d %d\n",x,y);
    }
    reset;
    while(istSteinVorhanden(backslashZurueckGehen) && treffer<4 && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
        treffer++;
    }
    // printf("Treffer Senkrecht : %d\n", treffer);
    reset;
    // printf("Backslash [%d]\n",treffer);
    if(treffer>=4){

        traversierungPositiv=1;
        markiere(x,y);
        while(istSteinVorhanden(backslashGehen) && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
            markiere(x,y);
            TRAVERSES++;

        }
        reset;
        while(istSteinVorhanden(backslashZurueckGehen) && (quelle==gibSteinAn(x,y) || KILL==gibSteinAn(x,y)) ){
            markiere(x,y);
            TRAVERSES++;
        }
    }
}
void add_traverseList(int x, int y){
    if(istSteinVorhanden(x,y) && (t==0 || traverseListX[t-1]!=x || traverseListY[t-1]!=y) ){
        traverseListX[t] = x;
        traverseListY[t] = y;
        traverseListH[t] = TURMHOEHE(x+offset);
        traverseListC[t] = gibSteinAn(x,y);
        t++;
        if(t>=TRAVERSE_BUFFER_SIZE) validiere(ABBRUCH, __LINE__);
    }
}
void killList_ausgeben(){
    // printf("KILLLIST\n");
    for(int i=0;i<k;i++)
        printf("To be killed: %d - %d - %d\n",killListX[i],killListY[i],killListH[i]);
}
void kill(){
    sortiereKillList();
    // killList_ausgeben();
    while(k>0){

        // killList_ausgeben();
        //ausgeben();
        //killList_ausgeben();
        //traverseList_ausgeben();
        k--;

        int x=killListX[k], y=killListY[k], h=killListH[k];
        y = fixedY(x,y,h);

        //printf("kill now [%2d][%2d]\n",x,y);
        pop(x,y);
        if(y<TURMHOEHE(x+offset)-1 && y<droppedTraverseList[(x+offset)%DROPPED_TRAVERSE_BUFFER_SIZE])
            droppedTraverseList[(x+offset)%DROPPED_TRAVERSE_BUFFER_SIZE] = y;
        // printf("killed [%2d][%2d]\n",x,y);
        // traversiere gekillte Steine
        // printf("hier");
            // printf("travers\n");
        add_traverseList(x,y);
    }
    // ausgeben();
    // traverseList_ausgeben();
    // killList_ausgeben();
}
void traverseList_ausgeben(){
    for(int i=0;i<t;i++)
        printf("Traverseitem x=%d - y=%d - h=%d - c=%d\n", traverseListX[i], traverseListY[i], traverseListH[i], traverseListC[i]);
}
//
int koordinatenUebergeben(int x, int y){
    var.KOORDINATE.x=x;
    var.KOORDINATE.y=y;
    return 0;
}
/* Gebe den Speicher vom temporaeren und derzeitigen Spielfeld wieder frei */
void beendeSpiel(){
    spielfeldBefreien();
    spielfeldZwischenspeichern();
    spielfeldBefreien();
    exit(VORZEITIG_BEENDEN);
}
void validiere(int frage,int zeilenaufruf, union Variable spaceholder){
    switch(frage){
        case IST_ZAHL:
            if('0'<=var.CHARACTER && var.CHARACTER<='9') return;
            break;
        case SPEICHER_ALLOKIERT:
            if(var.INTEGER_POINTER!=NULL) return;
            break;
        case SPEICHER_ALLOKIERT2:
            if(var.INTEGER_POINTER2!=NULL) return;
            break;
        case SPEICHER_ALLOKIERT_CH:
            if(var.CHAR_POINTER!=NULL) return;
            break;
        case SPEICHER_ALLOKIERT_CH2:
            if(var.CHAR_POINTER2!=NULL) return;
            break;
        case GUELTIGER_STRING:
            if(var.CHARACTER=='\0') return;
            break;
        case GUELTIGE_ZAHL:
            if(var.INTEGER!=0 || numIstNull) return;
            break;
        case GUELTIGE_FARBE:
            if(var.INTEGER>=0 && var.INTEGER<=254) return;
            break;
        case GUELTIGE_KOORDINATE:
            if(var.INTEGER>=-1048576 && var.INTEGER<=1048576) return;
            break;
        case GUELTIGER_STEIN:
            // printf("delete %d - %d\n",ltos[var.KOORDINATE.x+offset],0);
            if(var.KOORDINATE.x>=-offset && var.KOORDINATE.x+offset<SPALTEN && var.KOORDINATE.y<ltos[var.KOORDINATE.x+offset]) return;
            break;
        case ABBRUCH:
            break;

    }
    // illegales Ereignis
    fprintf(stderr, "---Fehler: %d--- Zeile %d",frage,zeilenaufruf);
    beendeSpiel();

}
void loesung_ausgeben(){
    for(int i=0;i<SPALTEN;i++){
        if(ltos[i]!=0){
            for(int j=ltos[i]-1;j>=0;j--){

                printf("%d %d %d\n", l[i][j], i-offset, j);
            }
        }
    }
}
void warte(){
    //printf("<----->\n");
    getchar();
}

int main(){
    speicherReservieren(4,4);
    while(lese()){
        //i++;
        //if(i%1100==0)
           // printf("%d - %d - %d\n", i, TRAVERSES, t);

         // printf("%d\n", k);
         // ausgeben();

    }
    // ausgeben();
    loesung_ausgeben();
    return 0;
}
/*

*/
