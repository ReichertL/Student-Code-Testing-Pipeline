// Digitale Systeme, C-Projekt
// LINUS PALM (palmlinu), 2020
//
#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
#include<stdbool.h>

// Value of empty cells
#define EMPTY 255
// Width and height buffer constants
#define HORIZONTAL_BUFFER 100
#define VERTICAL_BUFFER 100
// 2^20
#define MAX_X 1048576L
// Error messages
#define ERROR_MEMORY "Out of memory.\n"
#define ERROR_INVALID_INPUT "Invalid input.\n"
#define ERROR_INVALID_CHAR "Invalid input: Illegal character.\n"
#define ERROR_INVALID_COLOR "Invalid input: Color out of range.\n"
#define ERROR_X_TOO_LARGE "Invalid input. Maximum allowed x value is 2^20.\n"

typedef struct {
    long width;
    long height;
    long offset;
    long widthBuffer;
    long heightBuffer;
    long minHeight;
    long cellCount;
    long* colorCounts;
    long* lowestFreeCells;
    unsigned char* array;
} FieldData;

typedef struct {
    char cellsRemoved;
    long affectedXStart;
    long affectedXEnd;
    long maxY;
} LineResult;

typedef struct {
    long minX;
    long maxX;
    long minY;
    long maxY;
} GravityResult;

typedef struct {
    bool ignoreHorizontal;
    bool ignoreSouth;
    long x;
    long y;
    long minX;
    long maxX;
    long maxY;
} DetectParams;

// -- LIST --
// Linked list

typedef struct ListElement {
    struct ListElement* next;
    long x;
    long y;
} ListElement;

typedef struct {
    int count;
    ListElement* first;
    ListElement* last;
} List;

List* createList(void)
{
    List* list = malloc(sizeof(List));
    if (list != NULL)
    {
        list->count = 0;
        list->first = NULL;
        list->last = NULL;
    }

    return list;
}

// Returns true if list is empty
bool listIsEmpty(List* list)
{
    return list->first == NULL;
}

// Adds an item to the end of the list
void listPush(List* list, ListElement* element)
{
    if (listIsEmpty(list))
    {
        list->first = element;
        list->last = element;
    }
    else
    {
        list->last->next = element;
        list->last = element;
    }

    list->last->next = NULL;
    list->count++;
}

// Appends all items of list b to list a
void listConcat(List* a, List* b)
{
    if (listIsEmpty(a))
    {
        a->first = b->first;
        a->last = b->last;
    }
    else
    {
        if (!listIsEmpty(b))
        {
            a->last->next = b->first;
            a->last = b->last;
        }
    }

    a->count += b->count;
}

// Frees all list items.
// (Optional) Free the list container if freeContainer flag is set
void listFree(List* list, bool freeContainer)
{
    if (list == NULL)
    {
        return;
    }

    ListElement* current = list->first;
    while (current != NULL)
    {
        ListElement* tmp = current;
        current = current->next;
        free(tmp);
    }

    if (freeContainer)
    {
        free(list);
    }
    else
    {
        list->first = NULL;
        list->last = NULL;
        list->count = 0;
    }
}

// Returns true, if the list contains an element with the specified y value.
bool listContainsCol(List* list, long y)
{
    ListElement* current = list->first;
    while (current != NULL)
    {
        if (y == current->y)
        {
            return true;
        }

        current = current->next;
    }

    return false;
}

// -- END LIST --

// Creates a field with an allocated initial size.
// If colorCounts and/or lowestFreeCells are NULL, they will be allocated aswell.
// If there is insufficient memory, NULL ist returned.
FieldData* createFieldData(long initialWidth, long initialHeight, long* colorCounts, long* lowestFreeCells)
{
    FieldData* field = malloc(sizeof(FieldData));
    if (field != NULL)
    {
        field->width = initialWidth;
        field->height = initialHeight;
        field->widthBuffer = initialWidth;
        field->offset = 0;
        field->cellCount = 0;
        field->heightBuffer = initialHeight;
        field->minHeight = 0;

        if (colorCounts == NULL)
        {
            field->colorCounts = calloc(EMPTY, sizeof(long));

            if (field->colorCounts == NULL)
            {
                free(field);
                return NULL;
            }
        }
        else
        {
            field->colorCounts = colorCounts;
        }

        if (lowestFreeCells == NULL)
        {
            field->lowestFreeCells = calloc(initialWidth, sizeof(long));
            if (field->lowestFreeCells == NULL)
            {
                free(field->colorCounts);
                free(field);
                return NULL;
            }
        }
        else
        {
            field->lowestFreeCells = lowestFreeCells;
        }

        field->array = malloc(initialWidth * initialHeight * sizeof(unsigned char));
        if (field->array == NULL)
        {
            free(field->colorCounts);
            free(field->lowestFreeCells);
            free(field);
            return NULL;
        }

        memset(field->array, EMPTY, initialWidth * initialHeight);
    }
    
    return field;
}

// Frees a field struct and all of its dynamic members
void destroyFieldData(FieldData* field)
{
    free(field->array);
    free(field->colorCounts);
    free(field->lowestFreeCells);
    free(field);
}

LineResult* createLineResult(void)
{
    LineResult* result = malloc(sizeof(LineResult));
    if (result != NULL)
    {
        result->affectedXEnd = 0;
        result->affectedXStart = 0;
        result->cellsRemoved = 0;
    }

    return result;
}

GravityResult* createGravityResult(void)
{
    GravityResult* result = malloc(sizeof(GravityResult));
    if (result != NULL)
    {
        result->maxX = 0;
        result->maxY = 0;
        result->minX = 0;
    }

    return result;
}

DetectParams* createDetectParams(void)
{
    DetectParams* params = malloc(sizeof(DetectParams));
    if (params != NULL)
    {
        params->ignoreHorizontal = false;
        params->ignoreSouth = false;
        params->x = 0;
        params->y = 0;
        params->minX = 0;
        params->maxX = 0;
    }

    return params;
}

long min(long a, long b)
{
    return a > b ? b : a; 
}

long max(long a, long b)
{
    return a > b ? a : b;
}

// Reads a line of unspecified length from the stdin and returns it.
// If there is insufficient memory, NULL is returned.
char* readLine(void)
{
    size_t size = 16;
    char *line;
    int currentChar;
    size_t length = 0;
    line = realloc(NULL, size);
    if (line == NULL)
    {
        return NULL;
    }

    // Reads characters from stdin, until end of file or newline is reached.
    while (EOF != (currentChar = getchar()) && currentChar != '\n')
    {
        line[length++] = currentChar;
        if (length == size)
        {
            char* tmp = realloc(line, size += 16);
            if (tmp == NULL)
            {
                return NULL;
            }

            line = tmp;
        }
    }

    line[length++] = '\0';

    return realloc(line, length);
}

// Reads a line from standard input and extracts color and x.
// If the input is invalid, false is returned.
bool getInput(unsigned char* color, long* x, bool* isNegative)
{
    char* line = readLine();
    if (line == NULL)
    {
        fprintf(stderr, ERROR_MEMORY);
        return false;
    }

    int length = strlen(line);
    if (length == 0)
    {
        free(line);
        return true;
    }

    // Skip leading spaces
    int i = 0;
    while (i < length && line[i] == ' ')
    {
        ++i;
    }

    if (i > 0 && i == length - 1)
    {
        // Only spaces in input
        free(line);
        fprintf(stderr, ERROR_INVALID_INPUT);
        return false;
    }

    int start = i;
    char currentChar;

    // Check for digits until space is found
    for (; i < min(i + 3, length); ++i)
    {
        currentChar = line[i];
        if (isdigit(currentChar))
        {
            continue;
        }
        
        if (currentChar == ' ')
        {
            // Found end of color
            break;
        }
        else
        {
            // Invalid char is color
            free(line);
            fprintf(stderr, ERROR_INVALID_CHAR);
            return false;
        }
    }

    if (i == start)
    {
        // No color
        free(line);
        fprintf(stderr, ERROR_INVALID_INPUT);
        return false;
    }

    int colorLength = i - start;
    char* colorString = malloc(colorLength + 1);
    memcpy(colorString, line + start, colorLength);
    colorString[colorLength] = '\0';

    int colorRaw = atoi(colorString);
    free(colorString);

    if (colorRaw < 0 || colorRaw > 254)
    {
        // Color out of range
        free(line);
        fprintf(stderr, ERROR_INVALID_COLOR);
        return false;
    }

    *color = colorRaw;

    // Skip spaces between color and x
    while(i < length && line[i] == ' ')
    {
        ++i;
    }

    if (i == length)
    {
        // No x
        free(line);
        fprintf(stderr, ERROR_INVALID_INPUT);
        return false;
    }

    if (line[i] == '-')
    {
        *isNegative = true;
        ++i;
    }

    start = i;
    for(;i < length; ++i)
    {
        currentChar = line[i];
        if (!isdigit(currentChar))
        {
            free(line);
            fprintf(stderr, ERROR_INVALID_CHAR);
            return false;
        }
    }

    int xLength = length - start;
    if (xLength == 0)
    {
        // No x
        free(line);
        fprintf(stderr, ERROR_INVALID_INPUT);
        return false;
    }

    char* xString = malloc(xLength + 1);
    memcpy(xString, line + start, xLength);
    xString[xLength] = '\0';
    *x = atol(xString);

    free(xString);
    free(line);

    if (*x > MAX_X)
    {
        fprintf(stderr, ERROR_X_TOO_LARGE);
        return false;
    }

    return true;
}

// Increases the height to newHeight
// If there is insufficient memory, the old field is freed and false is returned 
bool increaseHeight(FieldData* field, long newHeight)
{
    long diff = newHeight - field->heightBuffer;
    size_t newSize = field->widthBuffer * newHeight * sizeof(unsigned char);
    unsigned char* temp = (unsigned char*)realloc(field->array, newSize);
    if (temp == NULL)
    {
        destroyFieldData(field);
        return false;
    }

    // Initialize newly created cells
    memset(temp + field->height * field->widthBuffer, EMPTY, field->widthBuffer * (newHeight - field->height));

    // Shift field to new height
    for (long x = 0; x < field->width; ++x)
    {
        for (long y = newHeight - 1; y >= newHeight - field->height; --y)
        {
            long sourceY = y - diff;
            unsigned char value;
            if (sourceY < 0)
            {
                value = EMPTY;
            }
            else
            {
                value = *(temp + sourceY * field->widthBuffer + x); 
                *(temp + sourceY * field->widthBuffer + x) = EMPTY;
            }

            *(temp + y * field->widthBuffer + x) = value;
        }
    }

    field->array = temp;
    field->heightBuffer = newHeight;
    field->height++;
    field->minHeight = field->heightBuffer - field->height; 

    return true;
}

void shiftToNewWidth(FieldData* field, long diff, long xShift)
{
    long long oldCellsStart = field->widthBuffer * field->heightBuffer - 1;
    long long oldCellsEnd = field->height != field->heightBuffer ?
                                oldCellsStart - field->widthBuffer * field->height 
                                : field->width;

    if (oldCellsStart != oldCellsEnd)
    {
        // Cells in first row of old width are already in the right place (j=cellCount)
        // Move cells of the smaller field to their correct old position
        for (long long j = oldCellsStart; j >= oldCellsEnd; --j)
        {
            long y = j / field->widthBuffer;
            long long newI = j + y * diff + xShift;

            *(field->array + newI) = *(field->array + j); 
            *(field->array + j) = EMPTY;
        }
    }
      
    // Shift first row of old width
    if (xShift > 0)
    {
        for (long long i = field->widthBuffer - 1; i >= 0; --i)
        {
            *(field->array + i + xShift) = *(field->array + i);
            *(field->array + i) = EMPTY;
        }
    }
}

// Increases the width of the field to newWidth and shifts the field by xShift
// If there is insufficient memory, the old field is freed and false is returned 
bool increaseWidth(FieldData* field, long newWidth, long xShift)
{
    long diff = newWidth - field->widthBuffer;
    long long newSize = newWidth * field->heightBuffer;
    unsigned char* temp = realloc(field->array, newSize * sizeof(unsigned char));
    if (temp == NULL)
    {
        destroyFieldData(field);
        return false;
    }

    long long cellCount = field->widthBuffer * field->heightBuffer;

    // Initialize newly created cells
    memset(temp + cellCount, EMPTY, newSize - cellCount);

    field->array = temp;

    shiftToNewWidth(field, diff, xShift);

    // Resize lowest free cell array aswell
    long* temp2 = realloc(field->lowestFreeCells, sizeof(long) * newWidth);
    if (temp2 == NULL)
    {
        destroyFieldData(field);
        return false;
    }

    // Initialize new elements and shift if necessary
    memset(temp2 + field->widthBuffer, 0, diff * sizeof(long));
    if (xShift > 0)
    {
        for (long long i = field->widthBuffer - 1; i >= 0; --i)
        {
            *(temp2 + i + xShift) = *(temp2 + i);
            *(temp2 + i) = 0;
        }
    }

    field->lowestFreeCells = temp2;

    field->widthBuffer = newWidth;

    return true;
}


// Adds all cells, that are the same color as (x, y) in the direction (dx, dy) to line.
// Returns the length of the line array.
char getDirection(FieldData* field, long x, long y, char dx, char dy, long long* line, char i)
{
    unsigned char color = *(field->array + field->widthBuffer * y + x);
    x += dx;
    y += dy;

    while (x >= 0 && x < field->width && y >= field->minHeight && y < field->heightBuffer)
    {
        unsigned char value = *(field->array + field->widthBuffer * y + x);
        if (value != color)
        {
            break;
        }

        line[(int)i++] = field->widthBuffer * y + x;

        x += dx;
        y += dy;
    }

    return i;
}

// Checks if the field is big enough to fit lines.
bool checkDimensions(FieldData* field, char dx, char dy)
{
    if (dx != 0)
    {
        // Field not wide enough for line
        if (field->width < 4)
        {
            return false;
        }
    }

    if (dy != 0)
    {
        // Field not tall enough
        if (field->height < 4)
        {
            return false;
        }
    }

    return true;
}

// Adds all cells of the same color as (x,y) in the direction (dx,dy) to line and shifts the coordinates by (xModifier, yModifier).
// If there is insufficient memory, NULL is returned and line is freed.
bool getDirectionNext(FieldData* field, long x, long y, long xModifier, long yModifier, char dx, char dy, List* line)
{
    if (!checkDimensions(field, dx, dy))
    {
        return true;
    }

    List* tmpLine = createList();
    if (tmpLine == NULL)
    {
        listFree(line, true);
        return NULL;
    }

    unsigned char color = *(field->array + field->widthBuffer * y + x);
    x += dx;
    y += dy;

    while (x >= 0 && x < field->width && y >= field->minHeight && y < field->heightBuffer)
    {
        unsigned char value = *(field->array + field->widthBuffer * y + x);
        if (value != color)
        {
            break;
        }

        ListElement* cell = malloc(sizeof(ListElement));
        if (cell == NULL)
        {
            listFree(line, true);
            return false;
        }

        cell->x = x + xModifier;
        cell->y = y + yModifier;

        listPush(tmpLine, cell);

        x += dx;
        y += dy;
    }

    if (tmpLine->count >= 3)
    {
        listConcat(line, tmpLine);
        free(tmpLine);
    }
    else
    {
        listFree(tmpLine, true);
    }

    return true;
}

// Replaces all cells in a line with EMPTY and frees the cell items.
// Frees the line list and its nodes.
// Returns the number of removed cells and the x-area of the line in result.
bool removeLine(FieldData* field, long long* line, char length)
{
    bool isEmptyAbove = true;
    for (int i = 0; i < length; ++i)
    {
        long long current = line[i];
        long x = current - (current / field->widthBuffer) * field->widthBuffer;
        unsigned char* ptr = field->array + line[i];

        field->colorCounts[*ptr]--;
        field->lowestFreeCells[x]--;
        
        *ptr = EMPTY;        
        if (current - field->widthBuffer > 0 && *(field->array + current - field->widthBuffer) != EMPTY)
        {
            isEmptyAbove = false;
        }
    }

    return isEmptyAbove;
}

// Removes lines from a field section and frees the line.
void removeSectionLine(FieldData* field, List* line, long minX, LineResult* result)
{
    long affectedXStart = field->width;
    long affectedXEnd = 0;
    long maxY = field->heightBuffer - 1;

    char removedCells = 0;
    ListElement* current = line->first;
    while (current != NULL)
    {
        unsigned char* ptr = field->array + current->y * field->widthBuffer + current->x;
        if (*ptr != EMPTY)
        {
            field->colorCounts[*ptr]--;
            field->lowestFreeCells[current->x + minX]--;
            *ptr = EMPTY;
            removedCells++;

            if (current->x < affectedXStart)
            {
                affectedXStart = current->x;
            }

            if (current->x > affectedXEnd)
            {
                affectedXEnd = current->x;
            }

            if (current->y > maxY)
            {
                maxY = current->y;
            }
        }
        
        ListElement* tmp = current;
        current = current->next;
        free(tmp);
    }

    free(line);

    result->affectedXStart = affectedXStart;
    result->affectedXEnd = affectedXEnd;
    result->maxY = maxY;
    result->cellsRemoved = removedCells;
}

// Checks (dx, dy) and (-dx, -dy) for a common line. 
// Returns the length of the line.
char checkOpposites(FieldData* field, DetectParams* params, char dx, char dy, long long* line)
{
    long localMaxX = params->x;
    long localMinX = localMaxX;
    long localMaxY = params->y;

    char i = 0;
    if (checkDimensions(field, dx, dy))
    {
        i = getDirection(field, params->x, params->y, dx, dy, line, i);
        if (i > 0)
        {
            if (dx == 1)
            {
                localMaxX = params->x + i; 
            }
            else if (dx == -1)
            {
                localMinX = params->x - i;
            }

            if (dy == 1)
            {
                localMaxY = params->y + i;
            }
        }
    }

    if (checkDimensions(field, -dx, -dy))
    {
        char start = i;
        i = getDirection(field, params->x, params->y, -dx, -dy, line, i);
        if (i > 0)
        {
            // dx = -dx
            if (dx == 1)
            {
                localMinX = params->x - (i - start);
            }
            else if (dx == -1)
            {
                localMaxX = params->x + (i - start);
            }

            if (dy == -1)
            {
                localMaxY = params->y + (i - start);
            }
        }      
    }

    if (i >= 3)
    {
        if (localMaxX > params->maxX)
        {
            params->maxX = localMaxX;
        }

        if (localMinX < params->minX)
        {
            params->minX = localMinX;
        }

        if (localMaxY > params->maxY)
        {
            params->maxY = localMaxY;
        }
    }

    return i;
}

// Returns true if all cells above a line are empty.
bool checkAbove(FieldData* field, List* line)
{
    ListElement* current = line->first;
    while (current != NULL)
    {
        if (current->y - 1 >= field->minHeight && *(field->array + (current->y - 1) * field->widthBuffer + current->x) != EMPTY)
        {
            return false;
        }

        current = current->next;
    }

    return true;
}

// Finds and removes lines start contain the cell specified in params.
// Returns NULL if there is insufficient memory.
LineResult* detectLines(FieldData* field, DetectParams* params)
{
    bool isEmptyAbove = true;
    bool hasAnyLines = false;
    char cellsRemoved = 0;

    if (!params->ignoreHorizontal)
    {
        // East and west
        long long horizontal[6] = { 0 };
        char lengthX = checkOpposites(field, params, -1, 0, horizontal);
        if (lengthX >= 3)
        {
            hasAnyLines = true;
            cellsRemoved += lengthX;
            isEmptyAbove &= removeLine(field, horizontal, lengthX);
        }
    }

    // North west and south east
    long long diagonalFalling[6] = { 0 };
    char lengthDiag1 = checkOpposites(field, params, -1, -1, diagonalFalling);

    if (lengthDiag1 >= 3)
    {
        hasAnyLines = true;
        cellsRemoved += lengthDiag1;
        isEmptyAbove &= removeLine(field, diagonalFalling, lengthDiag1);
    }

    // North east and south west
    long long diagonalRising[6] = { 0 };
    char lengthDiag2 = checkOpposites(field, params, 1, -1, diagonalRising);

    if (lengthDiag2 >= 3)
    {
        hasAnyLines = true;
        cellsRemoved += lengthDiag2;
        isEmptyAbove &= removeLine(field, diagonalRising, lengthDiag2);
    }

    long long south[3] = { 0 };
    char lengthSouth = 0;
    if (!params->ignoreSouth &&
        field->height >= 4 && 
        field->heightBuffer - params->y >= 4)
    {
        // South (0, 1)
        lengthSouth = getDirection(field, params->x, params->y, 0, 1, south, 0);

        if (lengthSouth == 3)
        {
            hasAnyLines = true;
            cellsRemoved += 3;
            removeLine(field, south, lengthSouth);
        }
    }

    if (hasAnyLines)
    {
        unsigned char* ptr = field->array + params->y * field->widthBuffer + params->x;
        unsigned char color = *ptr;
        *ptr = EMPTY;
        field->lowestFreeCells[params->x]--;
        field->colorCounts[color]--;
        
        cellsRemoved++;
    }

    LineResult* result = createLineResult();
    if (result != NULL)
    {
        result->cellsRemoved = cellsRemoved;
        result->affectedXStart = isEmptyAbove ? -1 : params->minX;
        result->affectedXEnd = params->maxX;
        result->maxY = params->maxY;
    }

    return result;
}

// Finds and removes line in the section of the field specified in area.
// If there is insufficient memory NULL is returned.
LineResult* detectLinesInArea(FieldData* field, GravityResult* area)
{
    long maxX = area->maxX;
    long minX = area->minX;
    long minY = area->minY;
    long maxY = area->maxY;

    if (minX > 0)
    {
        // Extend to the left 
        minX = max(minX - 3, 0);
    }

    if (maxX + 1 < field->width)
    {
        // Extend to the right
        maxX = min(maxX + 3, field->width - 1);
    }

    if (maxY + 1 < field->heightBuffer)
    {
        // Extend to the bottom
        maxY = min(maxY + 3, field->heightBuffer - 1);
    }

    long sectionWidth = maxX - minX + 1;
    long sectionHeight = maxY - minY + 1;

    FieldData* section = createFieldData(
        sectionWidth,
        sectionHeight, 
        field->colorCounts, 
        field->lowestFreeCells);

    if (section == NULL)
    {
        return NULL;
    }
    
    // Copy section from the field
    for (long y = minY; y < minY + sectionHeight; ++y)
    {
        long sectionY = y - minY;
        memcpy(
            section->array + sectionY * sectionWidth,
            field->array + y * field->widthBuffer + minX,
            sectionWidth * sizeof(unsigned char));
    }

    LineResult* result = createLineResult();
    if (result == NULL)
    {
        return NULL;
    }

    bool isEmptyAbove = true;

    char removedCells = 0;
    for (long x = 0; x < sectionWidth; ++x)
    {
        for (long y = sectionHeight - 1; y >= 0; --y)
        {
            long globalX = x + minX;
            long globalY = y + minY;

            unsigned char color = *(field->array + globalY * field->widthBuffer + globalX);
            if (color == EMPTY)
            {
                break;
            }

            if (field->colorCounts[color] < 4)
            {
                continue;
            }

            List* line = createList();
            if (line == NULL)
            {
                free(section);
                free(result);
                return NULL;
            }

            ListElement* self = malloc(sizeof(ListElement));
            if (self == NULL)
            {
                free(section);
                free(result);
                free(line);
                return NULL;
            }

            self->x = x;
            self->y = y;

            listPush(line, self);

            if (!getDirectionNext(field, globalX, globalY, -minX, -minY, 0, -1, line) || // North (0, -1)
                !getDirectionNext(field, globalX, globalY, -minX, -minY, 1, 0, line) ||  // East (1, 0)
                !getDirectionNext(field, globalX, globalY, -minX, -minY, 1, -1, line) || // North east (1, -1)
                !getDirectionNext(field, globalX, globalY, -minX, -minY, -1, -1, line))  // North west (-1, -1)
            {
                free(section);
                free(result);
                return NULL;
            }

            if (line->count > 1)
            {
                if(!checkAbove(field, line))
                {
                    isEmptyAbove = false;
                }

                removeSectionLine(section, line, minX, result);
                removedCells += result->cellsRemoved;
                result->affectedXEnd += minX;
                result->affectedXStart += minX;
                result->maxY += minY;
            }
            else
            {
                listFree(line, true);
            }
        }
    }

    if (removedCells > 0)
    {
        // Copy section (now without lines) back into the field
        for (long y = 0; y < sectionHeight; ++y)
        {
            long globalY = y + minY;
            memcpy(
                field->array + globalY * field->widthBuffer + minX,
                section->array + y * sectionWidth,
                sectionWidth * sizeof(unsigned char));
        }
    }

    // Pointers from the full field should not be freed
    section->colorCounts = NULL;
    section->lowestFreeCells = NULL;

    destroyFieldData(section);

    result->cellsRemoved = removedCells;
    if(!isEmptyAbove)
    {
        result->affectedXStart = -1;
    }

    return result;
}

// Moves colored cells down until they are on top of another colored cell or at the bottom of the field.
// If there is insufficient memory NULL is returned.
GravityResult* applyGravity(FieldData* field, LineResult* lineRes)
{
    GravityResult* result = malloc(sizeof(GravityResult));
    if (result == NULL)
    {
        return NULL;
    }

    // Lowest level (max. y) that was moved
    result->maxY = 0;

    // Highest non-empty level (min. y) that was moved
    result->minY = field->heightBuffer;

    long end = lineRes->affectedXEnd + 1;
    bool movedCell = false;
    for (long x = lineRes->affectedXStart; x < end; ++x)
    {
        bool isEmptyBelow = *(field->array + (field->heightBuffer - 1) * field->widthBuffer + x) == EMPTY;
        long lowestColor = isEmptyBelow ? field->heightBuffer : -1;

        bool foundLowest = false;

        for(long y = lineRes->maxY; y >= field->minHeight; --y)
        {
            unsigned char* ptr = field->array + y * field->widthBuffer + x;
            if (*ptr == EMPTY)
            {
                isEmptyBelow = true;
                if (lowestColor == -1)
                {
                    lowestColor = y + 1;
                }
                continue;
            }

            if (isEmptyBelow)
            {
                *(field->array + (lowestColor - 1) * field->widthBuffer + x) = *ptr;
                *ptr = EMPTY;
                lowestColor--;
                movedCell = true;

                if(!foundLowest && lowestColor > result->maxY)
                {
                    result->maxY = lowestColor;
                    foundLowest = true;
                }
            }
        }

        if (lowestColor < result->minY)
        {
            result->minY = lowestColor;
        }
    }

    if (!movedCell)
    {
        result->maxY = -1;
    }

    return result;
}

// Main entry point
int main(void)
{
    FieldData* field = createFieldData(1, 1, NULL, NULL);
    if (field == NULL)
    {
        fprintf(stderr, ERROR_MEMORY);
        return EXIT_FAILURE;
    }

    DetectParams* params = createDetectParams();
    if (params == NULL)
    {
        destroyFieldData(field);
        fprintf(stderr, ERROR_MEMORY);
        return EXIT_FAILURE;
    }

    while(true)
    {
        unsigned char color = EMPTY;
        long x = 0;
        bool isNegative = false;

        if (!getInput(&color, &x, &isNegative))
        {
            // Invalid input.
            free(params);
            destroyFieldData(field);
            return EXIT_FAILURE;
        }

        // Empty input
        if(color == EMPTY)
        {
            break;
        }

        params->ignoreHorizontal = false;
        params->ignoreSouth = false;

        long offsetX;
        long newY = -1L;
        if (isNegative)
        {
            // New x is smaller than the previous minimum x.
            if (x > field->offset)
            {
                long diff = x - field->offset;
                long newWidth = field->width + diff;
                if (newWidth > field->widthBuffer)
                {
                    if (diff < HORIZONTAL_BUFFER && newWidth > 100)
                    {
                        newWidth += HORIZONTAL_BUFFER;
                    }

                    // Reserve is not wide enough to allow shift -> Increase width
                    if (!increaseWidth(field, newWidth, diff))
                    {
                        free(params);
                        fprintf(stderr, ERROR_MEMORY);
                        
                        return EXIT_FAILURE;
                    }

                    field->width = field->width + diff;
                }
                else
                {
                    // Shift field by diff cells to the right
                    for (long y = 0; y < field->height; ++y)
                    {
                        long offsetY = y + field->minHeight;
                        for (long x = newWidth - 1; x >= 0; --x)
                        {
                            long sourceX = x - diff;
                            unsigned char val;
                            if (sourceX < 0)
                            {
                                val = EMPTY;
                            }
                            else
                            {
                                val = *(field->array + offsetY * field->widthBuffer + sourceX);
                            }

                            *(field->array + offsetY * field->widthBuffer + x) = val;
                        }
                    }

                    field->width = newWidth;
                }

                field->offset = x;
                offsetX = 0;
                newY = field->heightBuffer - 1;

                // New column, no need to check below
                params->ignoreSouth = true; 

                // diff > 1 means, that there is atleast 1 empty column between the new cell and the old field
                params->ignoreHorizontal = diff > 1; 
            }
            else
            {
                // X is negative and inside the field
                offsetX = -x + field->offset;
            }
        }
        else
        {
            // X is positive
            offsetX = x + field->offset;

            // X is outside the current field
            if (offsetX >= field->width)
            {
                long diff = offsetX - field->width;

                // X is outside the reserved field
                if (offsetX >= field->widthBuffer)
                {
                    long newWidth = offsetX + 1;
                    if (offsetX - field->width < HORIZONTAL_BUFFER && newWidth > 100)
                    {
                        // If there are >= 100 new columns already, do not reserve more right now.
                        newWidth += HORIZONTAL_BUFFER;
                    }

                    // Reallocate a wider field
                    if (!increaseWidth(field, newWidth, 0))
                    {
                        free(params);
                        fprintf(stderr, ERROR_MEMORY);
                        return EXIT_FAILURE;
                    }    
                }

                field->width = offsetX + 1;
                newY = field->heightBuffer - 1;

                // New column, no need to check below
                params->ignoreSouth = true; 

                // diff > 1 means, that there is atleast 1 empty column between the new cell and the old field
                params->ignoreHorizontal = diff > 1; 
            }
        }

        if (newY == -1L)
        {
            newY = field->heightBuffer - 1 - field->lowestFreeCells[offsetX];

            field->lowestFreeCells[offsetX]++;
            if (newY < field->minHeight)
            {
                // Column is full
                if (field->heightBuffer == field->height)
                {
                    long newHeight = field->height + VERTICAL_BUFFER;
                    if (!increaseHeight(field, newHeight))
                    {
                        free(params);
                        fprintf(stderr, ERROR_MEMORY);
                        return EXIT_FAILURE;
                    }
                }
                else
                {
                    // Use height buffer
                    field->height++;
                    field->minHeight--;
                }

                newY = field->minHeight;

                // New row with only the new cell, no need to check horizontally
                params->ignoreHorizontal = true;
            }
        }
        else
        {
            field->lowestFreeCells[offsetX]++;
        }

        // Insert new cell into field
        *(field->array + newY * field->widthBuffer + offsetX) = color;

        long colorCount = ++field->colorCounts[color];

        // Find lines and remove them
        if ((++field->cellCount) >= 4 && colorCount >= 4)
        {
            params->x = offsetX;
            params->y = newY;
            params->minX = offsetX;
            params->maxX = offsetX;
            params->maxY = newY;

            LineResult* result = detectLines(field, params);
            if (result == NULL)
            {
                destroyFieldData(field);
                free(params);
                fprintf(stderr, ERROR_MEMORY);
                return EXIT_FAILURE;
            }

            while (result->cellsRemoved > 0)
            {
                field->cellCount -= result->cellsRemoved;

                // All cells above the removed ones are empty 
                // -> no gravity needed and no new lines possible
                if (result->affectedXStart == -1)
                {
                    break;
                }

                GravityResult* area = applyGravity(field, result);
                if (area == NULL)
                {
                    free(result);
                    destroyFieldData(field);
                    free(params);
                    fprintf(stderr, ERROR_MEMORY);
                    return EXIT_FAILURE;
                }

                // If there were cells moved by gravity and enough cells to form a line exist
                // try to find lines and remove them in the moved area.
                if (area->maxY != -1 && field->cellCount >= 4)
                {
                    area->minX = result->affectedXStart;
                    area->maxX = result->affectedXEnd;

                    free(result);

                    result = detectLinesInArea(field, area);
                    free(area);

                    if (result == NULL)
                    {
                        destroyFieldData(field);
                        free(params);
                        fprintf(stderr, ERROR_MEMORY);
                        return EXIT_FAILURE;
                    }
                }
                else
                {
                    free(area);
                    break;
                }
            }

            free(result);
        }
    }

    // Print the final state as (color, x, y)
    for (long x = 0; x < field->width; ++x)
    {
        for (long y = field->heightBuffer - 1; y >= field->minHeight; --y)
        {
            unsigned char color = *(field->array + y * field->widthBuffer + x);
            if (color == EMPTY)
            {
                // Only empty cells above in this column
                break;
            }

            long actualX = x - field->offset;
            long actualY = field->heightBuffer - y - 1;

            printf("%d %ld %ld\n", color, actualX, actualY);
        }
    }

    destroyFieldData(field);
    free(params);

    return EXIT_SUCCESS;
}