#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <regex.h>
#include <math.h>

#define BUFFERSIZE 256

typedef struct mark_node {
	int x;
	int y;
}mark_node;

void init();
int drop_next();
int detect();
int eliminate();
int correct();
int generate_output();
int terminate();
int insert(int, int);
int expandPlayground(int);
int expandStack(int);
int expandMarkedList();
int getColor(int, int);
int mark_stone(int x, int y);
int eliminate_mark_stone(int x, int y);
int expandEliminateMarkedList();
int reinit_ml();
int reinit_eml();

int reti, offset, pointer_list_length;
regex_t regex;
int** playground;


mark_node* marked_list;
mark_node* eliminate_marked_list;
int* correct_marked_list;
int marked_list_size=0;
int eliminate_marked_list_size=0;
int correct_marked_list_size=0;

int main(){
	//exit(0);
	//printf("init\n");
  init();

	//printf("starting to drop stones\n");
  while(drop_next()){
		//printf("drop next \n" );
    while(detect()){
			//printf("detect line \n" );
			//printf("Detected Line\n");
      eliminate();
      correct();
			//printf("detected end\n");
    }
  }

  generate_output();

  terminate();

  return 0;

}

void init(){

  // eingehende x coordinate ist nicht größer als 2^20
	playground = calloc(20, sizeof(int*));
	if(playground == NULL){
		fprintf(stderr, "Out of Memory\n");
		// kein terminate weil playground NULL und kein speicher alloziert wurde
		exit(1);
	}
	offset = 0;
	pointer_list_length = 20;


	// compile regular expression
  reti = regcomp(&regex, "^[0-9]+ +-?[0-9]{1,9}$", REG_EXTENDED);
  if (reti) {
    fprintf(stderr, "Could not compile regex\n");
		terminate();
    exit(1);
  }

	// marked list init
	marked_list = calloc(20, sizeof(mark_node));
	if(marked_list == NULL){
		fprintf(stderr, "Out of Memory\n");
		terminate();
		exit(1);
	}
	eliminate_marked_list = calloc(20, sizeof(mark_node));
	if(eliminate_marked_list == NULL){
		fprintf(stderr, "Out of Memory\n");
		terminate();
		exit(1);
	}
	marked_list_size=20;
	eliminate_marked_list_size=20;
	// mark lists as empty
	for(int i = 0;i<marked_list_size;i++){
		marked_list[i].x=-1;
		eliminate_marked_list[i].x=-1;
	}

		//free(&regex);
		//terminate();
		//exit(1);

}

// for every line from stdin
// proof with regex
// scan with sscanf for line and color
int drop_next(){
	//printf("Drop Next Stone\n");

		// init buffer
    char *buffer = malloc(BUFFERSIZE*sizeof(char));
		if(buffer == NULL){
			fprintf(stderr, "Out of Memory\n");
			terminate();
			exit(1);
		}

    if(fgets(buffer, BUFFERSIZE, stdin)){

				// TODO vor oder nach newline part ,  empty input? komplett leer oder auch newline? jenachdem um newline zu akzeptieren
				if(buffer[0]=='\0'){
					//printf(stderr, "empty line\n" );
					free(buffer);
					terminate();
					exit(0);
				}

				if(buffer[0]=='\n'){
					free(buffer);
					terminate();
					//fprintf(stderr, "Empty Line");
					exit(1);
				}

				//TODO delete newline, probably bad
				for(int i=0;buffer[i]!='\0';i++)
				{
						if(buffer[i]=='\x00'){
								free(buffer);
								terminate();
								exit(1);
						}
						if(buffer[i]=='\n')
						{
							buffer[i]='\0';
						}
				}




	      //check buffer with regex
	      int reti;
				int color, line;
	      reti = regexec(&regex, buffer, 0, NULL, 0);
	      if (!reti) {
	          // match
						// extract color and line
						sscanf(buffer,"%d %d", &color, &line);
						//printf("Scanf return value: %i\n", sscanf(buffer,"%d %d.7", &color, &line));
						// check invalid input
						if(!(color>=0) || !(color<255)){
							fprintf(stderr, "Invalid Input Color must be between [0,254]\n");
							free(buffer);
							terminate();
							exit(1);
						}
						if(line>1048576 || line<-1048576){
							fprintf(stderr, "Invalid Input x must be between [1048576,-1048576]\n");
							free(buffer);
							terminate();
							exit(1);
						}


						//printf("Dropped Point X: %i Color: %i\n", line, color);

						// expand playground if line+offset(x) is not in range [0,pointer_list_length]
						if((line+offset)<0 || (line+offset)>=(pointer_list_length)){
								expandPlayground(line);
						}

						// test if playground[x] exist , if then its value is non zero
						if(playground[line+offset]==0){
								// line array does not exist
								// create array for x
								playground[line+offset] = malloc(sizeof(int)*5);
								// set [x][0] which is the length of the x array
								playground[line+offset][0] = 5;
								if(playground[line+offset] == NULL){
									fprintf(stderr, "Out of Memory\n");
									free(buffer);
									terminate();
									exit(1);
								}


								// initialize the array with -1 expect the 0th element
								for(int i = 1; i<5;i++){
									playground[line+offset][i]=-1;
								}
								//TODO abwägen welche zeile besser, performance mäßig erstere besser
								//playground[line+offset][0] = color;
								insert(line, color);
						}else{
							//line array exist
							//try to insert
							insert(line, color);
						}
						//printf("Color: %d Line: %d\n", color, line);
						//buffer[helper]='\n';
						free(buffer);
						return 1;
	      }
	      else if (reti == REG_NOMATCH) {
	          // no match
						fprintf(stderr, "Invalid Input\n");
						terminate();
						free(buffer);
						exit(1);
	      }
	      else {
	          fprintf(stderr, "Regex match failed\n");
						terminate();
						free(buffer);
	          exit(1);
	      }
	      //printf("%s\n", buffer);
				//printf("Color: %d Line: %d\n", color, line);
    }else{
			// TODO exit 0 ? korrekt? oder einfach returnen?
      //fprintf(stderr, "End of Stream\n");
			free(buffer);
      return 0;
    }
    // insert point into datastructure
    // insert in datastructure(line, value)
    // test if x+offset in range else increase array size
    // get line end y from x+offset and insert into [x+offset][y]
    //return 0;
}

// insert point safely into datastructure
// expand if needed
// mark placed stone
int insert(int line, int value){

	// get length x array [x][0]
	int stack_length = playground[line+offset][0];
	//printf("Line: %i , Offset: %i , Stack length %zu\n", line, offset, stack_length);

	// for every element in the x array starting at 1

	for(int i=1;i<stack_length;i++){
		// check if i is the last elemnt if then expandStack
		if(i==stack_length-1){
				//printf("insert: i = %zu , expand stack\n", i);
				expandStack(line);
		}
			// get the first element with color "-1"=empty
		if(playground[line+offset][i]==-1){
				//printf("insert: i: %zu playground[line+offset][i]: %i\n", i, playground[line+offset][i]);

				// insert new value and mark stone for next detect check
				// return if inserted
				playground[line+offset][i]=value;
				mark_stone(line+offset,i);
				return 1;
		}

	}

	// should always return 1 but just in case
  return 0;
}

// expand x axis by new x+some fixed size
int expandPlayground(int x){
	// check if left(negativ) expand or right(positiv) expand
	if(x+offset<0){
		// expand left
			// calculate difference between old offset and x , for shifitng the array
			int diff = abs(x)-offset;
			// calculate new offset
			int newoffset = abs(x);
			// tmp_playground which we fill with the old values
			int** tmp_playground = calloc((pointer_list_length+diff+1),sizeof(int*));
			if(tmp_playground == NULL){
				fprintf(stderr, "Out of Memory\n");
				terminate();
				exit(1);
			}

			// fill tmp_playground with shiftet x values
			// TODO check korrekt?
			for(int i = 0;i<pointer_list_length;i++){
					tmp_playground[i+diff] = playground[i];
			}
			// recalculate length and offset
			//TODO +1? eher nicht?
			pointer_list_length = pointer_list_length+diff+1;
			offset=newoffset;
			// free playground , playground = new shiftet array
			free(playground);
			playground=tmp_playground;
			tmp_playground=NULL;

	}else{
		// expand right
			int** tmp_playground = calloc((x+offset)+1,sizeof(int*));
			if(tmp_playground == NULL){
				fprintf(stderr, "Out of Memory\n");
				terminate();
				exit(1);
			}
			for(int i = 0; i<pointer_list_length; i++){
				tmp_playground[i] = playground[i];
			}
			// TODO +1??? wirklich richtig?
			pointer_list_length=(x+offset)+1;
			free(playground);
			playground=tmp_playground;
			tmp_playground=NULL;
	}
	//printf("expand Playground successfuly\n");
	//printf("pointer_list_length: %i\n", pointer_list_length);
  return 0;
}


// expand y axis at line(x-offset?)??
// TODO check if expandStack(line ) oder expandStack(x) ???
int expandStack(int line){
	// get array length [x][0]
	int stack_length = playground[line+offset][0];

// TODO wirklich um 6 erhöhen? performance???
	// test if x_size+6 creates an int stack overflow
	if((int) stack_length*2<=0){
		fprintf(stderr, "Stack Overflow!!!\n" );
		terminate();
		exit(1);
	}
	// expand x_size by 6
	int* tmp = malloc(sizeof(int)*(stack_length*2));
	if(tmp == NULL){
		fprintf(stderr, "Out of Memory\n");
		terminate();
		exit(1);
	}

	// fill new array with old values
	// starting at 1
  for(int i = 1; i<stack_length;i++){
		tmp[i] = playground[line+offset][i];
	}

	// free old x array and replace it with new bigger array
	free(playground[line+offset]);
	playground[line+offset]=tmp;
	tmp=NULL;
	// TODO auch anpassen eventuell
	playground[line+offset][0]=stack_length*2;
	// fill rest of the new array with -1
	// TODO werden alle korrekten elemente natlos mit -1 gefüllt?
	for(int i=stack_length;i<playground[line+offset][0];i++){
		playground[line+offset][i] = -1;
	}
	return 1;
}

// expand the marked list by doubling it size
int expandMarkedList(){
	// test if double the marked_list_size creates an stack_overflow
	if(((int) marked_list_size*2)<=0){
		fprintf(stderr, "Stack Overflow!!!\n" );
		terminate();
		exit(1);
	}
	// crete new tmp marked list
	mark_node* tmp = calloc(2*marked_list_size,sizeof(mark_node));
	if(tmp == NULL){
		fprintf(stderr, "Out of Memory\n");
		terminate();
		exit(1);
	}


	// copy all elements of marked list to tmp
	for(int i = 0; i<marked_list_size;i++){
		tmp[i]=marked_list[i];
	}
	// fill the rest of the tmp array with -1
	//TODO test ob wirklich natlos alles mit -1 befüllt wird
	for(int i =marked_list_size;i<2*marked_list_size;i++){
		tmp[i].x=-1;
	}
	// free marked_list and replace with bigger tmp_list
	free(marked_list);
	// TODO test ob korrekte größe??
	marked_list_size=2*marked_list_size;
	marked_list=tmp;
	tmp=NULL;
	return 0;
}

// reinitialize marked list
int reinit_ml(){
	// free old marked list
	free(marked_list);
	// new initialization of marked list
	marked_list = calloc(20, sizeof(mark_node));
	if(marked_list == NULL){
		fprintf(stderr, "Out of Memory\n");
		terminate();
		exit(1);
	}
	marked_list_size=20;
	// mark every point in list as empty (marked_list[i].x=-1)
	for(int i = 0;i<marked_list_size;i++){
		marked_list[i].x=-1;
	}

	return 0;
}

// mark stone in marked_stone_list
int mark_stone(int x, int y){
	// for every stone in marked_list
	for(int i = 0;i<marked_list_size;i++){
		// if i last element then expand marked list
		if(i==marked_list_size-1){
			expandMarkedList();
		}
		// if found first -1 insert x,y at marked_list[i]
		// break and return
		if(marked_list[i].x==-1){
			marked_list[i].x = x;
			marked_list[i].y = y;
			break;
		}
	}

	return 0;
}

// mark stone in eliminate_mark_stone_list
int eliminate_mark_stone(int x, int y){
	// for every point in eliminate mark_stone_list
	for(int i = 0;i<eliminate_marked_list_size;i++){
		// if i ist last element then expand the eliminate_marked_list
		if(i==eliminate_marked_list_size-1){
			expandEliminateMarkedList();
		}
		// if found first -1 then mark x,y ind eliminate_marked_list[i]
		// break and return then
		if(eliminate_marked_list[i].x==-1){
			eliminate_marked_list[i].x = x;
			eliminate_marked_list[i].y = y;
			break;
		}
	}

	return 0;
}

// expand the eliminate_marked_list
int expandEliminateMarkedList(){
	// test if 2*eliminate_marked_list_size creates a stack_overflow
	if(((int) eliminate_marked_list_size*2)<=0){
		fprintf(stderr, "Stack Overflow!!!\n" );
		terminate();
		exit(1);
	}
	// create new tmp eliminate_marked_list
	mark_node* tmp = calloc(2*eliminate_marked_list_size,sizeof(mark_node));
	if(tmp == NULL){
		fprintf(stderr, "Out of Memory\n");
		terminate();
		exit(1);
	}

	// fill values of old list in tmp
	for(int i = 0; i<eliminate_marked_list_size;i++){
		tmp[i]=eliminate_marked_list[i];
	}
	// fill rest of tmp list with .x=-1
	// TODO test ob 2*eliminate_marked_list_size korrekte größe und ob alles natlos gefüllt wird
	for(int i =eliminate_marked_list_size;i<2*eliminate_marked_list_size;i++){
		tmp[i].x=-1;
	}
	// free old list and replace it with tmp
	free(eliminate_marked_list);
	eliminate_marked_list_size=2*eliminate_marked_list_size;
	eliminate_marked_list=tmp;
	tmp=NULL;
	return 0;
}


// reinitialize eliminate_marked_list
int reinit_eml(){
	// free old list
	free(eliminate_marked_list);
	// eliminate marked list init
	eliminate_marked_list = calloc(20, sizeof(mark_node));
	if(eliminate_marked_list == NULL){
		fprintf(stderr, "Out of Memory\n");
		terminate();
		exit(1);
	}
	eliminate_marked_list_size=20;

	// fill elm with .x=-1(empty)
	for(int i = 0;i<eliminate_marked_list_size;i++){
		eliminate_marked_list[i].x=-1;
	}

	return 0;
}



// vorbedingung droped stone enthalten in marked list
// marked list ist array von struct nodes welche relevanten infos enthält

// scan around stones in marked_list for lines and mark the lines if they are a valid for elimination
int detect(){

	//printf("Start to detect\n");

	// marker which indicates if line were detected
	int detect_marker=0;

	// for every point in marked_list
	for(int i = 0;i<marked_list_size;i++){
		// TODO test if element in marked_list_size exist
		// vll -1 x initialisieren TODO ??

		// calculate current x from marked point i
		int x = marked_list[i].x;
		// test if marked point is empty
		// continue if its not empty
		// else skip next part
		if(x!=-1){

			// calculate y from marked point i
			int y = marked_list[i].y;


			// helpers for line detection
			int counter_pos=0;
			int counter_neg=0;

			//printf("%i\n", marked_list_size);
			//TODO Berechnungen überprüfen von allen line checks
			//printf("Checking for X Axis Lines\n");
			// check for x axis for line
			for(int j = 1;playground[x][y]==getColor(x+j,y);j++){
					counter_pos++;
			}
			for(int j = 1;playground[x][y]==getColor(x-j,y);j++){
					counter_neg++;
			}
			if(counter_neg+counter_pos>=3){
						// set detect marker if line was found
						detect_marker=1;
						//printf("Line found !!\n");

						// mark full line in eliminate marked list
						// from x-counter_neg to x+counter_pos
						for(int j = -counter_neg;j<=counter_pos;j++){
								eliminate_mark_stone(x+j,y);
						}
			}

			//printf("Checking Y Axis Lines\n");
			// check for y axis for line
			counter_pos=0;
			counter_neg=0;
			for(int j = 1;playground[x][y]==getColor(x,y+j);j++){
					counter_pos++;
			}
			for(int j = 1;playground[x][y]==getColor(x,y-j);j++){
					counter_neg++;
			}
			if(counter_neg+counter_pos>=3){
				// set detect marker if line was found
					detect_marker=1;
					//printf("Line found !!\n");
					// mark full line in eliminate marked list
					// from y-counter_neg to y+counter_pos
					for(int j = -counter_neg;j<=counter_pos;j++){
							eliminate_mark_stone(x,y+j);
					}
			}

			//printf("Checking / for Lines\n");
			// check / diagonal
			counter_pos=0;
			counter_neg=0;
			for(int j = 1; playground[x][y]==getColor(x+j,y+j);j++){
					counter_pos++;
			}
			for(int j = 1; playground[x][y]==getColor(x-j,y-j);j++){
					counter_neg++;
			}
			if(counter_neg+counter_pos>=3){
					// set detect marker if line was found
					detect_marker=1;
					//printf("Line found !!\n");
					// mark full line in eliminate marked list
					// from x-counter_neg,y-counter_neg bis x+counter_pos,y+counter_pos
					for(int j = -counter_neg;j<=counter_pos;j++){
						eliminate_mark_stone(x+j,y+j);
					}
			}

			//printf("Checking \\ for Lines \n");
			// check \ diagonal
			counter_pos=0;
			counter_neg=0;
			for(int j = 1; playground[x][y]==getColor(x-j,y+j);j++){
					counter_pos++;
			}
			for(int j = 1; playground[x][y]==getColor(x+j,y-j);j++){
					counter_neg++;
			}
			if(counter_neg+counter_pos>=3){
					// set detect marker if line was found
					detect_marker=1;
					//printf("Line found !!\n");
					// mark full line in eliminate marked list
					// from x-counter_pos,y+counter_pos to x+counter_neg,y-counter_neg
					for(int j = -counter_neg;j<=counter_pos;j++){
						eliminate_mark_stone(x-j,y+j);
					}
			}

		}


	}

//	for(int i = 0;i<eliminate_marked_list_size;i++){
//		if(eliminate_marked_list[i].x != -1){
//			printf("eliminate_marked_list[%i]: X:%i Y:%i\n", i, eliminate_marked_list[i].x, eliminate_marked_list[i].y);
//		}
//	}
//
//	for(int i = 0;i<marked_list_size;i++){
//		if(marked_list[i].x!=-1){
//			printf("marked_list[%i]: X:%i Y:%i\n", i, marked_list[i].x , marked_list[i].y );
//		}
//	}
  // scan for 4er lines check if new stone x-4 x+4, y-4 y+4 is same color
    // for every point test if current_x +-4  , current_y +-4 is same color
    // if then check if valid line length check if duplicate line mark valid points
    // mark as point and return

	// reset marked list
	reinit_ml();

	// if detection marker is not set(no lines found )  then return 0 (break the detect while loop)
	if(detect_marker){
		return 1;
	}else{
		return 0;
	}

}

// -1 in every for elimination marked stone, fill cml with all affected index x value lines
int eliminate(){
	//printf("eliminate\n");

	//return 0;
	int x,y;
  // -1 in every field in marked eliminate stone list
	for(int i = 0;i<eliminate_marked_list_size;i++){
			x = eliminate_marked_list[i].x;
			if(x!=-1){
				y = eliminate_marked_list[i].y;
				playground[x][y]=-1;
			}
	}


	//init correct_marked_list and fill with -1
	//size of eliminate_marked_list_size because it is >= correct_marked_list_size
	// should be freed in correct
	correct_marked_list = malloc(sizeof(int)*eliminate_marked_list_size);
	if(correct_marked_list == NULL){
		fprintf(stderr, "Out of Memory\n");
		terminate();
		exit(1);
	}
	correct_marked_list_size=eliminate_marked_list_size;
	for(int i = 0;i<correct_marked_list_size;i++){
		correct_marked_list[i]=-1;
	}


	// TODO check algorithm
	//mark all unique x for every line that was touched by eliminate
	for(int i = 0;i<eliminate_marked_list_size;i++){
			x = eliminate_marked_list[i].x;
			// save only unique xs in clm
			for(int j = 0;j<correct_marked_list_size;j++){
				if(x==correct_marked_list[j]){
					break;
				}
				if(correct_marked_list[j]==-1){
					correct_marked_list[j]=x;
					break;
				}
			}
	}



//	for(int i = 0;i<correct_marked_list_size;i++){
//		if(correct_marked_list[i]!=-1){
//			printf("correct_marked_list[%i]: %i \n", i, correct_marked_list[i]);
//		}
//	}
//

	// reset eliminate_marked_list for next turn
	reinit_eml();


//  // and zero marked list
// TODO check zero marked list here?? WTF, vllt aber ok
//	for(int i = 0;i<marked_list_size;i++){
//		if(marked_list[i].x!=-1){
//			printf("marked_list[%i]: X:%i Y:%i\n", i, marked_list[i].x , marked_list[i].y );
//		}
//	}


    return 0;
}

// returned -2 if  not reachable because of boundings
// returned -1 if empty
// returned >=0 if value exist and is not empty != -1
// safe way to geht x,y pair in playground
int getColor(int x, int row){
	if((x)<0 || (x)>=pointer_list_length || row<=0){
		// x out of bounds return -2
		return -2;
	}else{
		// x in bounds
		if(playground[x]==0){
			//x array not initialized
			return -2;
		}else{
			// x array is initialized
			if( playground[x][0]<=row){
				// y to big for array
				return -2;
			}else{
				// return value (color)
				return playground[x][row];
			}
		}
	}
}


// goes over all touched x lists and move all empty elements(-1) up
int correct(){

	//printf("correct\n");

	//current list of x
	int* current_list;
	int current_list_size;
	//tmp list in which the computet current_list will be saved
	int* tmp_list;
	//counter list for tracking move down counter per index
	int* counter_list;


//	for(int i = 0; i <correct_marked_list_size;i++){
//		if(correct_marked_list[i]!=-1){
//			printf("correct_marked_list[%i]: %i\n", i, correct_marked_list[i]);
//		}
//	}
//	for(int i = 0; i<pointer_list_length;i++){
//		if(playground[i]!=0){
//			printf("playground[%i][0]: %i\n", i, playground[i][0]);
//		}
//	}

//	exit(1);


// move all stones in marked eliminate lists
// mark every stone  above a -1 stone that were moved
	// TODO untersuchen correct_marked_list

	// for every x array in correct_marked_list which is not empty(-1)
	// TODO test if -1 is real empty???
	for(int i = 0; (i<correct_marked_list_size)&&(correct_marked_list[i]!=-1);i++){


	//			for(int j = 0; j<playground[correct_marked_list[i]][0];j++){
	//					if(correct_marked_list[i]!=-1){
	//						printf("play_list[x=%i][y=%i]: %i\n", correct_marked_list[i], j, playground[correct_marked_list[i]][j]);
	//									}
	//			}


				// fill current x list and size
				current_list=playground[correct_marked_list[i]];
				current_list_size=playground[correct_marked_list[i]][0];

				// if current x list is not empty
				if(current_list!=0){
					//	printf("Current List size: %i with i:%i\n",current_list_size , i);
						tmp_list=malloc(sizeof(int)*current_list_size);
						if(tmp_list == NULL){
								printf("playground[%i] %p\n",correct_marked_list[i], (void*)playground[correct_marked_list[i]] );
								printf("playlist[%i][0]: %i\n", correct_marked_list[i], playground[correct_marked_list[i]][0]);
								printf("current_list_size: %i by index: %i\n", current_list_size, correct_marked_list[i]);
								fprintf(stderr, "Out of Memory\n");
								terminate();
								exit(1);
						}

						counter_list=malloc(sizeof(int)*current_list_size);
						if(counter_list == NULL){
								fprintf(stderr, "Out of Memory\n");
								free(tmp_list);
								terminate();
								exit(1);
						}
						//fill counter list
						int counter = 0;
						for(int j=0;j<current_list_size;j++){
								if(current_list[j]==-1){
									counter++;
								}
								counter_list[j]=counter;
						}
						//fill tmp_list
						int counter2=0;
						for(int j=0;j<current_list_size;j++){
								if(current_list[j]!=-1){
									tmp_list[j-counter_list[j]]=current_list[j];
									counter2++;
								}
						}
						// fill rest of tmp list with -1
						for(int j=counter2;j<current_list_size;j++){
								tmp_list[j]=-1;
						}
						// mark every point that was affected (counter>0 & not -1)
						for(int j=1;j<current_list_size;j++){
								int x =correct_marked_list[i];
								if(counter_list[j]>0&&tmp_list[j]!=-1){
									mark_stone(x,j);
									//printf("teeeest\n" );
								}

						}

			//			for(int j=1;j<current_list_size;j++){
			//				printf("tmp_list[%i]: %i\n", j, tmp_list[j]);
			//			}
			//
			//			for(int j=1;j<current_list_size;j++){
			//				printf("counter_list[%i]: %i\n", j, counter_list[j]);
			//			}

						//free current list and replace with tmp
						// free indexlist
						free(current_list);
						playground[correct_marked_list[i]]=tmp_list;
						free(counter_list);
			}
	}

	free(correct_marked_list);
//	for(int i = 0;i<marked_list_size;i++){
//		if(marked_list[i].x!=-1){
//			printf("marked_list[%i]: X:%i Y:%i\n", i, marked_list[i].x , marked_list[i].y-1 );
//		}
//	}


    return 0;
}

// generate final output of playground and print it to stdout
int generate_output(){

		for(int i = 0; i<pointer_list_length;i++){
			if(playground[i]!=0){
				for(int j=1;j< playground[i][0];j++){
					if(playground[i][j]>=0){
							printf("%i %i %i\n",playground[i][j], i-offset, j-1);
					}
				}
			}
		}

    return 0;
}


// release all memory that is still allocated
int terminate(){

		// free arrays
		//printf("release memory\n");
  	for(int i = 0; i<pointer_list_length;i++){
			if(playground[i]!=0){
				free(playground[i]);
			}
		}

		// free playground
		free(playground);
		//printf("successfuly released memory\n");

		// free marked lists
//		for(int i = 0; i<marked_list_size;i++){
//			if(marked_list[i]!=0){
//				free marked_list[i];
//			}
//		}
		//free regex
		regfree(&regex);
		free(marked_list);
		free(eliminate_marked_list);
		//free(correct_marked_list);
		//free(mark_node);
    return 0;
}
