#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main (void){

    //vorab start

    //Hilfsvariable fuer strtok
    char* haelfte2;

    //Hilfsvariable fuer strtok 
    char* haelfte1;

    //Variable die die Farbe repraesentiert
    int farbe;

    //Variable die die X-Koordinate repraesentiert
    int xko;

    //Groesse zur Erzeugung des Feldes x-Laenge
    int size = 1024;

    //zur Erzeugung des Feldes y-Laenge
    int laenge = 1024;

    //Variable fuer dynamisches vergroessern des Feldes in x Richtung
    int sizeold = 0;

    //Variable fuer dynamisches vergroessern des Feldes in y Richtung
    int laengeold = 0;

    //Feld fuer positive X-Koordinaten (inkulsive 0)
    int** feld;

    //Feld fuer negative X-Koordinaten
    int** neg;

    //ermoeglicht dynamisches vergroessern des Feldes
    int** uebergang;

    //Array dass Fuellstand des positiven Feldes anzeigt
    int *extra;

    //Array dass Fuellstand des negativen Feldes anzeigt
    int *extraneg;

    //ermoeglicht dynamisches vergroessern des Feldes insb. der extras
    int *extrauebergang;

    //Hilfsvariable um Betrag der negativen X-Koordinaten zu brechnen
    int negx;

    //Puffer fuer Input
    char input[100];

    //Array dass X-Koordinate von feld der zu entfernenen Steine speichert
    int* entfernenxpos;

    //Array dass Y-Koordinate von feld der zu entfernenen Steine speichert
    int* entfernenypos;

    //Array dass X-Koordinate von neg der zu entfernenen Steine speichert
    int* entfernenxneg;

    //Array dass Y-Koordinate von neg der zu entfernenen Steine speichert
    int* entfernenyneg;

    //Array dass X-Koordinate von feld der zu entfernenen Steine speichert
    int* entfernenxposzwei;

    //Array dass Y-Koordinate von feld der zu entfernenen Steine speichert
    int* entfernenyposzwei;

    //Array dass X-Koordinate von neg der zu entfernenen Steine speichert
    int* entfernenxnegzwei;

    //Array dass Y-Koordinate von neg der zu entfernenen Steine speichert
    int* entfernenynegzwei;

    //Counter der die Position im pos entfernen Array angibt
    int entfernencounterpos = 0;

    //Counter der die Position im neg entfernen Array angibt
    int entfernencounterneg = 0;

    //Counter der die Position im pos entfernen Array angibt
    int entfernencounterposzwei = 0;

    //Counter der die Position im neg entfernen Array angibt
    int entfernencounternegzwei = 0;

    //Hilfvariable fuer vielseitige Nutzung
    int help;

    //fuer strpbrk benoetigt
    char fehler[] = "!\"#$%&\'()*+,./:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";

    //fuer split benoetigt
    char *marker;

    //Variable, die die loop stoppt, wenn es keine weiteren Aenderungen gibt
    int aenderungen = 0;

    //zaehlt die Durchlaeufe
    int durchlaeufe = 0;

    extra = (int *) malloc((size+1)*sizeof(int));
    extraneg = (int *) malloc((size+1)*sizeof(int));

    entfernenxpos = (int *) malloc(((size+1)) * sizeof(int));
    entfernenypos = (int *) malloc(((size+1)) * sizeof(int));
    entfernenxneg = (int *) malloc(((size+1)) * sizeof(int));
    entfernenyneg = (int *) malloc(((size+1)) * sizeof(int));
    entfernenxposzwei = (int *) malloc(((size+1)) * sizeof(int));
    entfernenyposzwei = (int *) malloc(((size+1)) * sizeof(int));
    entfernenxnegzwei = (int *) malloc(((size+1)) * sizeof(int));
    entfernenynegzwei = (int *) malloc(((size+1)) * sizeof(int));

    memset(extra,0,(size+1));
    memset(extraneg,0,(size+1));

    feld = (int **)malloc(sizeof(int *)*(size+1));
    neg = (int **)malloc(sizeof(int *)*(size+1));
    for(int i = 0;i < (size+1);i++){
        feld[i] = (int *)malloc(sizeof(int)*(laenge+1));
        neg[i] = (int *)malloc(sizeof(int)*(laenge+1));
        memset(feld[i],-1,(laenge+1));
        memset(neg[i],-1,(laenge+1));
    }

    //vorab ende

    //einlesen start
    while(1){
        if(fgets(input, 100, stdin) == NULL){
            break;
        }
        if(strpbrk(input, fehler) != NULL){
            free(entfernenxnegzwei);
            free(entfernenxposzwei);
            free(entfernenynegzwei);
            free(entfernenyposzwei);
            free(entfernenxneg);
            free(entfernenxpos);
            free(entfernenyneg);
            free(entfernenypos);
            free(extra);
            free(extraneg);
            for(int i = 0;i < (size+1);i++){
                free(feld[i]);
                free(neg[i]);
            }
            free(feld);
            free(neg);
            fprintf(stderr,"%s","Zeile enthaelt unzulaessinge Zeichen.\n");
            return 1;
            //etwas anderes als Ziffern
        }
        if(strchr(input, ' ') == NULL){
            free(entfernenxnegzwei);
            free(entfernenxposzwei);
            free(entfernenynegzwei);
            free(entfernenyposzwei);
            free(entfernenxneg);
            free(entfernenxpos);
            free(entfernenyneg);
            free(entfernenypos);
            free(extra);
            free(extraneg);
            for(int i = 0;i < (size+1);i++){
                free(feld[i]);
                free(neg[i]);
            }
            free(feld);
            free(neg);
            fprintf(stderr,"%s","Zeile enthaelt nur eine Zahl.\n");
            return 1;
            //nur eine Zahl
        }

        marker = strchr(input,' ');
        *marker = 'A';
        //printf("Input: %s\n",input);
        haelfte1 = strtok(input,"A");
        haelfte2 = strtok(NULL, "A");
        if(strchr(haelfte2, ' ') != NULL){
            free(entfernenxnegzwei);
            free(entfernenxposzwei);
            free(entfernenynegzwei);
            free(entfernenyposzwei);
            free(entfernenxneg);
            free(entfernenxpos);
            free(entfernenyneg);
            free(entfernenypos);
            free(extra);
            free(extraneg);
            for(int i = 0;i < (size+1);i++){
                free(feld[i]);
                free(neg[i]);
            }
            free(feld);
            free(neg);
            fprintf(stderr, "%s", "Zeile enthaelt mehr als zwei Zahlen.\n");
            return 1;
            //mehr als 2 Zahlen
        }
        farbe = atoi(haelfte1);
        xko = atoi(haelfte2);
        if(farbe < 0 || farbe > 254){
            free(entfernenxnegzwei);
            free(entfernenxposzwei);
            free(entfernenynegzwei);
            free(entfernenyposzwei);
            free(entfernenxneg);
            free(entfernenxpos);
            free(entfernenyneg);
            free(entfernenypos);
            free(extra);
            free(extraneg);
            for(int i = 0;i < (size+1);i++){
                free(feld[i]);
                free(neg[i]);
            }
            free(feld);
            free(neg);
            fprintf(stderr, "%s", "Farbe liegt in unzulaessigem Zahlbereich.\n");
            return 1;
        }
        if(xko > 1048576 || xko < -1048576){
            free(entfernenxnegzwei);
            free(entfernenxposzwei);
            free(entfernenynegzwei);
            free(entfernenyposzwei);
            free(entfernenxneg);
            free(entfernenxpos);
            free(entfernenyneg);
            free(entfernenypos);
            free(extra);
            free(extraneg);
            for(int i = 0;i < (size+1);i++){
                free(feld[i]);
                free(neg[i]);
            }
            free(feld);
            free(neg);
            fprintf(stderr,"%s", "Eine X-Koordinate liegt außerhalb des Bereiches [-1048576,1048576].\n");
            return 1;
        }
        if(xko >= 0){
            if(xko > size){
                if(xko > 1024 && xko <= 2048){
                    sizeold = size;
                    size = 2048;    
                }
                if(xko > 2048 && xko <= 4096){
                    sizeold = size;
                    size = 4096;
                }
                if(xko > 4096 && xko <= 8192){
                    sizeold = size;
                    size = 8192;
                }
                if(xko > 8192 && xko <= 16384){
                    sizeold = size;
                    size = 16384;
                }
                if(xko > 16384 && xko <= 32768){
                    sizeold = size;
                    size = 32768;
                }
                if(xko > 32768 && xko <= 65536){
                    sizeold = size;
                    size = 65536;
                }
                if(xko > 65536 && xko <= 131072){
                    sizeold = size;
                    size = 131072;
                }
                if(xko > 131072 && xko <= 262144){
                    sizeold = size;
                    size = 262144;
                }
                if(xko > 262144 && xko <= 524288){
                    sizeold = size;
                    size = 524288;
                }
                if(xko > 524288 && xko <= 1048576){
                    sizeold = size;
                    size = 1048576;                   
                }
                //uebergang einrichten
                uebergang = (int **)malloc(sizeof(int *)*(sizeold+1));
                if(uebergang == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (sizeold+1);i++){
                        free(feld[i]);
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (sizeold+1);i++){
                    uebergang[i] = (int *)malloc(sizeof(int)*(laenge+1));
                    if(uebergang[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(uebergang[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (sizeold+1);i++){
                            free(feld[i]);
                            free(neg[i]);
                        }
                        free(feld);
                        free(neg);
                        free(uebergang);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(uebergang[i],-1,(laenge+1));
                }
                //werte uebertragen
                for(int i = 0;i < (sizeold+1);i++){
                    if(feld[i][0] != -1){
                        int j = 0;
                        while(feld[i][j] != -1){
                            uebergang[i][j] = feld[i][j];
                            j++;
                        }
                    }
                }
                //feld freigeben
                for(int i = 0;i < (sizeold+1);i++){
                    free(feld[i]);
                }
                free(feld);
                //alloc neues Feld
                feld = (int **)malloc(sizeof(int *)*(size+1));
                if(feld == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (sizeold+1);i++){
                        free(neg[i]);
                        free(uebergang[i]);
                    }
                    free(neg);
                    free(uebergang);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (size+1);i++){
                    feld[i] = (int *)malloc(sizeof(int)*(laenge+1));
                    if(feld[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(feld[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (sizeold+1);i++){
                            free(neg[i]);
                            free(uebergang[i]);
                        }
                        free(neg);
                        free(uebergang);
                        free(feld);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(feld[i],-1,(laenge+1));
                }
                //werte uebertragen
                for(int i = 0;i < (sizeold+1);i++){
                    if(uebergang[i][0] != -1){
                        int j = 0;
                        while(uebergang[i][j] != -1){
                            feld[i][j] = uebergang[i][j];
                            j++;
                        }
                    }
                }
                //uebergang freigeben
                for(int i = 0;i < (sizeold+1);i++){
                    free(uebergang[i]);
                }
                free(uebergang);

                //uebergang einrichten
                uebergang = (int **)malloc(sizeof(int *)*(sizeold+1));
                if(uebergang == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (sizeold+1);i++){
                        free(neg[i]);
                    }
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (sizeold+1);i++){
                    uebergang[i] = (int *)malloc(sizeof(int)*(laenge+1));
                    if(uebergang[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(uebergang[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (sizeold+1);i++){
                            free(neg[i]);
                        }
                        for(int i = 0;i < (size+1);i++){
                            free(feld[i]);
                        }
                        free(feld);
                        free(neg);
                        free(uebergang);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(uebergang[i],-1,(laenge+1));
                }
                //werte uebertragen
                for(int i = 0;i < (sizeold+1);i++){
                    if(neg[i][0] != -1){
                        int j = 0;
                        while(neg[i][j] != -1){
                            uebergang[i][j] = neg[i][j];
                            j++;
                        }
                    }
                }
                //neg freigeben
                for(int i = 0;i < (sizeold+1);i++){
                    free(neg[i]);
                }
                free(neg);
                //alloc neues neg
                neg = (int **)malloc(sizeof(int *)*(size+1));
                if(neg == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                    }
                    for(int i = 0;i < (sizeold+1);i++){
                        free(uebergang[i]);
                    }
                    free(feld);
                    free(uebergang);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (size+1);i++){
                    neg[i] = (int *)malloc(sizeof(int)*(laenge+1));
                    if(neg[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(neg[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (size+1);i++){
                            free(feld[i]);
                        }
                        for(int i = 0;i < (sizeold+1);i++){
                            free(uebergang[i]);
                        }
                        free(feld);
                        free(uebergang);
                        free(neg);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(neg[i],-1,(laenge+1));
                }
                //werte uebertragen
                for(int i = 0;i < (sizeold+1);i++){
                    if(uebergang[i][0] != -1){
                        int j = 0;
                        while(uebergang[i][j] != -1){
                            neg[i][j] = uebergang[i][j];
                            j++;
                        }
                    }
                }
                //uebergang freigeben
                for(int i = 0;i < (sizeold+1);i++){
                    free(uebergang[i]);
                }
                free(uebergang);

                //extras vergroessern
                extrauebergang = (int *) malloc((sizeold+1)*sizeof(int));
                if(extrauebergang == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (sizeold+1);i++){
                    extrauebergang[i] = extra[i];
                }
                free(extra);
                extra = (int *) malloc((size+1)*sizeof(int));
                if(extra == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extraneg);
                    free(extrauebergang);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                memset(extra,0,(size+1));
                for(int i = 0;i < (sizeold+1);i++){
                    extra[i] = extrauebergang[i];
                }
                free(extrauebergang);

                extrauebergang = (int *) malloc((sizeold+1)*sizeof(int));
                if(extrauebergang == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (sizeold+1);i++){
                    extrauebergang[i] = extraneg[i];
                }
                free(extraneg);
                extraneg = (int *) malloc((size+1)*sizeof(int));
                if(extraneg == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extrauebergang);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                memset(extraneg,0,(size+1));
                for(int i = 0;i < (sizeold+1);i++){
                    extraneg[i] = extrauebergang[i];
                }
                free(extrauebergang);
            }
            feld[xko][extra[xko]] = farbe;
            extra[xko]++;
            if(extra[xko] == size){
                laengeold = laenge;
                laenge = laenge*2;
                uebergang = (int **)malloc(sizeof(int *)*(size+1));
                if(uebergang == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (size+1);i++){
                    uebergang[i] = (int *)malloc(sizeof(int)*(laengeold+1));
                    if(uebergang[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(uebergang[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (size+1);i++){
                            free(feld[i]);
                            free(neg[i]);
                        }
                        free(feld);
                        free(neg);
                        free(uebergang);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(uebergang[i],-1,(laengeold+1));
                }
                for(int i = 0;i < (size+1);i++){
                    if(feld[i][0] != -1){
                        int j = 0;
                        while(feld[i][j] != -1){
                            uebergang[i][j] = feld[i][j];
                            j++;
                        }
                    }
                }
                for(int i = 0;i < (size+1);i++){
                    free(feld[i]);
                }
                free(feld);
                feld = (int **)malloc(sizeof(int *)*(size+1));
                if(feld == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(uebergang[i]);
                        free(neg[i]);
                    }
                    free(uebergang);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (size+1);i++){
                    feld[i] = (int *)malloc(sizeof(int)*(laenge+1));
                    if(feld[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(feld[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (size+1);i++){
                            free(uebergang[i]);
                            free(neg[i]);
                        }
                        free(uebergang);
                        free(neg);
                        free(feld);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(feld[i],-1,(laenge+1));
                }
                for(int i = 0;i < (size+1);i++){
                    if(uebergang[i][0] != -1){
                        int j = 0;
                        while(uebergang[i][j] != -1){
                            feld[i][j] = uebergang[i][j];
                            j++;
                        }
                    }
                }
                for(int i = 0;i < (size+1);i++){
                    free(uebergang[i]);
                }
                free(uebergang);

                uebergang = (int **)malloc(sizeof(int *)*(size+1));
                if(uebergang == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (size+1);i++){
                    uebergang[i] = (int *)malloc(sizeof(int)*(laengeold+1));
                    if(uebergang[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(uebergang[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (size+1);i++){
                            free(feld[i]);
                            free(neg[i]);
                        }
                        free(feld);
                        free(neg);
                        free(uebergang);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(uebergang[i],-1,(laengeold+1));
                }
                for(int i = 0;i < (size+1);i++){
                    if(neg[i][0] != -1){
                        int j = 0;
                        while(neg[i][j] != -1){
                            uebergang[i][j] = neg[i][j];
                            j++;
                        }
                    }
                }
                for(int i = 0;i < (size+1);i++){
                    free(neg[i]);
                }
                free(neg);
                neg = (int **)malloc(sizeof(int *)*(size+1));
                if(neg == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                        free(uebergang[i]);
                    }
                    free(feld);
                    free(uebergang);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (size+1);i++){
                    neg[i] = (int *)malloc(sizeof(int)*(laenge+1));
                    if(neg[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(neg[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (size+1);i++){
                            free(feld[i]);
                            free(uebergang[i]);
                        }
                        free(feld);
                        free(uebergang);
                        free(neg);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(neg[i],-1,(laenge+1));
                }
                for(int i = 0;i < (size+1);i++){
                    if(uebergang[i][0] != -1){
                        int j = 0;
                        while(uebergang[i][j] != -1){
                            neg[i][j] = uebergang[i][j];
                            j++;
                        }
                    }
                }
                for(int i = 0;i < (size+1);i++){
                    free(uebergang[i]);
                }
                free(uebergang);
            }
            //printf("%i\n",extra[xko]);
        }
        if(xko < 0){
            negx = (int)fabsf(xko);
            if(negx > size){
                if(negx > 1024 && negx <= 2048){
                    sizeold = size;
                    size = 2048;
                }
                if(negx > 2048 && negx <= 4096){
                    sizeold = size;
                    size = 4096;
                }
                if(negx > 4096 && negx <= 8192){
                    sizeold = size;
                    size = 8192;
                }
                if(negx > 8192 && negx <= 16384){
                    sizeold = size;
                    size = 16384;
                }
                if(negx > 16384 && negx <= 32768){
                    sizeold = size;
                    size = 32768;
                }
                if(negx > 32768 && negx <= 65536){
                    sizeold = size;
                    size = 65536;
                }
                if(negx > 65536 && negx <= 131072){
                    sizeold = size;
                    size = 131072;
                }
                if(negx > 131072 && negx <= 262144){
                    sizeold = size;
                    size = 262144;
                }
                if(negx > 262144 && negx <= 524288){
                    sizeold = size;
                    size = 524288;
                }
                if(negx > 524288 && negx <= 1048576){
                    sizeold = size;
                    size = 1048576;
                }
                //uebergang einrichten
                uebergang = (int **)malloc(sizeof(int *)*(sizeold+1));
                if(uebergang == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (sizeold+1);i++){
                        free(feld[i]);
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (sizeold+1);i++){
                    uebergang[i] = (int *)malloc(sizeof(int)*(laenge+1));
                    if(uebergang[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(uebergang[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (sizeold+1);i++){
                            free(feld[i]);
                            free(neg[i]);
                        }
                        free(feld);
                        free(neg);
                        free(uebergang);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(uebergang[i],-1,(laenge+1));
                }
                //werte uebertragen
                for(int i = 0;i < (sizeold+1);i++){
                    if(feld[i][0] != -1){
                        int j = 0;
                        while(feld[i][j] != -1){
                            uebergang[i][j] = feld[i][j];
                            j++;
                        }
                    }
                }
                //feld freigeben
                for(int i = 0;i < (sizeold+1);i++){
                    free(feld[i]);
                }
                free(feld);
                //alloc neues Feld
                feld = (int **)malloc(sizeof(int *)*(size+1));
                if(feld == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (sizeold+1);i++){
                        free(uebergang[i]);
                        free(neg[i]);
                    }
                    free(uebergang);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (size+1);i++){
                    feld[i] = (int *)malloc(sizeof(int)*(laenge+1));
                    if(feld[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(feld[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (sizeold+1);i++){
                            free(uebergang[i]);
                            free(neg[i]);
                        }
                        free(uebergang);
                        free(neg);
                        free(feld);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(feld[i],-1,(laenge+1));
                }
                //werte uebertragen
                for(int i = 0;i < (sizeold+1);i++){
                    if(uebergang[i][0] != -1){
                        int j = 0;
                        while(uebergang[i][j] != -1){
                            feld[i][j] = uebergang[i][j];
                            j++;
                        }
                    }
                }
                //uebergang freigeben
                for(int i = 0;i < (sizeold+1);i++){
                    free(uebergang[i]);
                }
                free(uebergang);

                //uebergang einrichten
                uebergang = (int **)malloc(sizeof(int *)*(sizeold+1));
                if(uebergang == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                    }
                    for(int i = 0;i <(sizeold+1);i++){
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (sizeold+1);i++){
                    uebergang[i] = (int *)malloc(sizeof(int)*(laenge+1));
                    if(uebergang[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(uebergang[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (size+1);i++){
                            free(feld[i]);
                        }
                        for(int i = 0;i <(sizeold+1);i++){
                            free(neg[i]);
                        }
                        free(feld);
                        free(neg);
                        free(uebergang);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(uebergang[i],-1,(laenge+1));
                }
                //werte uebertragen
                for(int i = 0;i < (sizeold+1);i++){
                    if(neg[i][0] != -1){
                        int j = 0;
                        while(neg[i][j] != -1){
                            uebergang[i][j] = neg[i][j];
                            j++;
                        }
                    }
                }
                //feld freigeben
                for(int i = 0;i < (sizeold+1);i++){
                    free(neg[i]);
                }
                free(neg);
                //alloc neues Feld
                neg = (int **)malloc(sizeof(int *)*(size+1));
                if(neg == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                    }
                    for(int i = 0;i < (sizeold+1);i++){
                        free(uebergang[i]);
                    }
                    free(feld);
                    free(uebergang);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (size+1);i++){
                    neg[i] = (int *)malloc(sizeof(int)*(laenge+1));
                    if(neg[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(neg[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (size+1);i++){
                            free(feld[i]);
                        }
                        for(int i = 0;i < (sizeold+1);i++){
                            free(uebergang[i]);
                        }
                        free(feld);
                        free(uebergang);
                        free(neg);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(neg[i],-1,(laenge+1));
                }
                //werte uebertragen
                for(int i = 0;i < (sizeold+1);i++){
                    if(uebergang[i][0] != -1){
                        int j = 0;
                        while(uebergang[i][j] != -1){
                            neg[i][j] = uebergang[i][j];
                            j++;
                        }
                    }
                }
                //uebergang freigeben
                for(int i = 0;i < (sizeold+1);i++){
                    free(uebergang[i]);
                }
                free(uebergang);

                //extras vergroessern
                extrauebergang = (int *) malloc((sizeold+1)*sizeof(int));
                if(extrauebergang == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (sizeold+1);i++){
                    extrauebergang[i] = extra[i];
                }
                free(extra);
                extra = (int *) malloc((size+1)*sizeof(int));
                if(extra == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extrauebergang);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                memset(extra,0,(size+1));
                for(int i = 0;i < (sizeold+1);i++){
                    extra[i] = extrauebergang[i];
                }
                free(extrauebergang);

                extrauebergang = (int *) malloc((sizeold+1)*sizeof(int));
                if(extrauebergang == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (sizeold+1);i++){
                    extrauebergang[i] = extraneg[i];
                }
                free(extraneg);
                extraneg = (int *) malloc((size+1)*sizeof(int));
                if(extraneg == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extrauebergang);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                memset(extraneg,0,(size+1));
                for(int i = 0;i < (sizeold+1);i++){
                    extraneg[i] = extrauebergang[i];
                }
                free(extrauebergang);
            }
            neg[negx][extraneg[negx]] = farbe;
            extraneg[negx]++;
            if(extraneg[negx] == laenge){
                int laengeold = laenge;
                laenge = laenge*2;
                uebergang = (int **)malloc(sizeof(int *)*(size+1));
                if(uebergang == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (size+1);i++){
                    uebergang[i] = (int *)malloc(sizeof(int)*(laengeold+1));
                    if(uebergang[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(uebergang[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (size+1);i++){
                            free(feld[i]);
                            free(neg[i]);
                        }
                        free(feld);
                        free(neg);
                        free(uebergang);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(uebergang[i],-1,(laengeold+1));
                }
                for(int i = 0;i < (size+1);i++){
                    if(feld[i][0] != -1){
                        int j = 0;
                        while(feld[i][j] != -1){
                            uebergang[i][j] = feld[i][j];
                            j++;
                        }
                    }
                }
                for(int i = 0;i < (size+1);i++){
                    free(feld[i]);
                }
                free(feld);
                feld = (int **)malloc(sizeof(int *)*(size+1));
                if(feld == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(uebergang[i]);
                        free(neg[i]);
                    }
                    free(uebergang);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (size+1);i++){
                    feld[i] = (int *)malloc(sizeof(int)*(laenge+1));
                    if(feld[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(feld[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (size+1);i++){
                            free(uebergang[i]);
                            free(neg[i]);
                        }
                        free(uebergang);
                        free(neg);
                        free(feld);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(feld[i],-1,(laenge+1));
                }
                for(int i = 0;i < (size+1);i++){
                    if(uebergang[i][0] != -1){
                        int j = 0;
                        while(uebergang[i][j] != -1){
                            feld[i][j] = uebergang[i][j];
                            j++;
                        }
                    }
                }
                for(int i = 0;i < (size+1);i++){
                    free(uebergang[i]);
                }
                free(uebergang);
                
                uebergang = (int **)malloc(sizeof(int *)*(size+1));
                if(uebergang == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                        free(neg[i]);
                    }
                    free(feld);
                    free(neg);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (size+1);i++){
                    uebergang[i] = (int *)malloc(sizeof(int)*(laengeold+1));
                    if(uebergang[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(uebergang[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (size+1);i++){
                            free(feld[i]);
                            free(neg[i]);
                        }
                        free(feld);
                        free(neg);
                        free(uebergang);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(uebergang[i],-1,(laengeold+1));
                }
                for(int i = 0;i < (size+1);i++){
                    if(neg[i][0] != -1){
                        int j = 0;
                        while(neg[i][j] != -1){
                            uebergang[i][j] = neg[i][j];
                            j++;
                        }
                    }
                }
                for(int i = 0;i < (size+1);i++){
                    free(neg[i]);
                }
                free(neg);
                neg = (int **)malloc(sizeof(int *)*(size+1));
                if(neg == NULL){
                    free(entfernenxnegzwei);
                    free(entfernenxposzwei);
                    free(entfernenynegzwei);
                    free(entfernenyposzwei);
                    free(entfernenxneg);
                    free(entfernenxpos);
                    free(entfernenyneg);
                    free(entfernenypos);
                    free(extra);
                    free(extraneg);
                    for(int i = 0;i < (size+1);i++){
                        free(feld[i]);
                        free(uebergang[i]);
                    }
                    free(feld);
                    free(uebergang);
                    fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                    return 1;
                }
                for(int i = 0;i < (size+1);i++){
                    neg[i] = (int *)malloc(sizeof(int)*(laenge+1));
                    if(neg[i] == NULL){
                        free(entfernenxnegzwei);
                        free(entfernenxposzwei);
                        free(entfernenynegzwei);
                        free(entfernenyposzwei);
                        free(entfernenxneg);
                        free(entfernenxpos);
                        free(entfernenyneg);
                        free(entfernenypos);
                        free(extra);
                        free(extraneg);
                        while(i > 0){
                            free(neg[i-1]);
                            i--;
                        }
                        for(int i = 0;i < (size+1);i++){
                            free(feld[i]);
                            free(uebergang[i]);
                        }
                        free(feld);
                        free(uebergang);
                        free(neg);
                        fprintf(stderr,"%s","Es konnte nicht genug Speicher alloziert werden.\n");
                        return 1;
                    }
                    memset(neg[i],-1,(laenge+1));
                }
                for(int i = 0;i < (size+1);i++){
                    if(uebergang[i][0] != -1){
                        int j = 0;
                        while(uebergang[i][j] != -1){
                            neg[i][j] = uebergang[i][j];
                            j++;
                        }
                    }
                }
                for(int i = 0;i < (size+1);i++){
                    free(uebergang[i]);
                }
                free(uebergang);
            }
            
            //printf("%i\n",extraneg[negx]);
        }
        //printf("farbe: %i\nxko: %i\n",farbe,xko);        
    }
    //einlesen ende

    //vergleich start

    int hitcounterWag = 0;
    int hitcounterSen = 0;
    int hitcounterDiaLR = 0;
    int hitcounterDiaRL = 0;
    int hitcounterWagneg = 0;
    int hitcounterSenneg = 0;
    int hitcounterDiaLRneg = 0;
    int hitcounterDiaRLneg = 0;
    int k = 1;
    int l = 0;

    for(int i = 0; i < (size+1); i++){
        if(feld[i][0] != -1 || neg[i][0] != -1){
            int j = 0;
            while(1){
            //for(int j = 0; j < (size+1); j++){
                //abbruch der Spalte, wenn sie oben hin leer ist
                if(feld[i][j] == -1 && neg[i][j] == -1){
                    break;
                }
                if(feld[i][j] != -1){
                    hitcounterWag = 0;
                    hitcounterWagneg = 0;
                    l = 0;
                    k = 1;
                    while(1){//suche Wagerecht in pos Richtung
                        if((i+l) >= (size+1)){
                            break;
                        }
                        if(feld[i][j] != feld[i+l][j]){
                            break;
                        }
                        hitcounterWag++;
                        l++;
                    }
                    l = 0;
                    while(1){//suche Wagerecht in neg Richtung
                        if((i-l) < 0){
                            break;
                        }
                        if((i-l) == 0){
                            if((i-l+k) < 0 || (i-l+k) >= (size+1)){
                                break;
                            }
                            if(k == 1 && feld[i][j] == neg[i-l+k][j]){
                                hitcounterWagneg++;
                                hitcounterWagneg++;
                            }
                            if(feld[i][j] != neg[i-l+k][j]){
                                break;
                            }
                            k++;
                        }else{
                            if(feld[i][j] != feld[i-l][j]){
                                break;
                            }
                        }
                        hitcounterWagneg++;
                        if(k == 1){
                            l++;
                        }
                    }
                    if((hitcounterWag + hitcounterWagneg) >= 5){
                        //printf("Treffer: Feld Wag X: %i Y: %i => %i\n",i,j,feld[i][j]);
                        entfernenxpos[entfernencounterpos] = i;
                        entfernenypos[entfernencounterpos] = j;
                        entfernencounterpos++;
                        if(k > 1){
                            for(int m = 1;m < k;m++){
                                entfernenxneg[entfernencounterneg] = m;
                                entfernenyneg[entfernencounterneg] = j;
                                entfernencounterneg++;
                            }
                        }
                    }
                    hitcounterSen = 0;
                    hitcounterSenneg = 0;
                    l = 0;
                    k = 1;
                    while(1){//suche Senkrecht in pos Richtung
                        if((j+l) >= (laenge+1)){
                            break;
                        }
                        if(feld[i][j] != feld[i][j+l]){
                            break;
                        }
                        hitcounterSen++;
                        l++;
                    }
                    l = 0;
                    while(1){//suche Senkrecht in neg Richtung
                        if((j-l) < 0){
                            break;
                        }
                        if(feld[i][j] != feld[i][j-l]){
                            break;
                        }
                        hitcounterSenneg++;
                        l++;
                    }
                    if((hitcounterSen + hitcounterSenneg) >= 5){
                        //printf("Treffer: Feld Sen X: %i Y: %i => %i\n",i,j,feld[i][j]);
                        entfernenxpos[entfernencounterpos] = i;
                        entfernenypos[entfernencounterpos] = j;
                        entfernencounterpos++;
                    }
                    hitcounterDiaLR = 0;
                    hitcounterDiaLRneg = 0;
                    l = 0;
                    k = 1;
                    while(1){//suche Diagonal LR in pos Richtung
                        if((i+l) >= (size+1) || (j+l) >= (laenge+1)){
                            break;
                        }
                        if(feld[i][j] != feld[i+l][j+l]){
                            break;
                        }
                        hitcounterDiaLR++;
                        l++;
                    }
                    l = 0;
                    while(1){//suche Diagonal LR in neg Richtung
                        if((i-l) < 0 || (j-l) < 0){
                            break;
                        }
                        if((i-l) == 0){
                            if((i-l+k) < 0 || (i-l+k) >= (size+1) || (j-l-k) < 0 || (j-l-k) >= (laenge+1)){
                                break;
                            }
                            if(k == 1 && feld[i][j] == neg[i-l+k][j-l-k]){
                                hitcounterDiaLRneg++;
                                hitcounterDiaLRneg++;
                            }
                            if(feld[i][j] != neg[i-l+k][j-l-k]){
                                break;
                            }
                            k++;
                        }else{
                            if(feld[i][j] != feld[i-l][j-l]){
                                break;
                            }
                        }
                        hitcounterDiaLRneg++;
                        if(k == 1){
                            l++;
                        }
                    }
                    if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                        //printf("Treffer: Feld DiaLR X: %i Y: %i => %i\n",i,j,feld[i][j]);
                        entfernenxpos[entfernencounterpos] = i;
                        entfernenypos[entfernencounterpos] = j;
                        entfernencounterpos++;
                        if(k > 1){
                            for(int m = 1;m < k;m++){
                                entfernenxneg[entfernencounterneg] = m;
                                entfernenyneg[entfernencounterneg] = (j-m);
                                entfernencounterneg++;
                            }
                        }
                    }
                    hitcounterDiaRL = 0;
                    hitcounterDiaRLneg = 0;
                    l = 0;
                    k = 1;
                    while(1){//suche Diagonal RL in pos Richtung (bei (j+l) >= (laenge+1) war es davor ein -)
                        if((i-l) < 0 || (j+l) >= (laenge+1)){
                            break;
                        }
                        if((i-l) <= 0){
                            if((i-l+k) < 0 || (i-l+k) >= (size+1) || (j+l+k) < 0 || (j+l+k) >= (laenge+1)){
                                break;
                            }
                            if(k == 1 && feld[i][j] == neg[i-l+k][j+l+k]){
                                hitcounterDiaRL++;
                                hitcounterDiaRL++;
                            }
                            if(feld[i][j] != neg[i-l+k][j+l+k]){
                                break;
                            }
                            k++;
                        }else{
                            if(feld[i][j] != feld[i-l][j+l]){
                                break;
                            }
                        }
                        hitcounterDiaRL++;
                        if(k == 1){
                            l++;
                        }
                    }
                    l = 0;
                    while(1){//suche Diagonal RL in neg Richtung
                        if((i+l) >= (size+1) || (j-l) < 0){
                            break;
                        }
                        if(feld[i][j] != feld[i+l][j-l]){
                            break;
                        }
                        hitcounterDiaRLneg++;
                        l++;
                    }
                    if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                        //printf("Treffer: Feld DiaRL X: %i Y: %i => %i\n",i,j,feld[i][j]);
                        entfernenxpos[entfernencounterpos] = i;
                        entfernenypos[entfernencounterpos] = j;
                        entfernencounterpos++;
                        if(k > 1){
                            for(int m = 1;m < k;m++){
                                entfernenxneg[entfernencounterneg] = m;
                                entfernenyneg[entfernencounterneg] = (j+m);
                                entfernencounterneg++;
                            }
                        }
                        
                    }
                }
                
                //anfang neg
                if(neg[i][j] != -1){
                    hitcounterWag = 0;
                    hitcounterWagneg = 0;
                    l = 0;
                    while(1){//suche Wagerecht in pos Richtung
                        if((i+l) >= (size+1)){
                            break;
                        }
                        if(neg[i][j] != neg[i+l][j]){
                            break;
                        }
                        hitcounterWag++;
                        l++;
                    }
                    l = 0;
                    while(1){//suche Wagerecht in neg Richtung
                        if((i-l) < 0){
                            break;
                        }
                        if(neg[i][j] != neg[i-l][j]){
                            break;
                        }
                        hitcounterWagneg++;
                        l++;
                    }
                    if((hitcounterWag + hitcounterWagneg) >= 5){
                        //printf("COunterWag: %i CounterWagNeg: %i\n",hitcounterWag, hitcounterWagneg);
                        //printf("Treffer: Neg Wag X: %i Y: %i => %i\n",i,j,neg[i][j]);
                        entfernenxneg[entfernencounterneg] = i;
                        entfernenyneg[entfernencounterneg] = j;
                        entfernencounterneg++;
                    }
                    hitcounterSen = 0;
                    hitcounterSenneg = 0;
                    l = 0;
                    while(1){//suche Senkrecht in pos Richtung
                        if((j+l) >= (laenge+1)){
                            break;
                        }
                        if(neg[i][j] != neg[i][j+l]){
                            break;
                        }
                        hitcounterSen++;
                        l++;
                    }
                    l = 0;
                    while(1){//suche Senkrecht in neg Richtung
                        if((j-l) < 0){
                            break;
                        }
                        if(neg[i][j] != neg[i][j-l]){
                            break;
                        }
                        hitcounterSenneg++;
                        l++;
                    }
                    if((hitcounterSen + hitcounterSenneg) >= 5){
                        //printf("Treffer: Neg Sen X: %i Y: %i => %i\n",i,j,neg[i][j]);
                        entfernenxneg[entfernencounterneg] = i;
                        entfernenyneg[entfernencounterneg] = j;
                        entfernencounterneg++;
                    }
                    hitcounterDiaLR = 0;
                    hitcounterDiaLRneg = 0;
                    l = 0;
                    while(1){//suche Diagonal LR in pos Richtung
                        if((i+l) >= (size+1) || (j+l) >= (laenge+1)){
                            break;
                        }
                        if(neg[i][j] != neg[i+l][j+l]){
                            break;
                        }
                        hitcounterDiaLR++;
                        l++;
                    }
                    l = 0;
                    while(1){//suche Diagonal LR in neg Richtung
                        if((i-l) < 0 || (j-l) < 0){
                            break;
                        }
                        if(neg[i][j] != neg[i-l][j-l]){
                            break;
                        }
                        hitcounterDiaLRneg++;
                        l++;
                    }
                    if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                        //printf("Treffer: Neg DiaLR X: %i Y: %i => %i \n",i,j,neg[i][j]);
                        entfernenxneg[entfernencounterneg] = i;
                        entfernenyneg[entfernencounterneg] = j;
                        entfernencounterneg++;
                    }
                    hitcounterDiaRL = 0;
                    hitcounterDiaRLneg = 0;
                    l = 0;
                    while(1){//suche Diagonal RL in pos Richtung
                        if((i-l) < 0 || (j+l) >= (laenge+1)){
                            break;
                        }
                        if(neg[i][j] != neg[i-l][j+l]){
                            break;
                        }
                        hitcounterDiaRL++;
                        l++;
                    }
                    l = 0;
                    while(1){//suche Diagonal RL in neg Richtung
                        if((i+l) >= (size+1) || (j-l) < 0){
                            break;
                        }
                        if(neg[i][j] != neg[i+l][j-l]){
                            break;
                        }
                        hitcounterDiaRLneg++;
                        l++;
                    }
                    if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                        //printf("Treffer: Neg DiaRL X: %i Y: %i => %i\n",i,j,neg[i][j]);
                        entfernenxneg[entfernencounterneg] = i;
                        entfernenyneg[entfernencounterneg] = j;
                        entfernencounterneg++;
                    }
                }
                j++;
            }
        }
    }

    durchlaeufe++;

    //vergleich ende

    //rutschen start

    //printf("Counter NEG: %i\n", entfernencounterneg);
    //printf("Counter POS: %i\n", entfernencounterpos);

    if(entfernencounterneg > 0 || entfernencounterpos > 0){
        aenderungen = 1;
    }
    
    help = entfernencounterpos;
    while(help > 0){
        feld[entfernenxpos[help-1]][entfernenypos[help-1]] = 255;
        //printf("POS X: %i Y: %i\n", entfernenxpos[help-1], entfernenypos[help-1]);
        help--;
    }
    help = entfernencounterpos;
    while(help > 0){
        if(feld[entfernenxpos[help-1]][entfernenypos[help-1]] == 255){
            int k = 0;
            while(feld[entfernenxpos[help-1]][(entfernenypos[help-1])+k] == 255){
                //notausstieg [j+k] könnte über array hinaus laufen
                k++;
            }
            for(int l = 0;(l+(entfernenypos[help-1])) < ((laenge+1)-k);l++){
                feld[entfernenxpos[help-1]][(entfernenypos[help-1])+l] = feld[entfernenxpos[help-1]][(entfernenypos[help-1])+l+k];
            }
            //ungetestet
            for(int m = ((laenge+1)-k);m < (laenge+1);m++){
                feld[entfernenxpos[help-1]][m] = -1;
            }
        }        
        help--;
    }

    help = entfernencounterneg;
    while(help > 0){
        neg[entfernenxneg[help-1]][entfernenyneg[help-1]] = 255;
        //printf("NEG X: %i Y: %i\n", entfernenxneg[help-1], entfernenyneg[help-1]);
        help--;
    }
    help = entfernencounterneg;
    while(help > 0){
        if(neg[entfernenxneg[help-1]][entfernenyneg[help-1]] == 255){
            int k = 0;
            while(neg[entfernenxneg[help-1]][(entfernenyneg[help-1])+k] == 255){
                //notausstieg [j+k] könnte über array hinaus laufen
                k++;
            }
            for(int l = 0;(l+(entfernenyneg[help-1])) < ((laenge+1)-k);l++){
                neg[entfernenxneg[help-1]][(entfernenyneg[help-1])+l] = neg[entfernenxneg[help-1]][(entfernenyneg[help-1])+l+k];
            }
            //ungetestet
            for(int m = ((laenge+1)-k);m < (laenge+1);m++){
                neg[entfernenxneg[help-1]][m] = -1;
            }
        }
        help--;
    }
    help = 0;
    //entfernencounterpos = 0;
    //entfernencounterneg = 0;

    //printf("%i\n", neg[1][0]);

    //rutschen ende

    //loop start 
    
    while(1){
        //printf("Aendrungen: %i\n",aenderungen);
        if(aenderungen == 0){
            break;
        }else{
            aenderungen = 0;
        }

        //loop vergleich start
        //printf("NegCounter davor 621: %i\n", entfernencounterneg);

        if((durchlaeufe % 2) == 0){
            //printf("Gerade Anzahl an Durchläufen.\n");
            help = entfernencounterposzwei;
            while(help > 0){
                int i = 0;
                int k = 1;
                for(int j = 0;(j+entfernenyposzwei[(help-1)]) < (laenge+1);j++){
                    if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1){
                        break;
                    }
                    hitcounterWag = 0;
                    hitcounterWagneg = 0;
                    i = 0;
                    k = 1;
                    while(1){//suche Wagerecht in pos Richtung
                        if((entfernenxposzwei[(help-1)]+i) >= (size+1)){
                            break;
                        }
                        if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]+i][entfernenyposzwei[(help-1)]+j]){
                            break;
                        }
                        hitcounterWag++;
                        i++;
                    }
                    i = 0;
                    while(1){//suche Wagerecht in neg Richtung
                        if((entfernenxposzwei[(help-1)]-i) < 0){
                            break;
                        }
                        if((entfernenxposzwei[(help-1)]-i) == 0){
                            if((entfernenxposzwei[(help-1)]-i+k) < 0 || (entfernenxposzwei[(help-1)]-i+k) >= (size+1)){
                                break;
                            }
                            if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == feld[0][entfernenyposzwei[(help-1)]+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k][entfernenyposzwei[(help-1)]+j]){
                                hitcounterWagneg++;
                                break;
                            }
                            if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[0][entfernenyposzwei[(help-1)]+j]){
                                break;
                            }
                            if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == neg[k][entfernenyposzwei[(help-1)]+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                hitcounterWagneg++;
                                hitcounterWagneg++;
                            }
                            if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k+1][entfernenyposzwei[(help-1)]+j]){
                                break;
                            }
                            k++;
                        }else{
                            if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]-i][entfernenyposzwei[(help-1)]+j]){
                                break;
                            }
                        }
                        hitcounterWagneg++;
                        if(k == 1){
                            i++;
                        }
                    }
                    if((hitcounterWag + hitcounterWagneg) >= 5){
                        //printf("Gefunden Loop(0) Wag\n");
                        entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                        entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                        entfernencounterpos++;
                        int m = 1;
                        while(m < hitcounterWag){
                            entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]+m;
                            entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                            entfernencounterpos++;
                            m++;
                        }
                        m = 1;
                        int n = 0;
                        while(m < hitcounterWagneg){
                            if((entfernenxposzwei[(help-1)]-m) < 0){
                                entfernenxneg[entfernencounterneg] = n;
                                n++;
                                entfernenyneg[entfernencounterneg] = entfernenyposzwei[(help-1)]+j;
                                entfernencounterneg++;
                            }else{
                                entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]-m;
                                entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                                entfernencounterpos++;
                            }
                            m++;
                        }
                        
                    }
                    hitcounterSen = 0;
                    hitcounterSenneg = 0;
                    i = 0;
                    k = 1;
                    while(1){//suche Senkrecht in pos Richtung
                        if((entfernenyposzwei[(help-1)]+i+j) >= (laenge+1)){
                            break;
                        }
                        if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+i+j]){
                            break;
                        }
                        hitcounterSen++;
                        i++;
                    }
                    i = 0;
                    while(1){//suche Senkrecht in neg Richtung
                        if((entfernenyposzwei[(help-1)]-i+j) < 0){
                            break;
                        }
                        if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]-i+j]){
                            break;
                        }
                        hitcounterSenneg++;
                        i++;
                    }
                    if((hitcounterSen + hitcounterSenneg) >= 5){
                        //printf("Gefunden Loop(0) Sen\n");
                        entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                        entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                        entfernencounterpos++;
                        int m = 1;
                        while(m < hitcounterSen){
                            entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                            entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j+m;
                            entfernencounterpos++;
                            m++;
                        }
                        m = 1;
                        while(m < hitcounterSenneg){
                            entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                            entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j-m;
                            entfernencounterpos++;
                            m++;
                        }
                    }
                    hitcounterDiaLR = 0;
                    hitcounterDiaLRneg = 0;
                    i = 0;
                    k = 1;
                    while(1){//suche Diagonal LR in pos Richtung
                        if((entfernenxposzwei[(help-1)]+i) >= (size+1) || (entfernenyposzwei[(help-1)]+i+j) >= (laenge+1)){
                            break;
                        }
                        if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]+i][entfernenyposzwei[(help-1)]+i+j]){
                            break;
                        }
                        hitcounterDiaLR++;
                        i++;
                    }
                    i = 0;
                    while(1){//suche Diagonal LR in neg Richtung
                        if((entfernenxposzwei[(help-1)]-i) < 0 || (entfernenyposzwei[(help-1)]-i+j) < 0){
                            break;
                        }
                        if((entfernenxposzwei[(help-1)]-i) == 0){
                            if((entfernenxposzwei[(help-1)]-i+k) < 0 || (entfernenxposzwei[(help-1)]-i+k) >= (size+1) || (entfernenyposzwei[(help-1)]-i+j-k) < 0 || (entfernenyposzwei[(help-1)]-i+j-k) >= (laenge+1)){
                                break;
                            }
                            if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == feld[0][entfernenyposzwei[(help-1)]-i+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k][entfernenyposzwei[(help-1)]-i+j-k]){
                                hitcounterDiaLRneg++;
                                break;
                            }
                            if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[0][entfernenyposzwei[(help-1)]-i+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                break;
                            }
                            if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == neg[k][entfernenyposzwei[(help-1)]-i+j-k] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                hitcounterDiaLRneg++;
                                hitcounterDiaLRneg++;
                            }
                            if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k+1][entfernenyposzwei[(help-1)]-i+j-k-1]){
                                break;
                            }
                            k++;
                        }else{
                            if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]-i][entfernenyposzwei[(help-1)]-i+j]){
                                break;
                            }
                        }
                        hitcounterDiaLRneg++;
                        if(k == 1){
                            i++;
                        }
                    }
                    if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                        //printf("Gefunden Loop(0) DiaLR\n");
                        entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                        entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                        entfernencounterpos++;
                        int m = 1;
                        while(m < hitcounterDiaLR){
                            entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]+m;
                            entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j+m;
                            entfernencounterpos++;
                            m++;
                        }
                        m = 1;
                        int n = 0;
                        while(m < hitcounterDiaLRneg){
                            if((entfernenxposzwei[(help-1)]-m) < 0){
                                entfernenxneg[entfernencounterneg] = n;
                                n++;
                                entfernenyneg[entfernencounterneg] = entfernenyposzwei[(help-1)]+j+m;
                                entfernencounterneg++;
                            }else{
                                entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]-m;
                                entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j-m;
                                entfernencounterpos++;
                            }
                            m++;
                        }
                    }
                    hitcounterDiaRL = 0;
                    hitcounterDiaRLneg = 0;
                    i = 0;
                    k = 1;
                    while(1){//suche Diagonal RL in pos Richtung
                        if((entfernenxposzwei[(help-1)]-i) < 0 || (entfernenyposzwei[(help-1)]-i+j) >= (laenge+1)){
                            break;
                        }
                        if((entfernenxposzwei[(help-1)]-i) == 0){
                            if((entfernenxposzwei[(help-1)]-i+k) < 0 || (entfernenxposzwei[(help-1)]-i+k) >= (size+1) || (entfernenyposzwei[(help-1)]+i+j+k) < 0 || (entfernenyposzwei[(help-1)]+i+j+k) >= (laenge+1)){
                                break;
                            }
                            if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == feld[0][entfernenyposzwei[(help-1)]+i+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k][entfernenyposzwei[(help-1)]+i+j+k]){
                                hitcounterDiaRL++;
                                break;
                            }
                            if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[0][entfernenyposzwei[(help-1)]+i+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                break;
                            }
                            if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == neg[k][entfernenyposzwei[(help-1)]+i+j+k] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                hitcounterDiaRL++;
                                hitcounterDiaRL++;
                            }
                            if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k+1][entfernenyposzwei[(help-1)]+i+j+k+1]){
                                break;
                            }
                            k++;
                        }else{
                            if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]-i][entfernenyposzwei[(help-1)]+i+j]){
                                break;
                            }
                        }
                        hitcounterDiaRL++;
                        if(k == 1){
                            i++;
                        }
                    }
                    i = 0;
                    while(1){//suche Diagonal RL in neg Richtung
                        if((entfernenxposzwei[(help-1)]+i) >= (size+1) || (entfernenyposzwei[(help-1)]-i+j) < 0){
                            break;
                        }
                        if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]+i][entfernenyposzwei[(help-1)]-i+j]){
                            break;
                        }
                        hitcounterDiaRLneg++;
                        i++;
                    }
                    if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                        //printf("Gefunden Loop(0) DiaRL\n");
                        entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                        entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                        entfernencounterpos++;
                        int m = 1;
                        int n =0;
                        while(m < hitcounterDiaRL){
                            if((entfernenxposzwei[(help-1)]-m) < 0){
                                entfernenxneg[entfernencounterneg] = n;
                                n++;
                                entfernenyneg[entfernencounterneg] = entfernenyposzwei[(help-1)]+j+m;
                                entfernencounterneg++;
                            }else{
                                entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]-m;
                                entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j+m;
                                entfernencounterpos++;
                            }
                            m++;
                        }
                        m = 1;
                        while(m < hitcounterDiaRLneg){
                            entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]+m;
                            entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j-m;
                            entfernencounterpos++;
                            m++;
                        }
                    }
                }
                help--;
            }
            
            help = entfernencounternegzwei;
            while(help > 0){
                int i = 0;
                int k = 1;
                for(int j = 0;(j+entfernenynegzwei[(help-1)]) < (laenge+1);j++){
                    if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1){
                        break;
                    }
                    //printf("Aktuelles Neg: X: %i Y: %i Farbe: %i\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j]);
                    hitcounterWag = 0;
                    hitcounterWagneg = 0;
                    i = 0;
                    k = 1;
                    while(1){//suche Wagerecht in pos Richtung
                        if((entfernenxnegzwei[(help-1)]+i) >= (size+1)){
                            break;
                        }
                        if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]+i][entfernenynegzwei[(help-1)]+j]){
                            break;
                        }
                        hitcounterWag++;
                        i++;
                    }
                    i = 0;
                    while(1){//suche Wagerecht in neg Richtung
                        if((entfernenxnegzwei[(help-1)]-i) < 1){
                            //printf("break 1\n");
                            break;
                        }
                        if((entfernenxnegzwei[(help-1)]-i) == 1){
                            if((entfernenxnegzwei[(help-1)]-i+k) < 1 || (entfernenxnegzwei[(help-1)]-i+k) >= (size+1)){
                                //printf("break 2\n");
                                break;
                            }
                            if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == neg[1][entfernenynegzwei[(help-1)]+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k-1][entfernenynegzwei[(help-1)]+j]){
                                hitcounterWagneg++;
                                break;
                            }
                            if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[1][entfernenynegzwei[(help-1)]+j]){
                                break;
                            }
                            if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == feld[k-1][entfernenynegzwei[(help-1)]+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                //printf("hi\n");
                                hitcounterWagneg++;
                                hitcounterWagneg++;
                            }
                            if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k][entfernenynegzwei[(help-1)]+j]){
                                //printf("break 3\n");
                                break;
                            }
                            k++;
                        }else{
                            if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]-i][entfernenynegzwei[(help-1)]+j]){
                                //printf("break 4\n");
                                break;
                            }
                        }
                        hitcounterWagneg++;
                        if(k == 1){
                            i++;
                        }
                    }
                    //printf("Hit Wag: %i\n", hitcounterWag);
                    //printf("Hit Wag Neg: %i\n", hitcounterWagneg);
                    if((hitcounterWag + hitcounterWagneg) >= 5){
                        //printf("Gefunden Loop(0) Wag\n");
                        //printf("1) speichere: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                        entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                        entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                        entfernencounterneg++;
                        //printf("entfernt 982\n");
                        //printf("neu in neg entfernen: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                        //printf("entfernen NEG aktuelle Position: (%i,%i)\n",entfernenxnegzwei[entfernencounternegzwei-1],entfernenynegzwei[entfernencounternegzwei-1]);
                        int m = 1;
                        while(m < hitcounterWag){
                            //printf("2) speichere: (%i,%i)\n",entfernenxneg[(help-1)]+m,entfernenyneg[(help-1)]+j);
                            entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]+m;
                            entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                            entfernencounterneg++;
                            //printf("entfernt 990\n");
                            m++;
                        }
                        m = 1;
                        int n = 0;
                        while(m < hitcounterWagneg){
                            if((entfernenxnegzwei[(help-1)]-m) < 1){
                                //printf("3) speichere: (%i,%i)\n",n,entfernenyneg[(help-1)]+j);
                                entfernenxpos[entfernencounterpos] = n;
                                n++;
                                entfernenypos[entfernencounterpos] = entfernenynegzwei[(help-1)]+j;
                                entfernencounterpos++;
                                //printf("neu in entfernen: (%i,%i)\n",n-1,entfernenyneg[(help-1)]+j);
                                //printf("entfernen aktuelle Position: (%i,%i)\n",entfernenxposzwei[entfernencounterposzwei-1],entfernenyposzwei[entfernencounterposzwei-1]);
                            }else{
                                //printf("4) speichere: (%i,%i)\n",entfernenxneg[(help-1)]-m,entfernenyneg[(help-1)]+j);
                                entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]-m;
                                entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                                entfernencounterneg++;
                                //printf("entfernt 1008\n");
                            }
                            m++;
                        }
                        
                    }
                    hitcounterSen = 0;
                    hitcounterSenneg = 0;
                    i = 0;
                    while(1){//suche Senkrecht in pos Richtung
                        if((entfernenynegzwei[(help-1)]+i+j) >= (laenge+1)){
                            break;
                        }
                        if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+i+j]){
                            break;
                        }
                        hitcounterSen++;
                        i++;
                    }
                    i = 0;
                    while(1){//suche Senkrecht in neg Richtung
                        if((entfernenynegzwei[(help-1)]-i+j) < 0){
                            break;
                        }
                        if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]-i+j]){
                            break;
                        }
                        hitcounterSenneg++;
                        i++;
                    }
                    if((hitcounterSen + hitcounterSenneg) >= 5){
                        //printf("Gefunden Loop(0) Sen\n");
                        entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                        entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                        entfernencounterneg++;
                        //printf("entfernt 1143\n");
                        int m = 1;
                        while(m < hitcounterSen){
                            entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                            entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j+m;
                            entfernencounterneg++;
                            //printf("entfernt 1048\n");
                            m++;
                        }
                        m = 1;
                        while(m < hitcounterSenneg){
                            entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                            entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j-m;
                            entfernencounterneg++;
                            //printf("entfernt 1055\n");
                            m++;
                        }
                    }
                    hitcounterDiaLR = 0;
                    hitcounterDiaLRneg = 0;
                    i = 0;
                    k = 1;
                    while(1){//suche Diagonal LR in pos Richtung
                        if((entfernenxnegzwei[(help-1)]+i) >= (size+1) || (entfernenynegzwei[(help-1)]+i+j) >= (laenge+1)){
                            break;
                        }
                        if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]+i][entfernenynegzwei[(help-1)]+i+j]){
                            break;
                        }
                        hitcounterDiaLR++;
                        i++;
                    }
                    i = 0;
                    while(1){//suche Diagonal LR in neg Richtung
                        if((entfernenxnegzwei[(help-1)]-i) < 1 || (entfernenynegzwei[(help-1)]-i+j) < 1){
                            break;
                        }
                        if((entfernenxnegzwei[(help-1)]-i) == 1){
                            if((entfernenxnegzwei[(help-1)]-i+k) < 1 || (entfernenxnegzwei[(help-1)]-i+k) >= (size+1) || (entfernenynegzwei[(help-1)]-i+j-k) < 0 || (entfernenynegzwei[(help-1)]-i+j-k) >= (laenge+1)){
                                break;
                            }
                            if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == neg[1][entfernenynegzwei[(help-1)]-i+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k-1][entfernenynegzwei[(help-1)]-i+j-k]){
                                hitcounterDiaLRneg++;
                                break;
                            }
                            if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[1][entfernenynegzwei[(help-1)]-i+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                break;
                            }
                            if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == feld[k-1][entfernenynegzwei[(help-1)]-i+j-k] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                hitcounterDiaLRneg++;
                                hitcounterDiaLRneg++;
                            }
                            if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k][entfernenynegzwei[(help-1)]-i+j-k-1]){
                                break;
                            }
                            k++;
                        }else{
                            if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]-i][entfernenynegzwei[(help-1)]-i+j]){
                                break;
                            }
                        }
                        hitcounterDiaLRneg++;
                        if(k == 1){
                            i++;
                        }
                    }
                    if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                        //printf("Gefunden Loop(0) DiaLR\n");
                        entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                        entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                        entfernencounterneg++;
                        //printf("entfernt 1112\n");
                        int m = 1;
                        while(m < hitcounterDiaLR){
                            entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]+m;
                            entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j+m;
                            entfernencounterneg++;
                            //printf("entfernt 1117\n");
                            m++;
                        }
                        m = 1;
                        int n = 0;
                        while(m < hitcounterDiaLRneg){
                            if((entfernenxnegzwei[(help-1)]-m) < 1){
                                entfernenxpos[entfernencounterpos] = n;
                                n++;
                                entfernenypos[entfernencounterpos] = entfernenynegzwei[(help-1)]+j+m;
                                entfernencounterpos++;
                            }else{
                                entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]-m;
                                entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j-m;
                                entfernencounterneg++;
                                //printf("entfernt 1131\n");
                            }
                            m++;
                        }
                    }
                    hitcounterDiaRL = 0;
                    hitcounterDiaRLneg = 0;
                    i = 0;
                    k = 1;
                    while(1){//suche Diagonal RL in pos Richtung
                        if((entfernenxnegzwei[(help-1)]-i) < 1 || (entfernenynegzwei[(help-1)]-i+j) >= (laenge+1)){
                            break;
                        }
                        if((entfernenxnegzwei[(help-1)]-i) == 1){
                            //printf("3 wird verglichen mit: %i\n",neg[entfernenxneg[(help-1)]-i+k][entfernenyneg[(help-1)]+i+j+k]);
                            if((entfernenxnegzwei[(help-1)]-i+k) < 1 || (entfernenxnegzwei[(help-1)]-i+k) >= (size+1) || (entfernenynegzwei[(help-1)]+i+j+k) < 0 || (entfernenynegzwei[(help-1)]+i+j+k) >= (laenge+1)){
                                break;
                            }
                            if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == neg[1][entfernenynegzwei[(help-1)]+i+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k-1][entfernenynegzwei[(help-1)]+i+j+k]){
                                hitcounterDiaRL++;
                                break;
                            }
                            if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[1][entfernenynegzwei[(help-1)]+i+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                break;
                            }
                            if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == feld[k-1][entfernenynegzwei[(help-1)]+i+j+k] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                hitcounterDiaRL++;
                                hitcounterDiaRL++;
                                //printf("erhöhe um 2\n");
                            }
                            if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k][entfernenynegzwei[(help-1)]+i+j+k+1]){
                                break;
                            }
                            //printf("erhöhe um 1 (Übergang)\n");
                            k++;
                        }else{
                            //printf("3 wird verglichen mit: %i\n",neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j]);
                            if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]-i][entfernenynegzwei[(help-1)]+i+j]){
                                break;
                            }
                            //printf("erhöhe um 1 (kein Übergang)\n");
                            //printf("%i bei (%i,%i) und %ibei (%i,%i)\n",neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j],entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j],entfernenxneg[(help-1)]-i,entfernenyneg[(help-1)]+i+j);
                        }
                        hitcounterDiaRL++;
                        if(k == 1){
                            i++;
                        }
                    }
                    i = 0;
                    while(1){//suche Diagonal RL in neg Richtung
                        if((entfernenxnegzwei[(help-1)]+i) >= (size+1) || (entfernenynegzwei[(help-1)]-i+j) < 0){
                            break;
                        }
                        if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]+i][entfernenynegzwei[(help-1)]-i+j]){
                            break;
                        }
                        hitcounterDiaRLneg++;
                        i++;
                    }
                    //printf("hit DiaRL pos: %i\n", hitcounterDiaRL);
                    //printf("hit DiaRL neg: %i\n", hitcounterDiaRLneg);
                    if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                        //printf("Gefunden Loop(0) DiaRL\n");
                        //printf("1) speichere: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                        entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                        entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                        entfernencounterneg++;
                        //printf("entfernt 1198\n");
                        int m = 1;
                        int n =0;
                        while(m < hitcounterDiaRL){
                            if((entfernenxnegzwei[(help-1)]-m) < 1){
                                //printf("2) speichere: (%i,%i)\n",n,entfernenyneg[(help-1)]+j+m);
                                entfernenxpos[entfernencounterpos] = n;
                                n++;
                                entfernenypos[entfernencounterpos] = entfernenynegzwei[(help-1)]+j+m;
                                entfernencounterpos++;
                            }else{
                                //printf("3) speichere: (%i,%i)\n",entfernenxneg[(help-1)]-m,entfernenyneg[(help-1)]+j+m);
                                entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]-m;
                                entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j+m;
                                entfernencounterneg++;
                                //printf("entfernt 1212\n");
                            }
                            m++;
                        }
                        m = 1;
                        while(m < hitcounterDiaRLneg){
                            //printf("4) speichere: (%i,%i)\n",entfernenxneg[(help-1)]+m,entfernenyneg[(help-1)]+j-m);
                            entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]+m;
                            entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j-m;
                            entfernencounterneg++;
                            //printf("entfernt 1221\n");
                            m++;
                        }
                    }
                }
                help--;
            }
            help = 0;

            if(entfernencounterneg > 0 || entfernencounterpos > 0){
                aenderungen = 1;
            }
            //printf("entfernenPOS: %i\n", entfernencounterpos);
            //printf("entfernenNEG: %i\n", entfernencounterneg);
            help = entfernencounterpos;
            while(help > 0){
                feld[entfernenxpos[help-1]][entfernenypos[help-1]] = 255;
                //printf("POS X: %i Y: %i\n", entfernenxposzwei[help-1], entfernenyposzwei[help-1]);
                help--;
            }
            help = entfernencounterpos;
            while(help > 0){
                if(feld[entfernenxpos[help-1]][entfernenypos[help-1]] == 255){
                    int k = 0;
                    while(feld[entfernenxpos[help-1]][(entfernenypos[help-1])+k] == 255){
                        //notausstieg [j+k] könnte über array hinaus laufen
                        k++;
                    }
                    for(int l = 0;(l+(entfernenypos[help-1])) < ((laenge+1)-k);l++){
                        feld[entfernenxpos[help-1]][(entfernenypos[help-1])+l] = feld[entfernenxpos[help-1]][(entfernenypos[help-1])+l+k];
                    }
                    //ungetestet
                    for(int m = ((laenge+1)-k);m < (laenge+1);m++){
                        feld[entfernenxpos[help-1]][m] = -1;
                    }
                }        
                help--;
            }

            help = entfernencounterneg;
            while(help > 0){
                neg[entfernenxneg[help-1]][entfernenyneg[help-1]] = 255;
                //printf("NEG X: %i Y: %i\n", entfernenxnegzwei[help-1], entfernenynegzwei[help-1]);
                help--;
            }
            help = entfernencounterneg;
            while(help > 0){
                if(neg[entfernenxneg[help-1]][entfernenyneg[help-1]] == 255){
                    int k = 0;
                    while(neg[entfernenxneg[help-1]][(entfernenyneg[help-1])+k] == 255){
                        //notausstieg [j+k] könnte über array hinaus laufen
                        k++;
                    }
                    for(int l = 0;(l+(entfernenyneg[help-1])) < ((laenge+1)-k);l++){
                        neg[entfernenxneg[help-1]][(entfernenyneg[help-1])+l] = neg[entfernenxneg[help-1]][(entfernenyneg[help-1])+l+k];
                    }
                    //ungetestet
                    for(int m = ((laenge+1)-k);m < (laenge+1);m++){
                        neg[entfernenxneg[help-1]][m] = -1;
                    }
                }
                help--;
            }
            help = 0;
            entfernencounterposzwei = 0;
            entfernencounternegzwei = 0;
        }
        if((durchlaeufe % 2) == 1){
            //printf("Ungerade Anzahl an Durchläufen.\n");
            help = entfernencounterpos;
            while(help > 0){
                int i = 0;
                int k = 1;
                for(int j = 0;(j+entfernenypos[(help-1)]) < (laenge+1);j++){
                    if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1){
                        break;
                    }
                    hitcounterWag = 0;
                    hitcounterWagneg = 0;
                    i = 0;
                    k = 1;
                    while(1){//suche Wagerecht in pos Richtung
                        if((entfernenxpos[(help-1)]+i) >= (size+1)){
                            break;
                        }
                        if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]+i][entfernenypos[(help-1)]+j]){
                            break;
                        }
                        hitcounterWag++;
                        i++;
                    }
                    i = 0;
                    while(1){//suche Wagerecht in neg Richtung
                        if((entfernenxpos[(help-1)]-i) < 0){
                            break;
                        }
                        if((entfernenxpos[(help-1)]-i) == 0){
                            if((entfernenxpos[(help-1)]-i+k) < 0 || (entfernenxpos[(help-1)]-i+k) >= (size+1)){
                                break;
                            }
                            if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == feld[0][entfernenypos[(help-1)]+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k][entfernenypos[(help-1)]+j]){
                                hitcounterWagneg++;
                                break;
                            }
                            if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[0][entfernenypos[(help-1)]+j]){
                                break;
                            }
                            if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == neg[k-1][entfernenypos[(help-1)]+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                hitcounterWagneg++;
                                hitcounterWagneg++;
                            }
                            if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k+1][entfernenypos[(help-1)]+j]){
                                break;
                            }
                            k++;
                        }else{
                            if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]-i][entfernenypos[(help-1)]+j]){
                                break;
                            }
                        }
                        hitcounterWagneg++;
                        if(k == 1){
                            i++;
                        }
                    }
                    if((hitcounterWag + hitcounterWagneg) >= 5){
                        //printf("Gefunden Loop Wag\n");
                        entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                        entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                        entfernencounterposzwei++;
                        int m = 1;
                        while(m < hitcounterWag){
                            entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]+m;
                            entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                            entfernencounterposzwei++;
                            m++;
                        }
                        m = 1;
                        int n = 0;
                        while(m < hitcounterWagneg){
                            if((entfernenxpos[(help-1)]-m) < 0){
                                entfernenxnegzwei[entfernencounternegzwei] = n;
                                n++;
                                entfernenynegzwei[entfernencounternegzwei] = entfernenypos[(help-1)]+j;
                                entfernencounternegzwei++;
                            }else{
                                entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]-m;
                                entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                                entfernencounterposzwei++;
                            }
                            m++;
                        }
                        
                    }
                    hitcounterSen = 0;
                    hitcounterSenneg = 0;
                    i = 0;
                    k = 1;
                    while(1){//suche Senkrecht in pos Richtung
                        if((entfernenypos[(help-1)]+i+j) >= (laenge+1)){
                            break;
                        }
                        if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+i+j]){
                            break;
                        }
                        hitcounterSen++;
                        i++;
                    }
                    i = 0;
                    while(1){//suche Senkrecht in neg Richtung
                        if((entfernenypos[(help-1)]-i+j) < 0){
                            break;
                        }
                        if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]-i+j]){
                            break;
                        }
                        hitcounterSenneg++;
                        i++;
                    }
                    if((hitcounterSen + hitcounterSenneg) >= 5){
                        //printf("Gefunden Loop Sen\n");
                        entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                        entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                        entfernencounterposzwei++;
                        int m = 1;
                        while(m < hitcounterSen){
                            entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                            entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j+m;
                            entfernencounterposzwei++;
                            m++;
                        }
                        m = 1;
                        while(m < hitcounterSenneg){
                            entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                            entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j-m;
                            entfernencounterposzwei++;
                            m++;
                        }
                    }
                    hitcounterDiaLR = 0;
                    hitcounterDiaLRneg = 0;
                    i = 0;
                    k = 1;
                    while(1){//suche Diagonal LR in pos Richtung
                        if((entfernenxpos[(help-1)]+i) >= (size+1) || (entfernenypos[(help-1)]+i+j) >= (laenge+1)){
                            break;
                        }
                        if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]+i][entfernenypos[(help-1)]+i+j]){
                            break;
                        }
                        hitcounterDiaLR++;
                        i++;
                    }
                    i = 0;
                    while(1){//suche Diagonal LR in neg Richtung
                        if((entfernenxpos[(help-1)]-i) < 0 || (entfernenypos[(help-1)]-i+j) < 0){
                            break;
                        }
                        if((entfernenxpos[(help-1)]-i) == 0){
                            if((entfernenxpos[(help-1)]-i+k) < 0 || (entfernenxpos[(help-1)]-i+k) >= (size+1) || (entfernenypos[(help-1)]-i+j-k) < 0 || (entfernenypos[(help-1)]-i+j-k) >= (laenge+1)){
                                break;
                            }
                            if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == feld[0][entfernenypos[(help-1)]-i+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k][entfernenypos[(help-1)]-i+j-k]){
                                hitcounterDiaLRneg++;
                                break;
                            }
                            if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[0][entfernenypos[(help-1)]-i+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                break;
                            }
                            if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == neg[k][entfernenypos[(help-1)]-i+j-k] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                hitcounterDiaLRneg++;
                                hitcounterDiaLRneg++;
                            }
                            if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k+1][entfernenypos[(help-1)]-i+j-k-1]){
                                break;
                            }
                            k++;
                        }else{
                            if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]-i][entfernenypos[(help-1)]-i+j]){
                                break;
                            }
                        }
                        hitcounterDiaLRneg++;
                        if(k == 1){
                            i++;
                        }
                    }
                    if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                        //printf("Gefunden Loop DiaLR\n");
                        entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                        entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                        entfernencounterposzwei++;
                        int m = 1;
                        while(m < hitcounterDiaLR){
                            entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]+m;
                            entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j+m;
                            entfernencounterposzwei++;
                            m++;
                        }
                        m = 1;
                        int n = 0;
                        while(m < hitcounterDiaLRneg){
                            if((entfernenxpos[(help-1)]-m) < 0){
                                entfernenxnegzwei[entfernencounternegzwei] = n;
                                n++;
                                entfernenynegzwei[entfernencounternegzwei] = entfernenypos[(help-1)]+j+m;
                                entfernencounternegzwei++;
                            }else{
                                entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]-m;
                                entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j-m;
                                entfernencounterposzwei++;
                            }
                            m++;
                        }
                    }
                    hitcounterDiaRL = 0;
                    hitcounterDiaRLneg = 0;
                    i = 0;
                    k = 1;
                    while(1){//suche Diagonal RL in pos Richtung
                        if((entfernenxpos[(help-1)]-i) < 0 || (entfernenypos[(help-1)]-i+j) >= (laenge+1)){
                            break;
                        }
                        if((entfernenxpos[(help-1)]-i) == 0){
                            if((entfernenxpos[(help-1)]-i+k) < 0 || (entfernenxpos[(help-1)]-i+k) >= (size+1) || (entfernenypos[(help-1)]+i+j+k) < 0 || (entfernenypos[(help-1)]+i+j+k) >= (laenge+1)){
                                break;
                            }
                            if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == feld[0][entfernenypos[(help-1)]+i+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k][entfernenypos[(help-1)]+i+j+k]){
                                hitcounterDiaRL++;
                                break;
                            }
                            if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[0][entfernenypos[(help-1)]+i+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                break;
                            }
                            if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == neg[k][entfernenypos[(help-1)]+i+j+k] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                hitcounterDiaRL++;
                                hitcounterDiaRL++;
                            }
                            if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k+1][entfernenypos[(help-1)]+i+j+k+1]){
                                break;
                            }
                            k++;
                        }else{
                            if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]-i][entfernenypos[(help-1)]+i+j]){
                                break;
                            }
                        }
                        hitcounterDiaRL++;
                        if(k == 1){
                            i++;
                        }
                    }
                    i = 0;
                    while(1){//suche Diagonal RL in neg Richtung
                        if((entfernenxpos[(help-1)]+i) >= (size+1) || (entfernenypos[(help-1)]-i+j) < 0){
                            break;
                        }
                        if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]+i][entfernenypos[(help-1)]-i+j]){
                            break;
                        }
                        hitcounterDiaRLneg++;
                        i++;
                    }
                    if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                        //printf("Gefunden Loop DiaRL\n");
                        entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                        entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                        entfernencounterposzwei++;
                        int m = 1;
                        int n =0;
                        while(m < hitcounterDiaRL){
                            if((entfernenxpos[(help-1)]-m) < 0){
                                entfernenxnegzwei[entfernencounternegzwei] = n;
                                n++;
                                entfernenynegzwei[entfernencounternegzwei] = entfernenypos[(help-1)]+j+m;
                                entfernencounternegzwei++;
                            }else{
                                entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]-m;
                                entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j+m;
                                entfernencounterposzwei++;
                            }
                            m++;
                        }
                        m = 1;
                        while(m < hitcounterDiaRLneg){
                            entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]+m;
                            entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j-m;
                            entfernencounterposzwei++;
                            m++;
                        }
                    }
                }
                help--;
            }
            
            help = entfernencounterneg;
            //printf("NegCounter: %i\n", entfernencounterneg);
            while(help > 0){
                int i = 0;
                int k = 1;
                for(int j = 0;(j+entfernenyneg[(help-1)]) < (laenge+1);j++){
                    if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1){
                        break;
                    }
                    //printf("Aktuelles Neg: X: %i Y: %i Farbe: %i\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j]);
                    hitcounterWag = 0;
                    hitcounterWagneg = 0;
                    i = 0;
                    k = 1;
                    while(1){//suche Wagerecht in pos Richtung
                        if((entfernenxneg[(help-1)]+i) >= (size+1)){
                            break;
                        }
                        if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]+i][entfernenyneg[(help-1)]+j]){
                            break;
                        }
                        hitcounterWag++;
                        i++;
                    }
                    i = 0;
                    while(1){//suche Wagerecht in neg Richtung
                        if((entfernenxneg[(help-1)]-i) < 1){
                            //printf("break 1\n");
                            break;
                        }
                        if((entfernenxneg[(help-1)]-i) == 1){
                            if((entfernenxneg[(help-1)]-i+k) < 1 || (entfernenxneg[(help-1)]-i+k) >= (size+1)){
                                //printf("break 2\n");
                                break;
                            }
                            if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == neg[1][entfernenyneg[(help-1)]+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k-1][entfernenyneg[(help-1)]+j]){
                                hitcounterWagneg++;
                                break;
                            }
                            if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[1][entfernenyneg[(help-1)]+j]){
                                break;
                            }
                            if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == feld[k-1][entfernenyneg[(help-1)]+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                //printf("hi\n");
                                hitcounterWagneg++;
                                hitcounterWagneg++;
                            }
                            if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k][entfernenyneg[(help-1)]+j]){
                                //printf("break 3\n");
                                break;
                            }
                            k++;
                        }else{
                            if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+j]){
                                //printf("break 4\n");
                                break;
                            }
                        }
                        hitcounterWagneg++;
                        if(k == 1){
                            i++;
                        }
                    }
                    //printf("Hit Wag: %i\n", hitcounterWag);
                    //printf("Hit Wag Neg: %i\n", hitcounterWagneg);
                    if((hitcounterWag + hitcounterWagneg) >= 5){
                        //printf("Gefunden Loop Wag\n");
                        //printf("1) speichere: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                        entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                        entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                        entfernencounternegzwei++;
                        //printf("neu in neg entfernen: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                        //printf("entfernen NEG aktuelle Position: (%i,%i)\n",entfernenxnegzwei[entfernencounternegzwei-1],entfernenynegzwei[entfernencounternegzwei-1]);
                        int m = 1;
                        while(m < hitcounterWag){
                            //printf("2) speichere: (%i,%i)\n",entfernenxneg[(help-1)]+m,entfernenyneg[(help-1)]+j);
                            entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]+m;
                            entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                            entfernencounternegzwei++;
                            m++;
                        }
                        m = 1;
                        int n = 0;
                        while(m < hitcounterWagneg){
                            if((entfernenxneg[(help-1)]-m) < 1){
                                //printf("3) speichere: (%i,%i)\n",n,entfernenyneg[(help-1)]+j);
                                entfernenxposzwei[entfernencounterposzwei] = n;
                                n++;
                                entfernenyposzwei[entfernencounterposzwei] = entfernenyneg[(help-1)]+j;
                                entfernencounterposzwei++;
                                //printf("neu in entfernen: (%i,%i)\n",n-1,entfernenyneg[(help-1)]+j);
                                //printf("entfernen aktuelle Position: (%i,%i)\n",entfernenxposzwei[entfernencounterposzwei-1],entfernenyposzwei[entfernencounterposzwei-1]);
                            }else{
                                //printf("4) speichere: (%i,%i)\n",entfernenxneg[(help-1)]-m,entfernenyneg[(help-1)]+j);
                                entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]-m;
                                entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                                entfernencounternegzwei++;
                            }
                            m++;
                        }
                        
                    }
                    hitcounterSen = 0;
                    hitcounterSenneg = 0;
                    i = 0;
                    while(1){//suche Senkrecht in pos Richtung
                        if((entfernenyneg[(help-1)]+i+j) >= (laenge+1)){
                            break;
                        }
                        if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+i+j]){
                            break;
                        }
                        hitcounterSen++;
                        i++;
                    }
                    i = 0;
                    while(1){//suche Senkrecht in neg Richtung
                        if((entfernenyneg[(help-1)]-i+j) < 0){
                            break;
                        }
                        if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]-i+j]){
                            break;
                        }
                        hitcounterSenneg++;
                        i++;
                    }
                    if((hitcounterSen + hitcounterSenneg) >= 5){
                        //printf("Gefunden Loop Sen\n");
                        entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                        entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                        entfernencounternegzwei++;
                        int m = 1;
                        while(m < hitcounterSen){
                            entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                            entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j+m;
                            entfernencounternegzwei++;
                            m++;
                        }
                        m = 1;
                        while(m < hitcounterSenneg){
                            entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                            entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j-m;
                            entfernencounternegzwei++;
                            m++;
                        }
                    }
                    hitcounterDiaLR = 0;
                    hitcounterDiaLRneg = 0;
                    i = 0;
                    k = 1;
                    while(1){//suche Diagonal LR in pos Richtung
                        if((entfernenxneg[(help-1)]+i) >= (size+1) || (entfernenyneg[(help-1)]+i+j) >= (laenge+1)){
                            break;
                        }
                        if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]+i][entfernenyneg[(help-1)]+i+j]){
                            break;
                        }
                        hitcounterDiaLR++;
                        i++;
                    }
                    i = 0;
                    while(1){//suche Diagonal LR in neg Richtung
                        if((entfernenxneg[(help-1)]-i) < 1 || (entfernenyneg[(help-1)]-i+j) < 1){
                            break;
                        }
                        if((entfernenxneg[(help-1)]-i) == 1){
                            if((entfernenxneg[(help-1)]-i+k) < 1 || (entfernenxneg[(help-1)]-i+k) >= (size+1) || (entfernenyneg[(help-1)]-i+j-k) < 0 || (entfernenyneg[(help-1)]-i+j-k) >= (laenge+1)){
                                break;
                            }
                            if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == neg[1][entfernenyneg[(help-1)]-i+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k-1][entfernenyneg[(help-1)]-i+j-k]){
                                hitcounterDiaLRneg++;
                                break;
                            }
                            if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[1][entfernenyneg[(help-1)]-i+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                break;
                            }
                            if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == feld[k-1][entfernenyneg[(help-1)]-i+j-k] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                hitcounterDiaLRneg++;
                                hitcounterDiaLRneg++;
                            }
                            if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k][entfernenyneg[(help-1)]-i+j-k-1]){
                                break;
                            }
                            k++;
                        }else{
                            if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]-i+j]){
                                break;
                            }
                        }
                        hitcounterDiaLRneg++;
                        if(k == 1){
                            i++;
                        }
                    }
                    if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                        //printf("Gefunden Loop DiaLR\n");
                        entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                        entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                        entfernencounternegzwei++;
                        int m = 1;
                        while(m < hitcounterDiaLR){
                            entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]+m;
                            entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j+m;
                            entfernencounternegzwei++;
                            m++;
                        }
                        m = 1;
                        int n = 0;
                        while(m < hitcounterDiaLRneg){
                            if((entfernenxneg[(help-1)]-m) < 1){
                                entfernenxposzwei[entfernencounterposzwei] = n;
                                n++;
                                entfernenyposzwei[entfernencounterposzwei] = entfernenyneg[(help-1)]+j+m;
                                entfernencounterposzwei++;
                            }else{
                                entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]-m;
                                entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j-m;
                                entfernencounternegzwei++;
                            }
                            m++;
                        }
                    }
                    hitcounterDiaRL = 0;
                    hitcounterDiaRLneg = 0;
                    i = 0;
                    k = 1;
                    while(1){//suche Diagonal RL in pos Richtung
                        if((entfernenxneg[(help-1)]-i) < 1 || (entfernenyneg[(help-1)]-i+j) >= (laenge+1)){
                            break;
                        }
                        if((entfernenxneg[(help-1)]-i) == 1){
                            //printf("3 wird verglichen mit: %i\n",neg[entfernenxneg[(help-1)]-i+k][entfernenyneg[(help-1)]+i+j+k]);
                            if((entfernenxneg[(help-1)]-i+k) < 1 || (entfernenxneg[(help-1)]-i+k) >= (size+1) || (entfernenyneg[(help-1)]+i+j+k) < 0 || (entfernenyneg[(help-1)]+i+j+k) >= (laenge+1)){
                                break;
                            }
                            if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == neg[1][entfernenyneg[(help-1)]+i+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k-1][entfernenyneg[(help-1)]+i+j+k]){
                                hitcounterDiaRL++;
                                break;
                            }
                            if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[1][entfernenyneg[(help-1)]+i+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                break;
                            }
                            if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == feld[k-1][entfernenyneg[(help-1)]+i+j+k] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                hitcounterDiaRL++;
                                hitcounterDiaRL++;
                                //printf("erhöhe um 2\n");
                            }
                            if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k][entfernenyneg[(help-1)]+i+j+k+1]){
                                break;
                            }
                            //printf("erhöhe um 1 (Übergang)\n");
                            k++;
                        }else{
                            //printf("3 wird verglichen mit: %i\n",neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j]);
                            if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j]){
                                break;
                            }
                            //printf("erhöhe um 1 (kein Übergang)\n");
                            //printf("%i bei (%i,%i) und %ibei (%i,%i)\n",neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j],entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j],entfernenxneg[(help-1)]-i,entfernenyneg[(help-1)]+i+j);
                        }
                        hitcounterDiaRL++;
                        if(k == 1){
                            i++;
                        }
                    }
                    i = 0;
                    while(1){//suche Diagonal RL in neg Richtung
                        if((entfernenxneg[(help-1)]+i) >= (size+1) || (entfernenyneg[(help-1)]-i+j) < 0){
                            break;
                        }
                        if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]+i][entfernenyneg[(help-1)]-i+j]){
                            break;
                        }
                        hitcounterDiaRLneg++;
                        i++;
                    }
                    //printf("hit DiaRL pos: %i\n", hitcounterDiaRL);
                    //printf("hit DiaRL neg: %i\n", hitcounterDiaRLneg);
                    if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                        //printf("Gefunden Loop DiaRL\n");
                        //printf("1) speichere: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                        entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                        entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                        entfernencounternegzwei++;
                        int m = 1;
                        int n =0;
                        while(m < hitcounterDiaRL){
                            if((entfernenxneg[(help-1)]-m) < 1){
                                //printf("2) speichere: (%i,%i)\n",n,entfernenyneg[(help-1)]+j+m);
                                entfernenxposzwei[entfernencounterposzwei] = n;
                                n++;
                                entfernenyposzwei[entfernencounterposzwei] = entfernenyneg[(help-1)]+j+m;
                                entfernencounterposzwei++;
                            }else{
                                //printf("3) speichere: (%i,%i)\n",entfernenxneg[(help-1)]-m,entfernenyneg[(help-1)]+j+m);
                                entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]-m;
                                entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j+m;
                                entfernencounternegzwei++;
                            }
                            m++;
                        }
                        m = 1;
                        while(m < hitcounterDiaRLneg){
                            //printf("4) speichere: (%i,%i)\n",entfernenxneg[(help-1)]+m,entfernenyneg[(help-1)]+j-m);
                            entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]+m;
                            entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j-m;
                            entfernencounternegzwei++;
                            m++;
                        }
                    }
                }
                help--;
            }
            help = 0;

            if(entfernencounternegzwei > 0 || entfernencounterposzwei > 0){
                aenderungen = 1;
            }
            //printf("entfernenPOS: %i\n", entfernencounterposzwei);
            //printf("entfernenNEG: %i\n", entfernencounternegzwei);
            help = entfernencounterposzwei;
            while(help > 0){
                feld[entfernenxposzwei[help-1]][entfernenyposzwei[help-1]] = 255;
                //printf("POS X: %i Y: %i\n", entfernenxposzwei[help-1], entfernenyposzwei[help-1]);
                help--;
            }
            help = entfernencounterposzwei;
            while(help > 0){
                if(feld[entfernenxposzwei[help-1]][entfernenyposzwei[help-1]] == 255){
                    int k = 0;
                    while(feld[entfernenxposzwei[help-1]][(entfernenyposzwei[help-1])+k] == 255){
                        //notausstieg [j+k] könnte über array hinaus laufen
                        k++;
                    }
                    for(int l = 0;(l+(entfernenyposzwei[help-1])) < ((laenge+1)-k);l++){
                        feld[entfernenxposzwei[help-1]][(entfernenyposzwei[help-1])+l] = feld[entfernenxposzwei[help-1]][(entfernenyposzwei[help-1])+l+k];
                    }
                    //ungetestet
                    for(int m = ((laenge+1)-k);m < (laenge+1);m++){
                        feld[entfernenxposzwei[help-1]][m] = -1;
                    }
                }        
                help--;
            }

            help = entfernencounternegzwei;
            while(help > 0){
                neg[entfernenxnegzwei[help-1]][entfernenynegzwei[help-1]] = 255;
                //printf("NEG X: %i Y: %i\n", entfernenxnegzwei[help-1], entfernenynegzwei[help-1]);
                help--;
            }
            help = entfernencounternegzwei;
            while(help > 0){
                if(neg[entfernenxnegzwei[help-1]][entfernenynegzwei[help-1]] == 255){
                    int k = 0;
                    while(neg[entfernenxnegzwei[help-1]][(entfernenynegzwei[help-1])+k] == 255){
                        //notausstieg [j+k] könnte über array hinaus laufen
                        k++;
                    }
                    for(int l = 0;(l+(entfernenynegzwei[help-1])) < ((laenge+1)-k);l++){
                        neg[entfernenxnegzwei[help-1]][(entfernenynegzwei[help-1])+l] = neg[entfernenxnegzwei[help-1]][(entfernenynegzwei[help-1])+l+k];
                    }
                    //ungetestet
                    for(int m = ((laenge+1)-k);m < (laenge+1);m++){
                        neg[entfernenxnegzwei[help-1]][m] = -1;
                    }
                }
                help--;
            }
            help = 0;
            entfernencounterpos = 0;
            entfernencounterneg = 0;            
        }

        //loop vergleich ende

        durchlaeufe++;
    }

    //loop ende

    //ausgabe start     STDOUT NACHRICHT VERAENDERN!!!!

    for(int i = 0;i < (size+1);i++){
        //printf("%i\n",extra[i]);
        if(feld[i][0] != -1){
            //printf("%i mit i = %i\n",extra[i],i);
            int j = 0;
            while(feld[i][j] != -1){
                fprintf(stdout,"%i %i %i\n",feld[i][j], i,j);
                j++;
            }
        }
        //printf("%i\n",extraneg[i]);
        if(neg[i][0] != -1){
            int j = 0;
            while(neg[i][j] != -1){
                fprintf(stdout,"%i -%i %i\n",neg[i][j], i,j);
                j++;
            }
        }
    }

    //ausgabe ende

    free(entfernenxnegzwei);
    free(entfernenxposzwei);
    free(entfernenynegzwei);
    free(entfernenyposzwei);
    free(entfernenxneg);
    free(entfernenxpos);
    free(entfernenyneg);
    free(entfernenypos);
    free(extra);
    free(extraneg);
    for(int i = 0;i < (size+1);i++){
      free(feld[i]);
      free(neg[i]);
    }
    free(feld);
    free(neg);
    return 0; 
}