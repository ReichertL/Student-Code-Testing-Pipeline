#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

/* #define DEBUG 1 */
/* #define DEBUG_PRINT 1 */

typedef int bool;
#define true 1
#define false 0

/* The game world is represented as a doubly linked list of hblocks of a fixed size.
 * Each hblock contains an array of entries, with each entry representing one column of
 * pieces. A column is represented by a dynamically resized array.
 *
 * To simplify computations (in particular computing the hblock from a given x coordinate),
 * we make all x coordinates be positive by internally representing the coordinate p as
 * p + MAX_DISPLACEMENT.
 *
 * (Motivation for this representation:) The advantage of a linked list over an array is that
 * memory is only allocated for those x coordinates where pieces actually exists, which saves
 * a lot of memory in cases like example 03. The obvious disadvantage is that read and write
 * operations are far less efficient. However, this can be partially remedied by keeping a pointer
 * to our current position in the linked list. Since the clearing of lines is a local operation,
 * not many jumps between blocks will be necessary during this algorithm. This works particularly
 * well if sequentially dropped pieces are also dropped close to each other, which is the case for
 * all of the public testcases.
 *  A representation which improves on this even further might be organizing the hblocks in a
 * self-balancing tree (an AVL tree, a red-black tree, or a B tree) instead of a linked list,
 * but I chose linked lists because they are less complex to implement and thus less prone to errors.
 * Additionally, switching between adjacent blocks of linked lists is always O(1), which might
 * not be the case for trees.
 *
 * Clearing lines of pieces uses a queue to track which locations have to be checked from
 * which height upwards: If a piece is dropped the piece's location is pushed to the queue.
 * Afterwards the pieces are cleared in iterations. In each iteration, each location in the
 * queue is checked for rows that need to be cleared. If any are found, they are marked to
 * be cleared and pushed into a new queue. We then iterate through the new queue and drop the
 * pieces below which other pieces have been cleared. We then repeat the whole process with
 * the new queue as places to check.
 *
 * When dropping the piees downwards, we ensure that the clearing queue contains each column
 * only once.
 *
 */

/***************************** STRUCT DEFINITIONS *****************************/

#define NO_PIECE (-1)
#define CLEARED 2 << 8

typedef struct {
    int location;
    short color;
} dropping_piece;

typedef struct {
    short color;
} game_piece;

typedef struct {
    game_piece *pieces; 
    size_t size;
    size_t capacity;
    int drop_height;
    /* drop_height will contain the height from which we will
     * need to start settling blocks in the current iteration.
     * If no blocks need to be settled, it contains -1.*/
} hblock_entry;

#define CLEAR_LENGTH 4
#define MAX_DISPLACEMENT (2 << 20)
#define WORLD_WIDTH (MAX_DISPLACEMENT * 2)
#define HBLOCK_SIZE ((int) 0x100)
#define HBLOCK_COUNT (WORLD_WIDTH / HBLOCK_SIZE)
#define VBLOCK_START_SIZE 8

typedef struct hblock_ll {
    hblock_entry entries[HBLOCK_SIZE];
    struct hblock_ll *next_hblock;
    struct hblock_ll *prev_hblock;
    int location;
    int num_occupied;
} hblock;


typedef struct clear_ll {
    struct clear_ll *next;
    int location;
    int height;
} clear_queue;


/******************************** STRINGS *************************************/

const char INPUT_ERROR[] = "Ungültige Eingabe!\n";
const char OOM_ERROR[] = "Kein weiterer Speicherplatz verfügbar!\n";
const char UNREACHABLE_ERROR[] = "Logikfehler!\n";

/*************************** FUNCTION DECLARATION *****************************/

/* We're restricted to only one file so we might as well make everything static
 * and let the compiler optimize some of the function calls */
static hblock *new_hblock();
static void drop_piece(dropping_piece piece);
static bool move_to_hblock(int loc, bool create_new);
static dropping_piece read_next_piece();
static void exit_error(const char *errmsg);
static void clear_memory();
static void clear_line(int x, int y, int dx, int dy, short color, int *heights);
static void clear_pieces();
static inline game_piece new_gamepiece(short color);
#ifdef DEBUG_PRINT
static void print_world();
#endif

clear_queue *clearing_queue;
clear_queue *drop_queue;

/********************** MEMORY MANAGEMENT FUNCTIONS ***************************/

hblock *first_hblock = NULL;
hblock *last_hblock = NULL;

hblock *current_hblock = NULL;

/* Allocates a new hblock and clears the entries array. 
 * The location and the pointers are not initialized. */
hblock *new_hblock() {
    hblock *out = malloc(sizeof(hblock));
    if (out == NULL) {
        exit_error(OOM_ERROR);
    }
    hblock_entry empty_hblock = {.pieces = NULL, .size = 0, .capacity = 0, .drop_height = -1};
    for (int i = 0; i < HBLOCK_SIZE; i++) {
        out->entries[i] = empty_hblock;
    }
    out->num_occupied = 0;
    return out;
}

/* Prints all the pieces according to specifications. */
void output_pieces() {
    hblock *c_hblock = first_hblock;

    while (c_hblock) {
        for (int i = 0; i < HBLOCK_SIZE; i++) {
            int loc = i + c_hblock->location * HBLOCK_SIZE - MAX_DISPLACEMENT;
            for (int j = 0; j < (int) c_hblock->entries[i].size; j++) {
                printf("%d %d %d\n", c_hblock->entries[i].pieces[j].color & 0xFF, loc, j);
            }
        }

        c_hblock = c_hblock->next_hblock;
    }
}

/* Clears up all allocated memory (after an error or after finishing the computation) */
void clear_memory() {
    hblock *c_hblock = first_hblock;

    while (c_hblock) {
        for (int i = 0; i < HBLOCK_SIZE; i++) {
            if (c_hblock->entries[i].pieces) {
                free(c_hblock->entries[i].pieces);
            }
            c_hblock->entries[i].pieces = 0;
            c_hblock->entries[i].capacity = 0;
            c_hblock->entries[i].size = 0;
        }

        hblock *n_hblock = c_hblock->next_hblock;
        free(c_hblock);
        c_hblock = n_hblock;
    }

    while (clearing_queue) {
        clear_queue *nqueue = clearing_queue->next;
        free(clearing_queue);
        clearing_queue = nqueue;
    }

    while (drop_queue) {
        clear_queue *nqueue = drop_queue->next;
        free(drop_queue);
        drop_queue = nqueue;
    }

    first_hblock = NULL;
    last_hblock = NULL;
    current_hblock = NULL;
}

/* Settles the pieces at the given location, starting a the given height.
 * Returns: The height from which we need to check in the next iteration,
 *   -1 if we don't need to check (if the line did not change or was
 *   cleared entierely*/
static inline int settle_pieces(int x, int h) {
    if (!move_to_hblock(x / HBLOCK_SIZE, false)) {
        /* This can happen if a column is marked to be cleared twice, and the
         * corresponding hblock is freed after the first time. */
        return -1;
    }
    hblock_entry *entry = &current_hblock->entries[x % HBLOCK_SIZE];

    int y = entry->drop_height;

    if (y != h) {
        /* Knowing that this will at some point be called with h = y,
         * we can abort if this is not the case */
        return -1;
    }

    for (int i = y; i < (int) entry->size; i++) {
#ifdef DEBUG 
        if (entry->pieces[i].color == -1) {
            exit_error(UNREACHABLE_ERROR);
        }
#endif
        if (!(entry->pieces[i].color & CLEARED)) {
            entry->pieces[y].color = entry->pieces[i].color;
            y += 1;
        }
    }

#ifdef DEBUG
    if (entry->pieces == NULL) {
        exit_error(UNREACHABLE_ERROR);
    }
#endif

    entry->size = y;

    if (entry->size == 0) {
        free(entry->pieces);
        entry->pieces = NULL;
        entry->capacity = 0;
        entry->drop_height = -1;

        current_hblock->num_occupied -= 1;

        if (current_hblock->num_occupied == 0) {
            /* Can free current hblock */
            if (current_hblock->prev_hblock) {
                hblock *n_hblock = current_hblock->prev_hblock;
                n_hblock->next_hblock = current_hblock->next_hblock;
                if (current_hblock->next_hblock) {
                    current_hblock->next_hblock->prev_hblock = n_hblock;
                } else {
                    last_hblock = n_hblock;
                }
                free(current_hblock);
                current_hblock = n_hblock;
            } else if (current_hblock->next_hblock) {
                hblock *n_hblock = current_hblock->next_hblock;
                n_hblock->prev_hblock = current_hblock->prev_hblock;
                free(current_hblock);
                current_hblock = n_hblock;
                first_hblock = current_hblock;
            } else {
                free(current_hblock);
                current_hblock = NULL;
                first_hblock = NULL;
                last_hblock = NULL;
            }
        }
        return -1;
    }

    if (entry->size * 4 <= entry->capacity && entry->size >= VBLOCK_START_SIZE) {
        entry->pieces = realloc(entry->pieces, entry->size * sizeof(game_piece));
        if (!entry->pieces) {
            exit_error(OOM_ERROR);
        }
        entry->capacity = entry->size;
    }
    entry->drop_height = -1;
    
    return h;
}

game_piece get_piece(int x, int y) {
    if (y < 0) {
        return new_gamepiece(NO_PIECE);
    }
    if (!move_to_hblock(x / HBLOCK_SIZE, false)) {
        return new_gamepiece(NO_PIECE);
    }

    hblock_entry entry = current_hblock->entries[x % HBLOCK_SIZE];
    if ((int) entry.size <= y) {
        return new_gamepiece(NO_PIECE);
    }

    return entry.pieces[y];
}

int column_height(int x) {
    if (!move_to_hblock(x / HBLOCK_SIZE, false)) {
        return 0;
    }
    return current_hblock->entries[x % HBLOCK_SIZE].size;
}

/* If h == -1, clears the drop height for the given column.
 * If h != -1, ensures that at least the pieces above h will
 * be checked to be settled in the next iteration */
void set_column_drop(int x, int h) {
    if (move_to_hblock(x / HBLOCK_SIZE, false)) {
        hblock_entry *entry = &current_hblock->entries[x % HBLOCK_SIZE];
        if (h == -1 || h < entry->drop_height || entry->drop_height == -1) {
            entry->drop_height = h;
        }
    }
}

/* Marks the given piece to be cleares */
void clear_piece(int x, int y) {
    if (!move_to_hblock(x / HBLOCK_SIZE, false)) {
#ifdef DEBUG
        exit_error(UNREACHABLE_ERROR);
#endif
    }

    hblock_entry *entry = &current_hblock->entries[x % HBLOCK_SIZE];
#ifdef DEBUG
    if ((int) entry->size <= y) {
        exit_error(UNREACHABLE_ERROR);
    }
#endif

    entry->pieces[y].color |= CLEARED;
}

/* Inserts the given piece at the given location, updates current_hblock
 * accordingly, and clears the resulting lines. */
void drop_piece(dropping_piece piece) {
    move_to_hblock(piece.location / HBLOCK_SIZE, true);

    hblock_entry *entry = &current_hblock->entries[piece.location % HBLOCK_SIZE];

    if (entry->capacity == entry->size) {
        size_t newsize = entry->capacity == 0 ? VBLOCK_START_SIZE : entry->capacity * 2;
        entry->pieces = realloc(entry->pieces, newsize * sizeof(game_piece));
        if (entry->pieces == NULL) {
            exit_error(OOM_ERROR);
        }
        entry->capacity = newsize;
    }

    if (entry->size == 0) {
        current_hblock->num_occupied += 1;
    }

    entry->pieces[entry->size] = new_gamepiece(piece.color);
    entry->size += 1;

    clearing_queue = malloc(sizeof(clear_queue));
    if (!clearing_queue) {
        exit_error(OOM_ERROR);
    }
    clearing_queue->location = piece.location;
    clearing_queue->height = entry->size - 1;
    clearing_queue->next = NULL;

    clear_pieces();
}


/* Makes current_hblock point to the given location,
 * with create_new set also creating a new hblock if
 * necessary.
 *
 * Returns: Whether a block was found at this location. */
bool move_to_hblock(int loc, bool create_new) {
    if (current_hblock == NULL) {
        if (!create_new) {
            return false;
        }
        /* First piece */
        
        hblock *n_hblock = new_hblock();

        n_hblock->location = loc; 
        n_hblock->next_hblock = NULL;
        n_hblock->prev_hblock = NULL;

        first_hblock = n_hblock;
        last_hblock = n_hblock;

        current_hblock = n_hblock;
    }

    if (loc == current_hblock->location) {
        return true;
    } else if (loc > current_hblock->location) {
        while (current_hblock != NULL && loc > current_hblock->location) {
            current_hblock = current_hblock->next_hblock;
        }
        if (current_hblock == NULL) {
            if (!create_new) {
                current_hblock = first_hblock;
                return false;
            }
            /* Append new hblock */
            hblock *n_hblock = new_hblock();
            n_hblock->location = loc;

            last_hblock->next_hblock = n_hblock;
            n_hblock->prev_hblock = last_hblock;
            n_hblock->next_hblock = NULL;

            last_hblock = n_hblock;
            current_hblock = n_hblock;
        }
        if (loc < current_hblock->location) {
            if (!create_new) {
                return false;
            }
            /* Insert new hblock */
            hblock *n_hblock = new_hblock();
            n_hblock->location = loc;
            n_hblock->next_hblock = current_hblock;
            n_hblock->prev_hblock = current_hblock->prev_hblock;

            current_hblock->prev_hblock->next_hblock = n_hblock;
            current_hblock->prev_hblock = n_hblock;

            current_hblock = n_hblock;
        }
    } else {
        while (current_hblock != NULL && loc < current_hblock->location) {
            current_hblock = current_hblock->prev_hblock;
        }
        if (current_hblock == NULL) {
            if (!create_new) {
                current_hblock = last_hblock;
                return false;
            }
            /* Append new hblock */
            hblock *n_hblock = new_hblock();
            n_hblock->location = loc;

            first_hblock->prev_hblock = n_hblock;
            n_hblock->next_hblock = first_hblock;
            n_hblock->prev_hblock = NULL;

            first_hblock = n_hblock;
            current_hblock = n_hblock;
        }
        if (loc > current_hblock->location) {
            if (!create_new) {
                return false;
            }
            /* Insert new hblock */
            hblock *n_hblock = new_hblock();
            n_hblock->location = loc;
            n_hblock->next_hblock = current_hblock->next_hblock;
            n_hblock->prev_hblock = current_hblock;

            current_hblock->next_hblock->prev_hblock = n_hblock;
            current_hblock->next_hblock = n_hblock;

            current_hblock = n_hblock;
        }
    }

    return true;
}

/* Clears vertical stacks at the given y coordinate,
 * starting from the given height. 
 * Returns: The lowest cleared y-coordinate, -1 if none
 *  were cleared. */
int clear_vertical(int x, int height) {
    move_to_hblock(x / HBLOCK_SIZE, false);
    hblock_entry *entry = &current_hblock->entries[x % HBLOCK_SIZE];
    if (height >= (int) entry->size) {
        return -1;
    }

    height -= 3;
    if (height < 0) {
        height = 0;
    }

    short c_color = entry->pieces[height].color;

    int streak = 0;
    int ret = -1;
    for (int y = height + 1; y < (int) entry->size; y++) {
        if ((entry->pieces[y].color & 0xFF) == (c_color & 0xFF)) {
            streak += 1;

            if (streak == CLEAR_LENGTH - 1) {
                for (int i = 0; i < CLEAR_LENGTH; i++) {
                    entry->pieces[y - i].color |= CLEARED;
                }
                if (ret == -1) {
                    ret = y - CLEAR_LENGTH + 1;
                }
            } else if (streak > CLEAR_LENGTH - 1) {
                entry->pieces[y].color |= CLEARED;
            }
        } else {
            streak = 0;
            c_color = entry->pieces[y].color;
        }
    }
    
    return ret;
}

/************************ CLEARING  ALGORITHM *********************************/

/* The queues are global variables so that they can be freed in case
 * we run out of memory */
clear_queue *clearing_queue = NULL;
clear_queue *drop_queue = NULL;

/* Looks for lines to be cleared that contain (x, y) and have the
 * orientation (dx, dy) (i.e. dx = 1, dy = 0 for horizontal lines,
 * dx = 1, dy = 1 for upwards diagonal lines, etc). We only check for
 * four steps in each direction (If the line is longer, it will be marked
 * to be cleared when checking another column). color is the color of the
 * piece at (x, y), not flagged as cleared. *heights is an array of
 * 2 * CLEAR_LENGTH - 1 numbers containing the heights that will need to
 * be pushed into the next queue. */
void clear_line(int x, int y, int dx, int dy, short color, int *heights) {
#ifdef DEBUG
    if (color == NO_PIECE) {
        exit_error(UNREACHABLE_ERROR);
    }
#endif

    int p = x;
    int q = y;
    int streakl = 0;
    for (int i = 0; i < CLEAR_LENGTH - 1; i++) {
        p -= dx;
        q -= dy;

        short ncolor = get_piece(p, q).color;
        if (ncolor != NO_PIECE && (ncolor & 0xFF) == color) {
            streakl += 1;
        } else {
            break;
        }
    }
    p = x;
    q = y;
    int streakr = 0;
    for (int i = 0; i < CLEAR_LENGTH - 1; i++) {
        p += dx;
        q += dy;

        short ncolor = get_piece(p, q).color;
        if (ncolor != NO_PIECE && (ncolor & 0xFF) == color) {
            streakr += 1;
        } else {
            break;
        }
    }

    if (streakl + streakr + 1 >= CLEAR_LENGTH) {
        for (int i = -streakl; i <= streakr; i++) {
            int newx = x + i * dx;
            int newy = y + i * dy;
            clear_piece(newx, newy);
            if (heights[i + CLEAR_LENGTH - 1] == -1 || heights[i + CLEAR_LENGTH - 1] > newy) {
                heights[i + CLEAR_LENGTH - 1] = newy;
            }
        }
    }
}

/* Clears pieces after a piece has been dropped */
void clear_pieces() {
    /* In each iteration, we empty the clearing_queue and check for clears
     * at each entry. If any are found, we push the locations into the drop_queue.
     * Afterwards, we iterate through the drop_queue and settle the pieces in those
     * locations. Since these columns changed again, we then push them into the new
     * clearing_queue. */
    while (true) {
#ifdef DEBUG_PRINT
            print_world();
#endif

        while (clearing_queue) {
            int x = clearing_queue->location;
            int h = clearing_queue->height;

            int heights[2 * CLEAR_LENGTH - 1];
            for (int i = 0; i < 2 * CLEAR_LENGTH - 1; i++) {
                heights[i] = -1;
            }

            heights[CLEAR_LENGTH - 1] = clear_vertical(x, h);

            for (int y = h; y < column_height(x); y++) {
                /* c_color is needed in every call to clear_line, so
                 * we fetch it here to shave off some time */
                short c_color = get_piece(x, y).color & 0xFF;
                clear_line(x, y, 1, -1, c_color, heights);
                clear_line(x, y, 1,  0, c_color, heights);
                clear_line(x, y, 1,  1, c_color, heights);
            }

            /* Any lines we find here will contain the column we're checking right
             * now, so if heights[CLEAR_LENGTH] is -1, no lines have been found */
            if (heights[CLEAR_LENGTH - 1] != -1) {
                for (int i = 0; i < 2 * CLEAR_LENGTH - 1; i++) {
                    if (heights[i] == -1) {
                        continue;
                    }

                    clear_queue *nqueue = malloc(sizeof(clear_queue));
                    if (!nqueue) {
                        exit_error(OOM_ERROR);
                    }
                    nqueue->location = x + i - CLEAR_LENGTH + 1;
                    nqueue->height = heights[i];
                    nqueue->next = drop_queue;
                    drop_queue = nqueue;

                    set_column_drop(nqueue->location, nqueue->height);
                }
            }

            clear_queue *nq = clearing_queue->next;
            free(clearing_queue);
            clearing_queue = nq;
        }

        if (drop_queue == NULL) {
            break;
        }

        while (drop_queue) {
            int h = settle_pieces(drop_queue->location, drop_queue->height);
            if (h != -1) {
                clear_queue *nqueue = malloc(sizeof(clear_queue));
                if (!nqueue) {
                    exit_error(OOM_ERROR);
                }
                nqueue->location = drop_queue->location;
                nqueue->height = h;
                nqueue->next = clearing_queue;
                clearing_queue = nqueue;
            }

            clear_queue *nq = drop_queue->next;
            free(drop_queue);
            drop_queue = nq;
        }
    }
}

/************************* UTILITY FUNCTIONS **********************************/

#ifdef DEBUG_PRINT
void print_world() {
    hblock *c_hblock = first_hblock;
    bool gap = false;
    while (c_hblock) {
        for (int i = 0; i < HBLOCK_SIZE; i++) {
            hblock_entry entry = c_hblock->entries[i];

            if (!entry.size) {
                if (!gap) {
                    fprintf(stderr, "---------------\n");
                    gap = true;
                }
            } else {
                gap = false;
                for (int j = 0; j < (int) entry.size; j++) {
                    fprintf(stderr, "%3d ", entry.pieces[j].color & 0xFF);
                }
                fprintf(stderr, "\n");
            }
        }

        c_hblock = c_hblock->next_hblock;
    }
    fprintf(stderr, "\n================================\n");
}
#endif

inline game_piece new_gamepiece(short color) {
    game_piece out = {.color = color};
    return out;
}

/* Reads the color and location of a game piece from stdin.
 * We chose manual parsing over solutions like scanf, because scanf
 * makes it hard to not accept an input such as "1 +2" (which does not match
 * the given regex) as correct.
 * We don't use atoi because it's slower than parsing manually.*/
dropping_piece read_next_piece() {
    char lastc = 0;

    int n1 = 0;
    bool started = true;

    while (n1 < 256) {
        char c = fgetc(stdin);
        if (started && c == EOF) {
            dropping_piece out = {.color = NO_PIECE, .location = 0};
            return out;
        }
        started = false;
        if ('0' <= c && c <= '9') {
            n1 = 10 * n1 + (int) (c - '0');
        } else if (c == ' '){
            lastc = c;
            break;
        } else {
            exit_error(INPUT_ERROR);
        }
    }

    if (n1 >= 0xFF) {
        exit_error(INPUT_ERROR);
    }

    if (lastc != ' ') {
        if (fgetc(stdin) != ' ') {
            exit_error(INPUT_ERROR);
        }
    }

    int sign = 1;

    int n2 = 0;

    while (true) {
        char c = fgetc(stdin);
        if (c == ' ') {
            continue;
        } else if (c == '-') {
            sign = -1;
            break;
        } else if ('0' <= c && c <= '9') {
            n2 = (int) c - '0';
            break;
        } else {
            exit_error(INPUT_ERROR);
        }
    }

    while (n2 <= MAX_DISPLACEMENT) {
        char c = fgetc(stdin);
        if (c == '\n' || c == EOF) {
            break;
        } else if ('0' <= c && c <= '9') {
            n2 = 10 * n2 + (int) (c - '0');
        } else {
            exit_error(INPUT_ERROR); 
        }
    }

    if (n2 > (MAX_DISPLACEMENT)) {
        exit_error(INPUT_ERROR);
    }

    dropping_piece out = {.color = n1, .location = MAX_DISPLACEMENT + (sign * n2)};
    return out;
}

void exit_error(const char *errmsg) {
    fprintf(stderr, "%s", errmsg);
    clear_memory();
    exit(1);
}


int main() {
#ifdef DEBUG_PRINT
    int i = 0;
#endif
    while(true) {
#ifdef DEBUG_PRINT
        fprintf(stderr, "Iteration %d\n", i++);
#endif
        dropping_piece p = read_next_piece();
        if (p.color == NO_PIECE) {
            break;
        }

        drop_piece(p);
    }

    output_pieces();
    clear_memory();

    return 0;
}
