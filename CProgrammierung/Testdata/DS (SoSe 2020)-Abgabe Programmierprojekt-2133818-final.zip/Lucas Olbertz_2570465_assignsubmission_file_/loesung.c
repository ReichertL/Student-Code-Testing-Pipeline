#include <stdio.h>
#include <stdlib.h>

typedef struct dynarray {
    int leftposx;
    int rightposx;
    int ** array;
    int arrayheight;
}dynarray;

typedef struct gameboard {
    int cntparts;
    dynarray ** parts;
}gameboard;

gameboard * board;

int * xtodelete;
int * ytodelete;
int arraylength = 0;

// Input von stdin lesen und in Datenstruktur speichern
void readinput ();

// Speicher aufraeumen
void clearmem ();

// Im Fehlerfall auf stderr schreiben und immer clearmem() nutzen. Ausserdem exit() mit exitcode
void die (char * msg, int exitcode);

// Zwei benachbarte Spielfeldteile zusammenfügen
void fuse (int leftarray, int rightarray, int mode);

// Spielfeldteil suchen, das an firstpart liegt
int search (int firstpart, int mode);

// Stein in Datenstruktur speichern
void saveelements (int posx, int color);

// Neuen Spielfeldteil, der nicht mit anderen zusammenhaengt, zum gameboard hinzufuegen
void addnewparttoboard (int posx, int color);

// Auf existierenden Spielfeldteil einen Stein fallen lassen.
void addstoneontop(int posx, int color, int part);

// Bestimmen ob Stein auf oder rechts/links neben ein Spielfeldteil platziert oder ein neues erzeugt werden muss.
void checkconnectedparts (int part, int mode, int posx, int color);

// Ausgabe des Spielfelds
void printgameboard ();

// Verbundene Steine suchen
void searchfour (int part, int x);

// Umgebung um Stein pruefen
void checkblock (int part, int x, int y);

// Zu loeschende Elemente merken
void savetodeleteelements (int xarray [4], int yarray [4]);

// Verbundene Steine loeschen und nachruecken lassen
void delete (int part);

int main(int argc, char * argv []) {

    // Das Spielfeld erzeugen
    board = (gameboard *) calloc(1, sizeof(gameboard));
    if (board == NULL) die("Fehler beim Allozieren von Speicher!", -1);
    board->cntparts = 0;
    board->parts = NULL;

    xtodelete = (int *) calloc(0, sizeof(int));
    if (xtodelete == NULL) die("Fehler beim Allozieren von Speicher!", -1);
    ytodelete = (int *) calloc(0, sizeof(int));
    if (ytodelete == NULL) die("Fehler beim Allozieren von Speicher!", -1);

    // Input lesen
    readinput();

    // Ausgabe schreiben
    printgameboard();

    //Programm beenden
    die("", 0);
    return 0;
}


void readinput () {

    char inputchar = 'a';

    // mode = 0: Zeilenbeginn
    // mode = 1: Farbe
    // mode = 2: Leerzeichen
    // mode = 3: negative Koordinate
    // mode = 4: Koordinate
    int mode = 0;

    // Zum Lesen/Speichern von Farbe und Position
    int color = 0;
    int pos = 0;
    // Zum Lesen/Speichern einer negativen Position
    int negative = 1;

    // Input lesen
    while ((inputchar= (char) getc(stdin))!=EOF){

        switch (mode) {

            // mode = 0: Zeilenbeginn
            case 0:

                // Ziffer
                if (inputchar > 47 && inputchar < 58) {
                    color = (inputchar-48);
                    mode = 1;
                } else {
                    die("Beim Einlesen der Farbe wurde ein ungueltiger Character registriert.", -1);
                }

                break;

            // mode = 1: Farbe
            case 1:
                // Ziffer
                if (inputchar > 47 && inputchar < 58) {
                    // Zahl groesser 9
                    color = color*10+(inputchar-48);
                    if (color > 254) die("Ungueltige Farbe registriert.", -1);
                } else if (inputchar == ' ') {
                    mode = 2;
                } else {
                    die("Beim Einlesen der Farbe wurde ein ungueltiger Character registriert.", -1);
                }
                break;

            // mode = 2: Leerzeichen
            case 2:
                    // Ziffer
                    if (inputchar > 47 && inputchar < 58) {
                        pos = inputchar-48;
                        mode = 4;
                    } else if (inputchar == ' ') {
                        continue;
                    // negative Koordinate
                    } else if (inputchar == '-') {
                        negative = -1;
                        mode = 3;
                    } else {
                        die("Beim Einlesen nach der Farbe wurde ein ungueltiger Character registriert.", -1);
                    }
                break;

            // mode = 3: negative Koordinate
            case 3:
                    // Ziffer
                    if (inputchar > 47 && inputchar < 58) {
                        pos = inputchar-48;
                        mode = 4;
                    } else {
                        die("Beim Einlesen der Position wurde ein ungueltiger Character registriert.", -1);
                    }
                break;

            // mode = 4: Koordinate
            case 4:
                // Ziffer
                if (inputchar > 47 && inputchar < 58) {
                    // Position hat mehrere Ziffern
                    pos = pos*10+(inputchar-48);
                    // Position ist groesser als 2^20
                    if (pos > 1048576) {
                        die("Zu grosse Zahl fuer Position registriert.", -1);
                    }

                // Zeilenende
                } else if (inputchar == '\n') {

                    // Element speichern
                    saveelements(negative*pos, color);

                    // Variablen zuruecksetzen
                    color = 0;
                    pos = 0;
                    mode = 0;
                    negative = 1;
                } else {
                    die("Beim Einlesen der Position wurde ein ungueltiger Character registriert.", -1);
                }
                break;
        }

    }
    switch (mode) {
        case 1:
        case 2:
        case 3:
            die("EOF an ungueltiger Stelle registriert.", -1);
            break;
        case 4:
            // Element speichern
            saveelements(negative*pos, color);
            break;
    }
}

void clearmem () {

    free(xtodelete);
    free(ytodelete);

    for (int i = 0; i < board->cntparts; i++) {
        for (int j = 0; j <= board->parts[i]->rightposx - board->parts[i]->leftposx; j++) {
            // Alle Spalten des Arrays eines Spielfeldteils freigeben
            free(board->parts[i]->array[j]);
        }
        // Alle Zeilen des Arrays eines Spielfeldteils freigeben
        free(board->parts[i]->array);
        // Das Spielfeldteil freigeben
        free(board->parts[i]);
    }
    // Die Spielfeldteilsammlung freigeben
    free(board->parts);
    // Das Spielbrett freigeben
    free(board);
}

void die (char * msg, int exitcode) {

    // Fehlerfall
    if (exitcode != 0)
        fprintf(stderr,"%s\n", msg);
    // Speicher aufraeumen
    clearmem();
    // Programm beenden
    exit(exitcode);
}



void fuse (int leftarray, int rightarray, int mode) {

    // Linkes Spielfeldteil ist kuerzer
    if (board->parts[leftarray]->arrayheight < board->parts[rightarray]->arrayheight) {
        // Alle Spalten durchgehen und reallozieren für gleiche Arrayhoehe
        for (int i = 0; i <= board->parts[leftarray]->rightposx - board->parts[leftarray]->leftposx; i++) {
            // Spaltenhoehe vergroessern
            board->parts[leftarray]->array[i] = (int*) realloc(board->parts[leftarray]->array[i], sizeof(int)*board->parts[rightarray]->arrayheight);
            if (board->parts[leftarray]->array[i] == NULL) die("Fehler beim Reallozieren von Speicher!", -1);
            // Neu hinzugefügte Zellen mit 0 fuellen
            for (int j = board->parts[leftarray]->arrayheight; j < board->parts[rightarray]->arrayheight; j++) {
                board->parts[leftarray]->array [i] [j] = 0;
            }
        }
        // Neue gleiche Arrayhoehe setzen
        board->parts[leftarray]->arrayheight = board->parts[rightarray]->arrayheight;
    // Rechtes Spielfeldteil ist kuerzer
    } else if (board->parts[leftarray]->arrayheight > board->parts[rightarray]->arrayheight) {
        // Alle Spalten durchgehen und reallozieren für gleiche Arrayhoehe
        for (int i = 0; i <= board->parts[rightarray]->rightposx - board->parts[rightarray]->leftposx; i++) {
            // Spaltenhoehe vergroessern
            board->parts[rightarray]->array[i] = (int*) realloc(board->parts[rightarray]->array[i], sizeof(int)*board->parts[leftarray]->arrayheight);
            if (board->parts[rightarray]->array[i] == NULL) die("Fehler beim Reallozieren von Speicher!", -1);
            // Neu hinzugefügte Zellen mit 0 fuellen
            for (int j = board->parts[rightarray]->arrayheight; j < board->parts[leftarray]->arrayheight; j++) {
                board->parts[rightarray]->array [i] [j] = 0;
            }
        }
    }
    // Linkes teil um Breite von rechtem Teil vergroessern
    board->parts[leftarray]->array = (int**) realloc(board->parts[leftarray]->array, sizeof(int*)*((board->parts[leftarray]->rightposx-board->parts[leftarray]->leftposx+1)+(board->parts[rightarray]->rightposx-board->parts[rightarray]->leftposx+1)));
    if (board->parts[leftarray]->array == NULL) die("Fehler beim Reallozieren von Speicher!", -1);
    for (int i = 0; i <= board->parts[rightarray]->rightposx-board->parts[rightarray]->leftposx; i++) {
        // Vom rechten Teil kopieren
        board->parts[leftarray]->array[board->parts[leftarray]->rightposx-board->parts[leftarray]->leftposx+1+i] = board->parts[rightarray]->array[i];
    }
    // Die neue rechte Position uebernehmen
    board->parts[leftarray]->rightposx = board->parts[rightarray]->rightposx;
    // Wenn rightarray nicht das letzte Element des Spielbretts ist, wird das letzte Teil in rightarray uebernommen
    if (rightarray < board->cntparts-1) {
        // Das Duplikat freigeben
        free(board->parts[rightarray]->array);
        free(board->parts[rightarray]);
        board->parts[rightarray] = board->parts[board->cntparts-1];
    } else {
        // Das Duplikat freigeben
        free(board->parts[board->cntparts-1]->array);
        free(board->parts[board->cntparts-1]);
    }
    // Die Groesse des Spielbretts nachjustieren
    board->cntparts--;
    board->parts = (dynarray**) realloc(board->parts, sizeof(dynarray*)*board->cntparts);
    if (board->parts == NULL) die("Fehler beim Reallozieren von Speicher!", -1);
    int partfound;
    // Nach anliegenden Spielfeldteilen suchen
    if (leftarray != board->cntparts) {
        partfound = search(leftarray, mode);
        // Wenn eines gefunden wurde...
        if (partfound >= 0) {
            // Wenn das gefundene Teil rechts davon liegt...
            if (board->parts[leftarray]->leftposx < board->parts[partfound]->leftposx) {
                fuse(leftarray, partfound, mode);
            // Wenn das gefundene Teil links davon liegt...
            } else {
                fuse(partfound, leftarray, mode);
            }

        }
    // Nach anliegenden Spielfeldteilen suchen
    } else {
        partfound = search(rightarray, mode);
        // Wenn eines gefunden wurde...
        if (partfound >= 0) {
            // Wenn das gefundene Teil rechts davon liegt...
            if (board->parts[rightarray]->leftposx < board->parts[partfound]->leftposx) {
                fuse(rightarray, partfound, mode);
            // Wenn das gefundene Teil links davon liegt...
            } else {
                fuse(partfound, rightarray, mode);
            }

        }
    }

}

int search (int firstpart, int mode) {

    for (int i = 0; i < board->cntparts; i++) {
        if (mode == 0) {
            // Stein wird links hinzugefuegt
            if (board->parts[i]->rightposx+1 == board->parts[firstpart]->leftposx) {
                return i;
            }
        } else if (mode == 1) {
            // Stein wurde rechts hinzugefuegt
            if (board->parts[i]->leftposx-1 == board->parts[firstpart]->rightposx) {
                return i;
            }
        }
    }
    return -1;
}



void saveelements (int posx, int color) {

    // Bestimmen wo der Stein eingefuegt werden muss
    for (int i = 0; i < board->cntparts; i++) {
        // Zwischen linker und rechter Position von part
        if ((posx >= board->parts[i]->leftposx) && (posx <= board->parts[i]->rightposx)) {
            // Auf Spielfeldteil fallen lassen
            addstoneontop(posx, color, i);
            searchfour(i, posx - board->parts[i]->leftposx);
            return;
        // Links von Spielfeldteil fallen lassen
        } else if (posx == (board->parts[i]->leftposx)-1) {
            checkconnectedparts(i, 0, posx, color);
            return;
        // Rechts von Spielfeldteil fallen lassen
        } else if (posx == (board->parts[i]->rightposx)+1) {
            checkconnectedparts(i, 1, posx, color);
            return;
        }
    }
        // Nicht direkt neben oder auf einem Spielfeldteil fallen lassen. Also ein neues erzeugen.
        addnewparttoboard(posx, color);
}

void addnewparttoboard (int posx, int color) {

    // Neues Spielfeldteil anlegen
    dynarray * dynnewpart= (dynarray*) calloc(1, sizeof(dynarray));
    if (dynnewpart == NULL) die("Fehler beim Allozieren von Speicher!", -1);
    // Array des Spielfeldteils anlegen
    int ** col = (int**) calloc(1, sizeof(int *));
    if (col == NULL) die("Fehler beim Allozieren von Speicher!", -1);
    col [0] = (int*) calloc(1, sizeof(int));
    if (col [0] == NULL) die("Fehler beim Allozieren von Speicher!", -1);

    // Spielfeldteil mit entsprechenden Werten versehen
    dynnewpart->array = col;
    dynnewpart->array[0][0] = color+1;
    dynnewpart->leftposx = posx;
    dynnewpart->rightposx = dynnewpart->leftposx;
    dynnewpart->arrayheight = 1;
    board->cntparts++;

    // Die Groesse des Spielbretts erhoehen
    board->parts = (dynarray**) realloc(board->parts, sizeof(dynarray*)*board->cntparts);
    if (board->parts == NULL) die("Fehler beim Reallozieren von Speicher!", -1);
    // Neues Spielfeldteil dem Spielbrett hunzufuegen
    (board->parts [board->cntparts-1]) = dynnewpart;
}

void addstoneontop(int posx, int color, int part) {

    // Pruefen ob das Spielbrett bis oben gefuellt ist
    if (board->parts[part]->array [posx - board->parts[part]->leftposx] [board->parts[part]->arrayheight-1] != 0) {
        board->parts[part]->arrayheight++;
        // Spaltenhoehe des Spielfeldteilarrays vergroessern und neue Zellen mit 0 fuellen
        for (int j = 0; j <= board->parts[part]->rightposx - board->parts[part]->leftposx; j++) {
            board->parts[part]->array[j] = (int *) realloc(board->parts[part]->array[j], sizeof(int)*board->parts[part]->arrayheight);
            if (board->parts[part]->array[j] == NULL) die("Fehler beim Reallozieren von Speicher!", -1);
            board->parts[part]->array [j] [board->parts[part]->arrayheight-1] = 0;
        }

    }

    // Koordinaten der Steinposition bestimmen
    int i = board->parts[part]->arrayheight-1;

    while (board->parts[part]->array [posx - board->parts[part]->leftposx] [i] == 0 && i >= 0) {
        i--;
        if (i < 0) break;
    }
    i++;

    // Farbe in das entsprechende Feld schreiben
    board->parts[part]->array [posx - board->parts[part]->leftposx] [i] = color+1;
}

void checkconnectedparts (int part, int mode, int posx, int color) {

    // Spielfeldteil fuer neuen Stein erzeugen und dann mit dem danebenliegenden verschmelzen
    addnewparttoboard(posx, color);

    // Links eingefuegt
    if (mode == 0) {
        fuse(board->cntparts-1, part, mode);
    } else if (mode == 1) {
        // Rechts eingefuegt
        fuse(part, board->cntparts-1, mode);
    }

    // Nach Viererreihen suchen
    for (int i = 0; i < board->cntparts; i++) {
        if ((posx >= board->parts[i]->leftposx) && (posx <= board->parts[i]->rightposx))
            searchfour(i, posx - board->parts[i]->leftposx);
    }
}

void printgameboard () {

    // Ausgabe auf stdout schreiben
    for (int i = 0; i < board->cntparts; i++) {
        for (int j = 0; j <= board->parts[i]->rightposx - board->parts[i]->leftposx; j++) {
            for (int k = 0; k < board->parts[i]->arrayheight; k++) {
                if (board->parts[i]->array [j] [k] != 0)
                    printf("%i %i %i\n", board->parts[i]->array [j] [k]-1, board->parts[i]->leftposx+j, k);
            }
        }
    }
}

void searchfour (int part, int x) {

    int y = board->parts[part]->arrayheight-1;

    // maximale Spaltenhoehe der jeweiligen Spalte (oberster Stein)
    while (board->parts[part]->array [x] [y] == 0) {
        y--;
        if (y < 0) die("Fehler beim Suchen nach Reihen.", -1);
    }

    checkblock(part, x, y);

    while (arraylength > 0) {

        // Gefundene Steine loeschen
        delete(part);

        int * xdeletecopy = xtodelete;
        int * ydeletecopy = ytodelete;
        int alencopy = arraylength;

        xtodelete = (int *) calloc(0, sizeof(int));
        if (xtodelete == NULL) die("Fehler beim Reallozieren von Speicher!", -1);

        ytodelete = (int *) calloc(0, sizeof(int));
        if (ytodelete == NULL) die("Fehler beim Reallozieren von Speicher!", -1);

        arraylength = 0;

        // Steine, deren Hoehe geaendert wurde, beobachten
        for (int i = alencopy-1; i >= 0; i--) {
            for (int j = ydeletecopy[i]; j < board->parts[part]->arrayheight; j++) {

                if (board->parts[part]->array [xdeletecopy[i]] [j] == 0) break;
                int found = 0;

                //Ueberpruefen ob ein Stein schon vorkam in der Liste mit zu loeschenden Steinen
                for (int k = 0; k < alencopy; k++) {

                    if (j == ydeletecopy[k] && xdeletecopy[k] == xdeletecopy[i]) {
                        found=1;
                        break;
                    }

                }

                if (found == 0) {
                    alencopy++;

                    xdeletecopy = (int *) realloc(xdeletecopy, sizeof(int)*alencopy);

                    if (xdeletecopy == NULL) {
                        free(xdeletecopy);
                        free(ydeletecopy);
                        die("Fehler beim Reallozieren von Speicher!", -1);
                    }

                    ydeletecopy = (int *) realloc(ydeletecopy, sizeof(int)*alencopy);
                    if (ydeletecopy == NULL) {
                        free(xdeletecopy);
                        free(ydeletecopy);
                        die("Fehler beim Reallozieren von Speicher!", -1);
                    }

                    // Neuen Stein zum Loeschen hinzufuegen
                    xdeletecopy[alencopy-1] = xdeletecopy[i];
                    ydeletecopy[alencopy-1] = j;
                }



            }
        }

        // Umgebung neuer Steine nach Reihen absuchen
        for (int k = 0; k < alencopy; k++) {
            checkblock(part, xdeletecopy[k], ydeletecopy[k]);
        }

        free(xdeletecopy);
        free(ydeletecopy);
    }

    // Bei vielen leeren Zeilen den Spielfeldteil verkleinern (bzgl Hoehe)
    int newheight = board->parts[part]->arrayheight * 0.99;

    if (board->parts[part]->arrayheight - newheight >= 50) {
        for (int i = 0; i <= board->parts[part]->rightposx - board->parts[part]->leftposx; i++) {
            if (board->parts[part]->array [i] [newheight] != 0) return;
        }
        for (int i = 0; i <= board->parts[part]->rightposx - board->parts[part]->leftposx; i++) {
            board->parts[part]->array[i] = (int *) realloc(board->parts[part]->array[i], newheight*sizeof(int));
            if (board->parts[part]->array[i] == NULL) die("Fehler beim Reallozieren von Speicher!", -1);
            board->parts[part]->arrayheight = newheight;
        }
    }


}

void checkblock (int part, int x, int y) {

    if (board->parts[part]->array [x] [y] == 0) return;

    // In Bereich um jeweiligen Stein nach Reihen suchen.

    // Drei Steine nach links moeglich
    if (x >= 3) {

        // Drei Steine nach links
        if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-1] [y]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-2] [y]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-3] [y]))) {
            int xarray [4] = {x, x-1, x-2, x-3};
            int yarray [4] = {y, y, y, y};
            savetodeleteelements(xarray, yarray);
        }

        // Drei Steine nach unten moeglich
        if (y >= 3) {

            // Drei Steine nach links unten
            if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-1] [y-1]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-2] [y-2]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-3] [y-3]))) {
                int xarray [4] = {x, x-1, x-2, x-3};
                int yarray [4] = {y, y-1, y-2, y-3};
                savetodeleteelements(xarray, yarray);
            }
        }

        // Drei Steine nach oben moeglich
        if (y <= board->parts[part]->arrayheight-4) {

            // Drei Steine nach links oben
            if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-1] [y+1]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-2] [y+2]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-3] [y+3]))) {
                int xarray [4] = {x, x-1, x-2, x-3};
                int yarray [4] = {y, y+1, y+2, y+3};
                savetodeleteelements(xarray, yarray);
            }
        }
    }

    // Zwei Steine nach links, einer nach rechts moeglich
    if (x >= 2 && x < board->parts[part]->rightposx - board->parts[part]->leftposx) {

        // Zwei Steine nach links, einer nach rechts
        if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-1] [y]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-2] [y]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+1] [y]))) {
            int xarray [4] = {x, x-1, x-2, x+1};
            int yarray [4] = {y, y, y, y};
            savetodeleteelements(xarray, yarray);
        }

        // Zwei Steine nach unten, einer nach oben moeglich
        if (y >= 2 && y < board->parts[part]->arrayheight-1) {

            // Zwei Steine nach links unten, einer nach oben rechts
            if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-1] [y-1]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-2] [y-2]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+1] [y+1]))) {
                int xarray [4] = {x, x-1, x-2, x+1};
                int yarray [4] = {y, y-1, y-2, y+1};
                savetodeleteelements(xarray, yarray);
            }
        }

        // Ein Stein nach unten, zwei nach oben moeglich
        if (y >= 1 && y < board->parts[part]->arrayheight-2) {

            // Zwei Steine nach links oben, einer nach rechts unten
            if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-1] [y+1]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-2] [y+2]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+1] [y-1]))) {
                int xarray [4] = {x, x-1, x-2, x+1};
                int yarray [4] = {y, y+1, y+2, y-1};
                savetodeleteelements(xarray, yarray);
            }
        }
    }

    // Ein Stein nach links, zwei nach rechts moeglich
    if (x > 0 && x < board->parts[part]->rightposx - board->parts[part]->leftposx-1) {

        // Ein Stein nach links, zwei nach rechts
        if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-1] [y]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+2] [y]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+1] [y]))) {
            int xarray [4] = {x, x-1, x+2, x+1};
            int yarray [4] = {y, y, y, y};
            savetodeleteelements(xarray, yarray);
        }

        // Zwei Steine nach unten, einer nach oben moeglich
        if (y >= 2 && y < board->parts[part]->arrayheight-1) {

            // Ein Stein nach links oben, zwei nach rechts unten
            if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-1] [y+1]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+2] [y-2]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+1] [y-1]))) {
                int xarray [4] = {x, x-1, x+2, x+1};
                int yarray [4] = {y, y+1, y-2, y-1};
                savetodeleteelements(xarray, yarray);
            }
        }

        // Ein Stein nach unten, zwei nach oben moeglich
        if (y >= 1 && y < board->parts[part]->arrayheight-2) {

            // Ein Stein nach links unten, zwei rnach rechts oben
            if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x-1] [y-1]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+2] [y+2]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+1] [y+1]))) {
                int xarray [4] = {x, x-1, x+2, x+1};
                int yarray [4] = {y, y-1, y+2, y+1};
                savetodeleteelements(xarray, yarray);
            }
        }
    }

    // Drei Steine nach rechts moeglich
    if (x < board->parts[part]->rightposx - board->parts[part]->leftposx-2) {

        // Drei Steine nach rechts
        if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+3] [y]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+2] [y]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+1] [y]))) {
            int xarray [4] = {x, x+3, x+2, x+1};
            int yarray [4] = {y, y, y, y};
            savetodeleteelements(xarray, yarray);
        }

        // Drei Steine nach unten moeglich
        if (y >= 3) {

            // Drei Steine nach rechts unten
            if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+1] [y-1]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+2] [y-2]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+3] [y-3]))) {
                int xarray [4] = {x, x+1, x+2, x+3};
                int yarray [4] = {y, y-1, y-2, y-3};
                savetodeleteelements(xarray, yarray);
            }
        }

        // Drei Steine nach oben moeglich
        if (y < board->parts[part]->arrayheight-3) {

            // Drei Steine nach rechts oben
            if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+1] [y+1]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+2] [y+2]))
                && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x+3] [y+3]))) {
                int xarray [4] = {x, x+1, x+2, x+3};
                int yarray [4] = {y, y+1, y+2, y+3};
                savetodeleteelements(xarray, yarray);
            }
        }
    }

    // Drei Steine nach unten moeglich
    if (y >= 3) {

        // Drei Steine nach unten
        if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x] [y-1]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x] [y-2]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x] [y-3]))) {
            int xarray [4] = {x, x, x, x};
            int yarray [4] = {y, y-1, y-2, y-3};
            savetodeleteelements(xarray, yarray);
        }
    }
    // Zwei Steine nach unten, einer nach oben moeglich
    if (y >= 2 && y < board->parts[part]->arrayheight-1) {

        // Zwei Steine nach unten, einer nach oben
        if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x] [y-1]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x] [y-2]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x] [y+1]))) {
            int xarray [4] = {x, x, x, x};
            int yarray [4] = {y, y-1, y-2, y+1};
            savetodeleteelements(xarray, yarray);
        }
    }

    // Ein Stein nach unten, zwei nach oben moeglich
    if (y >= 1 && y < board->parts[part]->arrayheight-2) {

        // Zwei Steine nach unten, einer nach oben
        if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x] [y-1]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x] [y+2]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x] [y+1]))) {
            int xarray [4] = {x, x, x, x};
            int yarray [4] = {y, y-1, y+2, y+1};
            savetodeleteelements(xarray, yarray);
        }
    }

    // Drei Steine nach oben moeglich
    if (y < board->parts[part]->arrayheight-3) {

        // Drei Steine nach oben
        if ((abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x] [y+1]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x] [y+2]))
            && (abs(board->parts[part]->array [x] [y]) == abs(board->parts[part]->array [x] [y+3]))) {
            int xarray [4] = {x, x, x, x};
            int yarray [4] = {y, y+1, y+2, y+3};
            savetodeleteelements(xarray, yarray);
        }
    }
}

void savetodeleteelements (int xarray [4], int yarray [4]) {

    // Pruefen ob einer der Steine der Viererreihe bereits vorkam.
    int alreadyfound [] = {1, 1, 1, 1};

    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < arraylength; j++) {
            if (xarray[i] == xtodelete[j] && yarray[i] == ytodelete [j]) {
                alreadyfound[i] = 0;
                break;
            }
        }
    }

    // Laenge des Steinarrays, in dem Steine stehen, die zu loeschen sind, aendern.
    int k = alreadyfound[0] + alreadyfound[1] + alreadyfound[2] + alreadyfound[3];
    arraylength += alreadyfound[0] + alreadyfound[1] + alreadyfound[2] + alreadyfound[3];

    xtodelete = (int *) realloc(xtodelete, sizeof(int)*arraylength);
    if (xtodelete == NULL) die("Fehler beim Reallozieren von Speicher!", -1);

    ytodelete = (int *) realloc(ytodelete, sizeof(int)*arraylength);
    if (ytodelete == NULL) die("Fehler beim Reallozieren von Speicher!", -1);

    // Neue zu loeschende Steine den Arrays hinzufuegen
    for (int i = 0; i < 4; i++) {
        if (alreadyfound[i] == 1) {
            xtodelete[arraylength-k] = xarray[i];
            ytodelete[arraylength-k] = yarray[i];
            k--;
        }
    }

}

void delete (int part) {

    // Jeden Stein, der zu loeschen ist, durchgehen.
    for (int i = 0; i < arraylength; i++) {
        //Jede entsprechende Spalte durchgehen
        for (int j = ytodelete[i]; j < board->parts[part]->arrayheight-1; j++) {
            // Wenn ein zu loeschender Stein gefunden wurde, den darueberliegenden runterziehen.
            board->parts[part]->array [xtodelete[i]] [j] = board->parts[part]->array [xtodelete[i]] [j+1];
            if (board->parts[part]->array [xtodelete[i]] [j] == 0) break;
        }
        // Stein am oberen Rand auf 0 setzen
        board->parts[part]->array [xtodelete[i]] [board->parts[part]->arrayheight-1] = 0;

        // y-Position der Steine verringern, die in  der gleichen Spalte ueber dem geloeschten Stein standen.
        for (int k = 0; k < arraylength; k++) {
            if (xtodelete[i] == xtodelete[k]) {
                if (ytodelete[k] > ytodelete[i])
                    ytodelete[k]--;
            }
        }
    }
}