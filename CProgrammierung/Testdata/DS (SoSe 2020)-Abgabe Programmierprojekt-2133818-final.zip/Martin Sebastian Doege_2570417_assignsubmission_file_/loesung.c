/*
	C-Programmierprojekt 2020
	von Martin Doege
	Matrikelnummer: 575026
*/

#include <stdio.h>
#include <stdlib.h> // for malloc() and realloc()
#include <string.h> // for memmove()

// global variables
struct token {
	long xPos;
	long yPos;
	int colour; // colour of 255 is treated as deleted token
};

struct token* gameBoard; // 1d array of struct
// both variables need to be always up to date
long gameBoardSlots = 0; // total amount of slots resp. allocated structs
long tokenCount = 0; // amount of token on the gameBoard

long* verticalList = 0;
long* horizontalList = 0;
long* diagonalUpList = 0;
long* diagonalDownList = 0;
long* deletionList = 0; // stores (indices of) token that will be deleted
long deletionListLength = 0; // number of tokens that will be deleted
long* nextCheckList = 0; // stores (indices of) token that will be checked for lines
long nextCheckListLength = 0; // number of tokens that will be checked next

void printGameBoard()
{
	//printf("Gameboard with %d Tokens\n", tokenCount);
	//printf("| C | x | y |\n");
	for (long i = 0; i < tokenCount; i++)
	{
		//printf("%d %d %d\n", gameBoard[i].colour, gameBoard[i].xPos, gameBoard[i].yPos);
		fprintf(stdout, "%d %ld %ld\n", gameBoard[i].colour, gameBoard[i].xPos, gameBoard[i].yPos);

	}
}

long power(long base, long exp) // returns base^exp
{
	if (exp == 0)
		return 1;
	else if (exp % 2 == 0)
		return power(base, exp / 2) * power(base, exp / 2);
	else
		return base * power(base, exp / 2) * power(base, exp / 2);
}

int getNextToken(struct token* tempToken) // reads line character by character from stdin
{
	static char line[256]; // TODO: maximale L�nge einer Eingabezeile? Unbegrenzt?
	char* linePointer = fgets(line, sizeof(line), stdin); // reads line from stdin
	if (linePointer == 0) // EOF or no file
	{
		return -2;
	}
	long number = 0;
	int sign = 1;
	int numberCounter = 0;
	int numberStartIndex = 256;

	for (int i = 0; i < 256; i++) // read line char by char
	{
		char c = line[i];
		if (c != 32 && c != 45 && !(c >= 48 && c <= 57) && c != 10 && c != 0) // any forbidden character
		{
			fprintf(stderr, "invalid character\n");
			return -1;
		}
		/*if (c == '\0')
		{
			fprintf(stderr, "invalid character\n");
			return -1;
		}*/

		if (c == 32) // blank space
		{
			if (numberStartIndex < 256)
			{
				for (int j = numberStartIndex; j < i; j++)
				{
					number += (line[j] - 48) * power(10, i - j - 1); // char value -48 to get digit between 0 and 9
				}
				number = sign * number;
				numberCounter++;

				if (numberCounter == 1)
				{
					tempToken->colour = number;
					if (number > 254 || number < 0 || number == 65536)
					{
						fprintf(stderr, "colour value out of bounds\n");
						return -1;
					}
				}
				else if (numberCounter == 2)
				{
					if (number > 1048576 || number < -1048576)
					{
						fprintf(stderr, "value out of bounds\n");
						return -1;
					}
					tempToken->xPos = number;
				}
				else
				{
					fprintf(stderr, "too many numbers\n");
					return -1; // too many numbers
				}

				numberStartIndex = 256; // reset for next number
				sign = 1;
				number = 0;
			}
			continue;
		}
		if (c == 45) // minus
		{
			sign = -1;
			continue;
		}
		if (c >= 48 && c <= 57) // digit
		{
			if (i < numberStartIndex)
			{
				numberStartIndex = i;
			}
			continue;
		}
		if (c == 10 || c == 0) // new line or null
		{
			for (int j = numberStartIndex; j < i; j++)
			{
				number += (line[j] - 48) * power(10, i - j - 1); // char value -48 to get digit between 0 and 9
			}
			number = sign * number;
			numberCounter++;
			if (numberCounter == 2)
			{
				if (number > 1048576 || number < -1048576)
				{
					fprintf(stderr, "value out of bounds\n");
					return -1;
				}
				tempToken->xPos = number;
			}
			else
			{
				fprintf(stderr, "too many numbers\n");
				return -1;
			}
			break;
		}
	}

	return 1;
}

long searchForColumn(long xPos) // search for index of the passed column/xPos
{
	long maxIndex = 0;
	for (long index = 0; index < tokenCount; index++)
	{
		if (xPos >= gameBoard[index].xPos)
		{
			maxIndex++;
		}
	}
	return maxIndex;
}

long addTokenToBoard(struct token* tempToken) // checks gameBoard size and may makes room for the incoming token; returns index
{
	long index = searchForColumn(tempToken->xPos); // find the correct place for the token (sort by xPos)
	tokenCount++;
	if (tokenCount > gameBoardSlots) // no free slots on the gameBoard
	{
		gameBoard = realloc(gameBoard, tokenCount * sizeof(struct token));
		if (gameBoard == 0)
		{
			fprintf(stderr, "not enough memory to allocate\n");
			return -1;
		}
		gameBoardSlots = tokenCount;
	}
	if (index < tokenCount - 1) // token not inserted at the right --> need to make room for new token
	{
		memmove(&gameBoard[index + 1], &gameBoard[index], (tokenCount - 1 - index) * sizeof(struct token));// move all tokens 1 to the right
	}
	gameBoard[index].xPos = tempToken->xPos;
	gameBoard[index].yPos = tempToken->yPos;
	gameBoard[index].colour = tempToken->colour;
	return index;
}

int settleSingleToken(long index) // calculates yPos for a single token
{
	if (index == 0)
	{
		gameBoard[0].yPos = 0;
	}
	else if (gameBoard[index - 1].xPos == gameBoard[index].xPos)
	{
		gameBoard[index].yPos = gameBoard[index - 1].yPos + 1;
	}
	else
	{
		gameBoard[index].yPos = 0;
	}
	return 0;
}

int addIndex(long* list, long length, long index, int tokenForDeletionOrCheck) // adds (unique) index at the correct position (sorted ascending)
{
	long maxIndex = 0;
	for (long i = 0; i < length - 1; i++)
	{
		if (index > list[i])
		{
			maxIndex++;
		}
		else if (index == list[i]) // index of startToken already stored 
		{
			if (tokenForDeletionOrCheck == 1)
			{
				deletionListLength--; // length of list is increased before addIndex() is called, hence it needs to be corrected
			}
			else if (tokenForDeletionOrCheck == 2)
			{
				nextCheckListLength--;
			}
			return 0; // token doesn't need to be added again
		}
		else // index should be added at 0
		{
			break;
		}
	}
	memmove(&list[maxIndex + 1], &list[maxIndex], (length - 1 - maxIndex) * sizeof(long));// move all tokens 1 to the right
	list[maxIndex] = index;
	return 0;
}

int settleAllTokenAbove(long index) // moves tokens after index in same column 1 row down and stores those tokens for next check
{
	long xPos = gameBoard[index].xPos;
	long tokenIndex = index + 1;
	while (gameBoard[tokenIndex].xPos == xPos && tokenIndex < tokenCount)
	{
		gameBoard[tokenIndex].yPos -= 1; // move token 1 row down
		//printf(" (%d,%d,%d) falls ", gameBoard[tokenIndex].colour, gameBoard[tokenIndex].xPos, gameBoard[tokenIndex].yPos);
		nextCheckListLength++;
		nextCheckList = realloc(nextCheckList, nextCheckListLength * sizeof(long));
		if (nextCheckList == 0)
		{
			fprintf(stderr, "not enough memory to allocate\n");
			return -1;
		}
		addIndex(nextCheckList, nextCheckListLength, tokenIndex, 2); // store token for next check for lines
		tokenIndex++;
	}
	for (long i = 0; i < nextCheckListLength; i++)
	{
		nextCheckList[i] -= 1;
	}
	return 0;
}

int deleteLines(long* indexList, long length) // deletes found lines and adjusts yPos of tokens above
{
	if (length <= 3) // not enough tokens to form a line hence no need to delete anything
	{
		return 0;
	}

	for (long i = length - 1; i >= 0; i--)
	{
		if (settleAllTokenAbove(indexList[i]) == -1) // drop tokens above the token that will be deleted
		{
			return -1;
		}
		memmove(&gameBoard[indexList[i]], &gameBoard[indexList[i] + 1], (tokenCount - 1 - indexList[i]) * sizeof(struct token));// move all tokens on right 1 index to the left
	}
	tokenCount -= deletionListLength;

	return 0;
}

int findLines(long recentIndex) // looks for lines from 1 index/token
{
	long tokenXPos = gameBoard[recentIndex].xPos;
	long tokenYPos = gameBoard[recentIndex].yPos;
	long tokenColour = gameBoard[recentIndex].colour;
	long nextTokenXPos = 0;
	long nextTokenYPos = 0;

	// some variables to count line lengths and to buffer lines less than 4; in 2*4 directions
	long up = 0;
	long down = 0;
	long right = 0;
	long left = 0;
	long upRight = 0;
	long downLeft = 0;
	long downRight = 0;
	long upLeft = 0;

	// look for tokens right of startToken to form a line
	for (long positive = recentIndex + 1; positive < tokenCount; positive++)
	{
		nextTokenXPos = gameBoard[positive].xPos;
		nextTokenYPos = gameBoard[positive].yPos;
		if (nextTokenXPos > tokenXPos + 3) // token to far right
		{
			break;
		}

		if (gameBoard[positive].colour == tokenColour)
		{
			// vertical up
			if (nextTokenXPos == tokenXPos && nextTokenYPos == tokenYPos + up + 1)
			{
				up++;
				verticalList = realloc(verticalList, up * sizeof(long));
				if (verticalList == 0)
				{
					fprintf(stderr, "not enough memory to allocate\n");
					return -1;
				}
				addIndex(verticalList, up, positive, 0);
			}
			// diagonal up right
			else if (nextTokenXPos == tokenXPos + upRight + 1 && nextTokenYPos == tokenYPos + upRight + 1)
			{
				//printf("upRight ");
				upRight++;
				diagonalUpList = realloc(diagonalUpList, upRight * sizeof(long));
				if (diagonalUpList == 0)
				{
					fprintf(stderr, "not enough memory to allocate\n");
					return -1;
				}
				addIndex(diagonalUpList, upRight, positive, 0);
			}
			// horizontal
			else if (nextTokenXPos == tokenXPos + right + 1 && nextTokenYPos == tokenYPos)
			{
				right++;
				horizontalList = realloc(horizontalList, right * sizeof(long));
				if (horizontalList == 0)
				{
					fprintf(stderr, "not enough memory to allocate\n");
					return -1;
				}
				addIndex(horizontalList, right, positive, 0);
			}
			// diagonal down right
			else if (nextTokenXPos == tokenXPos + downRight + 1 && nextTokenYPos == tokenYPos - downRight - 1)
			{
				downRight++;
				diagonalDownList = realloc(diagonalDownList, downRight * sizeof(long));
				if (diagonalDownList == 0)
				{
					fprintf(stderr, "not enough memory to allocate\n");
					return -1;
				}
				addIndex(diagonalDownList, downRight, positive, 0);
			}
		}
	}
	// look for tokens left of startToken to form a line
	for (long negative = recentIndex - 1; negative >= 0; negative--)
	{
		nextTokenXPos = gameBoard[negative].xPos;
		nextTokenYPos = gameBoard[negative].yPos;
		if (nextTokenXPos < tokenXPos - 3) // token to far left
		{
			break;
		}

		if (gameBoard[negative].colour == tokenColour)
		{
			// vertical down
			if (nextTokenXPos == tokenXPos && nextTokenYPos == tokenYPos - down - 1)
			{
				down++;
				verticalList = realloc(verticalList, (up + down) * sizeof(long));
				if (verticalList == 0)
				{
					fprintf(stderr, "not enough memory to allocate\n");
					return -1;
				}
				addIndex(verticalList, down + up, negative, 0);
			}
			// diagonal down left
			else if (nextTokenXPos == tokenXPos - downLeft - 1 && nextTokenYPos == tokenYPos - downLeft - 1)
			{
				//printf("downLeft ");
				downLeft++;
				diagonalUpList = realloc(diagonalUpList, (upRight + downLeft) * sizeof(long));
				if (diagonalUpList == 0)
				{
					fprintf(stderr, "not enough memory to allocate\n");
					return -1;
				}
				addIndex(diagonalUpList, downLeft + upRight, negative, 0);
			}
			// horizontal
			else if (nextTokenXPos == tokenXPos - left - 1 && nextTokenYPos == tokenYPos)
			{
				//printf("left");
				left++;
				horizontalList = realloc(horizontalList, (right + left) * sizeof(long));
				if (horizontalList == 0)
				{
					fprintf(stderr, "not enough memory to allocate\n");
					return -1;
				}
				addIndex(horizontalList, right + left, negative, 0);
			}
			// diagonal down right
			else if (nextTokenXPos == tokenXPos - upLeft - 1 && nextTokenYPos == tokenYPos + upLeft + 1)
			{
				upLeft++;
				diagonalDownList = realloc(diagonalDownList, (upLeft + downRight) * sizeof(long));
				if (diagonalDownList == 0)
				{
					fprintf(stderr, "not enough memory to allocate\n");
					return -1;
				}
				addIndex(diagonalDownList, upLeft + downRight, negative, 0);
			}
		}
	}

	// save the tokens for deletion if they form a line of 4 or more
	if (left + right >= 3)
	{
		deletionListLength++;
		deletionList = realloc(deletionList, deletionListLength * sizeof(long));
		if (deletionList == 0)
		{
			fprintf(stderr, "not enough memory to allocate\n");
			return -1;
		}
		addIndex(deletionList, deletionListLength, recentIndex, 1); // adding the startToken
		for (long i = 0; i < right + left; i++) // adding every other token of its line
		{
			deletionListLength++;
			//printf("%d ", horizontalList[i]);
			deletionList = realloc(deletionList, deletionListLength * sizeof(long));
			if (deletionList == 0)
			{
				fprintf(stderr, "not enough memory to allocate\n");
				return -1;
			}
			addIndex(deletionList, deletionListLength, horizontalList[i], 1);
		}
	}
	if (downLeft + upRight >= 3)
	{
		deletionListLength++;
		deletionList = realloc(deletionList, deletionListLength * sizeof(long));
		if (deletionList == 0)
		{
			fprintf(stderr, "not enough memory to allocate\n");
			return -1;
		}
		addIndex(deletionList, deletionListLength, recentIndex, 1); // adding the startToken
		for (long i = 0; i < downLeft + upRight; i++) // adding every other token of its line
		{
			deletionListLength++;
			deletionList = realloc(deletionList, deletionListLength * sizeof(long));
			if (deletionList == 0)
			{
				fprintf(stderr, "not enough memory to allocate\n");
				return -1;
			}
			addIndex(deletionList, deletionListLength, diagonalUpList[i], 1);
		}
	}
	if (upLeft + downRight >= 3)
	{
		deletionListLength++;
		deletionList = realloc(deletionList, deletionListLength * sizeof(long));
		if (deletionList == 0)
		{
			fprintf(stderr, "not enough memory to allocate\n");
			return -1;
		}
		addIndex(deletionList, deletionListLength, recentIndex, 1); // adding the startToken
		for (long i = 0; i < upLeft + downRight; i++) // adding every other token of its line
		{
			deletionListLength++;
			deletionList = realloc(deletionList, deletionListLength * sizeof(long));
			if (deletionList == 0)
			{
				fprintf(stderr, "not enough memory to allocate\n");
				return -1;
			}
			addIndex(deletionList, deletionListLength, diagonalDownList[i], 1);
		}
	}
	if (up + down >= 3)
	{
		deletionListLength++;
		deletionList = realloc(deletionList, deletionListLength * sizeof(long));
		if (deletionList == 0)
		{
			fprintf(stderr, "not enough memory to allocate\n");
			return -1;
		}
		addIndex(deletionList, deletionListLength, recentIndex, 1); // adding the startToken
		for (long i = 0; i < up + down; i++) // adding every other token of its line
		{
			deletionListLength++;
			deletionList = realloc(deletionList, deletionListLength * sizeof(long));
			if (deletionList == 0)
			{
				fprintf(stderr, "not enough memory to allocate\n");
				return -1;
			}
			addIndex(deletionList, deletionListLength, verticalList[i], 1);
		}
	}
	return 0;
}

int main(void)
{
	gameBoard = malloc(sizeof(struct token)); // allocate memory for the 1st token
	if (gameBoard == 0)
	{
		fprintf(stderr, "not enough memory to allocate\n");
		return -1;
	}
	gameBoardSlots++;

	struct token currentToken;
	int validToken = getNextToken(&currentToken);
	while (validToken > -1) { // as long as valid token are coming/read
		long recentIndex = addTokenToBoard(&currentToken); // add token at the correct column/xPos
		if (recentIndex == -1) { return -1; }
		settleSingleToken(recentIndex); // drops the newly added token

		nextCheckListLength = 1;
		nextCheckList = realloc(nextCheckList, nextCheckListLength);
		if (nextCheckList == 0)
		{
			fprintf(stderr, "not enough memory to allocate\n");
			return -1;
		}
		nextCheckList[0] = recentIndex;

		while (nextCheckListLength != 0) // as long as there are tokens to check for lines
		{
			deletionListLength = 0; // no tokens to be deleted yet
			for (long i = 0; i < nextCheckListLength; i++)
			{
				if (findLines(nextCheckList[i]) == -1) // collect all tokens that will be deleted
				{
					return -1;
				}
			}
			nextCheckListLength = 0; // empty this list so that it can be filled with new tokens to be checked in next iteration
			if (deleteLines(deletionList, deletionListLength) == -1) // delete found lines, drop token above and store them for the next check
			{
				return -1;
			};
		}
		validToken = getNextToken(&currentToken);
	}

	if (validToken != -1 && gameBoardSlots > 0) // if there was no invalid read and at least 1 token was read
	{
		printGameBoard();
	}

	// free all dynamic lists
	if (gameBoardSlots > 0) { free(gameBoard); }
	verticalList = realloc(verticalList, sizeof(long));
	if (verticalList == 0)
	{
		fprintf(stderr, "not enough memory to allocate\n");
		return -1;
	}
	free(verticalList);
	horizontalList = realloc(horizontalList, sizeof(long));
	if (horizontalList == 0)
	{
		fprintf(stderr, "not enough memory to allocate\n");
		return -1;
	}
	free(horizontalList);
	diagonalDownList = realloc(diagonalDownList, sizeof(long));
	if (diagonalDownList == 0)
	{
		fprintf(stderr, "not enough memory to allocate\n");
		return -1;
	}
	free(diagonalDownList);
	diagonalUpList = realloc(diagonalUpList, sizeof(long));
	if (diagonalUpList == 0)
	{
		fprintf(stderr, "not enough memory to allocate\n");
		return -1;
	}
	free(diagonalUpList);
	deletionList = realloc(deletionList, sizeof(long));
	nextCheckList = realloc(nextCheckList, sizeof(long));

	/*if (deletionListLength> 0)*/ { free(deletionList); }
	/*if (nextCheckListLength>0)*/ { free(nextCheckList); }
	if (validToken == -1)
	{
		return -1;
	}
	return 0;
}
