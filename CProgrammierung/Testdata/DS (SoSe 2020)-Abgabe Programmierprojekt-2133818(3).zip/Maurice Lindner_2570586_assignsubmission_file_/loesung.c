#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <limits.h>


/* TODO TODO TODO TODO TODO TODO TODO TODO TODO 

    1. add free for array mallocs
    2. create array with offset


   TODO TODO TODO TODO TODO TODO TODO TODO TODO */

typedef struct DynRow {
    unsigned char* colors;
    bool* dFlag;
    int length;
    int max;
    int critical;
    int newCrit;
} DynRow;

typedef struct DynArray {
    DynRow** rows;
    int length;
    int offset;
    int criticalMin;
    int newCriticalMin;
    int criticalMax;
    int newCriticalMax;
} DynArray;

typedef struct Point {
    int x;
    int y;
} Point;

int offset = 0;
int expand = 0;

DynArray *createDynArray(int size, int offset);
DynRow *createRow(int size);

int minKey(DynArray *dyn) {
    return dyn->offset;
}


int maxKey(DynArray *dyn) {
    return dyn->length+dyn->offset-1;
}

int getIndex(int key, DynArray *dyn) {
    return key - dyn->offset;
}

int minOf(int a, int b) {
    if(a<=b) {
        return a;
    }
    return b;
}

int maxOf(int a, int b) {
    if(a>=b) {
        return a;
    }
    return b;
}


void copyRow(DynRow *src, DynRow *dest, int offsetSrc, int offsetDest, int copyLength) {
    for(int i = 0; i < copyLength && i <10; i++) {
        dest->colors[i+offsetDest] = src->colors[i+offsetSrc];
    }
    dest->length = maxOf(dest->length, offsetDest+copyLength);
}



void copyArray(DynArray *src, DynArray *dest, int shift) {
    for(int i = 0; i < src->length; i++) {
        dest->rows[i+shift] = src->rows[i]; 
    }
}

void printRow(DynRow *row) {
    printf("Row: size: %d ", row->length);
    for(int i = 0; i < row->length; i++) {
        printf(" / %d: %d", i, row->colors[i]);        
    }
    printf("\n");
}

void printDynArray(DynArray *dyn) {
    printf("/// ArraySize:%d ///\n", dyn->length);
    for(int i = 0;  i < dyn->length; i++) {
        printf("%d => %d ",i, i+dyn->offset);
        printRow(dyn->rows[i]);
    }
    printf("\n");
}

DynRow *resizeRow(DynRow *row, int newLength) {
    DynRow *new = createRow(newLength);
    copyRow(row, new, 0, 0, row->length);
    return new;
}

void addInRow(unsigned char value, DynRow *row) {
    if(row->length > row->max) {
        int newSize = maxOf(1,2*row->length);
        row->colors = realloc(row->colors, newSize*sizeof(unsigned char));
        if(row->colors == NULL) {
            fprintf(stderr, "Not enough memory");
            exit(1);
        }        

        row->dFlag = realloc(row->dFlag, newSize*sizeof(bool));
        if(row->dFlag == NULL) {
            fprintf(stderr, "Not enough memory");
            exit(1);
        }  

        row->max = newSize-1;
    }
    row->colors[row->length] = value;
    row->dFlag[row->length] = false;
    row->critical = minOf(row->critical, row->length);
    row->length = row->length+1;
}

void addInArray(int key, unsigned char value, DynArray *dyn) {
    int diff = 0;
    if(key>maxKey(dyn)) {
        diff = key-maxKey(dyn);
        dyn->rows = realloc(dyn->rows, (dyn->length+diff)*sizeof(DynRow));
        if(dyn->rows == NULL || dyn->length+diff > 1048576) {
            fprintf(stderr, "Not enough memory or x-coordinates too far away from each other");
            exit(1);
        }  
        for(int i = 0; i < diff; i++) {
            dyn->rows[dyn->length+i] = createRow(1);
        }

        dyn->length = dyn->length+diff;
        
        
    } else if(key < minKey(dyn)) {
        diff = minKey(dyn)-key;
        dyn->rows = realloc(dyn->rows, (dyn->length+diff)*sizeof(DynRow));
        if(dyn->rows == NULL || dyn->length+diff > 1048576) {
            fprintf(stderr, "Not enough memory or x-coordinates too far away from each other");
            exit(1);
        }  
        dyn->length = dyn->length+diff;
        dyn->offset = dyn->offset-diff;
        for(int i = dyn->length-1; i >= diff; i--) {
            dyn->rows[i] = dyn->rows[i-diff];
        }
        for(int i = 0; i < diff;i++) {
            dyn->rows[i] = createRow(1);
        }
    }
    addInRow(value, dyn->rows[key-dyn->offset]);
}

void deleteValueFromRow(int y, int height, DynRow *row) {
    for(int i = y; i<row->length-height;i++) {
        row->colors[i] = row->colors[i+height];
    }
    
    row->length = row->length-height;
}

void deleteValue(int x, int y, int height, DynArray *dyn) {
    deleteValueFromRow(y, height, dyn->rows[x-dyn->offset]);
}

int* getVerticalLine(int indX, int indY, DynArray *dyn, int* result) {
    int x = indX;
    int y = indY;
    unsigned char c = dyn->rows[x]->colors[y];
    int minus = y;
    int plus = y;
    while(minus-1 >= 0 && dyn->rows[x]->colors[minus-1] == c) {
        minus--;
    }
    while(plus+1 < dyn->rows[x]->length && dyn->rows[x]->colors[plus+1] == c) {
        plus++;
    }
    result[0] = minus;
    result[1] = plus;
    return result;
}

int* getHorizontalLine(int indX, int indY, DynArray *dyn, int* result) {
    int x = indX;
    int y = indY;
    unsigned char c = dyn->rows[x]->colors[y];
    int minus = x;
    int plus = x;
    while(minus-1 >= 0 && dyn->rows[minus-1]->length > y && dyn->rows[minus-1]->colors[y] == c) {
        minus--;
    }
    while(plus+1 < dyn->length && dyn->rows[plus+1]->length > y && dyn->rows[plus+1]->colors[y] == c) {
        plus++;
    }
    result[0] = minus;
    result[1] = plus;
    return result;
}

int* getDiagonalUpLine(int indX, int indY, DynArray *dyn, int* result) {
    int x = indX;
    int y = indY;
    unsigned char c = dyn->rows[x]->colors[y];
    int minusX = x;
    int minusY = y;
    int plusX = x;
    int plusY = y;
    while(minusX-1 >= 0 && minusY-1 >= 0 && dyn->rows[minusX-1]->length > minusY-1 && dyn->rows[minusX-1]->colors[minusY-1] == c) {
        minusX--;
        minusY--;
    }
    while(plusX+1 < dyn->length && plusY+1 < dyn->rows[plusX+1]->length && dyn->rows[plusX+1]->colors[plusY+1] == c) {
        plusX++;
        plusY++;
    }
    result[0] = minusX;
    result[1] = minusY;
    result[2] = plusX;
    result[3] = plusY;
    return result;
}

int* getDiagonalDownLine(int indX, int indY, DynArray *dyn, int* result) {
    int x = indX;
    int y = indY;
    unsigned char c = dyn->rows[x]->colors[y];
    int minusX = x;
    int minusY = y;
    int plusX = x;
    int plusY = y;
    //hochlinks
    while(minusX-1 >= 0 && plusY+1 < dyn->rows[minusX-1]->length && dyn->rows[minusX-1]->colors[plusY+1] == c) {
        minusX--;
        plusY++;
    }
    //runterrechts
    while(plusX+1 < dyn->length && dyn->rows[plusX+1]->length > minusY-1 && minusY-1 >= 0 && dyn->rows[plusX+1]->colors[minusY-1] == c) {
        plusX++;
        minusY--;
    }
    result[0] = minusX;
    result[1] = plusY;
    result[2] = plusX;
    result[3] = minusY;
    return result;
}

void registerCrit(DynArray *dyn, int x, int y) {
    DynRow *row = dyn->rows[x];
    //Row critical
    if(row->newCrit == -1) {
        row->newCrit = y;
    } else {
        row->newCrit = minOf(row->newCrit, y);
    }
    //arr critical
    if(dyn->newCriticalMin == -1 && dyn->newCriticalMax == -1) {
        dyn->newCriticalMin = x;
        dyn->newCriticalMax = x;
    } else {
        dyn->newCriticalMin = minOf(dyn->newCriticalMin, x);
        dyn->newCriticalMax = maxOf(dyn->newCriticalMax, x);        
    }
}

void checkPoint(int x, int y, DynArray *dyn) {

    int *res = malloc(4*sizeof(int));
    if(res == NULL) {
       fprintf(stderr, "Not enough memory");
       exit(1);
    }
    int len = 0;

    getVerticalLine(x, y, dyn, res);
    if(res[1]-res[0] >= 3) {
        for(int i = res[0]; i <= res[1]; i++) {
            dyn->rows[x]->dFlag[i] = true;
        }
        registerCrit(dyn, x, res[0]);
    }

    getHorizontalLine(x, y, dyn, res);
    if(res[1]-res[0] >= 3) {
        for(int i = res[0]; i <= res[1]; i++) {
            dyn->rows[i]->dFlag[y] = true;
            registerCrit(dyn,i, y);
        }
    }

    getDiagonalUpLine(x, y, dyn, res);
    len = res[2] - res[0]+1;
    if(len >= 4) {
        for(int i = 0; i < len; i++) {
            dyn->rows[res[0]+i]->dFlag[res[1]+i] = true;
            registerCrit(dyn, res[0]+i, res[1]+i);
        }
    }

    getDiagonalDownLine(x, y, dyn, res);
    len = res[2] - res[0]+1;
    if(len >= 4) {
        for(int i = 0; i < len; i++) {
            dyn->rows[res[0]+i]->dFlag[res[1]-i] = true;
            registerCrit(dyn, res[0]+i, res[1]-i);
        }
    }


    free(res);
}

void gravity(DynRow* row) {
    int delCount = 0;
    for(int i = row->newCrit; i < row->length; i++) {
        if(row->dFlag[i]) {
            delCount++;
        } else {
            row->colors[i-delCount] = row->colors[i];
        }
        row->dFlag[i] = false;
    }
    row->length = row->length-delCount;
}

void performDelete(DynArray* dyn) {
    if(dyn->newCriticalMax != -1) {
        for(int i = dyn->newCriticalMin; i <= dyn->newCriticalMax; i++) {
            if(dyn->rows[i]->newCrit != -1) {
                gravity(dyn->rows[i]);
            }

            dyn->rows[i]->critical = dyn->rows[i]->newCrit;
            dyn->rows[i]->newCrit = -1;
        }
    }

    dyn->criticalMin = dyn->newCriticalMin;
    dyn->criticalMax = dyn->newCriticalMax;
    dyn->newCriticalMin = -1;
    dyn->newCriticalMax = -1;
}

bool check(DynArray *dyn) {
    bool isCrit = false;

    if(dyn->criticalMin == -1) {
        return false;
    }

    for(int i = dyn->criticalMin; i <= dyn->criticalMax; i++) {
        if(dyn->rows[i]->critical != -1) {
            isCrit = true;
            for(int j = dyn->rows[i]->critical; j < dyn->rows[i]->length; j++) {
                checkPoint(i,j,dyn);
            }
        }
    }   
    return isCrit;
}

void fix(DynArray *dyn) {
    while(check(dyn)) {
        performDelete(dyn);
    }
}



void printArray(DynArray *dyn) {
    for(int i = 0;  i < dyn->length; i++) {
        printRow(dyn->rows[i]);
    }
}


void printDyn(DynArray *dyn) {
    printf("Size:%d ///", dyn->length);
    for(int i = 0;  i < dyn->length; i++) {
        printf("%d ",i);
        printf("Size:%d //", dyn->length);
        for(int j = 0; j < dyn->rows[i]->length;j++) {
            printf("%d ",dyn->rows[i]->colors[j]);
        }
    }
}

void add(int key, unsigned char value, DynArray *dyn) {
    addInArray(key, value, dyn);  
    int i = getIndex(key,dyn);
    dyn->rows[i]->critical = dyn->rows[i]->length-1;
    dyn->criticalMin = i;
    dyn->criticalMax = i;
    fix(dyn);
}

void printResult(DynArray *dyn) {
    for(int x = 0; x < dyn->length;x++) {
        for(int y = 0; y < dyn->rows[x]->length; y++) {
            printf("%d %d %d\n", dyn->rows[x]->colors[y], x+dyn->offset, y);
        }
    }
}

void freeDynRow(DynRow *row) {
    free(row->colors);
    free(row->dFlag);
    free(row);
}

void freeDynArray(DynArray *arr) {
    for(int i = 0; i < arr->length; i++) {
            if(arr->rows[i] != NULL) {
            freeDynRow(arr->rows[i]);
        }
    }
    free(arr->rows);
    free(arr);
}

int main() {
    char in;
    char color;
    int row;
    bool sign = false;
    bool oneChar = false;

    DynArray *pitch = createDynArray(1,0);
    pitch->rows[0] = createRow(0);

    color = 0;
    in = getchar();
    while(in != EOF) {
        color = 0;
        row = 0;
        oneChar = false;
        while(in != EOF && in != 32 && in >= '0' && in <='9') {
            oneChar = true;
            color=10*color+(in-'0');
            in = getchar();
        }
        if((in != 32 && in != EOF)|| color > 254 || !oneChar) {
            //ungültige Eingabe, da das Zeichen kein Leerzeichen oder EOF ist, oder color > 254 oder weil keine einizge Ziffer eingegeben wurde als color
            fprintf(stderr, "unvalid input 1\n");
            exit(1);
        }

        while(in == 32) {
            in = getchar();
        }
        if(in != 45 && (in <'0' || in >'9')) {
            //Wenn das Zeichen weder Sign noch zwischen 0 und 9 liegt: unvalid eingabe
            fprintf(stderr, "unvalid input 2 char %c\n", in);
            exit(1);
        }
        sign = false;
        if(in == 45) {
            sign = true;
            in = getchar();
        }
        oneChar = false;
        while(in >= '0' && in <= '9') {
            row=10*row+(in-'0');
            in = getchar();
            oneChar = true;
        }
        if(sign == true) {
            row = row*(-1);
        }
        if(in != EOF && in != 10 && !oneChar) {
            //weder umbruch noch eof oder es wurde nicht eine Ziffer als row angegeben
            fprintf(stderr, "unvalid input 3\n");
            exit(1);
        }
        add(row, color, pitch);
        if(in == 10) {
            in = getchar();
        }

    }

    printResult(pitch);

    freeDynArray(pitch);
    return 0;
}




DynRow *createRow(int size) {
    DynRow *new = malloc(sizeof(DynRow));
    if(new == NULL) {
       fprintf(stderr, "Not enough memory");
        exit(1);
    }
    new->max = size-1;
    new->length = 0;
    new->colors = malloc(sizeof(unsigned char)*size);
    if(new->colors == NULL) {
       fprintf(stderr, "Not enough memory");
       exit(1);
    }
    new->dFlag = malloc(sizeof(bool)*size);
    if(new->dFlag == NULL) {
       fprintf(stderr, "Not enough memory");
       exit(1);
    }
    new->newCrit = -1;
    new->critical = -1;


    return new;
}

DynArray *createDynArray(int size, int offset) {
    DynArray *new = malloc(sizeof(DynArray));
    if(new == NULL) {
       fprintf(stderr, "Not enough memory");
       exit(1);
    }
    new->length = size;
    new->offset = offset;
    new->rows = malloc(sizeof(DynRow)*size);
    if(new->rows == NULL) {
       fprintf(stderr, "Not enough memory");
       exit(1);
    }
    new->newCriticalMin = -1;
    new->newCriticalMax = -1;
    new->criticalMin = -1;
    new->criticalMax = -1;

    return new;
}



