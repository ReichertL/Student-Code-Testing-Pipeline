#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Matrix Matrix;
typedef struct Stein Stein;
typedef struct Ergebnis Ergebnis;

struct Matrix {
	int **Grid;
	long int Spalten;
	long int LSZeile; //Letzte Stein Zeile
	long int Zeilen;
	long int KleinsteSpalte; //
};

struct Stein {
	int Farbe;
	long int Spalte;
};

struct Ergebnis {
	int Links;
	int Rechts;
};

//y = Zeilen, x = Spalten

Matrix* CreateMatrix() { //erstellt leere 5x5 Matrix als basis zum einfuegen von werten.

	Matrix *newMatrix = malloc(sizeof(Matrix)); //Objekt Matrix erstellt. Ohne werte.
	int *Pointer[5]; //Erstellt konkrete Matrix mit 25 elementen platz
	for (int y = 0; y < 5; y++) {
			Pointer[y] = malloc(sizeof(int)* 5); //x,y zur illustration wie doppelarrays aufgebaut.
		for(int x = 0; x < 5; x++) {
			Pointer[y][x] = -1;
		}	
	}
	
	//Zuweisung der Variablen von Matrix Objekt
	newMatrix->Grid = Pointer;
	newMatrix->Spalten = 5;
	newMatrix->LSZeile = 0;
	newMatrix->Zeilen = 5;
	newMatrix->KleinsteSpalte = 0;

	return newMatrix;
}

void FreeMatrix (Matrix *Array) { //Gibt Speicher von Matrix frei

	free(Array->Grid); 	//Matrixpointer freigeben
	free(Array);		//Matrix freigeben
}

Matrix* SpalteHinzufuegen (Matrix *Array) { //fuegt Zeile zur Matrix hinzu

	Array->Spalten++;
	for(int x = 0; x < Array->Zeilen; x++) {
		Array->Grid[x] = realloc(Array->Grid[x], sizeof(int) * Array->Zeilen);
		Array->Grid[x][Array->Spalten-1] = -1;
	}
	
	return Array;
}

Matrix* ZeileHinzufuegen (Matrix *Array) { //Fuegt Spalte zu Matrix hinzu

	int *nextPointer[Array->Zeilen +1];	
	Array->Zeilen++;
	for(long int i = 0; i < Array->Zeilen-2; i++) {
		nextPointer[i] = Array->Grid[i];
	}
	nextPointer[Array->Zeilen-1] = malloc(sizeof(int) * Array->Spalten);
	for (long int j = 0; j < Array-> Spalten; j++) {
		nextPointer[Array->Zeilen-1][j] = -1;
	}
	Array->Grid = nextPointer;

	return Array;
}

Ergebnis* SpaltenScan (Matrix *Array,long int x,long int y, Ergebnis *SSE) {

	int SUCounter = 0;
	int i = 1;
	while (Array->Grid[y-i+1][x] == Array->Grid[y-i][x] && (y-i) >= 0) {
		SUCounter++;
		i++;
	}
	int SOCounter = 0;
	i = 1;
	while (Array->Grid[y+i-1][x] == Array->Grid[y+i][x]) {
		SOCounter++;
		i++;
	}
	if (SUCounter + SOCounter >= 3) {
		SSE->Links = SUCounter;
		SSE->Rechts = SOCounter;
	}
	return SSE;
}
Ergebnis* ZeilenScan (Matrix *Array,long int x,long int y, Ergebnis *ZSE) { //ZeilenScan nach links vom Ausgehenden Stein

	int ZLCounter = 0; //Zeilen Links Scan
	int i = 1;
	while (Array->Grid[y][x-i+1] == Array->Grid[y][x-i] && (x-i) >= Array->KleinsteSpalte)	{
		ZLCounter++;
		i++;
	}

	int ZRCounter = 0; //Zeilen Rechts Scan
	i = 1;
	while (Array->Grid[y][x+i-1] == Array->Grid[y][x+i] && (x+i) < Array->Spalten) {
		ZRCounter++;
		i++;
	}
	if (ZLCounter + ZRCounter >= 3) {
		ZSE->Links = ZLCounter;
		ZSE->Rechts = ZRCounter;
	}
	return ZSE;
}

Ergebnis* DLOScan (Matrix *Array, long int x, long int y, Ergebnis *DLOSE) { //Diagonal Links Oben nach rechts Unten Scan

	int DLOCount = 0; //Anzahl gleicher Steine Diagonal nach diagonal links oben gehend vom gefallenen Stein
	int i = 1;
	while (Array->Grid[y+i-1][x-i+1] == Array->Grid[y+i][x-i] && (x-i) >= Array->KleinsteSpalte && (y+i) < Array->Zeilen) {
		DLOCount++;
		i++;
	}
	
	int DRUCount = 0; //Anzahl gleicher Steine nach Diagonal Rechts Unten gehend vom gefallenen Stein
	i = 1;
	while (Array->Grid[y-i+1][x+i-1] == Array->Grid[y-i][x+i] && (x+i) < Array->Spalten && (y-i) >= 0) {
		DRUCount++;
		i++;
	}

	if (DLOCount + DRUCount >= 3) {
		DLOSE->Links = DLOCount;
		DLOSE->Rechts = DRUCount;
	}
	return DLOSE;
}
Ergebnis* DLUScan (Matrix *Array, long int x, long int y, Ergebnis *DLUSE) { //Diagonal links Unten nach rechts Oben Scan

	int DLUCount = 0;
	int i = 1;
	while (Array->Grid[y-i+1][x-i+1] == Array->Grid[y-i][x-i] && (x-i) >= Array->KleinsteSpalte && (y-i) >= 0) {
		DLUCount++;
		i++;
	}
	
	int DROCount = 0;
	i = 1;
	while (Array->Grid[y+i-1][x+i-1] == Array->Grid[y+i][x+i] && (x+i) < Array->Spalten && (y+i) < Array->Zeilen) {
		DROCount++;
		i++;
	}

	if (DLUCount + DROCount >= 3) {
		DLUSE->Links = DLUCount;
		DLUSE->Rechts = DROCount;
	}
	return DLUSE;
}

Matrix* ZeilenCleanMatrix (Matrix *Array, Ergebnis *ZSE, long int x, long int y) { //Entfernt gefundene Matches von Zeilen

	int deleteLength = ZSE->Links + ZSE->Rechts + 1;
	int start = x - ZSE->Links;
	for (int i = 0; i < deleteLength; i++) {
		Array->Grid[y][start + i] = -1;
	}

	return Array;
}

Matrix* SpaltenCleanMatrix (Matrix *Array,Ergebnis *SSE, long int x, long int y) { //Entfernt gefundene Matches von Spalte

	int deleteLength = SSE->Links + SSE->Rechts + 1;	
	int start = y - SSE->Links;
	for (int i = 0; i < deleteLength; i++) {
		Array->Grid[start +i][x] = -1;
	}

	return Array;
}

Matrix* DLOCleanMatrix (Matrix *Array,Ergebnis *DLOSE, long int x, long int y) { //Entfernt gefundene Matches von Diagonale (linksoben nach rechtsunten)

	int deleteLength = DLOSE->Links + DLOSE->Rechts + 1;
	int startY = y + DLOSE->Links;
	int startX = x - DLOSE->Links;
	for (int i = 0; i < deleteLength; i++) {
		Array->Grid[startY - i][startX + i] = -1;
	}

	return Array;
}

Matrix* DLUCleanMatrix (Matrix *Array,Ergebnis *DLUSE, long int x, long int y) { //Entfernt gefundene Matches von Diagonale (linksunten nach rechtsoben)

	int deleteLength = DLUSE->Links + DLUSE->Rechts + 1;
	int startY = y - DLUSE->Links;
	int startX = x - DLUSE->Links;
	for (int i = 0; i < deleteLength; i++) {
		Array->Grid[startY + i][startX + i] = -1;
	}

	return Array;
}

Matrix* ScanMatrix (Matrix *Array,long int x,long int y) { //ueberprueft auf 4+er Matches, Vertikal Horizontal und Diagonal + inizierung von Clean Matrix wenn noetig.

	Ergebnis *ZSE = malloc(sizeof(Ergebnis));
	Ergebnis *SSE = malloc(sizeof(Ergebnis));
	Ergebnis *DLOSE = malloc(sizeof(Ergebnis));
	Ergebnis *DLUSE = malloc(sizeof(Ergebnis));

	ZSE = ZeilenScan (Array, x, y, ZSE); //ZeilenScanErgebnis
	SSE = SpaltenScan (Array, x, y, SSE); //SpaltenScanErgebnis
	DLOSE = DLOScan (Array, x, y, DLOSE); //DiagonalLinksObenScanErgebnis
	DLUSE = DLUScan (Array, x, y, DLUSE); //DiagonalLinksUntenScanErgebnis

	if (ZSE->Links != NULL) {
		ZeilenCleanMatrix(Array, ZSE, x, y);
	}
	if (SSE->Links != NULL) {
		SpaltenCleanMatrix(Array, SSE, x, y);
	}
	if (DLOSE->Links != NULL) {
		DLOCleanMatrix(Array, DLOSE, x, y);
	}
	if (DLUSE->Links != NULL) {
		DLUCleanMatrix(Array, DLUSE, x, y);
	}

}


void PrintMatrix (Matrix *Array) {

	for (long int i = 0; i < Array->Zeilen; i++) {
		for (long int j = 0; j < Array->Spalten; i++) {
			printf ("%d %d %d\n", Array->Grid[j][i], j, i);  //Ausgabe im format Farbe, Spalte, Zeile
		}
	}
}

Stein* CheckString (size_t characters, char *buffer, Stein *Feld) {

	int Integer; 
	int counter = 0;

	char *ptr; //gibt position von ende der 1. Zahl an	
	char *ptr2;
	int Farbe;
	int Spalte;
	characters--;
	if (2 >= characters) {
		perror("Eingabe zu klein. Error 1");
		exit(1);
	}

	Integer = (int) buffer[counter]; //Speichert ersten char als ASCII code in Integer	
	if (Integer < 48 || Integer > 57) { //Zahlen liegen im bereich 48-57 im ASCII code >= test ob 1. char etas anderes als eine zahl
		perror("Farbe ist keine Zahl im Bereich [0,254]! Error 2");
		exit(1);
	}

	while (Integer >= 48 && Integer <= 57 && counter < characters) {
		counter++;
		Integer = (int) buffer[counter];
	}

	if (Integer != 32 || counter == characters) {    //32 im ASCII code ist ein Leerzeichen
		perror("Fehlerhafte Eingabe, nach der Farbe folgt kein Leerzeichen. Error 3");
		exit(1);
	}
/**/	Farbe = strtol(buffer, &ptr, 10); //extrahieren unsere Farbe aus dem string.
	
	if (Farbe < 0 || Farbe > 254) { //Test ob Farbe im Bereich;
		perror("Farbe ist keine Zahl im Bereich [0,254]! Error 4");
		exit(1);
	}
	characters = characters - counter; //Characters wird gekuerzt um 1. Zahl, um im reststring damit gut arbeiten zu können.
	counter = 0;
	Integer = (int) ptr[counter];

	while (Integer == 32 && counter < characters) {		
		counter++;
		Integer = (int) ptr[counter];
	}
	if (counter == characters) {
		perror("Eingabe besteht nur aus 1er Zahl. Error 5");
		exit(1);
	}
	if ((Integer < 48 || Integer > 57) && Integer != 45) { //45 ist in ASCII ein -
		perror("Eingabe fehlerhaft. Besteht nur aus 1er Zahl oder enthaelt ungueltiges Zeichen. Error 6");
		exit(1);
	}
	int speicher = counter;
	counter++;
	int check = (int) ptr[counter];
	if (Integer == 45 && check < 48 || check > 57) { //test ob nach einem potenziellen - noch eine zahl folgt.
		perror("ungueltige eingabe. Keine zahl nach -. Error 7");
		exit(1);
	}
	int vz = 0;
	if (Integer == 45) {
		vz = 1;
	}
	Integer = (int) ptr[counter];
	while (Integer >= 48 && Integer <= 57 && counter < characters) { 
		counter++;		
		Integer = (int) ptr[counter];
	}
	Integer = (int) ptr[--counter];
	if (counter < characters-1 && (ptr[counter] != 45 && ptr[counter] != 10)) {
		perror("Eingabe > 2 Zahlen. Error 8");
		exit(1);
	}

	if (Integer < 48 || Integer > 57) {
		perror("Letztes Zeichen ist ungueltig. Error 9");
		exit(1);
	}
	//Ab hier correkte eingabe.
	if (vz == 1) {
		speicher++;
	}
	int i;
	for (i = 0; i < (characters - speicher) ; i++) { //Entfernen der Leerstellen durch vorschieben der Zeichen nach den Leerzeichen + loeschen von überfluessigen zeichen durch nullpointer 

		ptr[i] = ptr[speicher];
	}
	ptr[i] = NULL;
/**/	Spalte = strtol(ptr, &ptr2, 10);
	
	if(vz == 1) {
		Spalte = Spalte * (-1);
	}
	if (Spalte < -1048576 || Spalte > 1048576) {
		perror("Spalte zu groß/klein. Error 10");
		exit(1);
	}
	Feld->Farbe = Farbe;
	Feld->Spalte = Spalte;

	return Feld;
}

Matrix* DropStein (Matrix *Array, int Farbe, long int Spalte) {
	
	int diff = 0;
	if (Spalte < Array->KleinsteSpalte) {
		diff = Array->KleinsteSpalte - Spalte;
		Array->KleinsteSpalte = Spalte;
	}
	else if (Spalte > Array->KleinsteSpalte + Array->Spalten) {
		diff = Spalte - (Array->KleinsteSpalte + Array->Spalten);
	}
	while (diff > 0) {
		Array = SpalteHinzufuegen(Array);
		diff--;
	}
	if (Array->Grid[Array->Zeilen][Spalte] != -1) {
		Array = ZeileHinzufuegen(Array);
	}
	long int y = Array->Zeilen;
	while (Array->Grid[y][Spalte] == -1) {
		y--;
	}
	Array->Grid[y][Spalte] = Farbe;
	Array->LSZeile = y;

	return Array;
}


int main () {

	size_t bufsize = 32; 
	char *buffer = malloc(bufsize * sizeof(char));
	size_t characters; //Anzahl Chars pro zeile.
	if(buffer == NULL) { //Malloc fehlgeschlagen
		perror("Unable to allocate buffer");
        	exit(1);
    	}
	characters = getline(&buffer, &bufsize, stdin);
	Stein *Stone = malloc(sizeof(Stein));

	Stone = CheckString (characters, buffer, Stone);

	int Integer;
	Matrix *Array;
	Array = CreateMatrix();
	while(characters!=-1) { //Hier Algorythmus einfuegen
		Integer = (int) buffer[0];

		Stone = CheckString(characters, buffer, Stone);
		Array = DropStein(Array, Stone->Farbe, Stone->Spalte);
		ScanMatrix(Array, Array->LSZeile, Stone->Spalte);
				
        	characters = getline(&buffer, &bufsize, stdin); //holt naechste line.
    	}
	PrintMatrix(Array); 
	fclose(fp);
	free(Stone);
    	free(buffer);
	FreeMatrix(Array);
    	return 0;
}






