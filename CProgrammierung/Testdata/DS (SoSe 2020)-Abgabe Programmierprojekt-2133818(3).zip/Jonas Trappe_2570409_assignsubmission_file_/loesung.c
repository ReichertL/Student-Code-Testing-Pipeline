
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

// --- helpers --- //

void die(char* msg);

// --- long array implementation --- //

size_t ARRAYSIZE = 4;
int ROW_LENGTH = 4;

typedef struct {
   int *array;
   size_t used;
   size_t size;
} Array;

typedef struct {
   Array* array;
} NullableArray;

Array* initArray(Array *a) {
   a->array = malloc(ARRAYSIZE * sizeof(int));
   if(!a->array) {
      die("Could not allocate memory for array");
   }
   a->used = 0;
   a->size = ARRAYSIZE;
   return a;
}

void insertArray(Array *a, int element) {
   if (a->used == a->size) {
      a->size *= 2;
      a->array = realloc(a->array, a->size * sizeof(int));
      if(!a->array) {
         die("Could not reallocate memory for array");
      }
   }
   a->array[a->used++] = element;
}

int popArray(Array *a) {
   int ret = a->array[a->used];
   a->used--;
   return ret;
}

void removeAtArray(Array* a, int index) {
   if(index>a->used-1)
      return;
   int toRemove = index + 1 - a->used;
   Array tmpArray;
   initArray(&tmpArray);
   //insert into array
   for(int i=0; i<toRemove; ++i) {
      insertArray(&tmpArray, popArray(a));
   }
   //remove Element to be removed
   popArray(a);
   //re-insert elements
   for(int i=0; i<toRemove; ++i) {
      insertArray(a, popArray(&tmpArray));
   }
}

void freeArray(Array *a) {
   free(a->array);
   a->array = NULL;
   a->used = a->size = 0;
}

// --- functions --- //

typedef struct {
   int color;
   long x;
} Block;

//return 0 if done, exit on error, write result in struct and return 1 on success
int readInputLine(Block* block, FILE* inputFile) {
   char* line = NULL;
   int read = 0;
   size_t len = 0;

   //read one line
   read = getline(&line, &len, inputFile);
   //return on error/finish
   if(read<0) {
      return 0;
   }

   //check string for invalid chars
   for(int i=0; i<strlen(line); ++i) {
      if(!(isdigit(line[i])||line[i]=='-'||line[i]==' '||line[i]=='\n'||line[i]=='\r')) {
         char out[256];
         sprintf(out, "Invalid char in input: %c", line[i]);
         die(out);
      }
   }

   //parse color
   char* tmp;
   char* str = strtok(line, " ");
   if(str==NULL) {
      die("Error while reading color");
   }
   block->color = strtol(str, &tmp, 0);
   if(str==tmp) {
      //parsing error
      die("Error while parsing color");
   }
   if(block->color < 0 || block->color > 254) {
      //color out of range
      char out[256];
      sprintf(out, "Invalid color %i", block->color);
      die(out);
   }

   //parse x position
   str = strtok(NULL, " ");
   if(str==NULL) {
      die("Error while reading x position");
   }
   block->x = strtol(str, &tmp, 0);
   if(str == tmp) {
      //parsing error
      die("Error while parsing x position");
   }

   //return 1 on success
   return 1;
}

typedef struct _ListElement ListElement;
struct _ListElement {
   ListElement* next;
   Block* block;
};

NullableArray* Cols = NULL;
long size = 0;
long offset = 0;

void die(char* msg) {
   if(Cols!=NULL) {
      for(int i=0; i<size; ++i) {
         freeArray(Cols[i*sizeof(NullableArray)].array);
      }
      free(Cols);
   }
   perror(msg);
   char out[256];
   sprintf(out, "%s\n", msg);
   exit(-1);
}

int checkInDirection(int color, long startX, int startY, int dirX, int dirY) {
   long XtoCheck = startX + dirX;
   //edge of field
   if(XtoCheck < 0 || XtoCheck > size -1) {
      return 0;
   }
   Array* Column = Cols[XtoCheck*sizeof(NullableArray)].array;
   //unintitialized column
   if(!Column) {
      return 0;
   }
   int YtoCheck = startY + dirY;
   //out of bounds check for column
   if(Column->used<=YtoCheck||YtoCheck<0) {
      return 0;
   }
   //color not equal
   if(Column->array[YtoCheck]!=color) {
      return 0;
   }

   //if all conditions pass, check next field in given direction
   return checkInDirection(color, XtoCheck, YtoCheck, dirX, dirY) + 1;
}

void checkToRemove(long x, int y) {
   //get color at location
   Array* Column = Cols[x*sizeof(NullableArray)].array;
   int color = Column->array[y];

   //check downwards
   int down = checkInDirection(color,x,y,0,-1);

   //check left
   int left = checkInDirection(color,x,y,-1,0);
   //check right
   int right = checkInDirection(color,x,y,1,0);

   //check diagonal left-up
   int diagLeftUp = checkInDirection(color,x,y,-1,1);
   //check diagonal left-down
   int diagLeftDown = checkInDirection(color,x,y,-1,-1);
   //check diagonal right-up
   int diagRightUp = checkInDirection(color,x,y,1,1);
   //check diagonal right-down
   int diagRightDown = checkInDirection(color,x,y,1,-1);

   //keep track of how many blocks have been removed per row relative to current row (middle of array)
   int RemovedBlocksPerCol[2*ROW_LENGTH-1];
   for(int i=0; i<2*ROW_LENGTH-1; ++i)
      RemovedBlocksPerCol[i] = 0;

   //in the same manner, track the lowest index of removed blocks, to know which ones should be checked later
   int LowesetRemovedBlockPerCol[2*ROW_LENGTH-1];
   for(int i=0; i<2*ROW_LENGTH-1; ++i)
      LowesetRemovedBlockPerCol[i] = -1;

   //make sure the current block isn't removed twice
   int CurrentBlockRemoved = 0;

   //remove vertically
   if(down+1>=ROW_LENGTH) {
      printf("removing vert\n");
      while(down>0) {
         popArray(Column);
         down--;
      }
      removeAtArray(Cols[(x)*sizeof(NullableArray)].array, y);
      CurrentBlockRemoved = 1;
   }

   //remove horizontally
   if(left+right+1>=ROW_LENGTH) {
      printf("removing horiz\n");
      while(left>0) {
         removeAtArray(Cols[(x-left)*sizeof(NullableArray)].array, y);
         RemovedBlocksPerCol[x-left]++;
         LowesetRemovedBlockPerCol[x-left] = y;
         left--;
      }
      while(right>0) {
         removeAtArray(Cols[(x+right)*sizeof(NullableArray)].array, y);
         RemovedBlocksPerCol[x+right]++;
         LowesetRemovedBlockPerCol[x+right] = y;
         right--;
      }
      if(!CurrentBlockRemoved) {
         removeAtArray(Cols[(x)*sizeof(NullableArray)].array, y);
         CurrentBlockRemoved = 1;
      }
   }

   //remove diagonally, bottom left to upper right
   if(diagLeftDown + diagRightUp +1 >=ROW_LENGTH) {
      printf("removing diag1\n");
      while(diagLeftDown>0) {
         removeAtArray(Cols[(x-diagLeftDown)*sizeof(NullableArray)].array, y-diagLeftDown);
         RemovedBlocksPerCol[x-diagLeftDown]++;
         LowesetRemovedBlockPerCol[x-diagLeftDown] = y - diagLeftDown;
         diagLeftDown--;
      }
      while(diagRightUp>0) {
         removeAtArray(Cols[(x+diagRightUp)*sizeof(NullableArray)].array, y+diagRightUp-RemovedBlocksPerCol[x+diagRightUp]);
         RemovedBlocksPerCol[x+diagRightUp]++;
         if(LowesetRemovedBlockPerCol[x+diagRightUp]<0||LowesetRemovedBlockPerCol[x+diagRightUp]>y + diagRightUp)
            LowesetRemovedBlockPerCol[x+diagRightUp] = y + diagRightUp;
         diagRightUp--;
      }
      if(!CurrentBlockRemoved) {
         removeAtArray(Cols[(x)*sizeof(NullableArray)].array, y);
         CurrentBlockRemoved = 1;
      }
   }

   //remove diagonally, top left to bottom right
   if(diagLeftUp + diagRightDown +1 >=ROW_LENGTH) {
      printf("removing diag2\n");
      while(diagLeftUp>0) {
         removeAtArray(Cols[(x-diagLeftUp)*sizeof(NullableArray)].array, y+diagLeftUp-RemovedBlocksPerCol[x-diagLeftUp]);
         RemovedBlocksPerCol[x-diagLeftUp]++;
         if(LowesetRemovedBlockPerCol[x-diagLeftUp]<0||LowesetRemovedBlockPerCol[x-diagLeftUp]>y + diagLeftUp)
            LowesetRemovedBlockPerCol[x-diagLeftUp] = y + diagLeftUp;
         diagLeftUp--;
      }
      while(diagRightDown>0) {
         removeAtArray(Cols[(x+diagRightDown)*sizeof(NullableArray)].array, y-diagRightDown);
         RemovedBlocksPerCol[x+diagRightUp]++;
         LowesetRemovedBlockPerCol[x+diagRightDown] = y - diagRightDown;
         diagRightDown--;
      }
      if(!CurrentBlockRemoved) {
         removeAtArray(Cols[(x)*sizeof(NullableArray)].array, y);
         CurrentBlockRemoved = 1;
      }
   }

   //recursivly check moved blocks
   for(int i=0; i<2*ROW_LENGTH-1; ++i) {
      if(LowesetRemovedBlockPerCol[i]<0) {
         continue;
      }
      //get the right column
      long xPos = x + i - ROW_LENGTH+1;
      if(xPos<0||xPos>size) {
         continue;
      }
      Array* Column = Cols[xPos*sizeof(NullableArray)].array;
      //check each moved block in the column
      for(int j=LowesetRemovedBlockPerCol[i]; j<Column->used; ++j) {
         checkToRemove(xPos, j);
      }
   }
}

void printArrayState(long offset) {
   //x
   for(int i=0; i<size; ++i) {
      Array* Column = Cols[i*sizeof(NullableArray)].array;
      if(Column==NULL)
         continue;
      //y
      for(int j=0; j<Column->used; ++j) {
         printf("%i, %li, %i\n", j<Column->array[j], i-offset, j);
      }
   }
}

// --- main --- //

int main(int argc, char* argv[]) {

   FILE *inputFile;
   //open file from first arg if there is one
   if(argc>1) {
      printf("using file %s\n", argv[1]);
      inputFile = fopen(argv[1], "r");
      if(!inputFile) {
         die("Could not open file");
      }
   }
   //or read from stdin
   else {
      printf("using stdin\n");
      inputFile = stdin;
   }

   //init list
   ListElement* list = NULL;
   list = malloc(sizeof(ListElement));
   list->block = malloc(sizeof(Block));
   //store pointer to first element to go through list later
   ListElement* first = list;
   //long offset = 0;
   long max = 0;

   //reading loop
   while(readInputLine(list->block, inputFile)) {
      //store the smallest x in offset
      if(list->block->x < offset) {
         offset = list->block->x;
      }
      //store the largest x in max
      if(list->block->x > max) {
         max = list->block->x;
      }
      //build list
      ListElement* next = NULL;
      next = malloc(sizeof(ListElement));
      next->block = malloc(sizeof(Block));
      next->next = NULL;

      list->next = next;
      list = next;
   }
   if(errno) {
      die("Error while reading input");
   }

   offset = labs(offset);
   size = offset + max + 1;

   Cols = malloc(size * sizeof(NullableArray));
   if(!Cols) {
      die("Malloc for column array faild");
   }

   for(int i=0; i<size; ++i) {
      Cols[i*sizeof(NullableArray)].array = NULL;
   }

   while(first->next!=NULL) {
      Array* Column = Cols[(first->block->x + offset)*sizeof(NullableArray)].array;
      if(Column==NULL) {
         Array* ColStrct = malloc(sizeof(Array));
         Column = initArray(ColStrct);
         Cols[(first->block->x + offset)*sizeof(NullableArray)].array = Column;
      }
      insertArray(Column, first->block->color);
      checkToRemove(first->block->x + offset, Column->used-1);
      printArrayState(offset);
      printf("\n");
      first = first->next;
   }

   printArrayState(offset);

	return 0;
}
