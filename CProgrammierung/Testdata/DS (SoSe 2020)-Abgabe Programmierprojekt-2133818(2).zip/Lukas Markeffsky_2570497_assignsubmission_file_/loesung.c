/*
    conditional compilation:
    - NDEBUG: If this is NOT defined additional checks and unit tests (see below) are enabled.
    - DUMP_GRAPHICAL: Writes a graphical representation of the board to stderr after every step of the simulation.
    - SLOW_IO: Use `printf` and `scanf` instead of the custom `reader` and `writer` types. (for performance benchmarks)
*/

#include <stdlib.h> // malloc, free, size_t, NULL
#include <stddef.h> // ptrdiff_t
#include <stdint.h> // SIZE_MAX, PTRDIFF_MAX
#include <string.h> // memset, memcpy
#include <stdio.h> // fread, fwrite
#include <stdbool.h> // bool
#include <assert.h> // assert
#include <limits.h> // CHAR_BIT


///// util /////

// Stuff that doesn't fit anywhere else.

// log2(10)
#define LOG2_10 3.321928094887362347870319429489390175864831393024580612054756395815934776608625215850139743359370155

// An upper bound the for the number of digits in decimal representation of an integer type.
// The actual number of digits of the maximun value may be less.
// For signed numbers add 1 for '-'.
// log10(max) = log2(max) / log2(10) = bit_count / log2(10)
#define DECIMAL_DIGITS_UPPER_BOUND(type) (size_t)((double)sizeof(type) * CHAR_BIT / LOG2_10 + 1)

#define MAX(a, b) (((a) > (b)) ? (a) : (b))

// Returns whether the character is a decimal digit ('0'..'9').
bool is_digit(char c) {
    // the digits are always ordered, even if `char` is not an ASCII character (cf. 5.2.1p3)
    return c >= '0' && c <= '9';
}


///// color /////

// An integer type that represents a color or the special value `COLOR_NONE`.

#define COLOR_NONE 255
#define COLOR_MAX 254
#define COLOR_FORMAT "hhu"
typedef unsigned char color;

// Fill an array of `color` with `COLOR_NONE`.
void color_array_fill_none(color *array, size_t count) {
    // this is ok, because `color` has the same representation as `unsigned char`
    memset(array, COLOR_NONE, count);
}


///// coord /////

// A pair of coordinates.
// The x coordinate is signed, the y coordinate is unsigned.

// `X_COORD_MAX - X_COORD_MIN + 1` must fit in `size_t` (because `width == x_upper_bound - x_lower_bound + 1`)
// note that `SIZE_MAX / 2 * 2 + 1 == SIZE_MAX`, because `SIZE_MAX` must be odd (cf. representation of unsigned integers, 6.2.6.2p1)
#if PTRDIFF_MAX <= (SIZE_MAX / 2)
#   define X_COORD_MAX PTRDIFF_MAX
#else
#   define X_COORD_MAX ((ptrdiff_t)(SIZE_MAX / 2))
#endif
#define X_COORD_MIN (-X_COORD_MAX)
#define X_COORD_FORMAT "td"
typedef ptrdiff_t x_coord;

// `Y_COORD_MAX + 1` must fit in `size_t` (because `height == y_upper_bound + 1`)
#define Y_COORD_MAX (SIZE_MAX - 1)
#define Y_COORD_FORMAT "zu"
typedef size_t y_coord;

typedef struct coord {
    x_coord x;
    y_coord y;
} coord;

// Creates a new pair coordinates from a single x and y coordinate.
coord coord_new(x_coord x, y_coord y) {
    coord result = { x, y };
    return result;
}


///// board /////

// A 2D array of colors.

#define BOARD_DEFAULT_WIDTH 16
#define BOARD_DEFAULT_HEIGHT 8
#define BOARD_DEFAULT_X_OFFSET 8 // must be less than `BOARD_DEFAULT_WIDTH`

// size += size / divisor
#define BOARD_HEIGHT_INCREASE_DIVISOR 2
#define BOARD_WIDTH_INCREASE_DIVISOR 4
#define BOARD_X_OFFSET_INCREASE_DIVISOR 4

typedef struct board {
    // usage: `fields[(size_t)x + x_offset + y * width]`
    // This works because casting a negative signed value (`x_coord`) to unsigned type (`size_t`) is done by
    // adding one more than the maximum representable value of the new type (cf. 6.3.1.3p2)
    // and unsigned integer arithmetic will always silently wrap (overflow) (cf. H.2.2p1).
    // The length of this array is always `width * height`.
    color *fields;

    // The y-coordinate one above the highest colored field in each column, or `0` if the column is empty.
    // The length of this array is always `width`.
    y_coord *top_of_column;

    // `x_offset` is always less than `width` and less than or equal to `X_COORD_MAX` (and `-X_COORD_MIN`).
    size_t width, height, x_offset;
} board;

// Constructs a new board and initializes it with default values.
// Returns false if memory is full. In that case calling any function on the board causes undefined behavior.
bool board_construct(board *b) {
    b->width = BOARD_DEFAULT_WIDTH;
    b->height = BOARD_DEFAULT_HEIGHT;
    b->x_offset = BOARD_DEFAULT_X_OFFSET;
    
    b->fields = (color *)malloc(b->width * b->height * sizeof(color));
    if (b->fields == NULL) return false;

    b->top_of_column = (y_coord *)malloc(b->width * sizeof(y_coord));
    if (b->top_of_column == NULL) {
        free(b->fields);
        return false;
    }

    color_array_fill_none(b->fields, b->width * b->height);

    // all bits set to zero represent the value 0 of any integer type (cf. 6.2.6.2p5)
    memset(b->top_of_column, 0, b->width * sizeof(y_coord));
    return true;
}

// Frees all resources used by the board. Do not use it after calling this function.
void board_destruct(board *b) {
    free(b->fields);
    free(b->top_of_column);
}

// Returns the lowest allowed x-coordinate.
x_coord board_get_x_lower_bound(const board *b) {
    return -(x_coord)b->x_offset;
}

// Returns the highest allowed x-coordinate.
x_coord board_get_x_upper_bound(const board *b) {
    return (x_coord)(b->width - b->x_offset - 1);
}

// Returns the highest allowed y-coordinate.
y_coord board_get_y_upper_bound(const board *b) {
    return (y_coord)(b->height - 1);
}

// Returns the color of a field on the board.
// Causes undefined behavior if the field is out of bounds.
color board_get_field(const board *b, coord coord) {
    assert(coord.x >= board_get_x_lower_bound(b));
    assert(coord.x <= board_get_x_upper_bound(b));
    assert(coord.y <= board_get_y_upper_bound(b));

    return b->fields[(size_t)coord.x + b->x_offset + coord.y * b->width];
}

// Sets the color of a field on the board.
// Causes undefined behavior if the field is out of bounds.
void board_set_field(board *b, coord coord, color color) {
    assert(coord.x >= board_get_x_lower_bound(b));
    assert(coord.x <= board_get_x_upper_bound(b));
    assert(coord.y <= board_get_y_upper_bound(b));

    b->fields[(size_t)coord.x + b->x_offset + coord.y * b->width] = color;
}

// Returns the y-coordinate one above the highest colored field for a given column, or `0` if the column is empty.
// This value is not determined automatically and must be manually set with `board_set_top_of_column` or `board_clear_top_of_column`.
// Causes undefined behavior if the x-coordinate is out of bounds.
y_coord board_get_one_above_top_of_column(const board *b, x_coord x) {
    assert(x >= board_get_x_lower_bound(b));
    assert(x <= board_get_x_upper_bound(b));

    return b->top_of_column[(size_t)x + b->x_offset];
}

// Sets the coordinates of the highest colored field in a column.
// Causes undefined behavior if the field is out of bounds.
void board_set_top_of_column(const board *b, coord coord) {
    assert(coord.x >= board_get_x_lower_bound(b));
    assert(coord.x <= board_get_x_upper_bound(b));
    assert(coord.y <= board_get_y_upper_bound(b));

    b->top_of_column[(size_t)coord.x + b->x_offset] = coord.y + 1;
}

// Returns whether a field is the highest colored field in its column.
// Causes undefined behavior if the field is out of bounds.
bool board_is_top_of_column(const board *b, coord coord) {
    assert(coord.x >= board_get_x_lower_bound(b));
    assert(coord.x <= board_get_x_upper_bound(b));
    assert(coord.y <= board_get_y_upper_bound(b));

    return b->top_of_column[(size_t)coord.x + b->x_offset] == coord.y + 1;
}

// Clears the top-of-column value of the given column. This indicates that the column is empty.
// Causes undefined behavior if the x-coordinate is out of bounds.
void board_clear_top_of_column(const board *b, x_coord x) {
    assert(x >= board_get_x_lower_bound(b));
    assert(x <= board_get_x_upper_bound(b));

    b->top_of_column[(size_t)x + b->x_offset] = 0;
}


// Changes the board size. The new size must be greater than the old size.
// Returns false if memory is full.
bool board_resize(board *b, size_t width, size_t height, size_t x_offset) {
    assert(width >= b->width);
    assert(height >= b->height);
    assert(x_offset >= b->x_offset);

    assert(width > x_offset);

    assert(x_offset <= X_COORD_MAX);
    assert(width - x_offset - 1 <= X_COORD_MAX);
    assert(height - 1 <= Y_COORD_MAX);

    if (   width != width * height * sizeof(color) / height / sizeof(color)
        || width != width * sizeof(y_coord) / sizeof(y_coord) 
    ){
        // `width * height * sizeof(color)` or `width * sizeof(y_coord)` will overflow `size_t` and won't fit in memory
        return false;
    }

    color *new_fields = (color *)malloc(width * height * sizeof(color));
    if (new_fields == NULL) return false;

    if (width == b->width) {
        // width unchanged, the first bytes of `b->fields` will stay the same
        const size_t old_field_count = b->width * b->height;
        memcpy(new_fields, b->fields, old_field_count * sizeof(color));

        // fill the new fields with `COLOR_NONE`
        color_array_fill_none(new_fields + old_field_count, width * height - old_field_count);
    } else {
        y_coord *new_top_of_column = (y_coord *)malloc(width * sizeof(y_coord));
        if (new_top_of_column == NULL) {
            free(new_fields);
            return false;
        }

        {
            // width increased, fill the new bytes (left/right) with `COLOR_NONE`, and copy the old ones (center)
            const size_t left_new_count = x_offset - b->x_offset;
            const size_t right_new_count = width - b->width - left_new_count;
            
            color *dest = new_fields;
            const color *src = b->fields;
            while (src != b->fields + b->width * b->height) {
                color_array_fill_none(dest, left_new_count);
                dest += left_new_count;

                memcpy(dest, src, b->width * sizeof(color));
                dest += b->width;
                src += b->width;

                color_array_fill_none(dest, right_new_count);
                dest += right_new_count;
            }


            // at the top of the new board there is nothing to copy, fill everything left with `COLOR_NONE`
            color_array_fill_none(dest, width * (height - b->height));
        }

        {
            // fill `new_top_of_column`, too
            const size_t left_new_count = x_offset - b->x_offset;
            const size_t right_new_count = width - b->width - left_new_count;
            y_coord *dest = new_top_of_column;

            memset(dest, 0, left_new_count * sizeof(y_coord));
            dest += left_new_count;
            
            memcpy(dest, b->top_of_column, b->width * sizeof(y_coord));
            dest += b->width;
            
            memset(dest, 0, right_new_count * sizeof(y_coord));
        }

        free(b->top_of_column);
        b->top_of_column = new_top_of_column;
    }

    free(b->fields);
    b->fields = new_fields;
    b->width = width;
    b->height = height;
    b->x_offset = x_offset;
    return true;
}

// Increases the board height by at least 1.
// Returns false if memory is full.
bool board_increase_height(board *b) {
    size_t new_height = b->height + b->height / BOARD_HEIGHT_INCREASE_DIVISOR;
    if (new_height > Y_COORD_MAX + 1) {
        new_height = Y_COORD_MAX + 1;
    }
    if (new_height <= b->height) {
        // integer overflow or we are at max height already
        return false;
    }
    return board_resize(b, b->width, new_height, b->x_offset);
}

// Sets the lower bound for x-coordinates. The new value must be smaller than the old value.
// Returns false if memory is full.
bool board_set_x_lower_bound(board *b, x_coord x_lower_bound) {
    assert(x_lower_bound < board_get_x_lower_bound(b));
    assert(x_lower_bound >= X_COORD_MIN);

    size_t new_x_offset = MAX((size_t)-x_lower_bound, b->x_offset + b->x_offset / BOARD_X_OFFSET_INCREASE_DIVISOR);
    if (new_x_offset > X_COORD_MAX) {
        new_x_offset = X_COORD_MAX;
    }
    if (new_x_offset <= b->x_offset) {
        // integer overflow or we are at min lower bound already
        return false;
    }
    size_t new_width = b->width + (size_t)(new_x_offset - b->x_offset);
    return board_resize(b, new_width, b->height, new_x_offset);
}

// Sets the upper bound for x-coordinates. The new value must be larger than the old value.
// Returns false if memory is full.
bool board_set_x_upper_bound(board *b, x_coord x_upper_bound) {
    assert(x_upper_bound > board_get_x_upper_bound(b));
    assert(x_upper_bound <= X_COORD_MAX);

    size_t new_width = MAX((size_t)x_upper_bound + b->x_offset + 1, b->width + b->width / BOARD_WIDTH_INCREASE_DIVISOR);
    if (new_width > b->x_offset + X_COORD_MAX + 1) {
        new_width = b->x_offset + X_COORD_MAX + 1;
    }
    if (new_width <= b->width) {
        // integer overflow or we are at max upper bound already
        return false;
    }
    return board_resize(b, new_width, b->height, b->x_offset);
}

#ifdef DUMP_GRAPHICAL

// Writes a graphical representation of the board to stderr.
// For debug purposes only.
void board_dump_graphical(const board *b) {
    const x_coord x_lower_bound = board_get_x_lower_bound(b);
    const x_coord x_upper_bound = board_get_x_upper_bound(b);
    const y_coord y_upper_bound = board_get_y_upper_bound(b);
    coord coord;
    for (coord.y = y_upper_bound;; --coord.y) {
        for (coord.x = x_lower_bound; coord.x <= x_upper_bound; ++coord.x) {
            color color = board_get_field(b, coord);
            if (color == COLOR_NONE) {
                fprintf(stderr, "  ");
            } else {
                fprintf(stderr, "%2" COLOR_FORMAT, color);
            }
        }
        fputc('\n', stderr);
        if (coord.y == 0) break;
    }
    for (coord.x = x_lower_bound; coord.x <= x_upper_bound; ++coord.x) {
        if (coord.x < 0) {
            fprintf(stderr, "--");
        } else if (coord.x > 0) {
            fprintf(stderr, "++");
        } else {
            fprintf(stderr, "00");
        }
    }
    fputc('\n', stderr);
}

#endif


///// coord vector /////

// A dynamic array of coordinates.

#define COORD_VECTOR_DEFAULT_CAPACITY 16

// cap += cap / divisor
#define COORD_VECTOR_CAPACITY_INCREASE_DIVISOR 4

typedef struct coord_vector {
    coord *data;
    size_t size;
    size_t capacity;
} coord_vector;


// Constructs a new coordinate vector.
// Returns false if memory is full. In that case calling any function on the coord vector causes undefined behavior.
bool coord_vector_construct(coord_vector *v) {
    v->size = 0;
    v->capacity = COORD_VECTOR_DEFAULT_CAPACITY;
    v->data = (coord *)malloc(COORD_VECTOR_DEFAULT_CAPACITY * sizeof(coord));
    return v->data != NULL;
}

// Frees all resources used by the vector. Do not use it after calling this function.
void coord_vector_destruct(coord_vector *v) {
    free(v->data);
}

// Returns whether the vector is empty.
bool coord_vector_is_empty(const coord_vector *v) {
    return v->size == 0;
}

// Returns a pointer to the first element in the vector.
// Used in combination with `coord_vector_end` to iterate over all elements of the vector.
coord *coord_vector_begin(coord_vector *v) {
    return v->data;
}

// Returns a pointer to one after the last element in the vector.
// Used in combination with `coord_vector_begin` to iterate over all elements of the vector.
coord *coord_vector_end(coord_vector *v) {
    return v->data + v->size;
}

// Inserts a coordinate at the end of the vector.
// Returns false if memory is full.
bool coord_vector_push(coord_vector *v, coord value) {
    if (v->size < v->capacity) {
        v->data[v->size] = value;
        ++v->size;
        return true;
    } else {
        size_t new_capacity = v->capacity + v->capacity / COORD_VECTOR_CAPACITY_INCREASE_DIVISOR;
        if (new_capacity <= v->capacity || new_capacity != new_capacity * sizeof(coord) / sizeof(coord)) {
            // integer overflow, new capacity won't fit in memory
            return false;
        }
        coord *new_data = (coord *)realloc(v->data, new_capacity * sizeof(coord));
        if (new_data == NULL) {
            return false;
        } else {
            v->data = new_data;
            v->capacity = new_capacity;
            v->data[v->size] = value;
            ++v->size;
            return true;
        }
    }
}

// Removes the last coordinate from the vector.
// Returns false if the vector is empty.
bool coord_vector_pop(coord_vector *v, coord *coord) {
    if (v->size == 0) return false;
    --v->size;
    *coord = v->data[v->size];
    return true;
}


///// reader /////

// Utilities for reading values from stdin.
// Because `scanf` is slow.

#define READER_BUFFER_CAPACITY 256

typedef struct reader {
    // offset in `buffer`, `end` is after the last byte
    size_t begin, end;

    char buffer[READER_BUFFER_CAPACITY];
} reader;

// Constructs a new reader. The reader doesn't have a destructor.
void reader_construct(reader *r) {
    r->begin = 0;
    r->end = 0;
}

// Returns a pointer to the internal buffer.
const char *reader_buffer(const reader *r) {
    return r->buffer + r->begin;
}

// Returns the number of bytes available in the internal buffer.
size_t reader_available(const reader *r) {
    return r->end - r->begin;
}

// Remove `count` bytes from the front of the internal buffer.
// Causes undefined behavior if `count` exceeds `reader_available(r)`.
void reader_consume(reader *r, size_t count) {
    assert(count <= reader_available(r));
    r->begin += count;
}

// Assures that there are at least `count` bytes in the buffer.
// If more bytes are required, move the remaining bytes to the start of the buffer,
// then try to read more bytes from stdin into the buffer.
// `count` must be less than or equal to `READER_BUFFER_CAPACITY`.
// Returns false, if there are not enough bytes left (EOF).
bool reader_fill_buffer(reader *r, size_t count) {
    assert(count <= READER_BUFFER_CAPACITY);

    const size_t available = reader_available(r);
    if (available >= count) return true;
    
    memmove(r->buffer, reader_buffer(r), available);
    r->begin = 0;
    r->end = available + fread(r->buffer + available, 1, READER_BUFFER_CAPACITY - available, stdin);
    return reader_available(r) >= count;
}

// Peeks the next character from the stream without removing it.
// Returns false at the end of stream.
bool reader_peek_char(reader *r, char *output) {
    if (reader_fill_buffer(r, 1)) {
        *output = reader_buffer(r)[0];
        return true;
    } else {
        return false;
    }
}

// Reads the next character from the stream.
// Returns false at the end of stream.
bool reader_get_char(reader *r, char *output) {
    if (reader_peek_char(r, output)) {
        reader_consume(r, 1);
        return true;
    } else {
        return false;
    }
}

// Removes a specific character from the front of stream.
// Returns false if that character is not there.
bool reader_has_char(reader *r, char expected) {
    char next_char;
    if (reader_peek_char(r, &next_char) && next_char == expected) {
        reader_consume(r, 1);
        return true;
    } else {
        return false;
    }
}

// Removes a newline ("\r\n" or "\n") from the front of stream.
// Returns false if there is no newline there.
bool reader_has_newline(reader *r) {
    if (reader_has_char(r, '\n')) {
        return true;
    } else if (reader_fill_buffer(r, 2) && reader_buffer(r)[0] == '\r' && reader_buffer(r)[1] == '\n') {
        reader_consume(r, 2);
        return true;
    } else {
        return false;
    }
}

// Returns whether the stream is at end-of-file (no bytes left to read).
bool reader_has_eof(reader *r) {
    return !reader_fill_buffer(r, 1);
}

// Reads an integer from the stream.
// Returns false, if
//   - there are no bytes left in the stream (EOF)
//   - the the next value is not an integer
//   - the next value does not fit into the specific integer type
#define READER_DEFINE_GET_INTEGER(identifier, type, min_value, max_value) \
bool identifier(reader *r, type *output) { \
    if (!reader_fill_buffer(r, 2)) { \
        char next_char; \
        if (reader_peek_char(r, &next_char) && is_digit(next_char)) { \
            /* single digit */ \
            reader_consume(r, 1); \
            *output = (type)(next_char - '0'); \
            return true; \
        } else { \
            /* EOF or single char that is not a digit */ \
            return false; \
        } \
    } \
    \
    const char *read_begin = reader_buffer(r); \
    const char *read_ptr = read_begin; \
    const char *read_end = read_begin + reader_available(r); \
    \
    const bool is_negative = min_value < 0 && *read_ptr == '-'; \
    if (is_negative) { \
        ++read_ptr; \
    } \
    \
    if (!is_digit(*read_ptr)) return false; \
    \
    type n = (type)(*read_ptr - '0'); \
    if (is_negative) { \
        n = -n; \
    } \
    ++read_ptr; \
    \
    for (;;) { \
        if (read_ptr == read_end) { \
            /* no more bytes in buffer */ \
            size_t index = (size_t)(read_end - read_begin); \
            if (index == READER_BUFFER_CAPACITY) { \
                /* lots of leading zeroes, consume some of them */\
                reader_consume(r, READER_BUFFER_CAPACITY / 2); \
                index /= 2; \
            } \
            if (!reader_fill_buffer(r, index + 1)) { \
                /* we're at EOF */ \
                break; \
            } \
            read_begin = reader_buffer(r); \
            read_ptr = read_begin + index; \
            read_end = read_begin + reader_available(r); \
        } \
        if (!is_digit(*read_ptr)) { \
            /* next character is not a digit*/ \
            break; \
        } \
        type next_digit = (type)(*read_ptr - '0'); \
        if (is_negative) { \
            next_digit = -next_digit; \
        } \
        if (   n > max_value / 10 \
            || n < min_value / 10 \
            || (n == max_value / 10 && next_digit > max_value % 10) \
            || (n == min_value / 10 && next_digit < min_value % 10) \
        ) { \
            /* next character is a digit, but will overflow `n` */ \
            return false; \
        } else {\
            /* next character is a digit and doesn't overflow `n` */ \
            n = n * 10 + next_digit; \
            ++read_ptr; \
        } \
    } \
    \
    *output = n; \
    reader_consume(r, read_ptr - read_begin); \
    return true; \
}

#ifdef __GNUC__
#   pragma GCC diagnostic push
#   pragma GCC diagnostic ignored "-Wtype-limits" // unsigned integer < 0 is always false
#endif

READER_DEFINE_GET_INTEGER(reader_get_color, color, 0, COLOR_MAX)
READER_DEFINE_GET_INTEGER(reader_get_x_coord, x_coord, X_COORD_MIN, X_COORD_MAX)

#ifdef __GNUC__
#   pragma GCC diagnostic pop
#endif


///// writer /////

// Utilities for writing values to stdout.
// Because `printf` is slow, too.

#define WRITER_BUFFER_CAPACITY 256

typedef struct writer {
    // number of bytes currently stored in the buffer, not total buffer size (= capacity)
    size_t buffer_size;
    char buffer[WRITER_BUFFER_CAPACITY];
} writer;

// Constructs a new writer. The writer doesn't have a destructor.
void writer_construct(writer *w) {
    w->buffer_size = 0;
}

// Writes the internal buffer to stdout.
// Returns false on I/O error.
bool writer_flush(writer *w) {
    if (w->buffer_size != fwrite(w->buffer, 1, w->buffer_size, stdout)) {
        // I/O error while writing to stdout.
        return false;
    }
    w->buffer_size = 0;
    return true;
}

// Reserves enough space for at least `count` bytes in the internal buffer.
// This is done by flushing the buffer if necessary.
// `count` must be less than or equal to `WRITER_BUFFER_CAPACITY`.
// Returns false on I/O error.
bool writer_reserve(writer *w, size_t count) {
    assert(count <= WRITER_BUFFER_CAPACITY);
    if (w->buffer_size + count > WRITER_BUFFER_CAPACITY) {
        return writer_flush(w);
    } else {
        return true;
    }
}

// Writes a single character to the stream.
// Returns false on I/O error.
bool writer_put_char(writer *w, char c) {
    if (!writer_reserve(w, 1)) return false;
    w->buffer[w->buffer_size] = c;
    ++w->buffer_size;
    return true;
}

// Writes any data to the stream.
// `count` must be less than or equal to `WRITER_BUFFER_CAPACITY`.
// Returns false on I/O error.
bool writer_put_data(writer *w, const void *data, size_t count) {
    if (!writer_reserve(w, count)) return false;
    memcpy(w->buffer + w->buffer_size, data, count);
    w->buffer_size += count;
    return true;
}

// Writes an integer to the stream.
// Returns false on I/O error.
#define WRITER_DEFINE_PUT_INTEGER(identifier, type) \
bool identifier(writer *w, type value) { \
    if (value < 0 && !writer_put_char(w, '-')) return false; \
    char buffer[DECIMAL_DIGITS_UPPER_BOUND(type)]; \
    size_t digits = 0; \
    do { \
        type next_digit = value % 10; \
        value /= 10; \
        if (next_digit < 0) { \
            next_digit = -next_digit; \
            value = -value; \
        } \
        buffer[DECIMAL_DIGITS_UPPER_BOUND(type) - digits - 1] = (char)next_digit + '0'; \
        ++digits; \
    } while (value != 0); \
    return writer_put_data(w, buffer + DECIMAL_DIGITS_UPPER_BOUND(type) - digits, digits); \
}

#ifdef __GNUC__
#   pragma GCC diagnostic push
#   pragma GCC diagnostic ignored "-Wtype-limits" // unsigned integer < 0 is always false
#endif

WRITER_DEFINE_PUT_INTEGER(writer_put_color, color)
WRITER_DEFINE_PUT_INTEGER(writer_put_y_coord, y_coord)
WRITER_DEFINE_PUT_INTEGER(writer_put_x_coord, x_coord)

#ifdef __GNUC__
#   pragma GCC diagnostic pop
#endif


///// error /////

// Utilities for error reporting.

// Copys a token from the reader to stderr for error diagnosis.
// A "token" is ' ', '\r', '\n', EOF or any string terminated by one of those.
void error_copy_token_to_stderr(reader *r) {
    char c;
    if (!reader_get_char(r, &c)) {
        fprintf(stderr, "end-of-file");
        return;
    } else if (c == ' ') {
        fprintf(stderr, "' '");
        return;
    } else if (c == '\r') {
        fprintf(stderr, "carriage-return");
        return;
    } else if (c == '\n') {
        fprintf(stderr, "line-feed");
        return;
    } else {
        // any sequence of characters terminated by ' ', '\r', '\n', or EOF
        fputc('\'', stderr);
        fputc(c, stderr);
        while (reader_peek_char(r, &c) && c != ' ' && c != '\r' && c != '\n') {
            reader_consume(r, 1);
            fputc(c, stderr);
        }
        fputc('\'', stderr);
    }
}

// For when there is not enough memory.
void error_out_of_memory() {
    fprintf(stderr, "Out of memory.\n");
}

// For when there is an I/O error while writing to stdout.
void error_stdout_io() {
    fprintf(stderr, "I/O error while writing to stdout.\n");
}

// For when a color is exprected, but something else is found.
void error_bad_color(reader *r) {
    fprintf(stderr, "Bad input: Expected color (0..%" COLOR_FORMAT "), got ", COLOR_MAX);
    error_copy_token_to_stderr(r);
    fprintf(stderr, " instead.\n");
}

// For when a space is exprected, but something else is found.
void error_bad_space(reader *r) {
    fprintf(stderr, "Bad input: Expected ' ', got ");
    error_copy_token_to_stderr(r);
    fprintf(stderr, " instead.\n");
}

// For when a `x_coord` is exprected, but something else is found.
void error_bad_x_coord(reader *r) {
    fprintf(stderr, "Bad input: Expected x coordinate (%" X_COORD_FORMAT "..%" X_COORD_FORMAT "), got ", X_COORD_MIN, X_COORD_MAX);
    error_copy_token_to_stderr(r);
    fprintf(stderr, " instead.\n");
}

// For when a newline or end-of-file is exprected, but something else is found.
void error_bad_newline_or_eof(reader *r) {
    fprintf(stderr, "Bad input: Expected newline or end-of-file, got ");
    error_copy_token_to_stderr(r);
    fprintf(stderr, " instead.\n");
}


///// simulation /////

// The main functionality of the program.
// Entry point is `run_simulation`.


// Reads a (color, x_coord)-tuple from the reader.
// Prints an error and returns false if the input format is invalid.
bool simulation_read_input(reader *reader, color *color, x_coord *x_coord) {
#ifdef SLOW_IO
    // unused parameter
    (void)reader;

    // this will accept some inputs that are not allowed (different whitespaces, unary '+', ...),
    // but `SLOW_IO` is just for testing purposes anyway
    if (2 != scanf("%" COLOR_FORMAT " %" X_COORD_FORMAT "\n", color, x_coord) || *color > COLOR_MAX || *x_coord < X_COORD_MIN || *x_coord > X_COORD_MAX) {
        fprintf(stderr, "Bad input.\n");
        return false;
    }
#else
    if (!reader_get_color(reader, color)) {
        error_bad_color(reader);
        return false;
    }
    if (!reader_has_char(reader, ' ')) {
        error_bad_space(reader);
        return false;
    }

    // consume additional spaces
    while (reader_has_char(reader, ' '));

    if (!reader_get_x_coord(reader, x_coord)) {
        error_bad_x_coord(reader);
        return false;
    }
    if (!reader_has_newline(reader) && !reader_has_eof(reader)) {
        error_bad_newline_or_eof(reader);
        return false;
    }
#endif
    return true;
}

// Reads a color and position from stdin and inserts the color into the board and `inserted_coords`.
// Returns false if any error is encountered.
bool simulation_insert_new_color(reader *reader, board *board, coord_vector *inserted_coords) {
    // read a color and position
    color new_color;
    coord new_color_coord;
    if (!simulation_read_input(reader, &new_color, &new_color_coord.x)) return false;

    // extend x bounds if necessary
    if (new_color_coord.x < board_get_x_lower_bound(board)) {
        if (!board_set_x_lower_bound(board, new_color_coord.x)) {
            error_out_of_memory();
            return false;
        }
    } else if (new_color_coord.x > board_get_x_upper_bound(board)) {
        if (!board_set_x_upper_bound(board, new_color_coord.x)) {
            error_out_of_memory();
            return false;
        }
    }

    // get the top of the column
    new_color_coord.y = board_get_one_above_top_of_column(board, new_color_coord.x);

    // extend height if necessary
    if (new_color_coord.y > board_get_y_upper_bound(board) && !board_increase_height(board)) {
        error_out_of_memory();
        return false;
    }

    // insert the color into the board and `inserted_coords`
    board_set_field(board, new_color_coord, new_color);
    if (!coord_vector_push(inserted_coords, new_color_coord)) {
        error_out_of_memory();
        return false;
    }

    // update the top-of-column value
    board_set_top_of_column(board, new_color_coord);

    return true;
}

// Removes groups of 4 of the same color from the board and inserts their coordinates into `removed_coords`.
// Only checks colors that are adjacent to coordinates in `inserted_coords`.
// Returns false if any error is encountered.
bool simulation_remove_groups(board *board, coord_vector *inserted_coords, coord_vector *removed_coords) {
    const x_coord x_lower_bound = board_get_x_lower_bound(board);
    const x_coord x_upper_bound = board_get_x_upper_bound(board);
    const y_coord y_upper_bound = board_get_y_upper_bound(board);
    coord inserted_coord;

    while (coord_vector_pop(inserted_coords, &inserted_coord)) {
        const color inserted_color = board_get_field(board, inserted_coord);

        // find begin and end of the row, column, and diagonals with the same color

        // row (-)
        x_coord row_begin = inserted_coord.x;
        while (
            row_begin > x_lower_bound
            && board_get_field(board, coord_new(row_begin - 1, inserted_coord.y)) == inserted_color
        ) {
            --row_begin;
        }
        x_coord row_end = inserted_coord.x;
        while (
            row_end < x_upper_bound
            && board_get_field(board, coord_new(row_end + 1, inserted_coord.y)) == inserted_color
        ) {
            ++row_end;
        }

        // column (|)
        y_coord column_begin = inserted_coord.y;
        while (
            column_begin > 0
            && board_get_field(board, coord_new(inserted_coord.x, column_begin - 1)) == inserted_color
        ) {
            --column_begin;
        }
        y_coord column_end = inserted_coord.y;
        while (
            column_end < y_upper_bound
            && board_get_field(board, coord_new(inserted_coord.x, column_end + 1)) == inserted_color
        ) {
            ++column_end;
        }

        // main diagonal (/)
        coord main_diagonal_begin = inserted_coord;
        while (
            main_diagonal_begin.x > x_lower_bound
            && main_diagonal_begin.y > 0
            && board_get_field(board, coord_new(main_diagonal_begin.x - 1, main_diagonal_begin.y - 1)) == inserted_color
        ) {
            --main_diagonal_begin.x;
            --main_diagonal_begin.y;
        }
        coord main_diagonal_end = inserted_coord;
        while (
            main_diagonal_end.x < x_upper_bound
            && main_diagonal_end.y < y_upper_bound
            && board_get_field(board, coord_new(main_diagonal_end.x + 1, main_diagonal_end.y + 1)) == inserted_color
        ) {
            ++main_diagonal_end.x;
            ++main_diagonal_end.y;
        }

        // anti diagonal (\)
        coord anti_diagonal_begin = inserted_coord;
        while (
            anti_diagonal_begin.x > x_lower_bound
            && anti_diagonal_begin.y < y_upper_bound
            && board_get_field(board, coord_new(anti_diagonal_begin.x - 1, anti_diagonal_begin.y + 1)) == inserted_color
        ) {
            --anti_diagonal_begin.x;
            ++anti_diagonal_begin.y;
        }
        coord anti_diagonal_end = inserted_coord;
        while (
            anti_diagonal_end.x < x_upper_bound
            && anti_diagonal_end.y > 0
            && board_get_field(board, coord_new(anti_diagonal_end.x + 1, anti_diagonal_end.y - 1)) == inserted_color
        ) {
            ++anti_diagonal_end.x;
            --anti_diagonal_end.y;
        }

        // clear the row/column/diagonal if there are at least 4 fields with the same color
        // if end - begin == 3, then there are 4 in that row/column/diagonal

        // row (-)
        if (row_end - row_begin >= 3) {
            for (coord coord = { row_begin, inserted_coord.y }; coord.x <= row_end; ++coord.x) {
                if (!coord_vector_push(removed_coords, coord)) {
                    error_out_of_memory();
                    return false;
                }
            }
        }

        // column (|)
        if (column_end - column_begin >= 3) {
            for (coord coord = { inserted_coord.x, column_begin }; coord.y <= column_end; ++coord.y) {
                if (!coord_vector_push(removed_coords, coord)) {
                    error_out_of_memory();
                    return false;
                }
            }
        }

        // main diagonal (/)
        if (main_diagonal_end.x - main_diagonal_begin.x >= 3) {
            for (coord coord = main_diagonal_begin; coord.x <= main_diagonal_end.x; ++coord.x, ++coord.y) {
                if (!coord_vector_push(removed_coords, coord)) {
                    error_out_of_memory();
                    return false;
                }
            }
        }

        // anti diagonal (\)
        if (anti_diagonal_end.x - anti_diagonal_begin.x >= 3) {
            for (coord coord = anti_diagonal_begin; coord.x <= anti_diagonal_end.x; ++coord.x, --coord.y) {
                if (!coord_vector_push(removed_coords, coord)) {
                    error_out_of_memory();
                    return false;
                }
            }
        }
    }

    for (coord *iter = coord_vector_begin(removed_coords); iter != coord_vector_end(removed_coords); ++iter) {
        board_set_field(board, *iter, COLOR_NONE);
    }

    return true;
}


// Makes the colors "drop down" in the board and insert any coordinates where a field was filled into `inserted_coords`.
// Only checks fields that are directly above coordinates in `removed_coords`.
// Returns false if any error is encountered.
bool simulation_drop(board *board, coord_vector *inserted_coords, coord_vector *removed_coords) {
    const y_coord y_upper_bound = board_get_y_upper_bound(board);
    coord current_coord;
    while (coord_vector_pop(removed_coords, &current_coord)) {
        if (COLOR_NONE != board_get_field(board, current_coord)) {
            // the field was filled in previous iteration (happens if it is multiple times in `removed_coords`)
            continue;
        }

        if (current_coord.y == y_upper_bound || COLOR_NONE == board_get_field(board, coord_new(current_coord.x, current_coord.y + 1))) {
            // nothing there to drop, but the coord may have been top of column, modify it if necessary
            if (board_is_top_of_column(board, current_coord)) {
                for (;;) {
                    if (current_coord.y == 0) {
                        board_clear_top_of_column(board, current_coord.x);
                        break;
                    }
                    --current_coord.y;
                    if (COLOR_NONE != board_get_field(board, current_coord)) {
                        board_set_top_of_column(board, current_coord);
                        break;
                    }
                }
            }
            continue;
        }
        
        // get the actual position to drop the colors to
        coord floor = current_coord;
        while (floor.y > 0 && COLOR_NONE == board_get_field(board, coord_new(floor.x, floor.y - 1)))
        {
            --floor.y;
        }
        
        do {
            // start one above the field that was cleared
            ++current_coord.y;

            // move the color to the floor
            const color color = board_get_field(board, current_coord);
            board_set_field(board, floor, color);
            board_set_field(board, current_coord, COLOR_NONE);
            if (!coord_vector_push(inserted_coords, floor)) {
                error_out_of_memory();
                return false;
            }

            // continue with the field above
            ++floor.y;
        } while (current_coord.y < y_upper_bound && COLOR_NONE != board_get_field(board, coord_new(current_coord.x, current_coord.y + 1)));

        // modify top-of-column value if necessary
        if (board_is_top_of_column(board, current_coord)) {
            --floor.y;
            board_set_top_of_column(board, floor);
        }
    }
    return true;
}

// Writes the colors of the board to the writer (`COLOR_NONE` is not a color).
// Returns false if any error is encountered.
bool simulation_print_output(const board *board, writer *writer) {
#ifdef SLOW_IO
    // unused parameter
    (void)writer;
#endif
    const x_coord x_lower_bound = board_get_x_lower_bound(board);
    const x_coord x_upper_bound = board_get_x_upper_bound(board);
    const y_coord y_upper_bound = board_get_y_upper_bound(board);
    coord coord;
    for (coord.y = 0; coord.y <= y_upper_bound; ++coord.y) {
        bool any_color_in_row = false;
        for (coord.x = x_lower_bound; coord.x <= x_upper_bound; ++coord.x) {
            color color = board_get_field(board, coord);
            if (color != COLOR_NONE) {
#ifdef SLOW_IO
                if (0 >= printf("%" COLOR_FORMAT " %" X_COORD_FORMAT " %" Y_COORD_FORMAT "\n", color, coord.x, coord.y)) {
                    error_stdout_io();
                    return false;
                }
#else
                if (   !writer_put_color(writer, color)
                    || !writer_put_char(writer, ' ')
                    || !writer_put_x_coord(writer, coord.x)
                    || !writer_put_char(writer, ' ')
                    || !writer_put_y_coord(writer, coord.y)
                    || !writer_put_char(writer, '\n')
                ) {
                    error_stdout_io();
                    return false;
                }
#endif
                any_color_in_row = true;
            }
        }
        if (!any_color_in_row) {
            // the colors can't "float", we're done
            break;
        }
    }
#ifndef SLOW_IO
    if (!writer_flush(writer)) {
        error_stdout_io();
        return false;
    }
#endif
    return true;
}

// Called by `main` if no arguments are specified.
// Returns false if any error is encountered and `main` should return non-zero.
bool run_simulation() {
    reader reader;
    writer writer;
    board board;
    coord_vector inserted_coords, removed_coords;

    // the return value of this function
    bool success = true;

    // initialize variables
    reader_construct(&reader);
    writer_construct(&writer);
    if (!board_construct(&board)) {
        error_out_of_memory();
        success = false;
        goto cleanup_after_board;
    }
    if (!coord_vector_construct(&inserted_coords)) {
        error_out_of_memory();
        success = false;
        goto cleanup_after_inserted_coords;
    }
    if (!coord_vector_construct(&removed_coords)) {
        error_out_of_memory();
        success = false;
        goto cleanup_after_removed_coords;
    }

#ifdef SLOW_IO
    scanf(" "); // set the end-of-file marker if the input is empty
    while (!feof(stdin)) {
#else
    while (!reader_has_eof(&reader)) {
#endif
        // add color
        if (!simulation_insert_new_color(&reader, &board, &inserted_coords)) {
            success = false;
            goto cleanup;
        }

        // process simulation
        for (;;) {
#ifdef DUMP_GRAPHICAL
            board_dump_graphical(&board);
#endif
            if (!simulation_remove_groups(&board, &inserted_coords, &removed_coords)) {
                success = false;
                goto cleanup;
            }
            
            if (coord_vector_is_empty(&removed_coords)) {
                break;
            }
            
#ifdef DUMP_GRAPHICAL
            board_dump_graphical(&board);
#endif
            if (!simulation_drop(&board, &inserted_coords, &removed_coords)) {
                success = false;
                goto cleanup;
            }
            
            if (coord_vector_is_empty(&inserted_coords)) {
                break;
            }
        }
    }

    // print the result
    if (!simulation_print_output(&board, &writer)) {
        success = false;
        goto cleanup;
    }

cleanup:
    coord_vector_destruct(&removed_coords);

cleanup_after_removed_coords:
    coord_vector_destruct(&inserted_coords);

cleanup_after_inserted_coords:
    board_destruct(&board);

cleanup_after_board:
    return success;
}


///// unit tests /////

// Tests for the individual components of the program.
// Start the program with `./loesung unit_tests` to run.

#ifndef NDEBUG

void test_board_set_values(board *b) {
    color color = 0;
    coord coord;
    for (coord.x = -5; coord.x <= 5; ++coord.x) {
        for (coord.y = 0; coord.y <= 5; ++coord.y) {
            board_set_field(b, coord, color);
            ++color;
        }
    }
}

void test_board_check_values(const board *b) {
    color color = 0;
    coord coord;
    for (coord.x = -5; coord.x <= 5; ++coord.x) {
        for (coord.y = 0; coord.y <= 5; ++coord.y) {
            assert(color == board_get_field(b, coord));
            ++color;
        }
    }
    for (coord.x = board_get_x_lower_bound(b); coord.x <= board_get_x_upper_bound(b); ++coord.x) {
        for (coord.y = 0; coord.y <= 5; ++coord.y) {
            assert((coord.x >= -5 && coord.x <= 5 && coord.y <= 5) || COLOR_NONE == board_get_field(b, coord));
        }
    }
}

void test_board() {
    board b;

    assert(board_construct(&b));

    // values initialized to `COLOR_NONE`
    coord coord;
    for (coord.x = board_get_x_lower_bound(&b); coord.x <= board_get_x_upper_bound(&b); ++coord.x) {
        for (coord.y = 0; coord.y <= board_get_y_upper_bound(&b); ++coord.y) {
            assert(COLOR_NONE == board_get_field(&b, coord));
        }
    }

    // basic set/get check
    test_board_set_values(&b);
    test_board_check_values(&b);

    // incresing height
    y_coord old_y_upper_bound = board_get_y_upper_bound(&b);
    assert(board_increase_height(&b));
    assert(board_get_y_upper_bound(&b) > old_y_upper_bound);

    // ... and copying the values to the correct place
    test_board_check_values(&b);


    // updating x bounds
    assert(board_get_x_lower_bound(&b) > -1000);
    assert(board_set_x_lower_bound(&b, -1000));
    assert(board_get_x_lower_bound(&b) == -1000);
    test_board_check_values(&b);

    assert(board_get_x_upper_bound(&b) < 2000);
    assert(board_set_x_upper_bound(&b, 2000));
    assert(board_get_x_upper_bound(&b) == 2000);
    test_board_check_values(&b);

    // bounds should go up by more than 1
    assert(board_set_x_lower_bound(&b, -1001));
    assert(board_get_x_lower_bound(&b) < -1001);

    assert(board_set_x_upper_bound(&b, 2001));
    assert(board_get_x_upper_bound(&b) > 2001);

    // big values
    assert(board_set_x_lower_bound(&b, -(1024 * 1024)));
    assert(board_set_x_upper_bound(&b, (1024 * 1024)));

    // top of column
    assert(0 == board_get_one_above_top_of_column(&b, 123));
    board_set_top_of_column(&b, coord_new(123, 4));
    assert(board_is_top_of_column(&b, coord_new(123, 4)));
    assert(5 == board_get_one_above_top_of_column(&b, 123));
    board_clear_top_of_column(&b, 123);
    assert(0 == board_get_one_above_top_of_column(&b, 123));
    

    // for good meassure
    test_board_check_values(&b);

    board_destruct(&b);
}

void test_coord_vector() {
    coord_vector v;
    assert(coord_vector_construct(&v));

    for (x_coord i = 0; i <= 1000; ++i) {
        assert(coord_vector_push(&v, coord_new(-i, (y_coord)i)));
    }

    {
        coord c = coord_new(0, 0);
        for (coord *iter = coord_vector_begin(&v); iter != coord_vector_end(&v); ++iter) {
            assert(iter->x == c.x);
            assert(iter->y == c.y);
            --c.x;
            ++c.y;
        }
    }

    for (x_coord i = 1000; i >= 0; --i) {
        coord coord;
        assert(coord_vector_pop(&v, &coord));
        assert(coord.x == -i);
        assert(coord.y == (y_coord)i);
    }

    assert(!coord_vector_pop(&v, NULL));
    coord_vector_destruct(&v);
}

void test_writer_output() {
    writer w;
    writer_construct(&w);
    
    assert(writer_put_char(&w, 'A'));
    assert(writer_put_char(&w, '\n'));
    assert(writer_put_data(&w, "Hello World!\n", sizeof("Hello World!\n") - 1));
    assert(writer_put_color(&w, 0));
    assert(writer_put_char(&w, ' '));
    assert(writer_put_color(&w, 1));
    assert(writer_put_char(&w, ' '));
    assert(writer_put_color(&w, 255));
    assert(writer_put_char(&w, '\n'));
    assert(writer_put_x_coord(&w, -1));
    assert(writer_put_char(&w, ' '));
    assert(writer_put_x_coord(&w, X_COORD_MIN));
    assert(writer_put_char(&w, ' '));
    assert(writer_put_x_coord(&w, X_COORD_MAX));
    assert(writer_put_char(&w, ' '));
    assert(writer_put_y_coord(&w, Y_COORD_MAX));
    assert(writer_put_char(&w, '\n'));

    assert(writer_flush(&w));
}

void test_writer_input() {
    char a, newline;
    char hello[20];
    int n0, n1, n255;
    x_coord x_minus1, x_min, x_max;
    y_coord y_max;
    scanf("%c%c%20[^\n] %d %d %d %" X_COORD_FORMAT " %" X_COORD_FORMAT " %" X_COORD_FORMAT " %" Y_COORD_FORMAT "\n", &a, &newline, hello, &n0, &n1, &n255, &x_minus1, &x_min, &x_max, &y_max);
    assert(a == 'A');
    assert(newline == '\n');
    assert(0 == strcmp(hello, "Hello World!"));
    assert(n0 == 0);
    assert(n1 == 1);
    assert(n255 == 255);
    assert(x_minus1 == -1);
    assert(x_min == X_COORD_MIN);
    assert(x_max == X_COORD_MAX);
    assert(y_max == Y_COORD_MAX);

    puts("writer OK");
}

void test_reader_output() {
    printf(
        "A\n"
        "\r\n"
        "0 0\n"
        "1 1\n"
        "254 255\n"
        "x -x -1x\n"
        "9223372036854775808 -9223372036854775808\n"
    );
    for (x_coord n = X_COORD_MIN; n <= X_COORD_MIN + 20; ++n) {
        printf("%" X_COORD_FORMAT " ", n);
    }
}

void test_reader_skip(reader *r, size_t count) {
    assert(reader_fill_buffer(r, count));
    reader_consume(r, count);
}

void test_reader_input() {
    reader r;
    reader_construct(&r);
    char a = 'C', space = 'C', x = 'C';
    color c0 = 0xCC, c1 = 0xCC, c254 = 0xCC, c_unchanged = 0xCC;
    x_coord x0 = 0xCC, x1 = 0xCC, x_minus1 = 0xCC, x_unchanged = 0xCC;
    assert(reader_get_char(&r, &a));
    assert(reader_has_newline(&r));
    assert(reader_has_newline(&r));
    assert(reader_get_color(&r, &c0));
    assert(reader_get_char(&r, &space));
    assert(reader_get_x_coord(&r, &x0));
    assert(reader_has_newline(&r));
    assert(reader_get_color(&r, &c1));
    assert(reader_has_char(&r, ' '));
    assert(reader_get_x_coord(&r, &x1));
    assert(reader_has_newline(&r));
    assert(reader_get_color(&r, &c254));
    assert(reader_has_char(&r, ' '));
    assert(!reader_get_color(&r, &c_unchanged));
    test_reader_skip(&r, 4);
    assert(!reader_get_x_coord(&r, &x_unchanged));
    test_reader_skip(&r, 2);
    assert(!reader_get_x_coord(&r, &x_unchanged));
    test_reader_skip(&r, 3);
    assert(reader_get_x_coord(&r, &x_minus1));
    assert(reader_get_char(&r, &x));
    assert(reader_has_newline(&r));
    assert(!reader_get_x_coord(&r, &x_unchanged));
    test_reader_skip(&r, 20);
    assert(!reader_get_x_coord(&r, &x_unchanged));
    test_reader_skip(&r, 20);
    assert(reader_has_newline(&r));

    assert(a == 'A');
    assert(space == ' ');
    assert(x == 'x');
    assert(c0 == 0);
    assert(c1 == 1);
    assert(c254 == 254);
    assert(x0 == 0);
    assert(x1 == 1);
    assert(x_minus1 == -1);
    assert(c_unchanged == 0xCC);
    assert(x_unchanged == 0xCC);

    for (x_coord n = X_COORD_MIN; n <= X_COORD_MIN + 20; ++n) {
        x_coord m;
        assert(reader_get_x_coord(&r, &m));
        assert(reader_has_char(&r, ' '));
        assert(n == m);
    }

    puts("reader OK");
}

void run_tests() {
    puts("testing board");
    test_board();
    puts("board OK");

    puts("testing coord_vector");
    test_coord_vector();
    puts("coord_vector OK");

    puts("testing reader");
    assert(0 == system("./loesung unit_tests reader_out | ./loesung unit_tests reader_in"));

    puts("testing writer");
    assert(0 == system("./loesung unit_tests writer_out | ./loesung unit_tests writer_in"));

    puts("all tests OK");
}

#endif


///// main /////

// Launch unit tests or simulation depending on args.

int main(int argc, char **argv) {
#ifndef NDEBUG
    if (argc >= 2 && 0 == strcmp(argv[1], "unit_tests")) {
        if (argc >= 3) {
            if (0 == strcmp(argv[2], "reader_in")) {
                test_reader_input();
                return 0;
            } else if (0 == strcmp(argv[2], "reader_out")) {
                test_reader_output();
                return 0;
            } else if (0 == strcmp(argv[2], "writer_in")) {
                test_writer_input();
                return 0;
            } else if (0 == strcmp(argv[2], "writer_out")) {
                test_writer_output();
                return 0;
            }
        }

        run_tests();
        return 0;
    }
#else
    // unused parameters
    (void)argc;
    (void)argv;
#endif
    return run_simulation() ? 0 : 1;
}
