/*
 */

/* 
 * File:   loesung.c
 * Author: Fabian Hohenstein
 */
#define _GNU_SOURCE
//#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>

#include <ctype.h>
//#include <algorithm>
//#include <locale>
//using namespace std;

//DEFINES 


typedef struct{
  int x;
  int y;
}Stone;

//Initialisations
const int maxX=1048576; //Es werden Werte von 0 bis +-2^20 akzeptiert => das ist die maximale Feldlänge (nr. 2^20 also 2^20+1 Felder im Positiven bereich.
const int initialFieldSize=16;

int controller=1;

int biggestVal=0;
int currentOffset=0;

int fieldHight=16;
int fieldWidth=16;
int **Field;
int *hightIndex;

Stone *deletion;
int delSize;
int delCapacity;

int *influencedArea;


//Funktions-Prototypen
int getHight(int x);
void setHight(int x, int pVal);
int getColor(int x, int y);
void setColor(int x, int y, int c);
int getUnusedRightColumns();
int getDiff(int a, int b);

void initArray(int xFrom, int yFrom);

int getTROS(int TypeNum, char XorY);
void checkSurroundings(int x, int y, int color);
void handleInput(int x, int color);
int deterministicFiniteAutomaton(char pLine[]);
int valueValidity(int color, int x);
void resizeArrayWidth(int toBeExtendet);
void resizeArrayHight(int toBeExtendet);
void shiftArrayContent(int shiftBy);
void collapseColumn(int x, int y);
void editStackSize(int operationType);
void pushOnStack(int x, int y);
void orderStack();
void elimininateDuplications();
void solveStack();
void checkInfluencedColumns(int minInfluenced, int maxInfluenced, int changeInfimum, int changeSupremum);
void clearRows();
void returnVisualizedArray();
void returnLoesung();

//Central Functions
int main(int argc, char** argv) { 
    //Finising initialisations
    Field=malloc(sizeof(*Field) * initialFieldSize);
    if(Field){
        for(size_t i=0;i<initialFieldSize;i++){
            Field[i]=malloc(sizeof(*Field[i]) * initialFieldSize);
        }
    }else{fprintf(stderr, "Space could not be allocated (initial Field allocation)\n"); return EXIT_FAILURE;}
    initArray(0,0);
    hightIndex=malloc(sizeof(int) * initialFieldSize);
    for (int i = 0; i < fieldWidth; i++) {hightIndex[i]=0;}
    
    //Starting reading Process
    size_t lineSize=0;   /*Die Stellen der Zahlen 1048576(2^20 von den x Coordinaten) und 254 (Farben Anzahl) sowie eine Stelle für Leerzeichen und eine für Vorzeichen der x coordinate (noch zusätzliche Stelle zur Kontrolle, das leer bleiben muss?)*/
    char *stringLine=NULL;                                              //behaves similar to array of char
    int i=0;                                                      //löchmich

    while(controller){
        //if(fgets(stringLine, max, stdin)==NULL){break;}               //break for EOF (fgets returns NULL)
        if(getline(&stringLine, &lineSize, stdin)<=0){break;}           //break for EOF (fgets returns -1)
        int dfa=deterministicFiniteAutomaton(stringLine);
        if(dfa==0){controller=0; break;}                                           //if validity check is 0 (not true)
        if(dfa==2){                                                     //if validity check is 2 (empty line)
            if(getline(&stringLine, &lineSize, stdin)==-1){break;}              //and the next line is EOF the entry is legit (be it a empty line at the end or a empty doc)
            else{controller=0; fprintf(stderr, "a line cant end empty\n"); break;}                                                     //and the next file is not EOF => the entry is illegal
        }
        
        int color, xCoordinates;
        sscanf(stringLine,"%d %d", &color, &xCoordinates);
        //printf("%d at x=%d\n", color, xCoordinates+currentOffset);
        if(!valueValidity(color, xCoordinates)){controller=0; break;}
        handleInput(color+1, xCoordinates);                             //Since the array is initialized with 0 all Color Values are shifted up by one (return fisxes this step.
        //if((i%500)==0){printf("Entry %d\n", i);}    //löschmich
        i++;                                        //löschmich
        //printf("Entry: %s -> Color: %d x:%d - Num %d\n", stringLine, color, xCoordinates, i);  //löschmich  
    }
    free(stringLine);
    if(deletion){free(deletion);}
    if(influencedArea){free(influencedArea);}
    if(controller==1){
        //returnVisualizedArray();
        returnLoesung();
        //printf("Fallen stones: %d\n", i);  //löschmich
        return (EXIT_SUCCESS);
    }
    free(hightIndex);
    for(int i=0; i<fieldWidth; i++){free(Field[i]);}
    free(Field);
    if(controller!=1){return EXIT_FAILURE;}
    
}

int deterministicFiniteAutomaton(char pLine[]){ //Erkennt die Sprache ^[0-9]+ +-?[0-9]+$
    int state=0;
    int i=0;
    while(pLine[i]!='\0'){
        switch(state){
            case 0: //Start state 
            switch(pLine[i]){
                case '-':{
                    fprintf(stderr, "Illegal start for line: colors cant be negative\n");
                    return 0;
                }
                case ' ':{
                    fprintf(stderr, "Illegal start for line: Space cant be used to start a line\n");
                    return 0;
                }
                case '\n':{
                    //fprintf(stderr, "a line cant end empty\n");
                    return 2;
                }
                default:{
                    if(isdigit(pLine[i])){
                        state=1;
                        break;
                    }else{
                        fprintf(stderr, "Illegal Char: %c cant be part of entry\n", pLine[i]);
                        return 0;
                    }
                }
            }break;
            
            case 1: //the first integer has started.
            switch(pLine[i]){
                case '-':{
                    fprintf(stderr, "its illegal for an integer to be followed by an -\n");
                    return 0;
                }
                case ' ':{
                    state=2;
                    break;

                }
                case '\n':{
                    fprintf(stderr, "a line cant end with only one integer in it\n");
                    return 0;
                }
                default:{
                    if(isdigit(pLine[i])){
                        //printf("%d %d\n", state, i);
                        break;
                    }else{
                        fprintf(stderr, "Illegal Char: %c cant be part of entry\n", pLine[i]);
                        return 0;
                    }
                }
            }break;
            
            case 2://space between both integers
            switch(pLine[i]){
                case '-':{
                    state=4;
                    break;
                }
                case ' ':{
                    break;//state=2;//do nothing
                }
                case '\n':{
                    fprintf(stderr, "a line cant end with only one integer in it\n");
                    return 0;
                }
                default:{
                    if(isdigit(pLine[i])){
                        state=3;
                        break;
                    }else{
                        fprintf(stderr, "Illegal Char: %c cant be part of entry", pLine[i]);
                        return 0;
                    }
                }
            }break;
            
            case 3://second integer has begun
            switch(pLine[i]){
                case '-':{
                    fprintf(stderr, "its illegal for an integer to be followed by an -\n");
                    return 0;
                }
                case ' ':{
                    fprintf(stderr, "no char is permitted after the second integer (in this case%cSpace)\n", pLine[i]);
                    return 0;
                }
                case '\n':{
                    break;//do nothing
                }
                default:{
                    if(isdigit(pLine[i])){
                        state=3;//do nothing
                        break;
                    }else{
                        fprintf(stderr, "Illegal Char: %c cant be part of entry\n", pLine[i]);
                        return 0;
                    }
                }
            }break;
            
            case 4://before a potential second integer stands a '-'
            switch(pLine[i]){
                case '-':{
                    fprintf(stderr, "its illegal for - to be followed by another -\n");
                    return 0;
                }
                case ' ':{
                    fprintf(stderr, "- stands without following integer\n");
                    return 0;
                }
                case '\n':{
                    fprintf(stderr, "a line cant end with -\n");
                    return 0;
                }
                default:{
                    if(isdigit(pLine[i])){
                        state=3;
                        break;
                    }else{
                        fprintf(stderr, "Illegal Char: %c cant be part of entry\n", pLine[i]);
                        return 0;
                    }
                }
                break;
            }
            }
        i++;
    }
    if(state==3){return 1;}
    else{fprintf(stderr, "Something went wrong...\n"); return 0;}
}
int valueValidity(int color, int x){
    if(color>254 || color<0){
        fprintf(stderr, "%d is not a valid color\n", color);
        return 0;
    }
    if(x<-maxX||x>maxX){
        fprintf(stderr, "%d is not a valid x Value\n", x);
        return 0;
    }
    return 1;
}

void handleInput(int color, int x){
    if(x>biggestVal){biggestVal=x;}                                     //Der am weitesten rechts liegende Stein hat die x Koordinate biggestVal. Diese Information dient zur Errechnung der freien Spalten
    if(x+currentOffset>=fieldWidth){                                    //Ist x Größer als der Feldbereich, der von Positiven Zahlen belegt wird, muss dieser Bereich ausgedehnt werden
        resizeArrayWidth(x+currentOffset);
    }else if(x<-currentOffset){                                         //Ist x Kleiner als -currentOffset (also der kleinste eingetragene Wert kleiner 0) müssen die bestehenden Einträge verschoben werden
        if(getUnusedRightColumns()>=-(currentOffset+x)){                //Passt die Verschiebung in das Aktuelle Array ist keine vergrößerung nötig. (currentOffset+x) ist kleiner als null, da currentOffset<|x| und 0>x. -(currentOffset+x) ist also der Absolutabstand zwischen dem kleinsten vorhandenen negativen Element und dem neuen Kleinsten 
            shiftArrayContent(-(currentOffset+x));                      //Alle Werte des Arrays werden nun um die differenz des Betrages des einzugebenden Wertes und des Offsets verschoben
        }else{
            resizeArrayWidth((-x)+biggestVal);                          //Um die neue Zahl unterzubekommen muss das Feld x vielen negativen werten und FieldWidth(-bisherige negative) vielen positiven Werten platz bieten. 
            shiftArrayContent(-(currentOffset+x));              	//-currentOffset entspricht der kleinsten eingetragenen negativen Zahl. 
        }
    }
    int h=getHight(x+currentOffset);
    if(h>=fieldHight-1){resizeArrayHight(h);}
    //printf("#############################################################################################################\n");
    //printf("Accessing Field at (%d,%d)->%d \nwriting %d \noffset %d and original x %d\n", x+currentOffset, h,Field[x+currentOffset][h], color, currentOffset, x);
    
    setColor(x+currentOffset, h, color);
    setHight(x+currentOffset, getHight(x+currentOffset)+1);
    
    //printf("actualy entered value: %d\n", Field[x+currentOffset][h]);
    //printf("\n---------------TrosX: %d TrosY: %d---------------\n", getTROS(2,'x'), getTROS(2,'y'));
    checkSurroundings(x, h, color);
    clearRows();
}
void clearRows(){
    //returnVisualizedArray();
    int minInf, maxInf, changeInfimum, changeSupremum;
    solveStack(&minInf, &maxInf, &changeInfimum, &changeSupremum);
    checkInfluencedColumns(minInf, maxInf, changeInfimum, changeSupremum);
}

void checkSurroundings(int x, int y, int color){
    int vectorLengthPlus=0;
    int vectorLengthMinus=0;
    for(int j = 0;(j < 4); j++){                    //diese Schleife repräsentiert die vier Richtungsgeraden auf denen ein umliegender Stein Liegen kann
        for (int i = -1;(i <= 1);i = i + 2){        //diese Schleife repräsentiert die zwei Lagemöglichkeiten eines Steins auf den vier (durch den geprüften Stein laufenden) Richtungsgeraden (rechts oder nicht)
            int l=1;
            //printf("Checking Surrounding of (%d, %d) j: %d i:%d\n", x, y, j, i);
            if(!((-currentOffset<=(x+(getTROS(j, 'x')*i*l)))&&(0<=(y+(getTROS(j, 'y')*i*l)))&&(fieldWidth>=(currentOffset+x+(getTROS(j, 'x')*i*l)))&&(fieldHight>(y+(getTROS(j, 'y')*i*l))))){continue;} //die überprüfung darf das Feld nicht verlassen
            int remoteColor = getColor((currentOffset+x+(getTROS(j, 'x')*i*l)),(y+(getTROS(j, 'y')*i*l)));
            while(color==remoteColor && color!=0){
                if(i>0){vectorLengthPlus++;}
                else{vectorLengthMinus++;}
                l++;
                if(!((-currentOffset<=(x+(getTROS(j, 'x')*i*l)))&&(0<=(y+(getTROS(j, 'y')*i*l)))&&(fieldWidth>=(currentOffset+x+(getTROS(j, 'x')*i*l)))&&(fieldHight>(y+(getTROS(j, 'y')*i*l))))){break;} //die überprüfung darf das Feld nicht verlassen
                remoteColor = getColor((currentOffset+x+(getTROS(j, 'x')*i*l)),(y+(getTROS(j, 'y')*i*l)));
            }
        }
        //Marking Lines corresponding with Ancor stone to be deleted
        if(3<=(vectorLengthMinus+vectorLengthPlus)){        //1 to <=3 since the idetity is not counted in but tere are still three cases to be testet
            
            pushOnStack(currentOffset+x,y); //push Center Stone (x,y) on stack
            for(int k=1;k<=vectorLengthPlus;k++){pushOnStack(currentOffset+x+(getTROS(j, 'x')*k),y+(getTROS(j, 'y')*k));}                 //Add the Stones in positive directions without the center stone
            for(int k=1;k<=vectorLengthMinus;k++){pushOnStack(currentOffset+x+(getTROS(j, 'x')*(-1)*k),y+(getTROS(j, 'y')*(-1)*k));}      //Add the Stones in negative directions without the center stone
        }
        vectorLengthPlus=0;
        vectorLengthMinus=0;
    }
}
void checkInfluencedColumns(int minInfluenced, int maxInfluenced, int changeInfimum, int changeSupremum){
    if(!influencedArea || minInfluenced<0){/*printf("no area influenced\n");*/return;}                //entsteht in solveStack() kein beeinflusstes Gebiet wurde kein Stein verändert.
    int distSize=((maxInfluenced-minInfluenced)+1);
    
    //Check Influenced columns
    for(int i=0; i<distSize; i++){                                      //go through influenced columns
        if(getColor(i+minInfluenced,changeInfimum)==0){continue;}       //if column is empty, no further influence can have it's origin here
        if(i!=0 && i!=maxInfluenced-minInfluenced){                     //if the currently checked lines are neither the fort or last
            if((influencedArea[i]==0/*influencedArea[i]==influencedArea[i-1])||(influencedArea[i]==influencedArea[i+1]*/)){   //and the array
                //continue; //did not work like it should have...
            }
        }
        //for(int i=0;i<delSize;i++){printf("deletion field %d: x:%d, y:%d\n", i, deletion[i].x, deletion[i].y/*,getColor(deletion[i].x, deletion[i].y)*/);} //löschmich
        for(int h=changeInfimum;h<fieldHight;h++){
            if(getColor(i+minInfluenced,h)==0){break;}
            //printf("----Checking (%d, %d) -> Color:%d----\n", i+minInfluenced, h, getColor(i+minInfluenced, h));
            checkSurroundings(i+minInfluenced-currentOffset, h, getColor(i+minInfluenced,h));
        }
    }
    clearRows();
}
void checkDeleteDistribution(int minInfluenced, int maxInfluenced){
    int distSize=((maxInfluenced-minInfluenced)+1);
    if(!influencedArea){
        influencedArea=malloc(sizeof(int)*distSize);
        if(!influencedArea){fprintf(stderr, "space could not be allocated (check Distribution of deleted stones)\n"); controller=0;}
    }else{
        int *temp=realloc(influencedArea, sizeof(int)*distSize);
        if(temp){
            influencedArea=temp;
        }else{fprintf(stderr, "space could not be reallocated (check Distribution of deleted stones)\n");controller=0;}
    }
    for(int i=0; i<distSize; i++){influencedArea[i]=0;}		//init influencedArrea with 0
    for (int i = 0; i < delSize; i++) {                         //counting trugh the stones that are to be deleted
        influencedArea[(deletion[i].x)-minInfluenced]++;        //For every ocurence of x the corresponding field (the first element at x+offset becomes i=0 and so on.) gets elevated by one
    }
    
    //find the columns where it's nessesary to check the surrounding. 
    for (int j=1, i = 1; i < distSize-j; i++) {//set all blocks to 0 that are inside a block of columns that move the same (just the borders stay)
        if((influencedArea[i]==influencedArea[i-1])&&(influencedArea[i]==influencedArea[i+1])){
            while(i<distSize-j && influencedArea[i]==influencedArea[i+1]){
                influencedArea[i]=0;
                i++;
            }
        }
    }
    for (int j=1, i = 1; i < distSize-j; i++) {//empty columns cant interact. set all blocks to 0 that are adjacent only to 0 or them selves
        if(influencedArea[i-1]==0){
            while((i<distSize-j-1) && ((influencedArea[i]==influencedArea[i+1])||(0==influencedArea[i+1]))){//-1 to avoid deleting the right border
                influencedArea[i]=0;
                i++;
            }
        }
    }
    //for(int i=0;i<distSize;i++){printf("|%d ", influencedArea[i]);}
}
void freeDistribution(){
    if(influencedArea){
        free(influencedArea);
        influencedArea=(int*) NULL;
    }
    return;
}

void pushOnStack(int x, int y){
    Stone pushedStone={x, y};
    editStackSize(1);
    deletion[delSize-1]=pushedStone;
}
void solveStack(int *minInfluenced, int *maxInfluenced, int *changeInfimum, int *changeSupremum){
    if(delSize<=0){*minInfluenced=-1; *maxInfluenced=-1; *changeInfimum=-1;/*freeDistribution();*/ return;}
    orderStack();
    elimininateDuplications();
    int max=deletion[0].x;
    int min=deletion[0].x;
    *changeInfimum=deletion[0].y;
    *changeSupremum=deletion[delSize-1].y;
    for(int i=0;i<delSize && delSize>0;i++){
        if(max<deletion[i].x){
            max=deletion[i].x;
        } 
        if(min>deletion[i].x){
            min=deletion[i].x;
        }
    }
    *minInfluenced=min; 
    *maxInfluenced=max;
    checkDeleteDistribution(min, max);
    
    while(delSize>0){
        collapseColumn(deletion[delSize-1].x, deletion[delSize-1].y);       //the stone that is to be deleted gets overrwritten by the stone above that will be overwritten b the stone above ...
        editStackSize(0);
    }
}
void orderStack(){
   Stone temp;
    for(int i=1;i<delSize;i++){
        for(int j=0;j<delSize-i; j++){
            if(deletion[j].y>deletion[j+1].y){ //the highest y should be at the very end of the array so the algorythm can cut the last element correctly
                temp=deletion[j];
                deletion[j]=deletion[j+1];
                deletion[j+1]=temp;
            }
        }
    }
}
void elimininateDuplications(){
    for(int j=0; j<delSize; j++) {
        for(int i=j+1; i<delSize; i++){
            if((deletion[j].y==deletion[i].y)&&(deletion[j].x==deletion[i].x)){
                for(int k=i; k<delSize-1;k++){
                    deletion[k]=deletion[k+1];
                }

                //delete last element
                editStackSize(0);
                i--;
            }
        }
    }
}
void editStackSize(int operationType){
    switch(operationType){    
        case 0:{ //reduce Stack by one 
            if(delSize<=1){
                free(deletion);
                deletion=(Stone*) NULL;
                if(deletion){fprintf(stderr, "space could not be deallocated (solve delitation Stack) delSize: %d\n",delSize);controller=0;}
                delCapacity=0;
                delSize=0;
            }else{
                if(delSize<delCapacity/2){
                    Stone *temp = realloc(deletion, sizeof(Stone)*(delCapacity/2));
                    if(temp){
                        deletion = temp;
                        //printf("Yay reducing the deletation stack size worked delSize: %d\n", delSize);
                    }else{fprintf(stderr, "less space could not be allocated (solve delitation Stack) delSize: %d\n",delSize);controller=0;}
                    delCapacity=delCapacity/2;
                }
                delSize--;
            }
        }break;
        case 1:{ //expand Stack by one 
            if(!deletion){
                //printf("Creating Deletion List");
                deletion=malloc(sizeof(Stone)*4);
                if(!deletion){fprintf(stderr, "space could not be allocated (push first Stone on delitation)\n"); controller=0;}
                //else{printf("Yay the initial deletation allication worked delSize: %d\n", delSize);}
                delCapacity=4;
                delSize=1;
            }else{
                if(delSize>=delCapacity){
                    Stone *temp=realloc(deletion, sizeof(Stone)*(delCapacity*2));
                    //printf("declared temp successful\n");
                    if(temp){
                        deletion=temp;
                        //printf("Yay increasing the deletation stack size worked delSize: %d\n", delSize);
                    }else{fprintf(stderr, "space could not be allocated (push Stone on delitation)\n");controller=0;}
                    delCapacity=delCapacity*2;
                }
                delSize++;
            }   
        }break;
        default:{
            fprintf(stderr, "unknown operation for delitation size editn)\n");
            controller=0;
        }break;
    }
}

void collapseColumn(int x, int y){
    int lY=y;
    //printf("::::::Deleting (%d, %d)->(%d)::::::\n", x,y, getColor(x,y));
    while(lY<fieldHight && getColor(x,lY)!=0){
        //printf("-------------------------------------Colapse %d onto %d-------------------------------------\n", lY+1, lY);
        setColor(x,lY,getColor(x,lY+1));
        lY++;
    }
    //printf("Manipulate Hight x=%d from hight=%d by -1 (y=%d)\n", x, getHight(x), y);
    if(getHight(x)>0){setHight(x, (getHight(x)-1));}
}

void resizeArrayHight(int toBeEntered){
    //löschmich ROWS = fieldWidth; COLS = fieldHight
    for (size_t i=0; i<fieldWidth; i++) {
        int *temp=realloc(Field[i], sizeof(*Field[i]) * (fieldHight*2));
        if(temp){
            Field[i]=temp;
        }else{fprintf(stderr, "Space could not be allocated (doubling Array Hight)\n");}
    }
    fieldHight=fieldHight*2;
    initArray(0 ,(fieldHight/2));//TODO tested
    //if(fieldHight<toBeEntered){resizeArrayHight(toBeEntered);}      //TODO wesshalb ist < zur funktion ausreichend anstelle von <= // kann eigentlich weg, da wert IMMER nur um eins angehoben wird, also höchstens eine verdopplung pro feld ausreicht
}

void resizeArrayWidth(int toBeEntered){             //The function calls recursively on itself to double the array until the parameter that is to be entered fits inside the arrery.
    int **temp=realloc(Field, sizeof(*Field) * (fieldWidth*2));
    if(temp){
        Field=temp;
        for(size_t i=0;i<fieldWidth;i++){
            Field[fieldWidth+i]=malloc(sizeof(*Field[fieldWidth+i])*fieldHight);
            //int ** p=malloc(fieldHight, sizeof *int);
        }
    }else{fprintf(stderr, "Space could not be allocated (doubling Array Width)\n");}  
    fieldWidth=fieldWidth*2;
    initArray((fieldWidth/2) ,0);
    
    int *tempH=realloc(hightIndex, sizeof(int)*fieldWidth);
    if(tempH){
        hightIndex=tempH;
        for (int i = fieldWidth/2; i < fieldWidth; i++) {hightIndex[i]=0;}
    }else{fprintf(stderr, "Space could not be allocated (doubling Array Hight Index)\n");}
    if(fieldWidth<=toBeEntered){resizeArrayWidth(toBeEntered);}     //da 2^20=MaxfieldWidth kann diese funktion mit genau 16 aufrufen das Maximale (positive) Feld erstellen(16=2^4 => 4-20 verdopplungen bleiben von 16 bis 2^20) 
}

void shiftArrayContent(int shiftBy){
    int unusedColumns=getUnusedRightColumns();
    currentOffset=currentOffset+shiftBy;
    for(int x=fieldWidth-(unusedColumns);x>=0;x--){                     //beginne bei der letzten beschriebenen Spalte //TODO nachvollziehen,weshalb keine überschreitung der Arraygrenzen stattfindet
        for(int y=fieldHight-1;y>=0;y--){                              //und durchlaufe diese von oben nach unten
            if(getColor(x+shiftBy,y)!=getColor(x,y)){
                //printf("x+shiftby=%d | ", x+shiftBy);   //löschmich
                setColor(x+shiftBy,y,getColor(x,y));                    //setze den um shiftBy verschobenen Nachfolger eines Wertes auf dssen wert.
            }
        }
    }                                                                   //an dieser Stelle sind bis auf die Zeilen 0 bis 0+shiftBy alle akutallisiert (die shiftBy ersten werte werden nicht überschrieben) 
    //printf("\n"); //löschmich
    for(int u=0;u<shiftBy;u++){                                         //beginne bei spalte null und gehe bis umittelbar vor die shiftBy-ten spalte
        for(int v=fieldHight-1;v>=0;v--){                               //und durchlaufe diese von oben nach unten
            setColor(u,v,0);                                            //damit werden die falschen steine gelöscht.
        }
    }
    //test
    for(int i=fieldWidth-(unusedColumns);i>=0;i--){                              //und durchlaufe diese von hinten nach vorn
        if(getHight(i)!=getHight(i+shiftBy)){
            setHight(i+shiftBy, getHight(i));
        }
    }
    for(int i=0;i<shiftBy;i++){
        setHight(i,0);
    }
    
}
void initArray(int xFrom, int yFrom){
    int line,column;
    line=yFrom;
    column=xFrom;
    while(line<fieldHight){
        while(column<fieldWidth){
            setColor(column, line, 0);
            column++;
        }
    column=xFrom;
    line++;
    }
}

void returnVisualizedArray(){ //TODO  // Funktioniert nicht: Segmentation fault; core dumped; 
    printf("\nInitialize ArrayReturn\n");
    int line=fieldHight-1/*-10*/;                                   //TODO entferne "-10"
    int column=0;
    while(line>-1){                                                 //beginne mit der Formatierten Ausgabe der Obersten Zeile
        while(column<fieldWidth){
            if(getColor(column,line)!=0){                           //geh die einzelnen Spaltenschnittstellen durch und druck die werte von 0 bis fieldWidth-1 (array size from 0->zize-1)
                //printf("column: %d line: %d color: %d\n", column, line, Field[column][line]);
                printf(" %d ", getColor(column,line)-1);   
            }else{printf(" - ");}
            column++;
        }
        column=0;
        printf("\n");
        line--;
    }
    printf("ArrayReturn Complete\n");
    
}
void returnLoesung(){
    //printf("\nInitialize Return-Stream\n");
    int i=0;
    int line=0;
    int column=0;
    while(line<fieldHight){                                                 //beginne mit der Formatierten Ausgabe der Obersten Zeile
        while(column<fieldWidth){
            if(getColor(column,line)!=0){                                   //geh die einzelnen Spaltenschnittstellen durch und druck die werte von 0 bis fieldWidth-1 (array size from 0->zize-1)
                fprintf(stdout, "%d %d %d\n", getColor(column,line)-1, column-currentOffset, line); 
                i++;
            }
            column++;
        }
        column=0;
        line++;
    }
    //printf("Return-Stream Complete \nStones On Field: %d\n", i);                         //löschmich
}

//GETter UND SETter
int getHightOld(int x){
    if(x<0){fprintf(stderr, "illegal Parameter for getHight()"); return -1;}
    int i=0;
    while((0<getColor(x,i)) && (255>getColor(x,i))){
        //printf("%d-tes Element = %d\n",i, getColor(x,i));                                                                                                 //löschmich
        i++;
        //printf("%d-tes %d\n",i, getColor(x,i));
        if((i>=fieldHight-1)){ return i;}
    }
    return i;
}
int getHight(int x){
    return hightIndex[x];
}
void setHight(int x, int pVal){
    hightIndex[x]=pVal;
}
int getColor(int x, int y){
    if((x<fieldWidth)&&(x>=0)&&(y<fieldHight)&&(y>=0)){
        return Field[x][y];
    }
    //fprintf(stderr, "Value (%d, %d) not in Field\n", x, y);
    return -1;
}
void setColor(int x, int y, int c){
   Field[x][y]=c; 
}
int getUnusedRightColumns(){return fieldWidth-(biggestVal+1+currentOffset);} //Biggest Val stands on the currentOffset+biggestVal+1 Position of the Array (since 0 is counted in)
int getDiff(int a, int b){return abs(a-b);}

//Help Functions
int getTROS(int TypeNum, char XorY)//get Typeresponding Offset (From the viewpoint of one stone, by what values are the surrounding stones modified)
{
  switch(XorY)
    {
    case 'x':
      switch(TypeNum)
        {
        case 0:return 0;
        case 1:return 1;
        case 2:return 1;
        default:return 1;
        }
    default:    //'y'
      switch(TypeNum)
        {
        case 0:return 1;
        case 1:return 1;
        case 2:return 0;
        default:return -1;
        }
    }
}

