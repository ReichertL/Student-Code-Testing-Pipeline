#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#define MAX_X 1048576 //maximum value for x

//global values

typedef struct inputVector { //input vector extracted from stdin
    int valid;
    int xvalue;
    unsigned char color;
} inputVector;

typedef struct fieldColumn { //structure representing a column
    int cap; // column capacity
    int len; // # of indexes in column
    char* arr; // the array holding the actual values
} fieldColumn;

void **field; //global playing field
size_t fieldSize; //current size of playing field
int offset = 0; //offset for neg x values

//END GLOBAL VALUES

//START INPUT FUNCTIONS

/** Checks if the given characters are valid input
 *  is given single tokens
 *  @param str the string to check
 *  @return 0 if characters are valid, 1 if not
 * */
int checkChars (const char* str) {
    int len = strlen(str);
    for (int i=0; i<len-1; i++) {
        if (i == 0) {
            if (str[i] != 45) { //first character is allowed to be '-'
                if (str[i] < 48 || str[i] > 57) {
                    write(STDERR_FILENO, "Kein gueltiges Zeichen!\n", 25);
                    return 1;
                }
            }
        }
        else {   
            if (str[i] < 48 || str[i]> 57) {
                write(STDERR_FILENO, "Falsche Eingabe!\n", 18);
                return 1;
            }
        }
    }
    return 0;
}

/** Checks if input is valid 
 * @param input string from stdin
 * @return InputVector specifying validity and inpute values
 * */
inputVector checkInput(char* input) {
    char *loc = strchr(input, '\0');
    char delim [2] = " "; //used for strtok
    //static int values [3]; //used for return extracted values
    static inputVector values;
    //int len = strlen(input);
    int valid = -1;
    //values[0] = 0;
    values.valid = 0;
    //printf("You entered:\n %s with %d characters\n", input, len);
    if (loc == NULL) {
        write(STDERR_FILENO, "SOMETHING WENT WRONG, NO NEWLINE?\n", 35);
        //values[0] = -1;
        values.valid = -1;
    }
    else {
        //printf("STRING TERMINATES AT %ld\n", loc-input);
        char *token;
        token = strtok(input, delim);
        int tmpvar = atoi(token);
        if ((valid=checkChars(token)) == 0 && (tmpvar>=0 && tmpvar <=255)) {
            values.color = tmpvar;
        }
        else {
            values.valid = -1;
            write(STDERR_FILENO,"Farbwert ausserhalb des Erlaubten!\n",36);
            return values;

        } ; // argument has valid characters?
        
        token = strtok(NULL, delim);
        (valid = checkChars(token)) == 0 ? (values.xvalue = atoi(token)) : (values.valid = -1); //argument correct? write in array, put -1 for otherwise
        if (abs(values.xvalue)>MAX_X) { // X value bigger than 2^20
            write(STDERR_FILENO, "X-Wert zu gross!\n", 18);
            //values[0] = -1;
            values.valid = -1;
            return values;
        }
        if ((token=strtok(NULL, delim))!=NULL) { //more than 2 values
            write(STDERR_FILENO, "TOO MANY ARGUMENTS ON LINE!\n", 29);
            //values[0] = -1;
            values.valid = -1;
            return values;
        }
    }
    //printf("also X-Value is %d, while color is %d\n", values[2], values[1]);
    return values;
}

// END INPUT FUNCTIONS


// START FUNCTIONS FOR PLAYING FIELD

/** Initializes column to have height 8 
 *  @param column pointer to column
 *  @return initialized column of height 8
 * */
fieldColumn* initColumn(fieldColumn* column) {
    // printf("Initializing new column...\n");
    char* colors = calloc(8, sizeof(unsigned char));
    column = malloc(sizeof(fieldColumn));
    if(colors == NULL || column == NULL) {
            // printf("Initialization of column failed!\n");
            return NULL;
        }
    column->arr = colors;
    column->cap = 8;
    column->len = 0;
    // if(colors != NULL && column!= NULL) printf("New column has capacity %d, with %d elements in it!\n\n", column->cap, column->len);
    return column;
}

/** Prints the whole field
 * */
void showField() {
    for(int i=0; (size_t) i<fieldSize; i++) { //for each column
        //void* c = field[i];
        // if(c != NULL){ //if it's initialized
            fieldColumn* t = (fieldColumn*) field[i];
            for(int j = t->len-1; j>=0;j--) { //show pieces from top to bottom
                fprintf(stdout,"%d %d %d\n", t->arr[j], i-offset, j);
            }
        // } 
    }
}

/** @brief checks if columns in playing field are corrupted
 * */
void checkColumns(){
    for (size_t i = 0; i< fieldSize; i++) {
        fieldColumn* t = (fieldColumn*) field[i];
        if (t->cap < 0 || t->len < 0 || (t->len>t->cap) || t->arr == NULL) {
            printf("Something is wrong with column %lu!\n \
            its length is %d, its capacity is %d, and maybe the array is NULL.\n", i, t->len, t->cap);
        }
    }
}

/**Initializes playing field
 *  @return NULL if initialization failed
 * **/
void* init() {
    // printf("Initializing playing field...\n");
    void** startingField = calloc(8, sizeof(fieldColumn*)); //initial playing field of 8 
    for (int i=0; i<8; i++) {
        fieldColumn* t = initColumn(t);
        if(t == NULL || t->arr == NULL) {
            // printf("Initialization failed!\n");
            return NULL;
        }
        startingField[i] = t;
    }
    field = startingField;
    fieldSize = 8;
    // printf("Field initialization completed!\n\n");
    // checkColumns();
    return field;
}

/** @brief gets index of playing field
 *  @param x the desired column
 * */
int getFieldIndex(int x) {
    // printf("Field Index for x value %d: %d\n", x, x+offset);
    return x+offset;
}

/** Frees the whole playing field
 *  @param oldField pointer to field needing cleanup
 *  @param size size of field to clean
 * */
void cleanUp(void** oldField, size_t size) {
    for(size_t i=0; i<size; i++) {
        // printf("Cleaning column %lu...\n", i);
        fieldColumn* t = (fieldColumn*) oldField[i];
        free(t->arr);
        free(t);
    }
    free(oldField);
}

/** @brief return a deep copy of a column
 *  @param old the pointer to the old column
 *  @return a new column
 * */
fieldColumn* copyColumn (fieldColumn* old) {
    fieldColumn* t = malloc(sizeof(fieldColumn));
    char* newArr = calloc((size_t) old->cap, sizeof(char));
    t->len = old->len;
    t->cap = old->cap;
    for(int i=0; i<old->len; i++) {
        newArr[i] = old->arr[i];
    }
    t->arr = newArr;
    return t;
}

/** Broaden the playing field
 * @param x the value that exceeds the bounds of the playing field
 * */
void* broaden(int x) {
    // printf("NEED TO BROADEN FIELD TO MATCH %d, current possible value is %d\n", x, (x<0 ? 0-offset: (int) fieldSize-offset));
    if ((x-offset)==(int) fieldSize-offset) {
        // printf("False alarm!\n");
    }
    else if (x>0) { //
        size_t newFieldSize = fieldSize+(size_t)x-(fieldSize - (size_t) offset);
        // printf("Broadening to size %lu from %lu, reallocating...\n", newFieldSize,fieldSize);
        //fieldSize += x - (fieldSize-offset); //broaden for the exact size needed
        
        field = realloc(field, newFieldSize*(sizeof(fieldColumn*)));
        for(size_t i = fieldSize; i<newFieldSize; i++) {
            // field[i] = (fieldColumn*) NULL;
            // printf("Initializing new column at index %lu...\n", i);
            fieldColumn* t = initColumn(t);
            field[i] = t;
        }
        fieldSize = newFieldSize;
        // printf("Done broadening, new FieldSize is %lu, offset is %d\n\n", fieldSize, offset);
        // checkColumns();
        //showField();
    }
    else {
        int oo = offset;
        offset = abs(x);
        size_t newFieldSize = fieldSize + (size_t) (offset-oo);
        //fieldSize += offset-oo; //broaden for difference between wanted and old offset
        // printf("New Field size is gonna be %lu (old value is %lu), old off set is %d, new offset is %d, allocating new field...\n", newFieldSize, fieldSize, oo, offset);
        void** newField = calloc(newFieldSize, (sizeof(fieldColumn)));
        // printf("Copying old field into new one...\n");
        for (unsigned int i = 0; i< newFieldSize-fieldSize; i++) {
            // printf("Initializing column at index %d\n", i);
            fieldColumn* t = initColumn(t);
            newField[i] = t;
            // newField[i] = (fieldColumn*) NULL;
        }
        for (unsigned int i = 0; i< fieldSize; i++) { //copy old field offset in new field
            // printf("Copying old column %d into new column %d...\n", i, (i+(offset-oo)));
            fieldColumn *t = field[i];
            newField[i+(offset-oo)] = copyColumn(t);
        }
        // printf("New field initialized, cleaning up old one...\n");
        cleanUp(field, fieldSize); // free all blocks from old field
        // printf("Setting new field as new global playing field...\n\n");
        field = newField;
        fieldSize = newFieldSize;
        // checkColumns();
    }
    return field;
}

/** Heightens the column when too small
 *  @param x the colum to be heightened 
 *  @return NULL if realloc failed
 *  */
void* heighten(int x) {
    int i = getFieldIndex(x);
    fieldColumn* curr = (fieldColumn*) field[i];
    curr->arr = realloc(curr->arr, curr->cap*2);
    curr->cap*=2;
    return curr->arr;
}

/** @brief Adds the "piece" to a column
 *  @param x the colum
 *  @param color the color;
 *  @return NULL if heightening failed
 * */
void* addColor(int x, unsigned char color) {
    // printf("Begin of addColor() function, trying to add color %d to column %d\n", color, x);
    int i = getFieldIndex(x);
    if((size_t) i >= fieldSize) {
        // printf("Need to broaden in addColor() function!\n");
        void* k = broaden(x);
        if (k == NULL) {
            // printf("Fail broadening!\n");
            return k;
        }
    }
    // printf("Accessing field at index %d...\n", i);
    fieldColumn* curr = (fieldColumn*) field[i];
    if (curr == NULL) {
        // printf("Initializing new column at index %d\n", i);
        curr = initColumn(curr);
    }
    if (curr->len==curr->cap) {
        void* k = heighten(x);
        if (k==NULL) return k;
    }
    // printf("Setting column at index %d to color %d\n", curr->len, color);
    if(curr->len > curr->cap) {
        // printf("something failed, length is %d but capacity is %d\n", curr->len, curr->cap);
        curr->len = 8;
        }
    curr->arr[curr->len] = color;
    curr->len++;
    //showField();
    // printf("End of addColor() function\n\n");
    return curr;
}

/** @brief removes piece at given index
 *  @param x the colum
 *  @param y the index to be removed (actual value)
 * */
void removePiece(size_t x, int y) {
    // printf("Removing piece at %lu, %d!\n", x, y);
    
    int i = getFieldIndex(x);
    fieldColumn* t = (fieldColumn*) field[i];

    // printf("Column so far: ");
    // for(int k = 0; k< t->len; k++) {
    //     printf("%d %d ", k, t->arr[k]);
    // }
    

    //move all elements one down, except for last which is set to 0
    //this is to avoid undefined behavior when array is full
    for (int j=y; j<t->len;j++) { 
        if(j!=t->len-1)t->arr[j] = t->arr[j+1];
        else (t->arr[j] = 0);
    }
    t->arr[t->len] = 0;
    t->len--;
    // printf("\nColumn afterwards: ");
    // for(int k = 0; k< t->len; k++) {
    //     printf("%d %d ", k, t->arr[k]);
    // }
    // printf("\n");
}

/** Add a color to column X
 * @param color the char value representing the color added
 * @param xvalue the column at which the piece is added
 * @return 0 if success, -1 if broaden() fails, -2 if addColor() fails
 * */
int addPiece(char color, int xvalue) { //TODO after data structure works
    if (((xvalue < 0) && (abs(xvalue)> offset)) || //Negative X Value that exceeds the offset
        ((size_t) (xvalue+ offset) >= fieldSize)) { //Positive X Value that exceeds the size of the field
        // printf("check for broadening neccessity in addPiece()\n");
        void* k = broaden(xvalue);
        if(k == NULL) return -1;
        }
    void* u = addColor(xvalue, color);
    if(u == NULL) return -2;
    else return 0;
}


//END FUNCTIONS FOR PLAYING FIELD


//solution algorithm

/** @brief checking for matches horizontally
 *  @param color the color that has to be matched
 *  @param x column of starting point
 *  @param y row of starting point
 * */
int checkHorizontal(unsigned char color, size_t x, int y) {
    // printf("Checking horizontally for color %d, starting at x: %lu, y: %d\n", color, x, y);
    int cnt = 0;
    for(int i=0; i<7; i++) {
        fieldColumn* t = (fieldColumn*) field[x+i];
        if(t->arr[y] != color) { //next is not the same color
            break;
        }
        else if(i >= 4 && t->arr[y] != color) {
            break;
        }
        // printf("Column %lu, row %d has also color %d\n ", x+i, y, color);
        cnt++;
    }
    
    // printf("There are %d fields in a row with color %d\n", cnt, color);
    for (int i = 0; cnt>=4 && i<cnt; i++ ) {
        // printf("Removing piece at x: %lu, y: %d...\n", x+i, y);
        removePiece(x+i, y);
        if(i==cnt) return 1;
    }
    return 0;
}

/** @brief checking for matches vertically
 *  @param color the color that has to be matched
 *  @param x column of starting point
 *  @param y row of starting point
 * */
int checkVertical(unsigned char color, size_t x, int y) {
    // printf("Checking vertically for color %d, starting at x: %lu, y: %d\n", color, x, y);
    int cnt = 0;
    fieldColumn* t = (fieldColumn*) field[x];
    for(int i=0; y+i < t->len && i<7; i++) {
        if(t->arr[y+i] != color) { //next is not the same color
            break;
        }
        else if(i >= 4 && t->arr[y+i] != color) {
            break;
        }
        // printf("Column %lu, row %d has also color %d\n ", x, y+i, color);
        cnt++;
    }
    
    // printf("There are %d fields in a column with color %d\n", cnt, color);
    for (int i = 0; cnt>=4 && i<cnt; i++ ) {
        // printf("Removing piece at x: %lu, y: %d...\n", x, y+i);
        removePiece(x, y+i);
        if(i==cnt) return 1;
    }
    return 0;
}

/** @brief checking for matches diagonally upwards
 *  @param color the color that has to be matched
 *  @param x column of starting point
 *  @param y row of starting point
 * */
int checkUpwardDiagonal(unsigned char color, size_t x, int y) {
    // printf("Checking diagonally upwards for color %d, starting at x: %lu, y: %d\n", color, x, y);
    int cnt = 0;
    for(int i=0; i<7; i++) {
        fieldColumn* t = (fieldColumn*) field[x+i];
        if((y+i) <t->len && t->arr[y+i] != color) { //next is not the same color
            break;
        }
        else if(i >= 4 && (y+i) <t->len && t->arr[y+i] != color) {
            break;
        }
        // printf("Column %lu, row %d has also color %d\n ", x, y+i, color);
        cnt++;
    }
    
    // printf("There are %d fields in an upwards diagonal with color %d\n", cnt, color);
    for (int i = 0; cnt>=4 && i<cnt; i++ ) {
        // printf("Removing piece at x: %lu, y: %d...\n", x, y+i);
        removePiece(x+i, y+i);
        if(i==cnt) return 1;
    }
    return 0;
}

/** @brief checking for matches diagonally downwards
 *  @param color the color that has to be matched
 *  @param x column of starting point
 *  @param y row of starting point
 * */
int checkDownwardDiagonal(unsigned char color, size_t x, int y) {
    // printf("Checking diagonally downwards for color %d, starting at x: %lu, y: %d\n", color, x, y);
    int cnt = 0;
    for(int i=0; i<7; i++) {
        fieldColumn* t = (fieldColumn*) field[x+i];
        if((y-i) >=0 && t->arr[y-i] != color) { //next is not the same color
            break;
        }
        else if(i >= 4 && (y-i) >= 0 && t->arr[y-i] != color) {
            break;
        }
        // printf("Column %lu, row %d has also color %d\n ", x, y+i, color);
        cnt++;
    }
    
    // printf("There are %d fields in an downwards diagonal with color %d\n", cnt, color);
    for (int i = 0; cnt>=4 && i<cnt; i++ ) {
        // printf("Removing piece at x: %lu, y: %d...\n", x, y+i);
        removePiece(x+i, y-i);
        if(i==cnt) return 1;
    }
    return 0;
}


/**resolve the pieces horizontally, vertically and diagonally
 **/
void resolve() {
    for(size_t i = 0; i< fieldSize-4; i++){ //for all columns but the last four
        fieldColumn* t = (fieldColumn*) field[i];
        for(int j=0; j<t->len ; j++) { //check for each row
            // printf("Checking column %lu, row %d...\n", i, j);
            int k = checkHorizontal(t->arr[j], i, j);
            if (k!=0) j--;
            k = checkVertical(t->arr[j], i, j);
            if (k!=0) j--;
            checkUpwardDiagonal(t->arr[j], i, j);
            if (j>=3) checkDownwardDiagonal(t->arr[j], i, j); 
        }

    }
    // printf("Done checking!\n\n");
}

//end of solution algorithm


/** Main function
 * @return 10 bei fehlerhaftem Aufruf, \\
 * 11 bei Scheitern der Initialisierung \\
 * 12 bei Fehlerhafter Eingabe, \\
 * 13 bei Fehler beim Verbreitern des Spielfelds,\\
 * 14 bei Fehler im Hinzufügen der Steine
 * */ 
int main (int argc, char **argv) {
    
    if (argc != 1) { //only run with piped input
        fprintf(stderr, "Too many arguments: %s\n", argv[1]);
        return 10;
    }
    
    char buf [4096]; //make sure input of maximum length can be handled
    void* ini = init();
    if(ini == NULL) return 11;
    while (fgets(buf, sizeof(buf), stdin) != NULL) { //reading input 
        inputVector values; 
        values = checkInput(buf); //extracting values from input
        if (values.valid == -1) {
            write(STDERR_FILENO, "Fehlerhafte Eingabe!\n", 22);
            return 12;
        }
        else {
            int v = addPiece(values.color, values.xvalue);
            if(v==-1) return 13;
            else if(v==-2) return 14;
            else resolve();
        }
    }

    showField();
    cleanUp(field, fieldSize);

    return 0;
}