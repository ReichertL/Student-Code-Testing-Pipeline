#define  _GNU_SOURCE	

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct{
    unsigned char color;
    int x;
} stone;

int rows,columns,offset;
int elements;
unsigned char* array;
int count;

stone processInput();
void processOutput();
int getPositionInArray(int x, int y);
int getPositionInNewArray(int x, int y, int c);
void dropStone(int x, char color);
void deleteElements(int lmax, int rmax, int topmax, int bottommax);
int* simpleRealloc(int* array, int size);
void reallocColumnsRight(int amount);
void reallocColumnsLeft(int amount);
void reallocRows();
void fallDown(int lmax, int rmax, int topmax, int bottommax);
int getYPos(int x);
int checkRightNeighbour(int x, int y, int count);
int checkLowerNeighbour(int x, int y, int count);
int checkDiagLeftDown(int x, int y, int count);
int checkDiagRightDown(int x, int y, int count);
int checkForNull(int x,int y, int count);
int checkIfNumerical(char* string);
int checkIfNumericalLinefeed(char* string);

int main(void)
{
	columns = 11;
	rows = 5;
	offset=5;
	count=1;
    
    array = (unsigned char *)malloc(rows * columns * sizeof(char));
    if(array==NULL){
        fprintf(stderr, "ERROR: could not allocate memory");
        exit(-2);
    }
    for(int r=0;r<rows;++r){
        for(int c=0;c<columns;++c){
            array[getPositionInArray(c,r)]=255;
        }
    }
    while(1){
		stone a = processInput();
        dropStone(a.x,a.color);
		++count;
    }
    return 0;
}

stone processInput(){
    char * line = NULL;
    size_t len = 0;
	
    int color,x;
    stone output;
	
	if(getline(&line, &len, stdin)==-1){
		processOutput();
		free(line);
        free(array);
        exit(0);
	}
    
    if(line == NULL){
        fprintf(stderr, "ERROR: empty line");
		free(line);
		free(array);
        exit(-2);
    }
	
   	char* posChar=NULL;
   	char* token = strtok(line, " ");
   	
	char* colorChar = token;
	if(atoi(colorChar)>254 || atoi(colorChar)<0){
		fprintf(stderr, "ERROR: color not in range [0,254]");
		free(line);
		free(array);
        exit(-2);
	}
	if(atoi(colorChar)==0){
		if(checkIfNumerical(colorChar)!=1){
			fprintf(stderr, "ERROR: color not numerical");
			free(line);
			free(array);
        	exit(-2);
		}
	}
	color = atoi(colorChar);
	
   	if( token != NULL) {
      	token = strtok(NULL, " ");
		if(token==NULL){
			fprintf(stderr, "ERROR: no coordinate");
			free(line);
			free(array);
        	exit(-2);
		}
      	posChar=token;
   	}
	
   	if(strtok(NULL, " ")!=NULL){
      	fprintf(stderr, "ERROR: empty line");
		free(line);
		free(array);
        exit(-2);
   	}
	
	if(posChar[0]=='-' && strlen(posChar)>=2){
		if(atoi(&posChar[1])==0 && checkIfNumericalLinefeed(&posChar[1])!=1){
			fprintf(stderr, "ERROR: pos not numerical");
			free(line);
			free(array);
        	exit(-2);
		}
		x = -1*atoi(&posChar[1]);
	}
	else{
		if(atoi(posChar)==0 && checkIfNumericalLinefeed(posChar)!=1){
			fprintf(stderr, "ERROR: pos not numerical");
			free(line);
			free(array);
        	exit(-2);
		}
		x=atoi(posChar);
	}
	
	output.color=color;
    output.x=x;
	free(line);
    return output;
}

void processOutput(){
    for(int i=0;i<rows;++i){
		for(int j=0;j<columns;++j){
			int color=(int) array[getPositionInArray(j,i)];
			if(color==255)	continue;
			else{
                printf("%i %i %i\n",color,(j-offset),abs(i-rows)-1);
            }
		}
	}
}

int getPositionInArray(int x, int y){
	return y*columns+x;
}
int getPositionInNewArray(int x, int y, int c){
	return y*c+x;
}
	
void dropStone(int x, char color){
    
	int x_offset = x+offset;
    
    if(x_offset<0){
        int amount = offset;
        if(abs(x_offset)>amount)  amount=abs(x_offset);
        reallocColumnsLeft(amount);
        x_offset = x+offset;
    }
    else if(x_offset>=columns){
        int amount = (columns-offset-1);
        if(x_offset>=(columns+amount))  amount=x_offset-(columns-1);
        reallocColumnsRight(amount);
    }
        
	int y = getYPos(x_offset);
    if(y==-1){
        reallocRows();
        y = getYPos(x_offset);
    }
    
	array[getPositionInArray(x_offset,y)]=color;
	++elements;
	int lmax=((x_offset-3)>0)?(x_offset-3):0;
	int rmax=((x_offset+3)<columns)?(x_offset+3):columns-1;
	int topmax=((y-3)>0?(y-3):0);
	int bottommax=y;
	deleteElements(lmax,rmax,topmax,bottommax);
	
}
//deleting elements: iterate through array and find chains >=4, write the positions to delete in array elementsToDelete
//after iterating through array, set all elements in array elementsToDelete to 255 (equals empty)
//if any value has been deleted, call fallDown so stones drop to their new positions
void deleteElements(int lmax, int rmax, int topmax, int bottommax){
	int size=elements;
	int *elementsToDelete = (int *)malloc(size * sizeof(int));
	int index=0;
	int deleted=0;
		
	for(int r=topmax;r<=bottommax;r++){
		for(int c=lmax;c<=rmax;c++){
			
			if(array[getPositionInArray(c,r)]==255)	continue;
            
			int rowCount = checkRightNeighbour(c, r, 1);
			if(rowCount>3){
				for(int i=0;i<rowCount;++i){
                    if(index==size){
                        elementsToDelete = simpleRealloc(elementsToDelete,size);
                        size=size*2;
                    }
					int pos = getPositionInArray(c+i,r);
					elementsToDelete[index]=pos;
					++index;
				}
			}	
			int columnCount = checkLowerNeighbour(c, r, 1);
			if(columnCount>3){
				for(int i=0;i<columnCount;++i){
                    if(index==size){
                        elementsToDelete = simpleRealloc(elementsToDelete,size);
                        size=size*2;
                    }
					int pos = getPositionInArray(c,r+i);
					elementsToDelete[index]=pos;
					++index;
				}
			}
			int diag1Count = checkDiagLeftDown(c, r, 1);
			if(diag1Count>3){
					for(int i=0;i<diag1Count;++i){
                        if(index==size){
                        elementsToDelete = simpleRealloc(elementsToDelete,size);
                        size=size*2;
                    }
					int pos = getPositionInArray(c-i,r+i);
					elementsToDelete[index]=pos;
					++index;
				}
			}
			int diag2Count = checkDiagRightDown(c, r, 1);
			if(diag2Count>3){
				for(int i=0;i<diag2Count;++i){
                    if(index==size){
                        elementsToDelete = simpleRealloc(elementsToDelete,size);
                        size=size*2;
                    }
					int pos = getPositionInArray(c+i,r+i);
					elementsToDelete[index]=pos;
					++index;
				}
			}
		}
	}
	for(int i=0;i<index;++i){
		if(array[elementsToDelete[i]]!=255){
			deleted=1;
			--elements;
			array[elementsToDelete[i]]=255;
		}
	}
    
    free(elementsToDelete);
    
	if(deleted==1){
		fallDown(lmax, rmax, topmax, bottommax);
	}
}
//simple realloc for integer array
int* simpleRealloc(int* arrayRealloc, int size){
    arrayRealloc = realloc(arrayRealloc, 2*size*sizeof(int));
    if(arrayRealloc==NULL){
        fprintf(stderr, "ERROR: could not reallocate memory");
		free(array);
		free(arrayRealloc);
        exit(-2);
    }
    return arrayRealloc;
}
//realloc columns to the right
void reallocColumnsRight(int amount){
    unsigned char* newArray = (unsigned char *)malloc(rows * (columns+amount) * sizeof(char));
    if(newArray==NULL){
        fprintf(stderr, "ERROR: could not allocate memory");
		free(array);
        exit(-2);
    }
    
    columns = columns+amount;
    for(int r=0;r<rows;++r){
        for(int c=0;c<columns;++c){
            if(c<columns-amount)    newArray[getPositionInArray(c,r)]=array[getPositionInNewArray(c,r,columns-amount)];
            else    newArray[getPositionInArray(c,r)]=255;
        }
    }
    
    free(array);
    array=NULL;
    array=newArray;
}
//realloc columns to the left, change the offset value
void reallocColumnsLeft(int amount){
    unsigned char* newArray = (unsigned char *)malloc(rows * (columns+amount) * sizeof(char));
    if(newArray==NULL){
        fprintf(stderr, "ERROR: could not allocate memory");
		free(array);
        exit(-2);
    }
    
    columns = columns+amount;
    offset=offset+amount;
    for(int r=0;r<rows;++r){
        for(int c=0;c<columns;++c){
            if(c>=amount)    newArray[getPositionInArray(c,r)]=array[getPositionInNewArray(c-amount,r,columns-amount)];
            else    newArray[getPositionInArray(c,r)]=255;
        }
    }
    
    free(array);
    array=NULL;
    array=newArray;
}
//realloc rows above
void reallocRows(){
    int diff = rows;
    unsigned char* newArray = (unsigned char *)malloc((rows+diff) * columns * sizeof(char));
    if(newArray==NULL){
        fprintf(stderr, "ERROR: could not allocate memory");
		free(array);
        exit(-2);
    }
    
    rows=rows+diff;
    for(int r=0;r<rows;++r){
        for(int c=0;c<columns;++c){
            if(r<diff){
                newArray[getPositionInArray(c,r)]=255;
            }
            else{
                newArray[getPositionInArray(c,r)]=array[getPositionInArray(c,r-diff)];
            }
        }
    }
    
    free(array);
    array=NULL;
    array=newArray;
}
//drop the stones (calls checkForNull to determine how far to drop a stone)
//begins from the lower end of the array (meaning the highest row count bottommax)
void fallDown(int lmax, int rmax, int topmax, int bottommax){
	int lmaxNew=((lmax-3)>0)?(lmax-3):0;
	int rmaxNew=((rmax+3)<columns)?(rmax+3):columns-1;
	int topmaxnew=topmax;
	int bottommaxnew=bottommax;
	
	for(int r=((bottommax+3)<(rows-1)?(bottommax+3):(rows-1));r>=0;r--){
		for(int c=lmax;c<=rmax;c++){
			int pos = getPositionInArray(c,r);
			if(array[pos]!=255){
				int fall = checkForNull(c, r, 0);
				if(fall>0){
					
					int lowerPos = getPositionInArray(c,r+fall);
					array[lowerPos]=array[pos];
					array[pos]=255;
					if(r+fall>bottommaxnew)	bottommaxnew=r+fall;
					if(r<topmaxnew)	topmaxnew=r;
				}
			}
		}
	}
    deleteElements(lmaxNew,rmaxNew,(topmaxnew-3>0?topmaxnew-3:0),bottommaxnew);
}

int getYPos(int x){
	for(int i=rows-1;i>=0;i--){
		int pos=getPositionInArray(x,i);
		int value = (int) array[pos];
		if(value==255)	return i;
	}
	return -1;
}
//search for chains to the right
int checkRightNeighbour(int x, int y, int count){
	int pos=getPositionInArray(x,y);
	unsigned char color = array[pos];
	if(color==255)	return count-1;
	if(x<columns-1){
		if(array[pos+1]==color)	return checkRightNeighbour(x+1,y,++count);
	}
	return count;
}
//search for chains below
int checkLowerNeighbour(int x, int y, int count){
	int pos=getPositionInArray(x,y);
	unsigned char color = array[pos];
	if(color==255)	return count-1;
	if(y<rows-1){
		int newPos = getPositionInArray(x,y+1);
		if(array[newPos]==color)	return checkLowerNeighbour(x,y+1,++count);
	}
	return count;
}
//search for chains diagonally down left
int checkDiagLeftDown(int x, int y, int count){
	int pos=getPositionInArray(x,y);
	unsigned char color = array[pos];
	if(color==255)	return count-1;
	if(x>0&&y<rows-1){
		int newPos = getPositionInArray(x-1,y+1);
		if(array[newPos]==color)	return checkDiagLeftDown(x-1,y+1,++count);
	}
	return count;
}
//search for chains diagonally down right
int checkDiagRightDown(int x, int y, int count){
	int pos=getPositionInArray(x,y);
	unsigned char color = array[pos];
	if(color==255)	return count-1;
	if(x<columns-1&&y<rows-1){
		int newPos = getPositionInArray(x+1,y+1);
		if(array[newPos]==color)	return checkDiagRightDown(x+1,y+1,++count);
	}
	return count;
}
//return the amount of empty values under a position to determine how far a stone drops down
int checkForNull(int x,int y, int count){
	if(y<rows-1){
		int newPos = getPositionInArray(x,y+1);
		if(array[newPos]==255)	return checkForNull(x,y+1,++count);
	}
	return count;
}
//check if a char array consists only of numerical values
int checkIfNumerical(char* string){
	int length = strlen(string);
    for (int i=0;i<length; i++){
        if (!isdigit(string[i]))	return 0;
	}
	return 1;
}
//check if a char array consists only of numerical values with a linefeed (ASCII:10) at last position
int checkIfNumericalLinefeed(char* string){
	int length = strlen(string);
    for (int i=0;i<length; i++){
		if(i==length-1){
			if(string[i]==10)	break;
		}
        if (!isdigit(string[i]))	return 0;
	}
	return 1;
}