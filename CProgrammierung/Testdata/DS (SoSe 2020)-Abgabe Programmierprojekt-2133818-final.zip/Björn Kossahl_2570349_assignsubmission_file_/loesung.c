#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <regex.h>
#include <errno.h>
#include <stdbool.h>
#include <stdarg.h>
#include <math.h>
#include <search.h>
#include <sys/resource.h>

#define DEBUG 0

#if defined(DEBUG) && DEBUG > 0
#define dprintf(...) \
        fprintf(stderr, "%s:%d:%s(): ",__FILE__, __LINE__, __func__);\
        fprintf(stderr, __VA_ARGS__);
#else
#define dprintf(...)    /* Do nothing */
#endif

#if defined(DEBUG) && DEBUG > 1
#define d2printf(...) \
        fprintf(stderr, "%s:%d:%s(): ",__FILE__, __LINE__, __func__);\
        fprintf(stderr, __VA_ARGS__);
#else
#define d2printf(...)    /* Do nothing */
#endif

//number of needed equal stones (horizontal, vertical or diagonal) to reduce
#define TARGET 4

int MEM_ERROR = false;

#define MAX_HASH 32
#define MAX_KEYLENGTH 64
size_t MAX_INPUTLENGTH = 128;

const char regular_expression[] = "^[0-9]+ +-?[0-9]+$";

typedef struct List_H LIST_H;
typedef struct List LIST;
typedef struct ListElement LISTELEMENT;
typedef struct Stone STONE;
typedef struct Col COL;
typedef struct hentry HENTRY;
typedef struct htable HTABLE;

int calloc_htable = 0, malloc_listH = 0, malloc_hentry = 0, malloc_key = 0, malloc_list = 0, malloc_listelement = 0, malloc_col = 0, malloc_stone = 0;
int count_listOfStoneListElementsToDelete = 0, count_lists_gameGetStones = 0, count_stoneListInCol = 0;

//____________________________________ HASH ____________________________________

struct hentry{
  void *data;
  char key[MAX_KEYLENGTH];
  HENTRY *next;
};

struct htable{
  int size;
  HENTRY *table[];
};

unsigned long hash( const char key[] );
HTABLE *hash_init( int size );
int hash_insert(void *data, const char key[], HTABLE *table);
void *hash_find( const char key[], HTABLE *table);
void hash_print(HTABLE *table);
void hash_destroy(HTABLE *table);
void hash_remove(void *data, const char key[], HTABLE *table);

//________________________ LIST_H _____________________________
//================================================================================================================

struct List_H{

  //Pointer to first LISTELEMENT
  LISTELEMENT *head;
  //Pointer to last LISTELEMENT
  LISTELEMENT *tail;

  int length;

  /*
   * zeiger auf Funktion die Daten aus Listenelement vergleicht
   * 
   * @return {int} 0 if equal, < 0 if first argument is smaller and > 0 else
   */
  int (*compareData)(void *, void *);
  void (*deleteData)(void *); //zeiger auf Funktion die Daten aus Listenelement löscht
  void (*printData)(void *); //zeiger auf Funktion die Daten aus Listenelement ausgibt
  const char* (*getKey)(void *data); //zeiger auf Funktion die key für Hashtabelle erzeugt

  HTABLE *myHashTable;
  //size_t max_hash; //max # item in hashtable
} ;


/*
 * List Initiation: Reserve memory for List and initialize the list
 * 
 * @param {function_delete_data} pointer to a function to delete data in listelements
 * @param {function_print_data} pointer to a function that will output data from listelement on stdout
 * @param {function_compare_elements} pointer to a function that will compare data of to listelements
 * @param {function_get_key} pointer to a function that will get a key for the listelement to store in hashtable
 * @param {max_hash} maximum number of items to store in hashtable
 * 
 * @return {LIST*} The pointer to the initialized LIST
 * 
 */
LIST_H *listH_init(
  void (*function_delete_data)(void *), 
  void (*function_print_data)(void *), 
  int (*function_compare_elements)(void *, void *),
  const char* (*function_get_key)(void *col),
  int max_hash
  );


/*
 * Delete data from list and free()
 * 
 * @param{list} Pointer to LIST to delete and free
 * 
 */
void listH_destroy(LIST_H  *list);


/*
 * doubles the amount of entries that can be stored in the hashtable. this is
 * achieved by destroing the old table, creating a new one with doubled size
 * and reentering each element
 * 
 * @param{list} Pointer to LIST to resize hashtable for
 * 
 * @return{struct hsearch_data*} pointer to the new hashlist
 * 
 */
HTABLE *listH_resizeHashTable(LIST_H *list);

/*
 * Delete the last LISTELEMENT in a LIST
 * 
 * @param{list} Pointer to List to delete last LISTELEMENT (list->tail) from
 * 
 */
void listH_deleteTail(LIST_H *list);


/*
 * Get the LISTELEMENT in list, that points to the same DATA
 *
 * @param {list} A pointer to the LIST to get the element from
 * @param {data} Pointer to data that the LISTELEMENT we search for has
 * 
 * @return {LISTELEMENT} returns NULL if such element does not exist, otherwise the element
 */
LISTELEMENT *listH_getElementByData(LIST_H *list, void *data);


/*
 * Erstellt eventuell eine neues Listenelement mit den Daten data und hängt es in die Liste list ein aufsteigend sortiert.
 * Sollte ein listenelement mit data/compare schon existieren, wird statt dessen dieses zurückgegeben.
 *
 * @param {list} Die Liste zu der die neuen Daten hinzugefügt werden sollen
 * @param {data} Die Daten die dem neu hinzuzufügenden Listenelement zugrundliegen
 * 
 * @return {LISTELEMENT*} Ein Zeiger auf das neu erstellte Listenelement (mit korrekten prev/next pointern) bzw. auf bestehendes Listenelement wenn data schon vorhanden
 */
LISTELEMENT *listH_addSorted(LIST_H *list, void *data);


/*
 * adds the data to the list if that data is not allready in the list
 * 
 * @param{list} Pointer to LIST to add data to
 * @param{data} data that will be added
 * 
 */
LISTELEMENT *listH_addIfUnique(LIST_H *list, void *data);

/*
 * adds a has entry to the lists hashtable for the LISTELEMENT data
 * 
 * @param{list} Pointer to LIST to add data to
 * @param{le} data that will be added
 * 
 * @return{int} the return value of the hsearch_r function
 * 
 */
int list_addHash(LIST_H *list, LISTELEMENT *le);

/*
 * wrapper for list_addTail for LIST_H
 * 
 * @param{list} Pointer to LIST to add data to
 * @param{le} data that will be added
 * 
 * @return{LISTELEMENT*} the listelement the new data was added to, NULL if any error
 * 
 */
LISTELEMENT *listH_addTail(LIST_H *list, void *data);


/*
 * sets the item->data for the hashtable entry for LISTELEMENT le to NULL
 * 
 * @param{list} list where data hash will be nulled
 * @param{le} data that will be nulled
 * 
 * @return{int} the return value of the hsearch_r function
 * 
 */
int listH_nullifyHashEntry(LIST_H *list, LISTELEMENT *le);


/*
 * Output data from list to stdout (wrapper for list_print)
 * 
 * @param{list} Pointer to LIST to orint
 * 
 */
void listH_print(LIST_H  *list);


//________________________LIST_____________________________
//================================================================================================================



struct List{

  //Pointer to first LISTELEMENT
  LISTELEMENT *head;
  //Pointer to last LISTELEMENT
  LISTELEMENT *tail;

  int length;

  /*
   * zeiger auf Funktion die Daten aus Listenelement vergleicht
   * 
   * @return {int} 0 if equal, < 0 if first argument is smaller and > 0 else
   */
  int (*compareData)(void *, void *);
  void (*deleteData)(void *); //zeiger auf Funktion die Daten aus Listenelement löscht
  void (*printData)(void *); //zeiger auf Funktion die Daten aus Listenelement ausgibt

} ;


/*
 * List Initiation: Reserve memory for List and initialize the list
 * 
 * @param {function_delete_data(void *)} pointer to a function to delete data in listelements
 * @param {function_print_data} pointer to a function that will output data from listelement on stdout
 * @param {function_compare_elements)(void *, void *)} pointer to a function that will compare data of to listelements
 * 
 * @return {LIST*} The pointer to the initialized LIST
 * 
 */
LIST *list_init( void (*function_delete_data)(void *), void (*function_print_data)(void *), int (*function_compare_elements)(void *, void *) );


/*
 * Delete the first LISTELEMENT in a LIST
 * 
 * @param{list} Pointer to List to delete first LISTELEMENT (list->head) from
 * 
 */
void list_deleteHead(LIST *list);


/*
 * Delete the last LISTELEMENT in a LIST
 * 
 * @param{list} Pointer to List to delete last LISTELEMENT (list->tail) from
 * 
 */
void list_deleteTail(LIST *list);


/*
 * Delete the LISTELEMENT from LIST it belongs to (listElement->myList)
 * 
 * @param{listElement} Pointer to LISTELEMENT to delete from the LIST it belongs to
 * 
 */
void list_deleteElement(LISTELEMENT *listElement);


/*
 * Delete data from list and free()
 * 
 * @param{list} Pointer to LIST to delete and free
 * 
 */
void list_destroy(LIST  *list);


/*
 * Output data from list to stdout
 * 
 * @param{list} Pointer to LIST to orint
 * 
 */
void list_print(LIST  *list);


/*
 * Erstellt eine neues Listenelement mit den Daten data und hängt es an den Anfang der Liste list .
 *
 * @param {list} Die Liste zu der die neuen Daten hinzugefügt werden sollen
 * @param {data} Die Daten die dem neu hinzuzufügenden Listenelement zugrundliegen
 * 
 * @return {LISTELEMENT*} Ein Zeiger auf das neu erstellte Listenelement.
 */
LISTELEMENT *list_addHead(LIST *list, void *data);


/*
 * Erstellt eine neues Listenelement mit den Daten data und hängt es an das Ende der Liste list .
 *
 * @param {list} Die Liste zu der die neuen Daten hinzugefügt werden sollen
 * @param {data} Die Daten die dem neu hinzuzufügenden Listenelement zugrundliegen
 * 
 * @return {LISTELEMENT*} Ein Zeiger auf das neu erstellte Listenelement.
 */
LISTELEMENT *list_addTail(LIST *list, void *data);


/*
 * Erstellt eventuell eine neues Listenelement mit den Daten data und hängt es in die Liste list ein aufsteigend sortiert.
 * Sollte ein listenelement mit data/compare schon existieren, wird statt dessen dieses zurückgegeben.
 *
 * @param {list} Die Liste zu der die neuen Daten hinzugefügt werden sollen
 * @param {data} Die Daten die dem neu hinzuzufügenden Listenelement zugrundliegen
 * 
 * @return {LISTELEMENT*} Ein Zeiger auf das neu erstellte Listenelement (mit korrekten prev/next pointern) bzw. auf bestehendes Listenelement wenn data schon vorhanden
 */
LISTELEMENT *list_addSorted(LIST *list, void *data);


/*
 *Get the nth element in a list, starting from head
 *
 * @param {list} A pointer to the LIST to get the element from
 * @param {n} The # element to get, return NULL if n <= 0
 * 
 * @return {LISTELEMENT} returns NULL if element does not exist, otherwise the element
 */
LISTELEMENT *list_getNthElement(LIST *list, int n);


/*
 * Get the LISTELEMENT in list, that points to the same DATA
 *
 * @param {list} A pointer to the LIST to get the element from
 * @param {data} Pointer to data that the LISTELEMENT we search for has
 * 
 * @return {LISTELEMENT} returns NULL if such element does not exist, otherwise the element
 */
LISTELEMENT *list_getElementByData(LIST *list, void *data);


/*
 * Merges listB into listA. All elements from listB will belong to listA (if their data is unique in list A). listB will be destroyed.
 * 
 * @param{listA} Pointer to LIST where the listB will be merged into
 * @param{listB} Pointer to LIST that will be merged into listA
 * 
 * @return {int} 0 if merged succesfull, 1 if error
 */
int list_merge(LIST *listA, LIST *listB);

/*
 * adds the data to the list if that data is not allready in the list
 * 
 * @param{list} Pointer to LIST to add data to
 * @param{data} data that will be added
 * 
 */
LISTELEMENT *list_addIfUnique(LIST *list, void *data);


/*
 * sets the data of each listelement of the list to NULL
 * this is usefull if we need to free the list, but the data is still used
 * 
 * @param{list} Pointer to LIST to NULL data
 * 
 */
void list_empty(LIST *list);

//________________________LISTELEMENT_____________________________
//================================================================================================================

struct ListElement{

  LISTELEMENT *next;
  LISTELEMENT *prev;

  LIST *myList;

  void *data;

  //char key[MAX_KEYLENGTH];

};

/*
 * Listelement Initiation: Reserve memory for LISTELEMENT and initialize it
 * 
 * @param{list} LIST the LSITELEMENT belongs to
 * @param {data} data stored in LISTELEMENT
 * 
 * @return{LISTELEMENT*} pointer to the initialized LISTELEMENT
 * 
 */
LISTELEMENT *listElement_init( void *data, LIST *list);


/*
 * Delete data from LISTELEMENT and free() (Function for list_init)
 * 
 * @param{le} Pointer to LISTELEMENT to delete and free
 * 
 */
void listelement_destroy(void *le);

/*
 * Output data from LISTELEMENT to stdout (Function for list_init)
 * 
 * @param{le} Pointer to LISTELEMENT to orint
 * 
 */
void listelement_print(void *le);


/*
 * Compare tha data of the two LISTELEMENTs (Function for list_init)
 * 
 * @param{le1} Pointer to first LISTELEMENT to compare with
 * @param{le2} second LISTELEMENT (pointer to)
 * 
 * @return{long} 0 if equal, < 0 if first argument is smaller and > 0 else
 * 
 */
int listelement_compare(void *le1, void *le2);



/* generate the Hashtable key for a LISTELEMENT with LISTELEMENT data
 *
 * @param {le} LISTELEMENT (data) to generate a hashtablekey for
 * 
 * @return the key
 */
const char *listelement_getKey(void *le);



//________________________COL_____________________________
//================================================================================================================


/*
 * A COL is one vertical line on the playingfield
 * 
 */
struct Col{

  //horizontal position of COL
  int posX;

  //A list of all the Stones in this COL
  LIST *stones;

};

/*
 * COL Initiation: Reserve memory for COL and initialize it
 *
 * @param{posX} horizontal position of COL 
 * @param{list} LIST of STONES to store in COL
 * 
 * @return{COL*} pointer to the initialized COL
 * 
 */
COL *col_init(int posX, LIST *list);


/*
 * Delete data from COL and free() (Function for list_init)
 * 
 * @param{col} Pointer to COL to delete and free
 * 
 */
void col_destroy(void *col);


/*
 * Output data from COL to stdout (Function for list_init)
 * 
 * @param{col} Pointer to COL to orint
 * 
 */
void col_print(void *col);

/* compare the horizonzal Positions of two Cols
 *
 * @param {col1} pointer to the first col
 * @param {col2} pointer to the second col
 * 
 * @return {int} returns 0 if they are at the same posX, 0 < if col1 is before col2, else > 0, where the returned value equals the distance between the two cols
 */
int col_compare(void *col1, void *col2 );


/* generate the Hashtable key for a LISTELEMENT with COL data
 *
 * @param {col} COL to generate a hashtablekey for
 * 
 * @return the key
 */
const char *col_getKey(void *col);




//________________________STONE_____________________________
//================================================================================================================


/*
 * A STONE is a piece on the playingfield. It has a color and a horizontal position (COL) where it belongs
 * 
 */
struct Stone{
  int color;
  int posX;

  COL* myCol; //the COL this STONE is in
  LISTELEMENT* myLE;
};


/*
 * STONE Initiation: Reserve memory for COL and initialize it
 *
 * @param{posX} horizontal position of STONE 
 * @param{color} color of STONE
 * @param{thisStonesCol} the COL this STONE is in
 * 
 * @return{STONE*} pointer to the initialized STONE
 * 
 */
STONE *stone_init(int color, int posX, COL* thisStonesCol);


/*
 * Delete data from STONE and free() (Function for list_init).
 * WARNING: stone->myCol will NOT be free()ed!
 * 
 * @param{stone} Pointer to STONE to delete and free
 * 
 */
void stone_destroy(void *stone);

/*
 * Output data from STONE to stdout (Function for list_init)
 * 
 * @param{stone} Pointer to STONE to orint
 * 
 */
void stone_print(void *stone);


/* compare the horizonzal Positions of two Stones
 *
 * @param {stone1} pointer to the first stone
 * @param {stone2} pointer to the second stone
 * 
 * @return {int} returns 0 if they are at the same posX, 0 < if stone1 is before stone 2, else > 0, where the returned value equals the distance between the two stones
 */
int stone_compare(void *stone1, void *stone2 );


/* Get the posY of this stone in its col
 *
 * @param {stone} the STONE to get the height from
 * 
 * @return {int} the height value of the STONE. Will be -1 if not computable (e.g. STONE has no COL), otherwise >= 0 
 */
int stone_getHeight(STONE *stone);


/* generate the Hashtable key for a LISTELEMENT with stone data
 *
 * @param {stone} stone to generate a hashtablekey for
 * 
 * @return the key
 */
const char *stone_getKey(void *stone);



//________________________GAME FUNCTIONS_____________________________
//================================================================================================================


/* checks wether a string complies to a regular expression
 *
 * @param {regex} the pre compiled regular expression
 * @param {line} the string the regex will be checked against
 * 
 * @returns {bool} true if regex applies, else returns false and puts a message to stderr 
 */
bool regex_string( char *line, regex_t *regex);


/* reads a string with two numbers divided by leerzeichen and saves them as long int
 *
 * @param {firstnumber} a pointer to the variable where the first number in the string should be saved
 * @param {secondnumber} a pointer to the variable where the second number in the string should be saved
 * @param {str} the string to compile the numbers from, must be valid, will not be checked!
 * @param {regex} precompiled regular expresionnen to check str against
 *
 * @returns {bool} true if two numbers have been successfully compiled, else false with errormessage to stderr
 */
bool check_and_compile_numbers(int *firstNumber, int *secondNumber, char *str, regex_t *regex);

/*
 * Scans the playing field (with the parameter stone as source) for stones that will be deleted
 *
 * @param {trigger} The STONE from where to start scanning
 * @param {playingfield} The playingfield LIST in which to scan
 * 
 * @return {LIST*} Returns a pointer to a LIST of LISTELEMENT containing the STONEs that should be deleted
 */
LIST *game_getStonesToDelete(LIST_H *playingfield, STONE *trigger );


/*
 * Check how many LISTELEMENTs with COL data have COLs directly adjacent to source that have equal or higher stonelist.
 * 
 * @param {source} The LISTELEMENT from where to start checking. Must have COL data
 * @param {height} The height neighboring cols need to have (aka source stone posY)
 * @param {left}
 * @param {right} pointers to int variables to store the number of directly left/right adjacent COLs count in. value will be max 3, even if mor COLs are adjacent.
 * 
 */
void game_getNumberOfAdjacentColsWithEqualOrHigherHeight(LISTELEMENT *source, int height, int *left, int *right);

/*
 * Check how many LISTELEMENTs with COL data have COLs directly adjacent to source.
 * 
 * @param {source} The LISTELEMENT from where to start checking. Must have COL data
 * @param {left}
 * @param {right} pointers to int variables to store the number of directly left/right adjacent COLs count in. value will be max 3, even if mor COLs are adjacent.
 * 
 */
void game_getNumberOfAdjacentCols(LISTELEMENT *source, int *left, int *right);



/*
 * Check how many LISTELEMENTs with COL data have COLs with diagonal to source adjacent stones.
 * 
 * @param {source} The LISTELEMENT from where to start checking. Must have COL data
 * @param {height} The height neighboring cols need to have (aka source stone posY)
 * @param {topleft}
 * @param {topright}
 * @param {bottomleft}
 * @param {bottomright} pointers to int variables to store the number of diagonal left/right top/bottom adjacent COLs count in. value will be max 3, even if more COLs are adjacent.
 * 
 */
void game_getNumberOfAdjacentDiagonals(LISTELEMENT *source, int height, int *topleft, int *topright, int *bottomleft, int *bottomright);


/*
 * Add a new STONE to the playingfield. If a COL at posX allready exists it is added to that COL, otherwise a new COL will be created
 * 
 * @param {playingfield} The LIST for the playingfield
 * @param {color} color of the STONE to add
 * @param {posX} posX of the COL to add the STONE to
 * 
 * @return {STONE*} Returns the STONE that was added to the playingfield. Its COL is available with stone->myCol
 */
STONE *game_addStoneToPlayingfield(LIST_H* playingfield, int color, int posX);


/*
 * commits all nescessary reduction that the new STONE will trigger
 * 
 * @param {playingfield} The LIST for the playingfield
 * @param {newStone} the new STONE that was last added to the playingfield
 * 
 * @return {int} 0 if everything is fine, -1 for memerror, 1 else
 */
int game_doReduction(LIST_H *playingfield, STONE *newStone);


//____________________________________ END DECLARATION ____________________________________

//================================================================================================================

//____________________________________ START DEFINITIONS __________________________________

//____________________________________ HASH ____________________________________

// djb2, http://www.cse.yorku.ca/~oz/hash.html
unsigned long hash( const char key[] ){
  unsigned long hash = 5381;
  int c;


  for (size_t i = 0; i < strlen(key); i++){
    c = key[i];
    hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
  }

  return hash;
}

HTABLE *hash_init( int size ){
  #if defined DEBUG && DEBUG < 0
    calloc_htable++;
  #endif
  HTABLE *table = calloc (1, sizeof(HTABLE) + size * sizeof(HENTRY*) );
  if (table == NULL) return NULL;

  table->size = size;

  return table;
}

int hash_insert(void *data, const char key[], HTABLE *table){

  if (data == NULL || key == NULL){
    fprintf(stderr, "NULL data or key to hash_insert.\n");
    return -1;
  }



  size_t index = hash(key) % table->size;

  #if defined DEBUG && DEBUG < 0
    malloc_hentry++;
  #endif
  HENTRY *entry = malloc( sizeof(HENTRY) );
  if ( entry == NULL){
    fprintf(stderr, "memerr.\n");
    return -2;
  }
  entry->data = data;
  entry->next = table->table[index];
  strncpy( entry->key, key, MAX_KEYLENGTH);

  if ( table->table[index] != NULL){
    dprintf("chaining data with key %s to index %li.\n", key, index);
    table->table[index] = entry;
  }
  else{
    dprintf("adding data with key %s to index %li.\n", key, index);
    table->table[index] = entry;
  }

  return EXIT_SUCCESS;

}

void *hash_find( const char key[], HTABLE *table){

  if ( key == NULL){
    dprintf("Got NULL data or key, returning NULL.\n")
    return NULL;
  }

  size_t index = hash(key) % table->size;

  if ( table->table[index] == NULL ){
    dprintf("No Entries for key %s @ index %li, returning NULL.\n", key, index)
    return NULL;
  }
  else {
    for (HENTRY *temp = table->table[index]; temp != NULL; temp = temp->next){
      if ( strcmp(key, temp->key) == 0){
        dprintf("Found matching hash for key %s @table[%li].\n", key, index);
        return temp->data;
      }
    }
  }
  dprintf("should not reach end of function.\n");
  return NULL;

}

void hash_print(HTABLE *table){

  for ( int i = 0; i < table->size; i++){
    if ( table->table[i] != NULL ){
      fprintf(stderr, "[%i] - ", i);
      for (HENTRY *entry = table->table[i]; entry != NULL; entry = entry->next){
        fprintf(stderr, "%s, ", entry->key);
      }
      fprintf(stderr, ".\n");
    }
  }
}


void hash_destroy(HTABLE *table){
  dprintf("calling.\n");
  for (int i = 0; i < table->size; i++){
    HENTRY *temp;
    while (table->table[i] != NULL){
      table->table[i]->data = NULL;
      temp = table->table[i]->next;
      free ( table->table[i] );
      table->table[i] = temp;
    }
  }
  free(table);
}

void hash_remove(void *data, const char key[], HTABLE *table){

  if (data == NULL || key == NULL){
    dprintf("Got NULL data or key to remove from hash.\n");
    return;
  }

  size_t index = hash(key) % table->size;

  if ( table->table[index] == NULL ){
    dprintf("Element not in hash, nothing to remove\n");
    return;
  }
  else {
    if (key == table->table[index]->key && table->table[index]->next == NULL){
      dprintf("found single element for index %li in hash, removing now.\n", index);
      free ( table->table[index] );
      table->table[index] = NULL;
    }
    else{

      HENTRY *prev = table->table[index];
      for (HENTRY *temp = table->table[index]->next; temp != NULL; temp = temp->next){
        d2printf("step.\n");
        if ( key == temp->key ){
          dprintf("found in chained elements of hash at index %li, removing now.\n", index);

          prev->next = temp->next;
          temp->data = NULL;
          free( temp );

          return;
        }
      }
    }
  }  

}



const char *dataFromLE_getKey(void *le){
  if (le == NULL){
    return NULL;
  }
  static char key[MAX_KEYLENGTH];
  
  snprintf(key, MAX_KEYLENGTH, "LE_%p", (void*) ( ((LISTELEMENT*) (le))->data ) );
  d2printf("generated key '%s' for listelement .\n", key );
  return key;
}


const char *data_getKey(void *data){
  if (data == NULL){
    return NULL;
  }
  static char key[MAX_KEYLENGTH];
  snprintf(key, MAX_KEYLENGTH, "D_%p", data );
  d2printf("generated key '%s' for listelement .\n", key );
  return key;
}
//____________________________________ LISTH ____________________________________


LIST_H *listH_init(
  void (*function_delete_data)(void *), 
  void (*function_print_data)(void *), 
  int (*function_compare_elements)(void *, void *),
  const char* (*function_get_key)(void *col),
  int max_hash
  ){

  #if defined DEBUG && DEBUG < 0
    malloc_listH++;
  #endif
  LIST_H *newList = (LIST_H*) malloc(sizeof(LIST_H));
  if ( newList == NULL){
      MEM_ERROR = true;
      dprintf("Out of memory is here.\n");
      return NULL;
  }

  newList->head = NULL;
  newList->tail = NULL;
  newList->deleteData = function_delete_data;
  newList->printData = function_print_data;
  newList->compareData = function_compare_elements;
  newList->getKey = function_get_key;

  newList->myHashTable = hash_init(max_hash);
  if ( newList->myHashTable == NULL){
    dprintf("Out of memory is here.\n");
    fprintf(stderr, "Out of Memory.\n");
    free(newList);
    return NULL;
  }

  newList->length = 0;

  return newList;
}



void listH_destroy(LIST_H  *list){

  if (list == NULL){
    return;
  }

  if (list->length == 0){
    hash_destroy(list->myHashTable);
    free(list);
    return;
  }

  //printf("Starting 'list_destroy'.\n");
  while ( (list->tail) != NULL){ 
    //printf("calling 'list_deleteTail'.\n");
    listH_deleteTail( (list) );
  }

  hash_destroy(list->myHashTable);
  free(list);
  return;

}

HTABLE *listH_resizeHashTable(LIST_H *list){

  if (list == NULL){
    dprintf("got null list.\n");
    return NULL;
  }

  if (list->length == 0){
    dprintf("got list with length 0.\n");
    return NULL;
  }

  dprintf("Resizing hashtable for a list of length %i with a hashtable of size %i:\n", list->length, list->myHashTable->size);
  #if defined(DEBUG) && DEBUG > 1
    list_print( (LIST*) list);
  #endif

  int max_hash = list->myHashTable->size * 8;
  dprintf("resized maxhash, new max is: %i\n", max_hash);

  hash_destroy(list->myHashTable);
  dprintf("destroyed old hashtable.\n");

  dprintf("Printing list after hash destroy:\n");
  #if defined(DEBUG) && DEBUG > 1
    list_print( (LIST*) list);
  #endif
  
  list->myHashTable = hash_init(max_hash);
  if ( list->myHashTable == NULL){
    dprintf("Out of Memory here.\n");
    return NULL;
  }

  for ( LISTELEMENT *le = list->head; le != NULL; le = le->next){
    dprintf("inserting LISTELEMENT to new hashtable. list->printdata follows:\n");

    #if defined(DEBUG) && DEBUG > 0
      if (list->printData != NULL) {
        list->printData(le);
      }
      else{
        d2printf("No printdatafunction for list.\n");
      }
    #endif

    if (le->data != NULL){
      if ( hash_insert(le, list->getKey(le->data), list->myHashTable) == -2){
        dprintf("Out of memory Error here.\n");
        return NULL;
      }
    }

  }

  return list->myHashTable;

}

void listH_deleteHead(LIST_H *list){

  if (list == NULL){
    dprintf("list %p = NULL.\n", (void*) list);
  }

  if (list->getKey == NULL){ 
    dprintf("getKey is NULL.\n");
  }
  if (list->myHashTable == NULL){
    dprintf("myHashTable is NULL.\n");
  }

  hash_remove(list->head, list->getKey(list->head->data), list->myHashTable);

  list_deleteHead( (LIST*) list );
}

void listH_deleteTail(LIST_H *list){
  hash_remove(list->tail, list->getKey(list->tail->data), list->myHashTable);
  list_deleteTail( (LIST*) list );
}


void listH_print(LIST_H  *list){
 list_print( (LIST*) list );
}


LISTELEMENT *listH_getElementByData(LIST_H *list, void *data){
  d2printf("getting a listelement.\n");
  
  if (list == NULL){
    dprintf("null list to get data from.\n");
    return NULL;
  }

  if (data == NULL){
    dprintf("null data to search in list.\n");
    return NULL;
  }

  return hash_find( list->getKey(data), list->myHashTable);

}


LISTELEMENT *listH_addSorted(LIST_H *list, void *data){

  d2printf("start listH_addSorted.\n");

  if (list == NULL){
    dprintf("null list to add data to.\n");
  }

  if (data == NULL){
    dprintf("null data to add to list.\n");
    return NULL;
  }

  LISTELEMENT *newLE = listH_getElementByData(list, data);

  if (newLE == NULL){

    if (MEM_ERROR){
      return NULL;
    }

    dprintf("hash for new Data not found, creating new.\n")

    newLE = list_addSorted( (LIST*)(list), data);
    if( newLE == NULL ){
      //nothing to add or memerror --> todo better mem error recognition
      dprintf("end listH_addSorted (maybe memerror). returning.\n");
      return NULL;
    }
    
    if ( list_addHash(list, newLE) == -2 ){
      dprintf("Out of memory Error here.\n");
      return NULL;
    }
  }
  else{
    dprintf("found hash for data.\n");
  }
  d2printf("end listH_addSorted. returning.\n");
  return newLE;
}


LISTELEMENT *listH_addIfUnique(LIST_H *list, void *data){

  if (list == NULL){
    dprintf("null list to add data to.\n");
  }

  if (data == NULL){
    dprintf("null data to add to list.\n");
    return NULL;
  }

  if ( listH_getElementByData(list, data) == NULL){
    LISTELEMENT *newLE = listH_addTail( list, data);
    if (newLE == NULL){
      return NULL;
    }

    return newLE;
  }
  else{
    return NULL;
  }
}

int list_addHash(LIST_H *list, LISTELEMENT *le){

  if (list == NULL){
    dprintf("Got NULL list.\n");
    return -1;
  }
  if (le == NULL){
    dprintf("Got NULL list element.\n");
    return -1;
  }
  if (le->data == NULL){
    dprintf("Got NULL listelement data.\n");
    return -1;
  }

  if ( list->length > list->myHashTable->size * 4){
    if ( listH_resizeHashTable(list) == NULL){
      dprintf("OUT of Memory here.\n");
      MEM_ERROR = true;
      return -2;
    }
    //now we can return, because resize hash allready added all elements that were part of the list.
    return EXIT_SUCCESS;
  }

  return hash_insert(le, list->getKey(le->data), list->myHashTable);
}


LISTELEMENT *listH_addTail(LIST_H *list, void *data){

  LISTELEMENT *newLE = list_addTail( (LIST*) list, data);

  if (newLE == NULL){
    fprintf(stderr, "memerr.\n");
    return NULL;
  }

  if ( list_addHash(list, newLE) == -2 ){
    dprintf("Out of memory Error here.\n");
    return NULL;
  }

  return newLE;

}


int listH_nullifyHashEntry(LIST_H *list, LISTELEMENT *le){

  if (le == NULL){
    dprintf("Listelement to nullify Hashentry for is NULL.\n");
    return 0;
  }

  if (le->myList == NULL){
    dprintf("Listelement->mylist is NULL.\n");
  }

  if (le->data == NULL){
    dprintf("Listelement data is NULL.\n");
    return 0;
  }

  hash_remove(le, list->getKey(le->data), list->myHashTable);
  return 1;

}




//____________________________________ LIST ____________________________________


LIST *list_init( 
  void (*function_delete_data)(void *), 
  void (*function_print_data)(void *), 
  int (*function_compare_data)(void *, void *) 
  ){

  #if defined DEBUG && DEBUG < 0
    malloc_list++;
  #endif
  LIST *newList = (LIST*) malloc(sizeof(LIST));
  if ( newList == NULL){
      MEM_ERROR = true;
      dprintf("Out of memory is here.\n");
      fprintf(stderr, "Out of Memory.\n");
      return NULL;
  }
  else{
    newList->head = NULL;
    newList->tail = NULL;
    newList->deleteData = function_delete_data;
    newList->printData = function_print_data;
    newList->compareData = function_compare_data;

  }

  newList->length = 0;

  return newList;
}


void list_deleteHead(LIST *list){

  //dprintf("Deleting head of List.\n");

  if (list == NULL){
    dprintf("List to delete head from is NULL.\n");
    return;
  }

  //leere Liste
  if (list->length == 0){
    dprintf("List to delete head from has length 0.\n");
    return;
  //einelementige Liste
  } else if (list->length == 1){
    dprintf("List to delete head from has length 1.\n");
    if (list->deleteData != NULL){
      list->deleteData(list->head->data);
    }
    free(list->head);
    list->head = NULL;
    list->tail = NULL;

    list->length--;

    return;
  }
  else {

    LISTELEMENT *temp = list->head->next;

    if (list->deleteData != NULL){
      list->deleteData(list->head->data);
    }
    free(list->head);

    list->head = temp;
    list->head->prev = NULL;



    list->length--;

    return;

  }
}

void list_deleteTail(LIST *list){

  //got no list
  if (list == NULL){
    dprintf("List to delete tail from is NULL.\n");
    return;
  }
  //got empty list
  if (list->length == 0){
    dprintf("List to delete tail from has length 0.\n");
    return;
  } 
  //list with only one element
  else if (list->length == 1){
    dprintf("Deleting tail from a list with length %i.\n", list->length);
    if (list->deleteData != NULL){
      list->deleteData(list->tail->data);
    }
    free(list->tail);
    list->head = NULL;
    list->tail = NULL;

    list->length--;

    return;
  }
  else {
    dprintf("Deleting tail from a list with length %i.\n", list->length);
    LISTELEMENT *temp = list->tail->prev;
    
    if (list->deleteData != NULL){
      list->deleteData(list->tail->data);
    }
    free(list->tail);

    list->tail = temp;
    list->tail->next = NULL; 

    list->length--;

    return;

  }
}


void list_deleteElement(LISTELEMENT *listElement){

  d2printf("Deleting a Listelement.\n");


  if (listElement == NULL){
    dprintf("Listelement to delete is NULL\n");
    return;
  }

  if (listElement->myList == NULL){
    dprintf("Listelement to delete has ->mylist = NULL\n");
    return;
  } 

  #if defined(DEBUG) && DEBUG > 1
    LIST* list = listElement->myList;
  #endif

  
  #if defined(DEBUG) && DEBUG > 1
    d2printf("Deleting a Listelement. List before deletion is: \n");
    list_print(list);
  #endif

  if (listElement->myList->tail == listElement) {
    d2printf("calling delete tail.\n");
    list_deleteTail(listElement->myList);
  } 
  else if (listElement->myList->head == listElement){
    d2printf("calling delete head.\n");
    list_deleteHead(listElement->myList);   
  } 
  else {
    d2printf("deleting element in middle of list.\n");
    listElement->prev->next = listElement->next;
    listElement->next->prev = listElement->prev;

    listElement->myList->deleteData(listElement->data);

    listElement->myList->length--;

    free(listElement);

  }
  listElement = NULL;
  
  #if defined(DEBUG) && DEBUG > 1
    d2printf("Done deleting a Listelement. List after deletion is: \n");
    list_print(list);
  #endif
}


void list_destroy(LIST  *list){

  if (list == NULL){
    return;
  }

  if (list->length == 0){
    free(list);
    return;
  }

  //printf("Starting 'list_destroy'.\n");
  while ( (list->tail) != NULL){ 
    //printf("calling 'list_deleteTail'.\n");
    list_deleteTail( (list) );
  }

  free(list);
  //*list = NULL;

  return;

}


void list_print(LIST  *list){

  #if defined DEBUG && DEBUG > 1
    dprintf("Printing a list.\n");
  #endif

  if (list == NULL){
     dprintf("got no list to print.\n");
    return;
  }
  if (list->length == 0){
    dprintf("list to print is empty.\n");
    return;
  }

  if (list->printData == NULL){
    dprintf("Got NULL fpr printData-Function in list.\n");
    return;
  }

  dprintf("Printing a List of length %i.\n", list->length);
  for (LISTELEMENT* item = list->head; item != NULL; item = item->next){
    list->printData(item->data);
  }
}


LISTELEMENT *list_addHead(LIST *list, void *data){

  if (list == NULL || data == NULL){
    dprintf("nothing to add to head of list.\n");
    return NULL;
  }

  if (list->head == NULL){

    LISTELEMENT *newListElement = listElement_init(data, list);
    if ( newListElement == NULL){
        MEM_ERROR = true;
        dprintf("Out of memory is here.\n");
        return NULL;
    }
    list->head = newListElement;
    list->tail = newListElement;

    list->length++;

    return newListElement;

  } else {
    
    LISTELEMENT *newListElement = listElement_init(data, list);
    if ( newListElement == NULL){
        MEM_ERROR = true;
        dprintf("Out of memory is here.\n");
        return NULL;
    }

    newListElement->next = list->head;
    newListElement->prev = NULL;
    list->head->prev = newListElement;
    list->head = newListElement;
    //newListElement->next->prev = newListElement;

    list->length++;

    return newListElement;
  };

  return NULL;
}


LISTELEMENT *list_addTail(LIST *list, void *data){

  d2printf("Adding new element as tail to alist of length %i.\n",list->length);

  if (list == NULL || data == NULL){
    dprintf("nothing to add to tail of list.\n");
    return NULL;
  }

  if (list->head == NULL){

    LISTELEMENT *newListElement = listElement_init(data, list);
    if ( newListElement == NULL){
        MEM_ERROR = true;
        dprintf("Out of memory is here.\n");
        return NULL;
    }
    list->head = newListElement;
    list->tail = newListElement;

    list->length++;

    return newListElement;

  } else {
    
    LISTELEMENT *newListElement = listElement_init(data, list);
    if ( newListElement == NULL){
        MEM_ERROR = true;
        dprintf("Out of memory is here.\n");
        return NULL;
    }

    newListElement->prev = list->tail;
    newListElement->next = NULL;
    list->tail->next = newListElement;
    list->tail = newListElement;
    //newListElement->next->prev = newListElement;

    list->length++;

    return newListElement;
  };

  return NULL;
}

LISTELEMENT *list_addSorted(LIST *list, void *data){

  if (list == NULL){
    dprintf("list_addSorted got NULL pointer as LIST.\n");
    return NULL;
  }

  if (data == NULL){
    dprintf("list_addSorted got NULL pointer as data.\n");
    return NULL;
  }

  
  if (list->length == 0){
    //list is empty
    return list_addTail(list, data);
  } 

  LISTELEMENT *new = listElement_init(data, list);
  if( new == NULL ){
    fprintf(stderr, "list_addSorted memerror.\n");
    return NULL;
  }

  int compareResult;
  //where does the element belong?
  if ( (compareResult = list->compareData(new, list->head)) <= 0 && compareResult <= 0 ){
    // new element belongs before or to head

    if (compareResult == 0){
      //data allready exists in head, returning head
      free(new);
      return list->head;
    }
    else{
      //add before head
      new->next = list->head;
      new->next->prev = new;
      
      list->head = new;
      list->length++;
    }
  }
  else if ( (compareResult = list->compareData(new, list->tail) ) >= 0 && compareResult >= 0 ){
    // new element belongs after or to tail
    if (compareResult == 0){
      free(new);
      //printf("adding to existing tail. \n");
      return list->tail;
    }
    else{
      //add as new tail
      free(new);
      return list_addTail(list, data);
    }
  } 
  else{
    //we have a list that is at least two elements long and new element belongs between head and tail
    LISTELEMENT *current = list->head;

    //find a place for the new element (where the next element would be bigger)
    //TODO - need to optimize code, this takes for ever for big lists.
    // --> maybe dont searchelement for element but do binary search according to length and getNthElement
    while ( (compareResult = list->compareData(new, current->next) ) >= 0 && compareResult >= 0){
        current = current->next;
    }

    //we reached end of while so we know current->next-data <= new->data
    compareResult = list->compareData(new, current);
    if ( compareResult == 0 ){
      
      free(new);
      //printf("adding to existing col. \n");
      return current;
    }
    else{
      //add after current
      new->next = current->next;
      new->prev = current;

      current->next->prev = new;
      current->next = new;

      list->length++;
    }
  }
  
  return new;

}


LISTELEMENT *list_getNthElement(LIST *list, int n){

  if ( n > list->length  || n <= 0){
    return NULL;
  }

  if (n == 1){
    return list->head;
  }

  if (n == list->length){
    return list->tail;
  }

  int b = 0, f = n;
  LISTELEMENT *forward = list->head, *backward = list->tail;

  do{
    b++; f--;
    forward = forward->next;
    backward= backward->prev;
  }while( b != list->length - n && f != 1);

  if (b == list->length - n){
    return backward;
  }
  else if (f == 1){
    return forward;
  }

  dprintf("No Element found, returning NULL.\n");
  return NULL;

}

LISTELEMENT *list_getElementByData(LIST *list, void *data){

  if (list == NULL || data == NULL || list->length == 0)
    return NULL;

  if ( list->tail->data == data ){
    return list->tail;
  }

  if ( list->head->data == data ){
    return list->head;
  }

  //search for data in list
  LISTELEMENT* iterator = list->head;
  while ( iterator->data != data && iterator->next != NULL ){
    iterator = iterator->next;
  }

  if (iterator->data == data){
    return iterator;
  }
  else{
    return NULL;
  }
}


int list_merge(LIST *listA, LIST *listB){

  dprintf("Start merging lists. listA length = %i, listB length = %i.\n", listA->length, listB->length);

  if ( listB == NULL || listB->length == 0){
    //nothing to merge
    list_destroy(listB);
    dprintf("Nothing in listB to merge to listA.\n");
    return 0;
  }

  if (
    listA == NULL ||
    listA->deleteData != listB->deleteData ||
    listA->printData != listB->printData ||
    listA->compareData != listB->compareData
  ){
    fprintf(stderr,"Cant merge lists of different types (with different delete/print/compare functions)\n");
    return -1;
  }

  //LIST_H *temp_list = listH_init(listelement_delete, NULL, NULL, data_getkey);

  for (LISTELEMENT *listItem = listB->head; listItem != NULL; listItem = listItem->next){
    //dprintf("assimilate a Listitem from listB.\n");
    list_addIfUnique(listA, listItem->data);
    listItem->data = NULL;
  }

  list_destroy(listB);
  dprintf("END merging lists\n");
  return EXIT_SUCCESS;

}

int list_mergeWithDuplicates(LIST *listA, LIST *listB){

  dprintf("Start merging lists. listA length = %i, listB length = %i.\n", listA->length, listB->length);

  if ( listB == NULL || listB->length == 0){
    //nothing to merge
    list_destroy(listB);
    dprintf("Nothing in listB to merge to listA.\n");
    return 0;
  }

  if (listA == NULL){
    fprintf(stderr,"no listA to merge things into\n");
    return -1;
  }
  if ( listA->deleteData != listB->deleteData ||
    listA->printData != listB->printData ||
    listA->compareData != listB->compareData
  ){
    fprintf(stderr,"Cant merge lists of different types (with different delete/print/compare functions)\n");
    return -1;
  }

  for (LISTELEMENT *listItem = listB->head; listItem != NULL; listItem = listItem->next){
    listItem->myList = listA;
  }

  if (listA->length == 0){
    listA->head = listB->head;
    listA->tail = listB->tail;
    listA->length = listB->length;
  }
  else{
    listB->head->prev = listA->tail;
    listA->tail->next = listB->head;
    listA->tail = listB->tail;
    listA->length += listB->length;
  }

  free(listB);
  
  dprintf("END merging lists\n");
  return EXIT_SUCCESS;

}

int list_removeDuplicateData(LIST* list){

  if (list == NULL || list->length < 2){
    return 0;
  }

  //helper list with hash table
  LIST_H *temp_list = listH_init(NULL, NULL, NULL, data_getKey, MAX_HASH );

  LISTELEMENT *listItem = list->head;
  dprintf("Adding unique listelements from source list with length %i to templist.\n", list->length);
  do{
    listH_addIfUnique(temp_list, listItem->data);
    listItem->data = NULL;
    list_deleteHead(list);
    listItem = list->head;
  }while( listItem != NULL);

  dprintf("templist now has length %i, source list has length %i.\n",temp_list->length ,list->length );
  dprintf("Readding elements from temp_list to source list\n");
  listItem = temp_list->head;
  do{
    list_addTail(list, listItem->data);
    listItem->data = NULL;
    listH_deleteHead(temp_list);
    listItem = temp_list->head;
  }while( listItem != NULL);
  dprintf("Done Readding. Destroying temp.\n");

  listH_destroy(temp_list);
  
  dprintf("Done removing duplicate. Returning.\n");
  return 0;

}

 int list_removeDuplicateDataOptimized(LIST* list){

  if (list == NULL || list->length < 2){
    return 0;
  }

  dprintf("Removing duplicates from a list of length %i.\n", list->length);

  HTABLE *htable = hash_init(list->length);

  for (LISTELEMENT *le = list->head; le != NULL; le = le->next){
    
    if ( hash_find( data_getKey(le->data), htable) == NULL ){
      dprintf("le->data is unique. leavin in list.\n");
      if ( hash_insert(le->data, data_getKey(le->data), htable) == -2){
        fprintf(stderr, "memerr");
        return -2;
      }
    }
    else{
      dprintf("hash for le->data allready in list, deleting.\n");
      LISTELEMENT *prev = le->prev;
      le->data = NULL;
      list_deleteElement(le);
      le = prev;
    }
   
  }

  hash_destroy(htable);
  
  dprintf("After Removing duplicates list has length %i.\n", list->length);
  return 0;
}


LISTELEMENT *list_addIfUnique(LIST *list, void *data){

  if ( list == NULL ){
    dprintf("list to add to is NULL.\n");
    return NULL;
  }

  if ( data == NULL){
    dprintf("data to add to is list NULL.\n");
    //return NULL;
  }

  if ( list->length == 0){
    return list_addTail(list, data);
  }

  if (list->length == 1 && list->head->data == data ){
    return NULL;
  }
  else if (list->length > 1){

    LISTELEMENT *backward = list->tail, *forward = list->head;

    while( forward != backward && forward->next != backward ){
      if ( forward->data == data || backward->data == data){
        return NULL;
      }  
      backward = backward->prev;
      forward = forward->next;
    }
    if ( forward->data == data || backward->data == data){
      return NULL;
    }
  }
  return list_addTail(list, data);
}

void list_empty(LIST *list){

  if (list == NULL || list->length == 0){
    return;
  }
  else{
    for (LISTELEMENT *le = list->head; le != NULL; le = le->next ){
      le->data = NULL;
    }
  }
}

void list_emptyAndDeleteAllElements(LIST *list){
  if (list == NULL || list->length == 0){
    return;
  }
  else{
    LISTELEMENT *next;
    LISTELEMENT *le = list->head;

    do{
      next = le->next;
      le->data = NULL;
      free(le);
      le = next;
    }while (le != NULL);

    list->head = NULL;
    list->tail = NULL;
    list->length = 0;

  }

}

//________________________LISTELEMENT_____________________________
//================================================================================================================


LISTELEMENT *listElement_init( void *data, LIST *list){
  #if defined DEBUG && DEBUG < 0
    malloc_listelement++;
  #endif
  LISTELEMENT *newListElement = (LISTELEMENT*) malloc(sizeof(LISTELEMENT));
  if ( newListElement == NULL){
      MEM_ERROR = true;
      dprintf("Out of memory is here.\n");
      fprintf(stderr, "Out of Memory.\n");
      return NULL;
  }
  else{
    newListElement->prev = NULL;
    newListElement->next = NULL;
    newListElement->myList = list;
    newListElement->data = data;

  }
  return newListElement;
}

void listelement_destroy(void *le){

  if (le == NULL)
    return;

  if ( ((LISTELEMENT*)(le))->data != NULL){
    ((LISTELEMENT*)(le))->myList->deleteData(((LISTELEMENT*)(le))->data);
  }

  free(le);
  return;
}
void listelement_print(void *le){

  d2printf("starting function.\n");

  if (le == NULL){
    dprintf("Got NULL Listelement to print.\n");
    return;
  }

  if ( ((LISTELEMENT*)(le))->data == NULL ){
    dprintf("Listelement has no data to print.\n");
    return;
  }

  if ( ((LISTELEMENT*)(le))->myList == NULL){
    dprintf("Listelement has no list.\n");
    return;
  }

  if ( ((LISTELEMENT*)(le))->myList->printData == NULL){
    dprintf("Listelement list has no printData function.\n");
    return;
  }

  ((LISTELEMENT*)(le))->myList->printData( ((LISTELEMENT*)(le))->data );
  return;
}

int listelement_compare(void *le1, void *le2){

  if (le1 == NULL || le2 == NULL)
    return (long) NULL;

  return ((LISTELEMENT*)(le1))->myList->compareData(le1, le2);
}


const char *listelement_getKey(void *data){

  if (data == NULL){
    return NULL;
  }
  static char key[MAX_KEYLENGTH];
  snprintf(key, MAX_KEYLENGTH, "LE_%p_%p", data, (void*)(( (LISTELEMENT*)(data) )->myList) );

  return key;
}



//________________________ COL _____________________________
//================================================================================================================


COL *col_init(int posX, LIST *list){
  #if defined DEBUG && DEBUG < 0
    malloc_col++;
  #endif
  COL *newCol = (COL*) malloc( sizeof(COL) ) ;
  if ( newCol == NULL ){
    MEM_ERROR = true;
    dprintf("Out of memory is here.\n");
    fprintf(stderr, "Out of Memory.\n");
    return NULL;
  }

  newCol->posX = posX;
  newCol->stones = list;

  return newCol;

}

void col_destroy(void *col){

  if ( col != NULL){
    list_destroy( ((COL*) col)->stones );
    free(col);
  }
  return;
}


void col_print(void *col){

  //dprintf("starting function.\n");

  if (col == NULL){
    dprintf("col to print is NULL.\n");
    return;
  }

  LIST* stoneList = (LIST*) ( (COL*) col )->stones;

  if ( stoneList == NULL){
    dprintf("stonelist in col to print is NULL.\n");
    return;
  }

  if ( stoneList->length == 0){
    dprintf("stonelist in col has length 0\n");
    return;
  }

  if ( stoneList->printData == NULL){
    dprintf("stonelist in col has no printfunction\n");
    return;
  }

  //printf("This is col %i:\n", ( (COL*) col )->posX );
  int i = 0;

  for (LISTELEMENT* item = ((LIST*) (stoneList))->head; item != NULL; item = item->next){
    stoneList->printData(item->data);
    printf(" %i\n", i++);
    dprintf(" %i\n", i++);
  }
  //printf("\n");
}

int col_compare(void *col1, void *col2 ){

  //TODO - check for valid stones?

  COL *firstCol  = (COL*) ( (LISTELEMENT*) col1 )->data;
  COL *secondCol = (COL*) ( (LISTELEMENT*) col2 )->data;

  if ( firstCol->posX == secondCol->posX){
    //printf("compare equals, returning 0\n");
    return 0;
  }
  else if ( firstCol->posX < secondCol->posX){
    //printf("first %i is smaller then second: %i\n", firstStone->posX, secondStone->posX);
    return firstCol->posX - secondCol->posX;
  }
  else{
    //printf("first %i is bigger then second: %i\n", firstStone->posX, secondStone->posX);
    return firstCol->posX - secondCol->posX;
  }

}


/* void col_getKey(void *col, char *key){
  
  sprintf(key, "C%i", ((COL*) (col))->posX );
  dprintf("generated key '%s' for col %i .\n", key, ((COL*) (col))->posX );
  return;
} */


const char *col_getKey(void *col){

  if ( col == NULL){
    return NULL;
  }

  static char key[MAX_KEYLENGTH];
  
  snprintf(key, MAX_KEYLENGTH, "C%i", ((COL*) (col))->posX );
  dprintf("generated key '%s' for col %i .\n", key, ((COL*) (col))->posX );
  return key;
}






//________________________ STONE _____________________________
//================================================================================================================



STONE *stone_init(int color, int posX, COL* thisStonesCol){

    #if defined DEBUG && DEBUG < 0
      malloc_stone++;
    #endif
    STONE *newStone = (STONE*) malloc( sizeof(STONE) ) ;
    if ( newStone == NULL ){
      MEM_ERROR = true;
      dprintf("Out of memory is here.\n");
      fprintf(stderr, "Out of Memory.\n");
      return NULL;
    };

    newStone->color = color;
    newStone->posX = posX;
    newStone->myCol = thisStonesCol;
    newStone->myLE = NULL;

    return newStone;

}

void stone_destroy(void *stone){
  free(stone);
  return;
}

void stone_print(void *stone){
  
  //dprintf("starting function.\n");

  if (stone == NULL){
    dprintf("got no stone to print.\n");
    return;
  }

  STONE *thisStone = (STONE*) stone;
  printf("%i %i", thisStone->color, thisStone->posX);
  dprintf("%i %i\n", thisStone->color, thisStone->posX);
}


int stone_compare(void *stone1, void *stone2 ){

  //TODO - check for valid stones?

  STONE *firstStone  = (STONE*) ( (LISTELEMENT*) stone1 )->data;
  STONE *secondStone = (STONE*) ( (LISTELEMENT*) stone2 )->data;

  if ( firstStone == secondStone){
    dprintf("compare equals, returning 0\n");
    return 0;
  }
  else {
    return -1;
  }

}


int stone_getHeight(STONE *stone){

  if (stone == NULL || stone->myCol == NULL || stone->myLE == NULL){
    dprintf("No Stone or COl or LE, returning -1");
    return -1;
  }

  d2printf("getting height for a stone in col %i.\n", stone->posX);

  if(stone->myCol->stones == NULL){
    dprintf("stones col has no stonelist, returning -2.\n");
    return -2;
  }

  if(stone->myCol->stones->length == 0){
    dprintf("stones col stonelist is empty, returning -1.\n");
    return -1;
  }

  if ( stone->myCol->stones->head->data == stone ){
    d2printf("bottom stone, returning 0.\n");
    return 0;
  }

  if ( stone->myCol->stones->tail->data == stone ){
    d2printf("returning hight %i.\n", stone->myCol->stones->length - 1);
    return stone->myCol->stones->length - 1;
  }


  int i = 0;
  LISTELEMENT *forward = stone->myLE, *backward = stone->myLE;

  do{
    i++;
    forward = forward->next;
    backward = backward->prev;

  }while( forward != stone->myCol->stones->tail && backward != stone->myCol->stones->head );

  if (forward == stone->myCol->stones->tail){
    return stone->myCol->stones->length - i - 1;
  }
  else if (backward == stone->myCol->stones->head){
    return i;
  }
  
  return -1;

  
/*   while ( iterator->data != stone && iterator->next != NULL ){
    iterator = iterator->next;
    i++;
    //dprintf("its higher, i now %i.\n", i);
  }

  if (iterator->data == stone){
    return i;
  }
  else{
    return -1;
  } */
}


const char  *stone_getKey(void *stone){
  if ( stone == NULL){
    return NULL;
  }
  static char key[MAX_KEYLENGTH];
  snprintf(key, MAX_KEYLENGTH, "S_%p_%i_%i", stone, ((STONE*)(stone))->posX, ((STONE*)(stone))->color );
  return key;
}


//________________________ GAMEFUNCTIONS _____________________________
//================================================================================================================

bool regex_string( char *line, regex_t *regex){

  //empty string is valid
  if (strlen(line) == 0){
    return true;
  }

  char msgbuf[100];
  int regexResult = regexec(regex, line, 0, NULL, 0);

    //regex matches, we have two numbers
  if (regexResult == 0) {
    return true;

  }
  else if (regexResult == REG_NOMATCH) {
      fprintf(stderr, "Regex not matching for the line: '%s'\n", line);
      return false;
  }
  else {
      regerror(regexResult, regex, msgbuf, sizeof(msgbuf));
      fprintf(stderr, "Regex match failed: %s\n", msgbuf);
      return false;
  }

}


bool check_and_compile_numbers(int *firstNumber, int *secondNumber, char *str, regex_t *regex){

  d2printf("compiling string '%s' to numbers.\n", str);

  long temp;

  if ( !regex_string( str, regex) ){
    return false;
  }

  if ( strlen(str) == 0){
    fprintf(stderr, "empty Input");
  }

  char *end;

  temp = strtol(str, &end, 10);
  if (errno == ERANGE){
    fprintf(stderr, "Range Error. First Number too big.\n");
    return false;
  }
  else if ( temp < 0 || temp > 254 ) {
    fprintf(stderr, "color out of range.\n");
    return false;
  }
  else{
    *firstNumber = (int) temp;
  }

  temp = strtol(end, &end, 10);
  if (errno == ERANGE){
    fprintf(stderr, "Range Error. Second Number too big.\n");
    return false;
  }
  else if ( temp > 1048576 || temp < -1048576 ) {
    fprintf(stderr, "Range Error. Second Number too big or small.\n");
    return false;
  }
  else{
    *secondNumber = (int) temp;
  }

  return true;

}

LIST *game_getStonesToDelete(LIST_H *playingfield, STONE *trigger ){

  //printf("Start function game_getStonesToDelete.\n");

  if(playingfield == NULL || trigger == NULL){
    fprintf(stderr, "game_getStonesToDelete: playingfield or trigger is NULL");
  }
  

  //we do a list of Listelements that contain the stones we need to delete
  #if defined DEBUG && DEBUG < 0
    count_listOfStoneListElementsToDelete++;
  #endif
  LIST* listOfStoneListElementsToDelete = list_init(listelement_destroy, listelement_print, listelement_compare);
  if ( listOfStoneListElementsToDelete == NULL ){
    return NULL;
  }

  int numberOfStonesToDelete = 0;

  LISTELEMENT *triggerColListElement = listH_getElementByData(playingfield, trigger->myCol);
  if (MEM_ERROR){
    return NULL;
  }
  if( triggerColListElement == NULL ){
    dprintf("triggerColListElement is NULL!.\n");
  }

  //the stonelist of the source col
  LIST *thisColsStones = trigger->myCol->stones;

  //the color we check for
  const int targetColor = trigger->color;

  //the posY we are in
  const int targetPosY = stone_getHeight(trigger);

  //the posX we are in
  const int targetPosX = trigger->posX;

  #if defined(DEBUG) && DEBUG > 0
  
  #endif


  dprintf("Getting Stones to delete for Trigger posX: %i, posY: %i, color: %i.\n",targetPosX, targetPosY, targetColor);

  LISTELEMENT *triggerListElement = trigger->myLE;
  
  int above = thisColsStones->length - (targetPosY + 1); //number of stones above trigger
  int below = targetPosY; //number of stones below trigger

  int n_left_adjacent, n_right_adjacent;
  
  game_getNumberOfAdjacentCols(triggerColListElement, &n_left_adjacent, &n_right_adjacent);

  dprintf("vertical: we have %i above and %i below.\n", above, below);

  if( above +  below + 1 >= TARGET ){

    int length = 17; // magic number for example2005 :P
    LISTELEMENT **tempListOfLE = malloc( (length) * sizeof(LISTELEMENT*) );
    if ( tempListOfLE == NULL){
      MEM_ERROR = true;
      return NULL;
    }
    
    int aboveC = 0, belowC = 0;
    LISTELEMENT *temp;

    //checking below
    temp = triggerListElement;
    for (int i = 1; i <= below; i++){
      temp = temp->prev;
      if ( ((STONE*)(temp->data))->color == targetColor){
        
        tempListOfLE[aboveC + belowC] = temp;
        belowC++;

        if ( aboveC + belowC >= length  ){
          malloc_key++;
          length *= 2;
          tempListOfLE = realloc( tempListOfLE, length * sizeof(LISTELEMENT*) );
          if ( tempListOfLE == NULL){
            MEM_ERROR = true;
            return NULL;
          }
        }

      }
      else{
          break;
      }
    }
    
    if (belowC + 1 >= TARGET){
      for (int i = 0; i < belowC; i++){
        list_addTail(listOfStoneListElementsToDelete, tempListOfLE[i]);
      }
      numberOfStonesToDelete += belowC;
      belowC = 0;
    }

    //checking above
    temp = triggerListElement;
    for (int i = 1; i <= above; i++){
      temp = temp->next;
      if ( ((STONE*)(temp->data))->color == targetColor){

        tempListOfLE[aboveC + belowC] = temp;
        aboveC++;

        if ( aboveC + belowC >= length  ){
          malloc_key++;
          length *= 2;
          tempListOfLE = realloc(tempListOfLE, length * sizeof(LISTELEMENT*) );
          if ( tempListOfLE == NULL){
            MEM_ERROR = true;
            return NULL;
          }
        }

      }
      else{
          break;
      }
    }

    if( aboveC + belowC + 1 >= TARGET){
      dprintf("we have %i above and %i below Stones with same color.\n", aboveC, belowC);
      numberOfStonesToDelete += aboveC + belowC;
      for (int i = 0; i < aboveC + belowC; i++){
        list_addTail(listOfStoneListElementsToDelete, tempListOfLE[i]);
      }

      d2printf("We have %i stones to delete: \n", numberOfStonesToDelete);
      #if defined(DEBUG) && DEBUG > 1
        list_print(listOfStoneListElementsToDelete);
      #endif
    }

    free(tempListOfLE);
    
  }//end vertical if( above +  below + 1 >= TARGET )
  
  LISTELEMENT *temp;

  if ( n_right_adjacent + n_left_adjacent + 1 >= TARGET){
    //check left+right

    LIST tempListOfLE;
    tempListOfLE.head = NULL;
    tempListOfLE.tail = NULL;
    tempListOfLE.length = 0;
    tempListOfLE.compareData = listelement_compare;
    tempListOfLE.deleteData = listelement_destroy;
    tempListOfLE.printData = listelement_print;

    int n_left_samecolor = 0, n_right_samecolor = 0;
    LISTELEMENT *temp;


    //check colors of adjacent right
    temp = triggerColListElement;
    while (
      //there is a col right
      temp->next != NULL &&
      //its distance is 1 + # of right adjacent cols
      ((COL*)(temp->next->data) )->posX == targetPosX + n_right_samecolor + 1 &&
      //it is higher or same height as source col
      ((COL*)(temp->next->data) )->stones->length >= targetPosY + 1
    ){
      temp = temp->next;
      
      LIST* adjacentStones = ((COL*)(temp->data))->stones;
      STONE *stoneToCompareTo = list_getNthElement(adjacentStones, targetPosY + 1)->data;
      
      if ( stoneToCompareTo->color == targetColor ){
        n_right_samecolor++;
        list_addTail(&tempListOfLE, stoneToCompareTo->myLE);
      }
      else{
        break;
      }
    }


    //check colors of adjacent left
    temp = triggerColListElement;
    while (
      //there is a col left
      temp->prev != NULL &&
      //its distance is 1 - # of left adjacent cols
      ((COL*)(temp->prev->data) )->posX == targetPosX - n_left_samecolor - 1 &&
      //it is higher or same height as source col
      ((COL*)(temp->prev->data) )->stones->length >= targetPosY + 1
    ){

      temp = temp->prev;
      
      LIST* adjacentStones = ((COL*)(temp->data))->stones;
      STONE *stoneToCompareTo = list_getNthElement(adjacentStones, targetPosY + 1)->data;
      
      if ( stoneToCompareTo->color == targetColor ){
        n_left_samecolor++;
        list_addTail(&tempListOfLE, stoneToCompareTo->myLE);
      }
      else{
        break;
      }
    }
    if (n_left_samecolor + n_right_samecolor + 1 >= TARGET){
      //there are 4 or more stones horizontally adjacent that have the same color, lets mark them for deletion

      dprintf("Stone in col %i @ height %i: On the left %i of same color, on the right %i:\n",targetPosX,targetPosY,n_left_samecolor,n_right_samecolor);
      #if defined(DEBUG) && DEBUG > 0
        list_print(&tempListOfLE);
      #endif
      numberOfStonesToDelete += n_left_samecolor + n_right_samecolor;
      for (LISTELEMENT *le = tempListOfLE.head; le != NULL; le = le->next){
        list_addTail(listOfStoneListElementsToDelete, le->data);
      }
    }
    list_emptyAndDeleteAllElements(&tempListOfLE);
  } // end: horizontal: if ( n_right_adjacent + n_left_adjacent + 1 >= TARGET)



  if ( n_right_adjacent + n_left_adjacent + 1 >= TARGET){

    //cheking diagonal
    int topLeft, topRight, bottomLeft, bottomRight;
    int topLeftC = 0, topRightC = 0, bottomLeftC = 0, bottomRightC = 0;
    game_getNumberOfAdjacentDiagonals(triggerColListElement, targetPosY, &topLeft, &topRight, &bottomLeft, &bottomRight);
    dprintf("Adjacent Diagonals are topleft: %i, topright: %i, bottomleft: %i, bottomright:%i (left: %i, right: %i).\n", topLeft, topRight, bottomLeft, bottomRight, n_left_adjacent, n_right_adjacent);

    if (topLeft + bottomRight + 1 >= TARGET){

      LISTELEMENT *tempLEs[topLeft + bottomRight];

      //we have a backslash diagonal with enough stones. lets check their colors
      dprintf("We have topleft to bottomright %i adjacent stones.\n", topLeft + bottomRight + 1);

      //get top left colors
      temp = triggerColListElement;
      for (int i = 1; i <= topLeft; i++){
        
        //get the next top left stone
        temp = temp->prev;
        LIST* adjacentStones = ((COL*)(temp->data))->stones;
        STONE *stoneToCompareTo = list_getNthElement(adjacentStones, targetPosY + i + 1)->data;

        //check color
        if ( stoneToCompareTo->color == targetColor ){
          tempLEs[topLeftC] = stoneToCompareTo->myLE;
          topLeftC++;
        }
        else
          //if different color, stop checking
          break;
      }

      //get bottom right colors
      temp = triggerColListElement;
      for (int i = 1; i <= bottomRight; i++){
        
        //get the next top left stone
        temp = temp->next;
        LIST* adjacentStones = ((COL*)(temp->data))->stones;
        STONE *stoneToCompareTo = list_getNthElement(adjacentStones, targetPosY - i + 1)->data;

        //check color
        if ( stoneToCompareTo->color == targetColor ){
          tempLEs[bottomRightC + topLeftC] = stoneToCompareTo->myLE;
          bottomRightC++;
        }
        else
          //if different color, stop checking
          break;
      }
      

      if ( topLeftC + bottomRightC + 1 >= TARGET){
        //we have reduction, I repeat: we have reduction. mark those bastones
        dprintf("Found %i topleft/bottomright diagonal Elements of same color to reduce.\n", topLeftC + bottomRightC + 1)
        numberOfStonesToDelete += topLeftC + bottomRightC;
        for (int i = 0; i < topLeftC + bottomRightC; i++){
          list_addTail(listOfStoneListElementsToDelete, tempLEs[i]);
        }
        d2printf("We have %i stones to delete: \n", numberOfStonesToDelete);
        #if defined(DEBUG) && DEBUG > 1
          list_print(listOfStoneListElementsToDelete);
        #endif
      }

    } //end if (topLeft + bottomRight + 1 >= TARGET)
    
    
    if (topRight + bottomLeft + 1 >= TARGET){

      LISTELEMENT *tempLEs[topRight + bottomLeft];
      
      dprintf("We have topRight to bottomLeft %i adjacent stones.\n", topRight + bottomLeft + 1);
      
      //we have a forwardslash diagonal with enough stones. lets check their colors


      //get top right colors
      temp = triggerColListElement;
      
      for (int i = 1; i <= topRight; i++){
        
        //get the next top left stone
        temp = temp->next;
        LIST* adjacentStones = ((COL*)(temp->data))->stones;
        STONE *stoneToCompareTo = list_getNthElement(adjacentStones, targetPosY + i + 1)->data;

        //check color
        if ( stoneToCompareTo->color == targetColor ){
          tempLEs[topRightC] = stoneToCompareTo->myLE;
          topRightC++;
        }
        else
          //if different color, stop checking
          break;
      }

      //get bottom left colors
      temp = triggerColListElement;
      for (int i = 1; i <= bottomLeft; i++){
        
        //get the next bottom left stone
        temp = temp->prev;
        LIST* adjacentStones = ((COL*)(temp->data))->stones;
        STONE *stoneToCompareTo = list_getNthElement(adjacentStones, targetPosY - i + 1)->data;

        //check color
        if ( stoneToCompareTo->color == targetColor ){
          tempLEs[bottomLeftC + topRightC] = stoneToCompareTo->myLE;
          bottomLeftC++;
        }
        else
          //if different color, stop checking
          break;
      }

      if ( topRightC + bottomLeftC + 1 >= TARGET){
        //we have reduction, I repeat: we have reduction. mark those bastones
        dprintf("Found %i topright/bottomleft diagonal Elements of same color to reduce.\n", topRightC + bottomLeftC + 1)
        numberOfStonesToDelete += topRightC + bottomLeftC;
        for (int i = 0; i < topRightC + bottomLeftC; i++){
          list_addTail(listOfStoneListElementsToDelete, tempLEs[i]);
        }
        d2printf("We have %i stones to delete: \n", numberOfStonesToDelete);
        #if defined(DEBUG) && DEBUG > 1
          list_print(listOfStoneListElementsToDelete);
        #endif
      }

    } //end if (topRight + bottomLeft + 1 >= TARGET)
  }

  if (numberOfStonesToDelete > 0){
    //we have stones to delete, so we add the triggering stone to the list (which we have not done before)
    numberOfStonesToDelete += 1;
    list_addHead(listOfStoneListElementsToDelete, triggerListElement );
  }

  dprintf("We have %i stones to delete: \n", numberOfStonesToDelete);
  #if defined(DEBUG) && DEBUG > 0
    list_print(listOfStoneListElementsToDelete);
  #endif
  return listOfStoneListElementsToDelete;
}


void game_getNumberOfAdjacentDiagonals(LISTELEMENT *source, int height, int *topleft, int *topright, int *bottomleft, int *bottomright){

  *topleft = *topright = *bottomleft = *bottomright = 0;
  const int posX = ((COL*) (source->data))->posX;

  LISTELEMENT* temp = source;

  //check top left
  while (
    //there is a col left
    temp->prev != NULL &&
    //its distance is 1 + # of left adjacent cols
    ((COL*)(temp->prev->data) )->posX == posX - *topleft - 1 &&
    //its height is 1 more then number of left adjacent cols
    ((COL*)(temp->prev->data) )->stones->length >= height + 1 + *topleft + 1
  ){
    //icrease left count and check next col
    *topleft += 1 ;

    //we need to check max 3 left/right
    if ( *topleft == 3){
      break;
    }

    temp = temp->prev;
  }

  //check bottom left
  temp = source;
  while (
    //there is a col left
    temp->prev != NULL &&
    //its distance is 1 + # of left adjacent cols
    ((COL*)(temp->prev->data) )->posX == posX - *bottomleft - 1 &&
    //its height is 1 less then number of left adjacent cols
    ((COL*)(temp->prev->data) )->stones->length >= height + 1 - *bottomleft - 1 && height + 1 - *bottomleft - 1 > 0
  ){
    //icrease left count and check next col
    *bottomleft += 1 ;

    //we need to check max 3 left/right
    if ( *bottomleft == 3){
      break;
    }

    temp = temp->prev;
  }


  //check top right
  temp = source;
  while (
    //there is a col right
    temp->next != NULL &&
    //its distance is 1 + # of right adjacent cols
    ((COL*)(temp->next->data) )->posX == posX + *topright + 1 &&
    //its height is 1 more then number of right adjacent cols
    ((COL*)(temp->next->data) )->stones->length >= height + 1 + *topright + 1
  ){
    //icrease left count and check next col
    *topright += 1 ;

    //we need to check max 3 left/right
    if ( *topright == 3){
      break;
    }

    temp = temp->next;
  }

  //check bottom right
  temp = source;
  while (
    //there is a col left
    temp->next != NULL &&
    //its distance is 1 + # of right adjacent cols
    ((COL*)(temp->next->data) )->posX == posX + *bottomright + 1 &&
    //its height is 1 less then number of right adjacent cols
    ((COL*)(temp->next->data) )->stones->length >= height + 1 - *bottomright - 1 && height + 1 - *bottomright - 1 > 0
  ){
    //icrease left count and check next col
    *bottomright += 1 ;

    //we need to check max 3 left/right
    if ( *bottomright == 3){
      break;
    }

    temp = temp->next;
  }


  //printf("Adjacent Diagonals for posX: %i posY: %i are topleft: %i, topright: %i, bottomleft: %i, bottomright:%i (left: %i, right: %i).\n",posX, height, *topleft, *topright, *bottomleft, *bottomright, left, right);
  return;
}

void game_getNumberOfAdjacentColsWithEqualOrHigherHeight(LISTELEMENT *source, int height, int *left, int *right){

  *left = *right = 0;
  
   //the posX we are in
  const int posX = ((COL*) (source->data))->posX;


  LISTELEMENT *temp = source;

  //checking left
  while (
    //there is a col left
    temp->prev != NULL &&
    //its distance is 1 + # of left adjacent cols
    ((COL*)(temp->prev->data) )->posX == posX- *left - 1 &&
    //it is higher or same height as source col
    ((COL*)(temp->prev->data) )->stones->length >= height + 1
  ){
    //icrease left count and check next col
    *left += 1;

    //we need to check max 3 left/right
    if ( *left == 3){
      break;
    }

    temp = temp->prev;
  }

  //checking right
  temp = source;
  while (
    //there is a col right
    temp->next != NULL &&
    //its distance is 1 + # of right adjacent cols
    ((COL*)(temp->next->data) )->posX == posX + *right + 1 &&
    //it is higher or same height as source col
    ((COL*)(temp->next->data) )->stones->length >= height + 1
  ){
    //icrease right count and check next col
    *right += 1;
    //we need to check max 3 left/right
    if ( *right == 3){
      break;
    }
    temp = temp->next;
  }

}


void game_getNumberOfAdjacentCols(LISTELEMENT *source, int *left, int *right){

  *left = *right = 0;

  COL *thisCol = (COL*) (source->data);

   //the posX we are in
  const int posX = thisCol->posX;


  LISTELEMENT *temp = source;

  //checking left
  while (
    //there is a col left
    temp->prev != NULL &&
    //its distance is 1 + # of left adjacent cols
    ((COL*)(temp->prev->data) )->posX == posX- *left - 1
  ){
    //icrease left count and check next col
    *left += 1;

    //we need to check max 3 left/right
    if ( *left == 3){
      break;
    }

    temp = temp->prev;
  }

  //checking right
  temp = source;
  while (
    //there is a col right
    temp->next != NULL &&
    //its distance is 1 + # of right adjacent cols
    ((COL*)(temp->next->data) )->posX == posX + *right + 1
  ){
    //icrease right count and check next col
    *right += 1;
    //we need to check max 3 left/right
    if ( *right == 3){
      break;
    }
    temp = temp->next;
  }

}



STONE *game_addStoneToPlayingfield(LIST_H* playingfield, int color, int posX){

  dprintf("Start Adding Stone.\n");
  
  //create a new col for the playingfield. list of stones in this col will be null at first
  COL *newCol = col_init(posX, NULL);
  if( newCol == NULL ){
    //outof memory
    return NULL;
  }

  
  //add the col to the playingfield (sorted), if a listelement with the col allready exists, the existing listelement will be returned
  //otherwise a new listelement will be created and returned
  LISTELEMENT *newListElementWithCol = listH_addSorted(playingfield, newCol);
  if( newListElementWithCol == NULL ){
    //out of memory
    return NULL;
  }

  //crete the new stone to add to the playing field
  STONE *newStone = stone_init(color, posX, newListElementWithCol->data);
  if( newStone == NULL ){
    //out of memory
    return NULL;
  }

  if ( ((COL*) (newListElementWithCol->data) )->stones == NULL ){
    //Col in the returned listelement has no stone List yet, this will be the first stone in the col
    dprintf("creating new stonelist in col %i\n", posX);
    #if defined DEBUG && DEBUG < 0
      count_stoneListInCol++;
    #endif
    LIST *stoneListInCol = list_init(stone_destroy, stone_print, stone_compare);
    if( stoneListInCol == NULL ){
      //outof memory
      return NULL;
    }
    
    newStone->myLE = list_addTail( stoneListInCol, newStone);

    ((COL*) (newListElementWithCol->data) )->stones = stoneListInCol;

  }
  else{

    //col has a stone list allready, adding new stone to it
    newStone->myLE = list_addTail( ( (COL*) (newListElementWithCol->data) )->stones, newStone);
    //destroying newCol because we did not use it
    free(newCol);

  }
  dprintf("Done Adding Stone. Returning.\n");
  return newStone;

}

int game_doReduction(LIST_H *playingfield, STONE *newStone){

  dprintf("Starting game_doReduction().\n");

  LIST *listOfListElementsWithStoneToDelete = game_getStonesToDelete(playingfield, newStone);
  if (listOfListElementsWithStoneToDelete == NULL){
    dprintf("Out of memory is here.\n");
    return -1;
  }

  #if defined(DEBUG) && DEBUG > 0
    int reductionRunCounter = 0;
  #endif

  #if defined(DEBUG) && DEBUG > 1
    d2printf("playingfield is: \n");
    listH_print(playingfield);
  #endif

  while( listOfListElementsWithStoneToDelete->length > 0 ){

    dprintf("Start reduction run %i, %i stones to delete.\n", reductionRunCounter, listOfListElementsWithStoneToDelete->length);
    #if defined(DEBUG) && DEBUG > 1
      dprintf("listOfListElementsWithStoneToDelete is:\n")
      list_print(listOfListElementsWithStoneToDelete);
    #endif


    LIST_H *listOfStonesToCheck = listH_init(stone_destroy, stone_print, stone_compare, stone_getKey, MAX_HASH);
    if (listOfStonesToCheck == NULL){
      list_destroy(listOfListElementsWithStoneToDelete);
      dprintf("Out of memory is here.\n");
      return -1;
    }


    LIST_H *tempListOfFollowUpListelementsWithStones = listH_init(listelement_destroy, listelement_print, listelement_compare, listelement_getKey, MAX_HASH);
    if (tempListOfFollowUpListelementsWithStones == NULL){
      list_destroy(listOfListElementsWithStoneToDelete);
      listH_destroy(listOfStonesToCheck);
      dprintf("Out of memory is here.\n");
      return -1;
    }

    for (LISTELEMENT* listElement = listOfListElementsWithStoneToDelete->head; listElement != NULL; listElement = listOfListElementsWithStoneToDelete->head){
      dprintf("start deletion for a element.\n");
      //all stones that are above the stone that we will delete, need to be checked after deletion
      //but not the stones we will delete this run
      //also we only need to add each stone once
      LISTELEMENT* stoneLE = ((LISTELEMENT*) (listElement->data))->next;
      if ( stoneLE != NULL &&
           list_getElementByData(listOfListElementsWithStoneToDelete, stoneLE) == NULL && //followup stone is not a stone we are going to delete
           listH_getElementByData(tempListOfFollowUpListelementsWithStones, stoneLE ) == NULL //followup stone is not allready in list of followups
      ){

        if (MEM_ERROR){
          return -1;
        }
        
        if (stoneLE->data != NULL){
          dprintf("we have a followup stone (posX: %i, posY: %i, color: %i).\n",((STONE*)(stoneLE->data))->posX , stone_getHeight( ((STONE*)(stoneLE->data)) ),  ((STONE*)(stoneLE->data))->color);
          
        }
        else{
          dprintf("followup stoneLE has no data.\n");
        }

        dprintf("Adding followup Listelement with Stone.\n");
        listH_addTail(tempListOfFollowUpListelementsWithStones, stoneLE);

        #if defined(DEBUG) && DEBUG > 1
          dprintf("tempListOfFollowUpListelementsWithStones is now.\n");
          listH_print(tempListOfFollowUpListelementsWithStones);
        #endif
      }
      else{
        if (MEM_ERROR){
          return -1;
        }
        dprintf("No followup Listelement with Stone to add.\n");
      }


      #if defined(DEBUG) && DEBUG > 0
        STONE* stone = ((LISTELEMENT*) (listElement->data))->data;
      #endif
      dprintf("deleting Stone (posX: %i, posY: %i, color: %i).\n", stone->posX, stone_getHeight(stone), stone->color);

      list_deleteElement(listElement->data);
      
      
      listElement->data = NULL;
      list_deleteHead(listOfListElementsWithStoneToDelete);
      dprintf("done deleting.\n");
    }

    #if defined(DEBUG) && DEBUG > 1
      dprintf("listOfListElementsWithStoneToDelete is:\n")
      list_print(listOfListElementsWithStoneToDelete);
      dprintf("playingfield after deletion is:\n");
      listH_print(playingfield);
      dprintf("done deleting stones for run %i.\n", reductionRunCounter);
      dprintf("followuplist has %i listelements:\n", tempListOfFollowUpListelementsWithStones->length);
      listH_print(tempListOfFollowUpListelementsWithStones);
    #endif

    
    #if defined(DEBUG) && DEBUG > 0
      int i= 1;
    #endif

    //for each listelement with a followup stone that we need to check
    for (LISTELEMENT* listElement = tempListOfFollowUpListelementsWithStones->head; listElement != NULL; listElement = listElement->next){
      // add the stonedata from the element it self and all elements that follow in that stonelist
      if ( listH_getElementByData(listOfStonesToCheck, ((LISTELEMENT*)(listElement->data))->data ) == NULL){
        //if we allready have the stone in our list of stones to delete, this mean we also allready added all stones above the stone to the list of stones to delete

        if (MEM_ERROR){
          return -1;
        }

        #if defined(DEBUG) && DEBUG > 0
          STONE* followupStone = ((LISTELEMENT*)(listElement->data))->data;
          int height = stone_getHeight(followupStone);
        #endif
        
        dprintf("adding stones above %i. followup stone (posX: %i, posY: %i, color: %i).\n",i++ , followupStone->posX, height, followupStone->color );
        
        for ( LISTELEMENT* temp = listElement->data; temp != NULL; temp = temp->next){

          if ( temp->data != NULL ){

            #if defined(DEBUG) && DEBUG > 0
              STONE* stoneToAdd = ((STONE*)(temp->data));
              int height = stone_getHeight(stoneToAdd);
            #endif

            dprintf("Adding followup Stone to check for reduction (posX: %i, posY: %i, color: %i).\n", stoneToAdd->posX, height, stoneToAdd->color );
            listH_addTail(listOfStonesToCheck, temp->data);
          }
          
        }
      }

      if (MEM_ERROR){
        return -1;
      }
      
      //removing element from list without deleting it
      listElement->data = NULL;
      
    }

    

    //for each stone we need to check, get the list of stones to delete and add it to listOfListElementsWithStoneToDelete
    for (LISTELEMENT* stoneLE = listOfStonesToCheck->head; stoneLE != NULL; stoneLE = listOfStonesToCheck->head ){

      LIST *newListElementsToDelete = game_getStonesToDelete(playingfield, stoneLE->data);
      if (MEM_ERROR){
        return -1;
      }

      if (newListElementsToDelete != NULL){
        dprintf("Got %i new Listelements with Stones to delete from a followup Stone\n", newListElementsToDelete->length);
      }
      else{
        dprintf("Got NO new Listelements with Stones to delete from a followup Stone\n");
      }
      
      if (newListElementsToDelete->length > 0){
        list_mergeWithDuplicates(listOfListElementsWithStoneToDelete, newListElementsToDelete);
        dprintf("merged list with master list.. now has length %i:\n",listOfListElementsWithStoneToDelete->length);
        #if defined(DEBUG) && DEBUG > 1
          list_print(listOfListElementsWithStoneToDelete);
        #endif
      }
      else{

        list_destroy(newListElementsToDelete);

      }

      stoneLE->data = NULL;
      listH_deleteHead(listOfStonesToCheck);

      
      #if defined(DEBUG) && DEBUG > 1
        dprintf("listOfStonesToCheck now: \n");
        listH_print(listOfStonesToCheck);
      #endif
      
      
    }
    d2printf("tempListOfFollowUpListelementsWithStones BEFORE FREEING IS: \n");
    #if defined(DEBUG) && DEBUG > 1
      listH_print(tempListOfFollowUpListelementsWithStones);
    #endif

    list_removeDuplicateData(listOfListElementsWithStoneToDelete);
    
    listH_destroy(tempListOfFollowUpListelementsWithStones);

    listH_destroy(listOfStonesToCheck);
    dprintf("==============================================================\n");
    dprintf("done reduction run %i, %i followup stones to delete.\n", reductionRunCounter++, listOfListElementsWithStoneToDelete->length);
  }
  dprintf("================================================================\n");
  dprintf("done all reduction runs. doing cleanup.\n")
  //listH_destroy(listOfStonesToCheck);
  list_destroy(listOfListElementsWithStoneToDelete);
  #if defined DEBUG && DEBUG > 1
    hash_print(playingfield->myHashTable);
  #endif
  dprintf("cleanup done. exiting function.\n")
  return 0;

}




//________________________MAIN_____________________________
//================================================================================================================
//================================================================================================================

int main(void){

  //compile regex from aufgabenstellung
  regex_t regex;
  int regexResult;
  regexResult = regcomp(&regex, regular_expression, REG_EXTENDED);
  if (regexResult == REG_ESPACE) {
      fprintf(stderr, "Could not compile regex, Out of memory.\n");
      exit(1);
  }

  LIST_H *playingfield = listH_init(col_destroy, col_print, col_compare, col_getKey, MAX_HASH);
  if( playingfield == NULL ){
    fprintf(stderr, "Out of Memory.\n");
    regfree(&regex);
    exit(1);
  }


  //init input stringbuffer
  char *str = calloc(1, MAX_INPUTLENGTH * sizeof(char) );

  long counter = 0;
  int color, posX;

  size_t gl = getline(&str, &MAX_INPUTLENGTH, stdin);
  //read input stream
  while( gl != (size_t) -1 ){
    //dprintf("read line is '%s', gl = %i, strlen = %i.\n", str, gl, strlen(str));
    if ( gl == strlen(str) && str[strlen(str)-1] == '\n')
      str[strlen(str)-1] = '\0';
    else if( gl == strlen(str) ) {
    }
    else{
      fprintf(stderr, "Input Error.\n");
      regfree(&regex);
      free(str);
      listH_destroy(playingfield);
      exit(1);
    }
    dprintf("\n\nline read is '%s'.\n",  str);

    //check if numbers are in valid range
    if (strlen(str) == 0  || !check_and_compile_numbers(&color, &posX, str, &regex)){
      fprintf(stderr, "error reading input\n");
      regfree(&regex);
      free(str);
      listH_destroy(playingfield);
      exit(1);
    }
    else{
      //if yes add stone to list
      
      counter++;

      #if defined(DEBUG) && DEBUG > 0
        dprintf("Adding stone #%li with color %i to col %i.\n", counter, color, posX);
      #endif

      //adding stone to playingfield
      STONE *newStone = game_addStoneToPlayingfield(playingfield, color, posX);
      if (newStone == NULL){
        regfree(&regex);
        free(str);
        listH_destroy(playingfield);
        exit(1);
      }

      //check for reduction
      if ( game_doReduction( playingfield, newStone) == -1){
        regfree(&regex);
        free(str);
        listH_destroy(playingfield);
        exit(1);
      };

    }

    //memset(str, 0,  MAX_INPUTLENGTH * sizeof(char) );
    str[0] = '\0';
    gl = getline(&str, &MAX_INPUTLENGTH, stdin);
  } //endwhile

  dprintf("last read line is '%s', gl = %li, strlen = %li.\n", str, gl, strlen(str));
  if ( gl == (size_t) -1 && strlen(str) == 0 ) {
    
  }
  else if ( gl == (size_t) -1 && str[strlen(str)-1] == '\n' ) {
    str[strlen(str)-1] = '\0';
  }
  else{
    fprintf(stderr, "Some Crazy String \\0 shenannigans.\n");
    regfree(&regex);
    free(str);
    listH_destroy(playingfield);
    exit(1);
  }
    
  if ( !strlen(str) == 0) {
    //if we have a non zero string
    //check if numbers are in valid range
    if ( !check_and_compile_numbers(&color, &posX, str, &regex) ){
      regfree(&regex);
      free(str);
      listH_destroy(playingfield);
      exit(1);
    }
    else{
      //if yes add stone to list
      dprintf("\n\nAdding last stone with color %i to col %i.\n", color, posX);

      STONE *newStone = game_addStoneToPlayingfield(playingfield, color, posX);
      if (newStone == NULL){
        regfree(&regex);
        free(str);
        listH_destroy(playingfield);
        exit(1);
      }

      //check for reduction
      if ( game_doReduction( playingfield, newStone) == -1){
        regfree(&regex);
        free(str);
        listH_destroy(playingfield);
        exit(1);
      };
      
    }
  }


  //clean up stuff we dont need anymore
  regfree(&regex);
  free(str);
  
  dprintf("\nPrinting Playingfield\n");
  listH_print(playingfield); 
  
  #if defined DEBUG && DEBUG > 1
    hash_print(playingfield->myHashTable);
  #endif

  listH_destroy(playingfield);

  #if defined DEBUG && DEBUG < 0
    fprintf(stderr, "calloc_htable = %i\nmalloc_hentry = %i\nmalloc_listH = %i\nmalloc_key = %i\nmalloc_list = %i\nmalloc_listelement = %i\nmalloc_col = %i\nmalloc_stone = %i\n",calloc_htable, malloc_hentry, malloc_listH, malloc_key, malloc_list, malloc_listelement, malloc_col, malloc_stone);
    fprintf(stderr, "\ncount_listOfStoneListElementsToDelete = %i\ncount_lists_gameGetStones = %i\ncount_stoneListInCol = %i\n", count_listOfStoneListElementsToDelete, count_lists_gameGetStones, count_stoneListInCol);
  #endif

  return EXIT_SUCCESS;
}
