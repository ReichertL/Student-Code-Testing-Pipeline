#include <stdio.h>
#include <stdlib.h>

#define true 1
#define false 0

int ERRNO = 0;

typedef unsigned int bool;
typedef unsigned char piece;

typedef struct baseNode_s{
    int lowestPieceChange;
    int posX;
    piece *pieces;
    int size;     // potentieller Platz
    int count;      // ausgeschoepfter Platz
    struct baseNode_s* next;
    struct baseNode_s* prev;
} baseNode_t;


// struct PieceRemoval 
// array with pointer and y pos
typedef struct pieceRemoval_s{
    baseNode_t* baseNode;
    int posY;
} pieceRemoval_t;


// changedNodeList
// array with pointers to changed nodes
typedef struct changedNode_s{
    baseNode_t** changeNode;
    int size;
    int count;
} changeNode_t;

typedef struct gameField_s{
    baseNode_t* baseNodeList;
    int size;
    int count;
} gameField_t;

int insert_piece(gameField_t* gameField, piece color, int posX);
int getBaseNode(gameField_t* gameField, int posX, baseNode_t** retval);
int createNewBaseNode(gameField_t* gameField, int posX, baseNode_t** retval);
int findNearestBaseNode(baseNode_t* currentBaseNode, int approximateValue, bool upwards, baseNode_t** retVal);
void printAusgabe(gameField_t* gameField);
int gameFieldUpdate(gameField_t* gameField, changeNode_t* changedNodeList, pieceRemoval_t* pieceRemovalList, piece* color);

// Process Input

int processInput(gameField_t* gameField){
    // return 0: success
    // return 7: E : unallowed character found on stdin

    char c;

    while(true){
        c = getchar();

        if((int) c == EOF){ break; }

        if ((int) c == 10){ continue; }

        int value = 0;
        
        while (true)
        {
            if ((int) c < 48 || (int) c > 57) { ERRNO = 7; goto err1; }

            // statemachine color identifier (0-9)*
            value = value * 10 + (int) c - 48;

            c = getchar();
            if (c == ' ') { break; }
        }

        if (value >= 255){ ERRNO = 6 ; goto err1; }
        c = getchar();
        int mult = 1;

        if (c == '-') 
        { 
            mult = -1;
            c = getchar();
        }

        int xPos = 0;

        // statemachine level identifier [-](0-9)*
        while (true)
        {
            if ((int) c < 48 || (int) c > 57) { ERRNO = 7; goto err1; }

            // statemachine color identifier (0-9)*
            xPos = xPos * 10 + (int) c - 48;

            c = getchar();
            if (c == '\n' || c == EOF) { break; }
        }

        xPos = mult * xPos;

        // insert piece
        if(insert_piece(gameField, (piece) value, xPos)) { goto err1; } ;

        if(c == EOF){ break; }


    }
    return 0;

    //error handling
err1:
    return ERRNO;

}

int insert_piece(gameField_t* gameField, piece color, int posX){

    // insert changenNodeList struct here
    changeNode_t* changedNodeList = (changeNode_t*)malloc(sizeof(changeNode_t));
    if (!changedNodeList) { ERRNO = 2 ; goto err1; }

    // allocate Pieceremoval struct
    pieceRemoval_t* pieceRemovalList = (pieceRemoval_t*)malloc(sizeof(pieceRemoval_t));
    if (!pieceRemovalList) { ERRNO = 2; goto err2; }
    
    
    // get basenode to insert too
    baseNode_t* currentBaseNode;
    int tmp = getBaseNode(gameField, posX, &currentBaseNode);

    if (ERRNO){ goto err1; }
    
    if (tmp == 1)
    {
        if(createNewBaseNode(gameField, posX, &currentBaseNode)) { goto err1; };
    }
    
    // insert piece to basenode
    
    // test ab hier

    if (currentBaseNode->count >= currentBaseNode->size){

        piece* tmp = (piece*) realloc(currentBaseNode->pieces, 2* currentBaseNode->size * sizeof(piece));
        if (!tmp) { ERRNO = 2; goto err1; }
        currentBaseNode->size = 2* currentBaseNode->size;

        currentBaseNode->pieces = tmp;
    }

    currentBaseNode->pieces[currentBaseNode->count] = color;
    currentBaseNode->count++;

    // gameFieldUpdate() - vertical, horizontal, diagonal

    gameFieldUpdate(gameField, changedNodeList, pieceRemovalList, &color);

    free(changedNodeList);

    return 0; 


    // error handling
err2:
    free(changedNodeList);
err1:
    return ERRNO;
 
}

int createNewBaseNode(gameField_t* gameField, int posX, baseNode_t** retval){    
    if(gameField->count == 0){
        gameField->baseNodeList->pieces = (piece*)malloc(sizeof(piece));
        if(!gameField->baseNodeList->pieces) { ERRNO = 2; goto err1; }

        gameField->baseNodeList->size = 1;
        gameField->baseNodeList->count = 0;
        gameField->baseNodeList->posX = posX;
        gameField->baseNodeList->prev = NULL;
        gameField->baseNodeList->next = NULL;
        gameField->baseNodeList->lowestPieceChange = -1;
        gameField->count = 1;
        *retval = &(gameField->baseNodeList[0]);
    }  
    else
    {
        
        if (gameField->count + 1 > gameField->size) {
            baseNode_t* tmp = (baseNode_t*) realloc(gameField->baseNodeList, 2* gameField->size * sizeof(baseNode_t));
            if (!tmp) { ERRNO = 2; goto err1; }
            gameField->size = 2* gameField->size;

            gameField->baseNodeList = tmp;
        }
        gameField->count = gameField->count + 1;
        gameField->baseNodeList[gameField->count-1].pieces = (piece*) malloc(sizeof(piece));
        gameField->baseNodeList[gameField->count-1].size = 1;
        gameField->baseNodeList[gameField->count-1].count = 0;
        gameField->baseNodeList[gameField->count-1].posX = posX;
        gameField->baseNodeList[gameField->count-1].lowestPieceChange = -1;
        *retval = &(gameField->baseNodeList[gameField->count-1]);

        baseNode_t* nearestBaseNode;
        if (gameField->baseNodeList[0].posX < posX) {
            findNearestBaseNode(gameField->baseNodeList, posX, 1, &nearestBaseNode);
            gameField->baseNodeList[gameField->count-1].prev = nearestBaseNode;
            gameField->baseNodeList[gameField->count-1].next = nearestBaseNode->next;
            if (nearestBaseNode->next != NULL){
                nearestBaseNode->next->prev = &gameField->baseNodeList[gameField->count-1];
            }
            nearestBaseNode->next = &gameField->baseNodeList[gameField->count-1];
        } else {
            findNearestBaseNode(gameField->baseNodeList, posX, 0, &nearestBaseNode);
            gameField->baseNodeList[gameField->count-1].next = nearestBaseNode;
            gameField->baseNodeList[gameField->count-1].prev = nearestBaseNode->prev;
            if (nearestBaseNode->prev != NULL){
                nearestBaseNode->prev->next = &gameField->baseNodeList[gameField->count-1];
            }
            nearestBaseNode->prev = &gameField->baseNodeList[gameField->count-1];
        }
    }
    return 0;

err1:
    return ERRNO;
}

int findNearestBaseNode(baseNode_t* currentBaseNode, int approximateValue, bool upwards, baseNode_t** retVal) {
    if (upwards) {
        if (currentBaseNode->next == NULL) {
            *retVal = currentBaseNode;
        } else if (approximateValue < currentBaseNode->posX){
            *retVal = currentBaseNode->prev;
        } else {
            findNearestBaseNode(currentBaseNode->next, approximateValue, upwards, retVal);
        }
    } else  {
        if (currentBaseNode->prev == NULL) {
            *retVal = currentBaseNode;
        } else if (approximateValue > currentBaseNode->posX){
           *retVal = currentBaseNode->next;
        } else {
           findNearestBaseNode(currentBaseNode->prev, approximateValue, upwards, retVal);
        }
    }
    
    return 0;
}

int getBaseNode(gameField_t* gameField, int posX, baseNode_t** retval){

    if(gameField->count == 0){ return 1; }  

    bool upwards = false;
    if (gameField->baseNodeList[0].posX < posX)
    {
        upwards = true;
    }
        
    findNearestBaseNode(&gameField->baseNodeList[0], posX, upwards, retval);

    if((*retval)->posX == posX){

        return 0;
    } 

    return 1;
err1:
    return ERRNO;

}

int destroyField(gameField_t* gameField){
    for (int i = 0; i < gameField->count; i++)
    {
        
    if (gameField->baseNodeList[i].size == 0){
        free(gameField->baseNodeList[i].pieces);
        gameField->baseNodeList[i].size = 0;
        } 
    }

    return 0;
}

int gameFieldUpdate(gameField_t* gameField, changeNode_t* changedNodeList, pieceRemoval_t* pieceRemovalList, piece* color){

    // check for all nodes in the toCheck list
    // all rows
    // vertical, horizontal , diagnoal
    // check and fill PieceRemoval list

    int rowcount = 0;
    int heightcount = 0;
    int diagonalcount = 0;
    unsigned char deleteColor = 255;

    for (int i = 0; i < gameField->count; i++)
    {
            for (int j = 0; j < gameField->baseNodeList->count; j++)
            {
                if (gameField->baseNodeList[i].pieces[j] == deleteColor)
                {
                    return 0;
                }
                else if (gameField->baseNodeList[i].pieces[j] == *color)
                {
                    rowcount++;
                }
                
                
            }
            
    }
    

    fprintf(stderr, " %d ", rowcount);
    

    // insert PieceRemovalList into gameField 


    // check all changed Nodes into changedNodeList and fill the list


    // use changedNodeList to let the pieces fall_down()


    gameFieldUpdate(gameField, changedNodeList, pieceRemovalList, color);


    // return if changeNodeList is NULL

    return 0;

    // error handling

}

/*

int fallDownPieces(changedNode_t changedNodeList, baseNode_t gameField){

    // for each node in changenodelist
    // take lowestPieceChange and iterate through array
    // two iterator 
    // get throught the list and copy all values from the changeNodeList into gameField
    // skip 255 values


    // return gameField


    return 0;
    // error handling

}


int getColor(int x, int y){

    // return color on the given position
    return 0;
}

*/

void printAusgabe(gameField_t* gameField){
    fprintf(stderr, "VVV\n");
    for (int i = 0; i < gameField->count; i++)
    {
        fprintf(stderr, " %d : ", gameField->baseNodeList[i].posX);
        for (int j = 0; j < gameField->baseNodeList->size; j++)
        {
            fprintf(stderr, " %d ", gameField->baseNodeList[i].pieces[j]);
        }
        fprintf(stderr, "\n");
        
    }
    fprintf(stderr, "\nAAA\n");
}

int main(int argc, char** argv){

   //baseNode_t* gameField = (baseNode_t*)malloc(sizeof(baseNode_t));

    gameField_t* gameField = (gameField_t*)malloc(sizeof(gameField_t));
    if (!gameField) { ERRNO = 2; goto err1; }
    
    gameField->baseNodeList = (baseNode_t*)malloc(sizeof(baseNode_t));
    if (!gameField->baseNodeList) { ERRNO = 2; goto err2; }
    gameField->size = 1;
    gameField->count = 0;

    if(processInput(gameField)){ goto err3; };

    printAusgabe(gameField);


    destroyField(gameField);
    free(gameField->baseNodeList);
    free(gameField);

    return 0;
err3:
    destroyField(gameField);            //position check if its right
    free(gameField->baseNodeList);
err2:
    free(gameField);
err1:
    fprintf(stderr, "ERRNO = %i", ERRNO);
    return ERRNO;
}