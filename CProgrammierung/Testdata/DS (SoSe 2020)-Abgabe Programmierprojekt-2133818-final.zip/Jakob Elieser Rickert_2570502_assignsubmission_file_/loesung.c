#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define BOARD_INIT_SIZE 64
#define ROW_SUCCESS_LEN 4

unsigned global_x;            //für die Übermittlung von board_add an first_check
int global_y;                 //

struct Board {
	uint8_t** fields;
	unsigned width;
	unsigned height;
	unsigned offset;
};


void board_destroy(struct Board *board) {
	for (int i = 0; i < board->width; i++)
		free(board->fields[i]);
	free(board->fields);
	free(board);
}

struct Board *board_init() {
	struct Board *board = malloc(sizeof(struct Board));
	if (!board) {
		fprintf(stderr, "board nicht erstellbar\n");
		exit(1);
	}
	board->fields = malloc(BOARD_INIT_SIZE * sizeof(uint8_t *));
	if (board == NULL){
		fprintf(stderr, "board nicht erstellbar\n");
		exit(1);
	}
	for (int i=0; i < BOARD_INIT_SIZE; i++){
		board->fields[i] = calloc(BOARD_INIT_SIZE, sizeof(uint8_t));
		if (board->fields[i] == NULL){
			fprintf(stderr, "board nicht erstellbar\n");
			exit(1);
		}
	}
	board->width = BOARD_INIT_SIZE;
	board->height = BOARD_INIT_SIZE;
	board->offset = 0;
	return board;
}

void board_double_width(struct Board *board) {
	uint8_t **tmp = realloc(board->fields, board->width * 2 * sizeof(uint8_t*));
	if (!tmp) {
		board_destroy(board);
		fprintf(stderr, "board nicht verbreiterbar\n");
		exit(1);
	}
	board->fields = tmp;
	for (int i = board->width; i < board->width*2; i++) {
		board->fields[i] = calloc(board->height, sizeof(uint8_t));
		if (board->fields[i] == NULL){
			fprintf(stderr, "board nicht verbreiterbar\n");
			exit(1);
		}
	}
	board->width *= 2;
}

void board_shift (struct Board *board) {
	unsigned shift = board->width;
	board_double_width(board);
	for (int i = 0; i < shift; i++) {
		uint8_t *tmp = board->fields[i];
		board->fields[i] = board->fields[i + shift];
		board->fields[i + shift] = tmp;
	}
	board->offset += shift;
}


void board_double_height(struct Board *board){
	for (int i = 0; i < board->width; i++) {
		uint8_t *tmp = realloc(board->fields[i], board->height * 2 * sizeof(uint8_t));
		if (!tmp) {
			board_destroy(board);
			fprintf(stderr, "board nicht verhöherbar\n");
			exit(1);
		}
		for (int j = board->height; j < board->height * 2; j++) {
			tmp[j] = 0;
		}
		board->fields[i] = tmp;
	}
	board->height *= 2;
}

void board_add(struct Board *board, int x, uint8_t farbe) {
	while (x + (int)board->offset < 0)
		board_shift(board);
	while (x + board->offset >= board->width)
		board_double_width(board);
	unsigned pos = x + board->offset;
	global_x = pos;
	for (int i = 0; i < board->height; i++) {
		if (board->fields[pos][i] == 0) {
			board->fields[pos][i] = farbe + 1;
			global_y = i;
			return;
		}
	}
	board_double_height(board);
	board->fields[pos][board->height/2] = farbe +1;
	global_y = board->height/2;
}

int get_farbe (uint8_t *ergebnis) {
	/*ergebnis* = calloc(1, sizeof(uint8_t));
	if (ergebnis == NULL) {
		fprintf(stderr, "Variable ergebnis (farbe) nicht erstellbar");
		exit(1);
	}*/
	char *farbe = calloc(3, sizeof(char));
	if (farbe == NULL) {
		fprintf(stderr, "Array farbe nicht erstellbar");
		exit(1);
	}
	int farbe_int = 0;
	char new_char;
	int dreistellig = 1;
	for (int i = 0; i < 3; i++) {
		new_char = getchar();
		if (new_char == EOF) {
			if (i == 0)
				return 1;
			fprintf(stderr, "Invalide Eingabe\n");
			exit(1);
		}
		if (new_char <= 57 && new_char >= 48) {
			farbe[i] = new_char;
			continue;
		}
		if (new_char == 32) {
			dreistellig = 0;
			break;
		}
		fprintf(stderr, "ungültiges Zeichen gelesen\n");
		exit(1);
	}
	if (dreistellig) {
		if (getchar() != 32) {
			fprintf(stderr, "ungültiges Zeichen gelesen und/oder Farbe zu groß\n");
			exit(1);
		}
	}
	for (int i = 0; i < 3; i++) {
		if (!farbe[i])
			break;
		farbe_int = farbe_int * 10 + (farbe[i] - 48);
	}
	if (farbe_int > 254) {
		fprintf(stderr, "Farbe zu groß\n");
		exit(1);
	}
	*ergebnis = (uint8_t) farbe_int;
	free(farbe);
	return 0;
}

int get_x (int *ergebnis) {
	char *x = calloc(7, sizeof(char));    // weilich davon ausgehen darf, dass |x| <= 2**20
	/*ergebnis* = calloc(1, sizeof(int));
	if (ergebnis == NULL) {
		fprintf(stderr, "Variable ergebnis (x) nicht erstellbar");
		exit(1);
	}*/
	if (x == NULL) {
		fprintf(stderr, "Array x nicht erstellbar");
		exit(1);
	}
	int x_int = 0;
	int vorzeichen = 1;
	int siebenstellig = 0;                // <--
	char new_char = getchar();
	while (new_char == 32) {
		new_char = getchar();
	}
	if (new_char == 45) {
		vorzeichen = -1;
		new_char = getchar();
	}
	if (new_char < 48 || new_char > 57) {
		fprintf(stderr, "ungültiges Zeichen gelesen und/oder ungültiges Eingabeformat\n");
		exit(1);
	}
	x[0] = new_char;
	for (int i = 1; i < 7; i++) {
		new_char = getchar();
		if (new_char == EOF)         // !!!
			break;
		if (new_char == 10)
			break;
		if (new_char > 57 || new_char < 48) {
			fprintf(stderr, "ungültiges Zeichen");
			exit(1);
		}
		x[i] = new_char;
		if (i == 6)
			siebenstellig = 1;
	}
	for ( int i = 0; i < 7; i++) {
		if (!x[i])
			break;
		x_int = x_int * 10 + vorzeichen * (x[i] - 48);
	}
	if (siebenstellig) { // naechstes Zeichen prüfen
		new_char = getchar();
		if (new_char != EOF && new_char != 10) {
			fprintf(stderr, "ungültige Eingabe: x zu groß oder von ungültigen Zeichen gefolgt");
			exit(1);
		}
	}
	free(x);
	*ergebnis = x_int;
	return 0;
		
}

int read (struct Board *board) {
	uint8_t *farbe = calloc(1, sizeof(uint8_t));
	if (farbe == NULL) {
		fprintf(stderr, "Variable farbe nicht erstellbar");
		exit(1);
	}
	int *x = calloc(1, sizeof(int));
	if (x == NULL) {
		fprintf(stderr, "Variable x nicht erstellbar");
		exit(1);
	}
	if (get_farbe(farbe))
		return 0;
	get_x(x);
	/*int letzter = get_x(x);
	if (letzter)
		while(further_check(board))*/
	uint8_t farbe_int = *farbe;
	int x_int = *x;
	free(farbe);
	free(x);
	board_add(board, x_int, farbe_int);
	return 1;
}
		

int read2 (struct Board *board){
	uint8_t farbe = 0;
	int x = 0;
	int ret = scanf("%hhd %d", &farbe, &x);
	if (ret == EOF){
		return 0;
	}else if(ret != 2){
		fprintf(stderr, "invalide Eingabe\n");
		exit(1);
	}
	board_add(board, x, farbe);
	//printf("farbe: %d \n", farbe);
	//printf("x: %d \n", x);
	return 1;
}

void destroy_loeschtabelle (int **loeschtabelle) {
	for (int i = 0; i < 3; i++) {
		free(loeschtabelle[i]);
	}
	free(loeschtabelle);
}

void double_loeschtabelle (int **loeschtabelle, int len) {
	for (int i = 3; i < 3; i++) {
		int *tmp = realloc(loeschtabelle[i], len * 2 * sizeof(int));
		if (!tmp) {
			fprintf(stderr, "löschtabelle nicht erweiterbar\n");
			exit(1);
		}
		for (int j = len; j < len * 2; j++) {
			tmp[j] = 0;
		}
		loeschtabelle[i] = tmp;
	}
}

void reihen_vertikal (struct Board *board, int **vertikal, int len) {
	int x;
	int y;
	for (int i = 0; i < len; i++) {
		if (!vertikal[2][i])
			break;
		x = vertikal[0][i];
		y = vertikal[1][i];
		for (int j = 0; j < vertikal[2][i]; j++) {
			board->fields[x][y + j] = 0;
		}
	}
}

void reihen_horizontal (struct Board *board, int **horizontal, int len) {
	int x;
	int y;
	for (int i = 0; i < len; i++) {
		if (!horizontal[2][i])
			break;
		x = horizontal[0][i];
		y = horizontal[1][i];
		for (int j = 0; j < horizontal[2][i]; j++) {
			board->fields[x + j][y] = 0;
		}
	}
}

void reihen_diagonal_auf (struct Board *board, int **diagonal_auf, int len) {
	int x;
	int y;
	for (int i = 0; i < len; i++) {
		if (!diagonal_auf[2][i])
			break;
		x = diagonal_auf[0][i];
		y = diagonal_auf[1][i];
		for (int j = 0; j < diagonal_auf[2][i]; j++) {
			board->fields[x + j][y + j] = 0;
		}
	}
}

void reihen_diagonal_ab (struct Board *board, int **diagonal_ab, int len) {
	int x;
	int y;
	for (int i = 0; i < len; i++) {
		if (!diagonal_ab[2][i])
			break;
		x = diagonal_ab[0][i];
		y = diagonal_ab[1][i];
		for (int j = 0; j < diagonal_ab[2][i]; j++) {
			board->fields[x + j][y - j] = 0;
		}
	}
}

void nachrutschen (struct Board *board) {
	int depth = 0;
	for (int i = 0; i < board->width; i++) {
		depth = 0;
		for (int j = 0; j < board->height; j++) {
			if (!board->fields[i][j]) {
				depth++;
				continue;
			}
			if (!depth)
				continue;
			board->fields[i][j - depth] = board->fields[i][j];
			board->fields[i][j] = 0;
		}
	}
}

int first_check (struct Board *board, unsigned x, int y) {
	int *vertikal = calloc(3, sizeof(int));
	if (!vertikal) {
		fprintf(stderr, "löschliste nicht erstellbar\n");
		exit(1);
	}
	int *horizontal = calloc(3, sizeof(int));
	if (!horizontal) {
		fprintf(stderr, "löschliste nicht erstellbar\n");
		exit(1);
	}
	int *diagonal_auf = calloc(3, sizeof(int));
	if (!diagonal_auf) {
		fprintf(stderr, "löschliste nicht erstellbar\n");
		exit(1);
	}
	int *diagonal_ab = calloc(3, sizeof(int));
	if (!diagonal_ab) {
		fprintf(stderr, "löschliste nicht erstellbar\n");
		exit(1);
	}
	int endpunkt = 0;                          //falls Reihe bis zum Rand geht
	int rueckgabe = 0;                         // >0, falls min. eine Reihe gefunden wurde
	int point_counter = 0;
	int farbe = 0;
	//vertikal
	for (int j = 0; j < board->height; j++) {
		if (!board->fields[x][j] && !farbe)
			continue;
		if (board->fields[x][j] == farbe && j < board->height - 1){     //falls Reihe bis nach ganz oben geht
			point_counter++;
			continue;
		}
		if (board->fields[x][j] == farbe && j == board->height - 1)      // <--
			endpunkt = 1;
		if (point_counter + endpunkt < 4) {
			farbe = board->fields[x][j];
			point_counter = 1;
			continue;
		}
		vertikal[0] = x;
		vertikal[1] = j - point_counter;
		vertikal[2] = point_counter + endpunkt;
		rueckgabe++;
		break;     //kann nur eine geben, wegen first_check
	}
	//horizontal
	farbe = 0;
	point_counter = 0;
	endpunkt = 0;
	for (int i = 0; i < board->width; i++) {
		if (!board->fields[i][y] && !farbe)
			continue;
		if (board->fields[i][y] == farbe && i < board->width - 1){     //falls Reihe bis nach ganz rechts geht
			point_counter++;
			continue;
		}
		if (board->fields[i][y] == farbe && i == board->width - 1)      // <--
			endpunkt = 1;
		if (point_counter + endpunkt < 4) {
			farbe = board->fields[i][y];
			point_counter = 1;
			continue;
		}
		horizontal[0] = i - point_counter;
		horizontal[1] = y;
		horizontal[2] = point_counter + endpunkt;
		rueckgabe++;
		break;       //kann nur eine Reihe geben, wegen first_check
	}
	//diagonal aufwärts
	int min_i;
	int max_i;
	farbe = 0;
	point_counter = 0;
	endpunkt = 0;
	min_i = (x <= y) ? x : y;
	max_i = (board->width - x <= board->height - y) ? board->width - x : board->height - y;
	for (int n = -min_i; n < max_i; n++) {
		if (!board->fields[x + n][y + n] && !farbe)
			continue;
		if (board->fields[x + n][y + n] == farbe && n < max_i - 1){     //falls Reihe bis zum Rand geht
			point_counter++;
			continue;
		}
		if (board->fields[x + n][y + n] == farbe && n == max_i - 1)      // <--
			endpunkt = 1;
		if (point_counter + endpunkt < 4) {
			farbe = board->fields[x + n][y + n];
			point_counter = 1;
			continue;
		}
		diagonal_auf[0] = x + n - point_counter;
		diagonal_auf[1] = y + n - point_counter;
		diagonal_auf[2] = point_counter + endpunkt;
		rueckgabe++;
		break;       //kann nur eine Reihe geben, wegen first_check
	}
	//diagonal abwärts
	farbe = 0;
	point_counter = 0;
	endpunkt = 0;
	min_i = (x <= board->height - y - 1) ? x : board->height - y - 1;
	max_i = (board->width - x <= y + 1) ? board->width - x : y + 1;
	for (int n = -min_i; n < max_i; n++) {
		if (!board->fields[x + n][y - n] && !farbe)
			continue;
		if (board->fields[x + n][y - n] == farbe && n < max_i - 1){     //falls Reihe bis zum Rand geht
			point_counter++;
			continue;
		}
		if (board->fields[x + n][y - n] == farbe && n == max_i - 1)      // <--
			endpunkt = 1;
		if (point_counter + endpunkt < 4) {
			farbe = board->fields[x + n][y - n];
			point_counter = 1;
			continue;
		}
		diagonal_ab[0] = x + n - point_counter;
		diagonal_ab[1] = y - n + point_counter;
		diagonal_ab[2] = point_counter + endpunkt;
		rueckgabe++;
		break;       //kann nur eine Reihe geben, wegen first_check
	}
	if (!rueckgabe){                        //vorzeitige Beendung, weil keine Reihen gefunden wurdeng
		free(vertikal);
		free(horizontal);
		free(diagonal_auf);
		free(diagonal_ab);
		return 0;
	}
	// <Null setzen>
	//reihen_vertikal(board, vertikal, vertikal_len);
	for (int i = 0; i < vertikal[2]; i++) {
		board->fields[vertikal[0]][vertikal[1] + i] = 0;
	}
	//reihen_horizontal(board, horizontal, horizontal_len);
	for (int i = 0; i < horizontal[2]; i++) {
		board->fields[horizontal[0] + i][horizontal[1]] = 0;
	}
	//reihen_diagonal_auf(board, diagonal_auf, dia_auf_len);
	for (int i = 0; i < diagonal_auf[2]; i++) {
		board->fields[diagonal_auf[0] + i][diagonal_auf[1] + i] = 0;
	}
	//reihen_diagonal_ab(board, diagonal_ab, dia_ab_len);
	for (int i = 0; i < diagonal_ab[2]; i++) {
		board->fields[diagonal_ab[0] + i][diagonal_ab[1] - i] = 0;
	}
	
	//bis hier
	free(vertikal);
	free(horizontal);
	free(diagonal_auf);
	free(diagonal_ab);
	//Nachrutschen
	nachrutschen(board);
	return 1;
}





int further_check (struct Board *board) {
	int vertikal_len = 5;
	int **vertikal = malloc(3 * sizeof(int*)); //vertikal
	if (!vertikal) {
		fprintf(stderr, "löschliste nicht erstellbar\n");
		exit(1);
	}
	for (int i = 0; i < 3; i++) {
		vertikal[i] = calloc(5, sizeof(int));
		if (!vertikal[i]) {
			fprintf(stderr, "löschliste nicht erstellbar\n");
			exit(1);
		}
	}
	int horizontal_len = 5;
	int **horizontal = malloc(3 * sizeof(int*)); //horizontal
	if (!horizontal) {
		fprintf(stderr, "löschliste nicht erstellbar\n");
		exit(1);
	}
	for (int i = 0; i < 3; i++) {
		horizontal[i] = calloc(5, sizeof(int));
		if (!horizontal[i]) {
			fprintf(stderr, "löschliste nicht erstellbar\n");
			exit(1);
		}
	}
	int dia_auf_len = 5;
	int **diagonal_auf = malloc(3 * sizeof(int*)); //aufsteigend
	if (!diagonal_auf) {
		fprintf(stderr, "löschliste nicht erstellbar\n");
		exit(1);
	}
	for (int i = 0; i < 3; i++) {
		diagonal_auf[i] = calloc(5, sizeof(int));
		if (!diagonal_auf[i]) {
			fprintf(stderr, "löschliste nicht erstellbar\n");
			exit(1);
		}
	}
	int dia_ab_len = 5;
	int **diagonal_ab = malloc(3 * sizeof(int*)); //absteigend
	if (!diagonal_ab) {
		fprintf(stderr, "löschliste nicht erstellbar\n");
		exit(1);
	}
	for (int i = 0; i < 3; i++) {
		diagonal_ab[i] = calloc(5, sizeof(int));
		if (!diagonal_ab[i]) {
			fprintf(stderr, "löschliste nicht erstellbar\n");
			exit(1);
		}
	}
	//further_check spezifisch von hier
	int endpunkt = 0;                          //falls Reihe bis zum Rand geht
	int rueckgabe = 0;                         // >0, falls min. eine Reihe gefunden wurde
	int point_counter = 0;
	int row_counter = 0;
	int farbe = 0;
	//vertikal
	for (int i = 0; i < board->width; i++) {
		point_counter = 0;
		endpunkt = 0;
		for (int j = 0; j < board->height; j++) {
			if (!board->fields[i][j] && !farbe)
				continue;
			if (board->fields[i][j] == farbe && j < board->height - 1){     //falls Reihe bis nach ganz oben geht
				point_counter++;
				continue;
			}
			if (board->fields[i][j] == farbe && j == board->height - 1)      // <--
				endpunkt = 1;
			if (point_counter + endpunkt < 4) {
				farbe = board->fields[i][j];
				point_counter = 1;
				continue;
			}
			if (row_counter == vertikal_len) {
				double_loeschtabelle(vertikal, vertikal_len);
				vertikal_len *= 2;
			}
			vertikal[0][row_counter] = i;
			vertikal[1][row_counter] = j - point_counter;
			vertikal[2][row_counter] = point_counter + endpunkt;
			row_counter++;
			farbe = board->fields[i][j];
			point_counter = 1;
		}
	}
	rueckgabe += row_counter;
	//horizontal
	point_counter = 0; //
	row_counter = 0;
	farbe = 0;
	for (int j = 0; j < board->height; j++) {
		point_counter = 0;
		endpunkt = 0;
		for (int i = 0; i < board->width; i++) {
			if (!board->fields[i][j] && !farbe)
				continue;
			if (board->fields[i][j] == farbe && i < board->width - 1){     //falls Reihe bis nach ganz rechts geht
				point_counter++;
				continue;
			}
			if (board->fields[i][j] == farbe && i == board->width - 1)      // <--
				endpunkt = 1;
			if (point_counter + endpunkt < 4) {
				farbe = board->fields[i][j];
				point_counter = 1;
				continue;
			}
			if (row_counter == horizontal_len) {
				double_loeschtabelle(horizontal, horizontal_len);
				horizontal_len *= 2;
			}
			horizontal[0][row_counter] = i - point_counter;
			horizontal[1][row_counter] = j;
			horizontal[2][row_counter] = point_counter + endpunkt;
			row_counter++;
			farbe = board->fields[i][j];
			point_counter = 1;
		}
	}
	rueckgabe += row_counter;
	//diagonal aufwärts
	int min_i = 0;
	point_counter = 0; //
	row_counter = 0;
	farbe = 0;
	// i = 0 (x = 0)
	for (int j = board->height - 4; j >= 0; j--) {
		point_counter = 0;
		endpunkt = 0;
		min_i = (board->height - j <= board->width) ? board->height - j : board->width;
		for (int n = 0; n < min_i; n++) {
			if (!board->fields[0 + n][j + n] && !farbe)
				continue;
			if (board->fields[0 + n][j + n] == farbe && n < min_i - 1){     //falls Reihe bis zum Rand geht
				point_counter++;
				continue;
			}
			if (board->fields[0 + n][j + n] == farbe && n == min_i - 1)      // <--
				endpunkt = 1;
			if (point_counter + endpunkt < 4) {
				farbe = board->fields[0 + n][j + n];
				point_counter = 1;
				continue;
			}
			if (row_counter == dia_auf_len) {
				double_loeschtabelle(diagonal_auf, dia_auf_len);
				dia_auf_len *= 2;
			}
			diagonal_auf[0][row_counter] = 0 + n - point_counter;
			diagonal_auf[1][row_counter] = j + n - point_counter;
			diagonal_auf[2][row_counter] = point_counter + endpunkt;
			row_counter++;
			farbe = board->fields[0 + n][j + n];
			point_counter = 1;
		}
	}
	// j = 0 (y = 0)
	for (int i = 1; i < board->width - 3; i++) {
		point_counter = 0;
		endpunkt = 0;
		min_i = (board->width - i <= board->height) ? board->width - i : board->height;
		for (int n = 0; n < min_i; n++) {
			if (!board->fields[i + n][0 + n] && !farbe)
				continue;
			if (board->fields[i + n][0 + n] == farbe && n < min_i - 1){      //falls Reihe bis zum Rand geht
				point_counter++;
				continue;
			}
			if (board->fields[i + n][0 + n] == farbe && n == min_i - 1)       // <--
				endpunkt = 1;
			if (point_counter + endpunkt < 4) {
				farbe = board->fields[i + n][0 + n];
				point_counter = 1;
				continue;
			}
			if (row_counter == dia_auf_len) {
				double_loeschtabelle(diagonal_auf, dia_auf_len);
				dia_auf_len *= 2;
			}
			diagonal_auf[0][row_counter] = i + n - point_counter;
			diagonal_auf[1][row_counter] = 0 + n - point_counter;
			diagonal_auf[2][row_counter] = point_counter + endpunkt;
			row_counter++;
			farbe = board->fields[i + n][0 + n];
			point_counter = 1;
		}
	}
	rueckgabe += row_counter;
	//diagonal abwärts
	min_i = 0;
	point_counter = 0; //
	row_counter = 0;
	farbe = 0;
	// i = 0 (x = 0)
	for (int j = 3; j < board->height; j++) {
		point_counter = 0;
		endpunkt = 0;
		min_i = (j + 1 <= board->width) ? j + 1 : board->width;
		for (int n = 0; n < min_i; n++) {
			if (!board->fields[0 + n][j - n] && !farbe)
				continue;
			if (board->fields[0 + n][j - n] == farbe && n < min_i - 1){       //falls Reihe bis zum Rand geht
				point_counter++;
				continue;
			}
			if (board->fields[0 + n][j - n] == farbe && n == min_i - 1)        // <--
				endpunkt = 1;
			if (point_counter + endpunkt < 4) {
				farbe = board->fields[0 + n][j - n];
				point_counter = 1;
				continue;
			}
			if (row_counter == dia_ab_len) {
				double_loeschtabelle(diagonal_ab, dia_ab_len);
				dia_ab_len *= 2;
			}
			diagonal_ab[0][row_counter] = 0 + n - point_counter;
			diagonal_ab[1][row_counter] = j - n + point_counter;
			diagonal_ab[2][row_counter] = point_counter + endpunkt;
			row_counter++;
			farbe = board->fields[0 + n][j - n];
			point_counter = 1;
		}
	}
	// j = board->height - 1 (y = board->height - 1)
	for (int i = 1; i < board->width - 3; i++) {
		point_counter = 0;
		endpunkt = 0;
		min_i = (board->width - i <= board->height) ? board->width - i : board->height;
		for (int n = 0; n < min_i; n++) {
			if (!board->fields[i + n][board->height - 1 - n] && !farbe)
				continue;
			if (board->fields[i + n][board->height - 1 - n] == farbe && n < min_i - 1){      //falls Reihe bis zum Rand geht
				point_counter++;
				continue;
			}
			if (board->fields[i + n][board->height - 1 - n] == farbe && n == min_i - 1)       // <--
				endpunkt = 1;
			if (point_counter + endpunkt < 4) {
				farbe = board->fields[i + n][board->height - 1 - n];
				point_counter = 1;
				continue;
			}
			if (row_counter == dia_ab_len) {
				double_loeschtabelle(diagonal_ab, dia_ab_len);
				dia_ab_len *= 2;
			}
			diagonal_ab[0][row_counter] = i + n - point_counter;
			diagonal_ab[1][row_counter] = board->height - 1 - n + point_counter;
			diagonal_ab[2][row_counter] = point_counter + endpunkt;
			row_counter++;
			farbe = board->fields[i + n][board->height - 1 - n];
			point_counter = 1;
		}
	}
	rueckgabe += row_counter;
	if (!rueckgabe){                        //vorzeitige Beendung, weil keine Reihen gefunden wurdeng
		destroy_loeschtabelle(vertikal);
		destroy_loeschtabelle(horizontal);
		destroy_loeschtabelle(diagonal_auf);
		destroy_loeschtabelle(diagonal_ab);
		return 0;
	}
	// <Null setzen>
	reihen_vertikal(board, vertikal, vertikal_len);
	reihen_horizontal(board, horizontal, horizontal_len);
	reihen_diagonal_auf(board, diagonal_auf, dia_auf_len);
	reihen_diagonal_ab(board, diagonal_ab, dia_ab_len);
	
	//bis hier
	destroy_loeschtabelle(vertikal);
	destroy_loeschtabelle(horizontal);
	destroy_loeschtabelle(diagonal_auf);
	destroy_loeschtabelle(diagonal_ab);
	//Nachrutschen
	nachrutschen(board);
	return 1;
}


void board_print (struct Board *board) {
	for (int i = 0; i < board->width; i++){
		for (int j = 0; j < board->height; j++) {
			if (board->fields[i][j] == 0)
				continue;
			printf("%d %d %d\n", board->fields[i][j] - 1, i - board->offset, j);
		}
	}
}

int main () {
struct Board *board = board_init();
while (read(board)) {
	if (first_check(board, global_x, global_y))
		while(further_check(board));
}
board_print(board);
board_destroy(board);
return 0;
}
