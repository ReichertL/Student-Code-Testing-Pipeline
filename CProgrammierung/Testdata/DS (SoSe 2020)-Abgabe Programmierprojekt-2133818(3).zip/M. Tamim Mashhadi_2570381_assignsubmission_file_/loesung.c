#include<stdio.h>
#include<stdlib.h>

int** array = NULL;
int X = 0;

void readInput();
void add(int color, int x);
void removePairs();
int findPair();
void moveDown();
void removeUnusedSpace();
void printOutput();
void deallocate();

void readInput()
{
	int color, x, success;
	while (1)
	{
		success = scanf("%d%d", &color, &x);
		if (success != 2)
		{
			if (success == -1)
			{
				break;
			}
			if (success == 0)
			{
				fprintf(stderr, "Error while reading color number.\n");
			}
			if (success == 1)
			{
				fprintf(stderr, "Error while reading column number.\n");
			}
			deallocate();
			exit(1);
		}
		if (color < 0 || color > 254)
		{
			fprintf(stderr, "Error: color number out of range.\n");
			deallocate();
			exit(1);
		}
		add(color, x);
		removePairs();
	}
}

void add(int color, int x)
{
	for (int i = 0; i < X; i++)
	{
		if (array[i][0] == x)
		{
			int* temp = array[i];
			array[i] = (int*)calloc(2 + temp[1] + 1, sizeof(int));
			for (int j = 0; j < 2 + temp[1]; j++)
			{
				array[i][j] = temp[j];
			}
			array[i][2 + temp[1]] = color;
			array[i][1]++;
			free(temp);
			return;
		}
	}
	int**temp = array;
	array = (int**)calloc(++X, sizeof(int*));
	for (int i = 0; i < X; i++)
	{
		if (i < X - 1 && temp[i][0] < x)
		{
			array[i] = temp[i];
		}
		else
		{
			array[i] = (int*)calloc(3, sizeof(int));
			array[i][0] = x;
			array[i][1] = 1;
			array[i][2] = color;
			while (++i < X)
			{
				array[i] = temp[i - 1];
			}
			break;
		}
	}
	if (temp != NULL)
	{
		free(temp);
	}
}

void removePairs()
{
	while (findPair() != 0)
	{
		moveDown();
	}
	removeUnusedSpace();
}

int findPair()
{
	int pair = 0;
	for (int x = 0; x < X - 3; x++)
	{
		for (int y = 2; y < 2 + array[x][1]; y++)
		{
			if (array[x][0] == array[x + 1][0] - 1 && array[x][0] == array[x + 2][0] - 2 && array[x][0] == array[x + 3][0] - 3)
			{
				if (y < 2 + array[x + 1][1] && y < 2 + array[x + 2][1] && y < 2 + array[x + 3][1])
				{
					if (array[x][y] % 1000 == array[x + 1][y] % 1000 && array[x][y] % 1000 == array[x + 2][y] % 1000 && array[x][y] % 1000 == array[x + 3][y] % 1000)
					{
						array[x][y] = array[x + 1][y] = array[x + 2][y] = array[x + 3][y] = array[x][y] + 1000;
						pair = 1;
					}
				}
			}

		}
	}
	for (int x = 0; x < X; x++)
	{
		for (int y = 2; y < 2 + array[x][1] - 3; y++)
		{
			if (array[x][y] % 1000 == array[x][y + 1] % 1000 && array[x][y] % 1000 == array[x][y + 2] % 1000 && array[x][y] % 1000 == array[x][y + 3] % 1000)
			{
				array[x][y] = array[x][y + 1] = array[x][y + 2] = array[x][y + 3] = array[x][y] + 1000;
				pair = 1;
			}
		}
	}
	for (int x = 0; x < X - 3; x++)
	{
		for (int y = 0; y < 2 + array[x][1]; y++)
		{
			if (array[x][0] == array[x + 1][0] - 1 && array[x][0] == array[x + 2][0] - 2 && array[x][0] == array[x + 3][0] - 3)
			{
				if (y + 1 < 2 + array[x + 1][1] && y + 2 < 2 + array[x + 2][1] && y + 3 < 2 + array[x + 3][1])
				{
					if (array[x][y] % 1000 == array[x + 1][y + 1] % 1000 && array[x][y] % 1000 == array[x + 2][y + 2] % 1000 && array[x][y] % 1000 == array[x + 3][y + 3] % 1000)
					{
						array[x][y] = array[x + 1][y + 1] = array[x + 2][y + 2] = array[x + 3][y + 3] = array[x][y] + 1000;
						pair = 1;
					}
				}
			}
		}
	}
	for (int x = X - 1; x >= 3; x--)
	{
		for (int y = 0; y < 2 + array[x][1]; y++)
		{
			if (array[x][0] == array[x - 1][0] + 1 && array[x][0] == array[x - 2][0] + 2 && array[x][0] == array[x - 3][0] + 3)
			{
				if (y + 1 < 2 + array[x - 1][1] && y + 2 < 2 + array[x - 2][1] && y + 3 < 2 + array[x - 3][1])
				{
					if (array[x][y] % 1000 == array[x - 1][y + 1] % 1000 && array[x][y] % 1000 == array[x - 2][y + 2] % 1000 && array[x][y] % 1000 == array[x - 3][y + 3] % 1000)
					{
						array[x][y] = array[x - 1][y + 1] = array[x - 2][y + 2] = array[x - 3][y + 3] = array[x][y] + 1000;
						pair = 1;
					}
				}
			}
		}
	}
	return pair;
}

void moveDown()
{
	for (int x = 0; x < X; x++)
	{
		int z = 2;
		for (int y = 2; y < 2 + array[x][1]; y++)
		{
			if (array[x][y] < 1000 && y != z++)
			{
				array[x][z - 1] = array[x][y];
			}
		}
		array[x][1] = z - 2;
	}
}

void removeUnusedSpace()
{
	int x = 0;
	for (int i = 0; i < X; i++)
	{
		if (array[i][1] > 0)
		{
			x++;
		}
	}
	if (x == 0)
	{
		deallocate();
		return;
	}
	X = x;
	int** temp = array;
	array = (int**)calloc(X, sizeof(int*));
	x = 0;
	for (int i = 0; x < X; i++)
	{
		if (temp[i][1] > 0)
		{
			array[x] = (int*)calloc(2 + temp[i][1], sizeof(int));
			for (int j = 0; j < 2 + temp[i][1]; j++)
			{
				array[x][j] = temp[i][j];
			}
			free(temp[i]);
			x++;
		}
		else
		{
			free(temp[i]);
		}
	}
	if (temp != NULL)
	{
		free(temp);
	}
}

void printOutput()
{
	int n = 0;
	for (int x = 0; x < X; x++)
	{
		n += array[x][1];
	}
	if (n == 0)
	{
		return;
	}
	int* outColor = (int*)calloc(n, sizeof(int));
	int* outX = (int*)calloc(n, sizeof(int));
	int* outY = (int*)calloc(n, sizeof(int));
	for (int x = 0, c = 0; x < X; x++)
	{
		for (int y = 2; y < 2 + array[x][1]; y++)
		{
			outColor[c] = array[x][y];
			outX[c] = array[x][0];
			outY[c] = y - 2;
			c++;
		}
	}
	for (int i = 0; i < n - 1; i++)
	{
		int min_idx = i;
		for (int j = i + 1; j < n; j++)
		{
			if (outColor[j] < outColor[min_idx])
			{
				min_idx = j;
			}
			else if (outColor[j] == outColor[min_idx])
			{
				if (abs(outX[j]) < abs(outX[min_idx]))
				{
					min_idx = j;
				}
				else if (abs(outX[j]) == abs(outX[min_idx]))
				{
					if (outY[j] < outY[min_idx])
					{
						min_idx = j;
					}
					else if (outY[j] == outY[min_idx])
					{
						if (outX[j] < outX[min_idx])
						{
							min_idx = j;
						}
					}
				}
			}
		}
		int t;
		t = outColor[min_idx];
		outColor[min_idx] = outColor[i];
		outColor[i] = t;
		t = outX[min_idx];
		outX[min_idx] = outX[i];
		outX[i] = t;
		t = outY[min_idx];
		outY[min_idx] = outY[i];
		outY[i] = t;
	}
	for (int i = 0; i < n; i++)
	{
		printf("%d %d %d\n", outColor[i], outX[i], outY[i]);
	}
	free(outColor);
	free(outX);
	free(outY);
}

void deallocate()
{
	if (X > 0)
	{
		for (int i = 0; i < X; i++)
		{
			free(array[i]);
		}
		free(array);
	}
	array = NULL;
	X = 0;
}

int main()
{
	readInput();
	printOutput();
	deallocate();
	return 0;
}
