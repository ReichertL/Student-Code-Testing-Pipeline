#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int    size;
    int    count;
    short* colors;
} column;

typedef struct {
  long yMin;
  long yMax;
  long xMin;
  long xMax;
} area_t;

column*  columnsRight;
column*  columnsLeft;
long     columnsRightSize = 64;
long     columnsLeftSize  = 64;


short   readInput();
int     insertElement(int, short);
int     check(int, int, short, short, short);
short   processArea(area_t*);
short   cleanArea(area_t*);
column* getColumn(int);
column* getColumnLeft(int);
column* getColumnRight(int);
void    cleanup(short);
void    error(short);

int main() {
    columnsRight = (column*) malloc(columnsRightSize * sizeof(column));
    columnsLeft  = (column*) malloc(columnsLeftSize  * sizeof(column));
    
    if(columnsRight == NULL || columnsLeft == NULL) {
      error(-1);
    }

    memset(columnsRight, 0, columnsRightSize * sizeof(column));
    memset(columnsLeft,  0, columnsLeftSize  * sizeof(column));

   
    short err = readInput();
    if (err) {
      error(-2);
    }
    cleanup(1);
}


short readInput() {
    short error = 0;
    int   input = getchar();

    while(input != EOF && !error) {
        int     color       = 0;
        int     xCoord      = 0;
        int     yCoord      = 0;
        short   sign        = 1;
        int     colorLength = 0;
        int     coordLength = 0;
        short   removed     = 1;
        area_t* bounds      = NULL;

        while(input == ' ') {
            input = getchar();
        } 

        while(input < 58 && input > 47 && !error) {
            if (colorLength > 2) {
                error = 1;
            } else {
                color = color * 10 + (input - 48);
            }
            input = getchar();
            colorLength++;
        }

        if (input != ' ') {
            error = 1;
        }        

        while(input == ' ') {
            input = getchar();
        }

        if(input == 45) {
            sign  = -1;
            input = getchar();
        }

        while(input < 58 && input > 47 && !error) {
            if (coordLength > 8 && xCoord > 2030303303030) {
                error = 1;
            } else {
                xCoord = xCoord * 10 + (sign * (input - 48));
            }
            input = getchar();
            coordLength++;
        }

        while(input == ' ') {
            input = getchar();
        }

        if (colorLength == 0 || coordLength == 0 || (input != '\n' && input != EOF)) {
            error = 1;
        } else {
          yCoord = insertElement(xCoord, color);
          bounds = &(area_t) {yCoord, yCoord, xCoord, xCoord};
         
          while(removed) {
            removed = processArea(bounds);
          }
        }

        if (input == '\n') {
            input = getchar();
        }
    }
    
    return error;
}


int check(int yCoord, int xCoord, short yOffset, short xOffset, short color) {

  int     matches = 0;
  int     yTmp    = yCoord + yOffset;
  int     xTmp    = xCoord + xOffset;
  column* tmp     = getColumn(xTmp);

  while(tmp->colors && (yTmp < tmp->count) && (yTmp >= 0) &&
       ((tmp->colors[yTmp] == color) || (tmp->colors[yTmp] == (-1 * (color + 1))))) {
    matches++;

    if (matches > 2 && (tmp->colors[yTmp] >= 0)) {
      tmp->colors[yTmp] = -1 * (tmp->colors[yTmp] + 1);
    }

    yTmp += yOffset;
    xTmp += xOffset;
    tmp  =  getColumn(xTmp);
    
  }

  if (matches > 2) {
    yTmp = yCoord + yOffset;
    xTmp = xCoord + xOffset;
    tmp  = getColumn(xTmp);
    if (tmp->colors[yTmp] >= 0) {
      tmp->colors[yTmp] = -1 * (tmp->colors[yTmp] + 1);
    }
    yTmp = yCoord + (2 * yOffset);
    xTmp = xCoord + (2 * xOffset);
    tmp  = getColumn(xTmp);
    if (tmp->colors[yTmp] >= 0) {
      tmp->colors[yTmp] = -1 * (tmp->colors[yTmp] + 1);
    }
  }

  return matches; 
}


short processArea(area_t* bounds) {
 
  for(int x = bounds->xMin; x <= bounds->xMax; x++) {
    column* col = getColumn(x);
  
    if (col->colors != NULL && col->size > 0) {

      for(int y = bounds->yMin; y <= bounds->yMax; y++) {
        if ((y < col->count) && (y >= 0)) {
          short color = col->colors[y];

          if (col->colors[y] < 0) {
            color = (-1 * color) - 1;
          }
          short   topLeft  = check(y, x,  1, -1, color);
          short   topRight = check(y, x,  1,  1, color);
          short   botLeft  = check(y, x, -1, -1, color);
          short   botRight = check(y, x, -1,  1, color);
          short   left     = check(y, x,  0, -1, color);
          short   right    = check(y, x,  0,  1, color);
          short   bot      = check(y, x, -1,  0, color);
          short   top      = check(y, x,  1,  0, color);
        }
      }
    }
    return cleanArea(bounds);
  }
}

short cleanArea(area_t* bounds) {
  int    yMin    = bounds->yMax + 3;
  int    yMax    = bounds->yMin - 3;
  int    xMin    = bounds->xMax + 3;
  int    xMax    = bounds->xMin - 3;
  short  removed = 0;

  for(int x = bounds->xMin - 3; x < bounds->xMax + 3; x++) {
    column* col      = getColumn(x);
    int     delCount = 0; 

    if (col->colors != NULL && col->size > 0) {
      for(int y = bounds->yMin - 3; y < col->count; y++) {
        if(y >= 0) {
          while(((y + delCount) < col->size) && (col->colors[y + delCount] < 0)) {
            yMax = yMax < y ? y : yMax;
            yMin = yMin > y ? y : yMin;
            delCount++;
          }
          if ((y + delCount) < col->size) {
            col->colors[y] = col->colors[y + delCount];
          }
        }
      }

      col->count -= delCount;
      
      //shrink colors
      if (col->count < (col->size / 2) && (col->size > 4)) {
        col->colors = (short*) realloc(col->colors, (col->size / 2) * sizeof(short));
        col->size   = col->size / 2;
        if (col->colors == NULL) {
          error(-1);
        }
      }

      if (delCount > 0) {
        xMin    = xMin > x ? x : xMin;
        xMax    = xMax < x ? x : xMax;
        removed = 1;
      }
    }
  }

  bounds->yMin = yMin;
  bounds->yMax = yMax;
  bounds->xMin = xMin;
  bounds->xMax = xMax;

  return removed;  
}


int insertElement(int xCoord, short color) {
  column* col = getColumn(xCoord);
  
  if (col->colors == NULL || col->size == 0) {
    col->colors = (short*) malloc(4 * sizeof(short));
    col->size   = 4;
    col->count  = 0;
  }

  if (col->size == col->count) {
    col->colors = (short*) realloc(col->colors, 2 * col->size * (sizeof(short)));
    col->size   = 2 * col->size;
  }

  if(col->colors != NULL) {
    col->colors[col->count] = color;
    col->count++;
  } else {
    error(-1);
  }

  return col->count - 1;
}


column* getColumn(int index) {
  column* col;

  if (index >= 0) {
    col = getColumnRight(index);
  } else {
    col = getColumnLeft((-1 * index) - 1);
  }
  if (col == NULL) {
    error(-1);
  }
  return col;
}


column* getColumnLeft(int index) {
  if (index >= columnsLeftSize) {
    columnsLeft     = (column*) realloc(columnsLeft, ((index + 1) * 2) * sizeof(column));
    if (columnsLeft == NULL) {
      error(-1);
    }
    memset(&columnsLeft[columnsLeftSize], 0, (((index + 1) * 2) - columnsLeftSize) * sizeof(column));
    columnsLeftSize = (index + 1) * 2;
  }
  return &columnsLeft[index];
}


column* getColumnRight(int index) {
  if (index >= columnsRightSize) {
    columnsRight     = (column*) realloc(columnsRight, ((index + 1) * 2) * sizeof(column));
    if (columnsRight == NULL) {
      error(-1);
    }
    memset(&columnsRight[columnsRightSize], 0, (((index + 1) * 2) - columnsRightSize) * sizeof(column));
    columnsRightSize = (index + 1) * 2;
  }
  return &columnsRight[index];
}
  

void cleanup(short output) {
  if(columnsLeft != NULL) {
    for(int x = 0; x < columnsLeftSize; x++) {
      if (columnsLeft[x].colors != NULL && columnsLeft[x].size > 0) {
        if(output) {
          for(int y = 0; y < columnsLeft[x].count; y++) {
            printf("%d -%d %d\n", columnsLeft[x].colors[y], x + 1, y);
          }
        }
        free(columnsLeft[x].colors);
      }
    }
    free(columnsLeft);
  }
  
  if(columnsRight != NULL) {
    for(int x = 0; x < columnsRightSize; x++) {
      if (columnsRight[x].colors != NULL && columnsRight[x].size > 0) {
        if(output) {
          for(int y = 0; y < columnsRight[x].count; y++) {
            printf("%d %d %d\n", columnsRight[x].colors[y], x, y);
          }
        }
        free(columnsRight[x].colors);
      }
    }
    free(columnsRight);
  }
}

void error(short code) {
  if (code == -1) {
    fprintf(stderr, "Fehler beim reservieren von Speicher\n");
  } else if (code == -2) {
    fprintf(stderr, "Fehler beim Parsen der Eingabe\n");
  }
  cleanup(0);
  exit(-1);
}
