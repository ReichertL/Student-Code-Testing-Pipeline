
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

// --- helpers --- //

void die(char* msg);
FILE *inputFile;

// --- long array implementation --- //

size_t ARRAYSIZE = 4;
int ROW_LENGTH = 4;

typedef struct {
   short *array;
   size_t used;
   size_t size;
} Array;

typedef struct {
   Array* array;
} NullableArray;

Array* initArray(Array *a, size_t arraySize) {
   a->array = malloc(arraySize * sizeof(short));
   if(!a->array) {
      die("Could not allocate memory for array");
   }
   a->used = 0;
   a->size = arraySize;
   return a;
}

void insertArray(Array *a, short element) {
   if (a->used == a->size) {
      a->size *= 2;
      a->array = realloc(a->array, a->size * sizeof(short));
      if(!a->array) {
         die("Could not reallocate memory for array");
      }
   }
   a->array[a->used] = element;
   a->used++;
}

void printArrayState();

void freeArray(Array *a) {
   free(a->array);
   a->array = NULL;
   a->used = a->size = 0;
}

void removeAtArray(Array* a, int index) {
   short* tmp = malloc((a->used -1)*sizeof(short));
   if(!tmp)
      die("Could not allocate memory for temporary array");
   if(index != 0)
      memcpy(tmp, a->array, index * sizeof(short));
   if(index != a->used-1)
      memcpy(tmp + index, a->array + index +1, (a->used - index -1) * sizeof(short));
   if(a->used>1)
      memcpy(a->array, tmp, (a->used-1)*sizeof(short));

   free(tmp);
   a->used--;
}

// --- functions --- //

typedef struct {
   short color;
   long x;
} Block;

//return 0 if done, exit on error, write result in struct and return 1 on success
int readInputLine(Block* block, FILE* inputFile) {
   char* line = NULL;
   int read = 0;
   size_t len = 0;

   //read one line
   read = getline(&line, &len, inputFile);
   //return on error/finish
   if(read<0) {
      free(line);
      return 0;
   }
   if(strlen(line)<read-1) {
      free(line);
      die("Invalid char in input");
   }

   //check string for invalid chars
   for(int i=0; i<strlen(line); ++i) {
      if(!(isdigit(line[i])||line[i]=='-'||line[i]==' '||line[i]=='\n'||line[i]=='\r')) {
         free(line);
         char out[256];
         sprintf(out, "Invalid char in input: %c", line[i]);
         die(out);
      }
   }

   //parse color
   char* tmp;
   char* str = strtok(line, " ");
   if(str==NULL) {
      free(line);
      die("Error while reading color");
   }
   long long color = strtoll(str, &tmp, 0);
   if(str==tmp) {
      free(line);
      //parsing error
      die("Error while parsing color");
   }
   if(color < 0 || color > 254) {
      free(line);
      //color out of range
      char out[256];
      sprintf(out, "Invalid color %lli", color);
      die(out);
   }
   block->color = (short)color;

   //parse x position
   str = strtok(NULL, " ");
   if(str==NULL) {
      free(line);
      die("Error while reading x position");
   }
   block->x = strtol(str, &tmp, 0);
   if(str == tmp) {
      free(line);
      //parsing error
      die("Error while parsing x position");
   }

   str = strtok(NULL, " ");
   if(str!=NULL) {
      free(line);
      die("Invalid input length");
   }

   free(line);

   //return 1 on success
   return 1;
}

typedef struct _ListElement ListElement;
struct _ListElement {
   ListElement* next;
   Block* block;
};

NullableArray* Cols = NULL;
long size = 0;
long offset = 0;

ListElement* list = NULL;
ListElement* first = NULL;

void die(char* msg) {
   if(Cols!=NULL) {
      for(int i=0; i<size; ++i) {
         if(Cols[i].array!=NULL) {
            freeArray(Cols[i].array);
            free(Cols[i].array);
         }
      }
      free(Cols);
   }
   if(first!=NULL) {
      while(first->next!=NULL) {
         ListElement* tmp = first;
         first = first->next;
         free(tmp->block);
         free(tmp);
      }
      free(first->block);
      free(first);
   }
   //close file if needed
   if(inputFile!=stdin) {
      fclose(inputFile);
   }
   perror(msg);
   char out[256];
   sprintf(out, "%s\n", msg);
   exit(-1);
}

void printArrayState() {
   //x
   for(int i=0; i<size; ++i) {
      Array* Column = Cols[i].array;
      if(Column==NULL)
         continue;
      //y
      for(int j=0; j<Column->used; ++j) {
         printf("%i %li %i\n", Column->array[j], i-offset, j);
      }
   }
}

/*void printDebugState() {
   for(int i=0; i<size; ++i) {
      Array* Column = Cols[i].array;
      if(Column==NULL)
         continue;
      printf("%i: ", i);
      //y
      for(int j=0; j<Column->used; ++j) {
         printf("%i  ", Column->array[j]);
         if(labs(Column->array[j])<10)
            printf("  ");
         else if(labs(Column->array[j])<100)
            printf(" ");
      }
      printf("\n");
   }
}*/

int checkInDirection(short color, long startX, int startY, int dirX, int dirY) {
   long XtoCheck = startX + dirX;
   //edge of field
   if(XtoCheck < 0 || XtoCheck > size -1) {
      return 0;
   }
   Array* Column = Cols[XtoCheck].array;
   //unintitialized column
   if(!Column) {
      return 0;
   }
   int YtoCheck = startY + dirY;

   //out of bounds check for column
   if(Column->used<=YtoCheck||YtoCheck<0) {
      return 0;
   }
   //color not equal
   if(Column->array[YtoCheck]!=color&&Column->array[YtoCheck]!=0-color-1) {
      return 0;
   }

   //check next field in given direction
   return checkInDirection(color, XtoCheck, YtoCheck, dirX, dirY) + 1;
}

void markToRemove(short color, long startX, long startY, int dirX, int dirY) {
   if(color<0)
      color = 0-color-1;

   long XtoCheck = startX + dirX;
   //edge of field
   if(XtoCheck < 0 || XtoCheck > size -1) {
      return;
   }
   Array* Column = Cols[XtoCheck].array;
   //unintitialized column
   if(!Column) {
      return;
   }
   int YtoCheck = startY + dirY;
   //out of bounds check for column
   if(Column->used<=YtoCheck||YtoCheck<0) {
      return;
   }
   //color not equal
   if((Column->array[YtoCheck]!=color)&&(Column->array[YtoCheck]!=0-color-1)) {
      return;
   }

   //if all conditions pass, set color to -color
   if(Column->array[YtoCheck]>=0)
      Column->array[YtoCheck] = 0-color-1;

   //check next field in given direction
   markToRemove(color, XtoCheck, YtoCheck, dirX, dirY);
}

void removeMarkedBlocks(long x, int y, int left, int right, int* LowesetRemovedBlockPerCol) {

   for(int i=0; i<left+right+1; ++i)  {
      Array* ColumnToCheck = Cols[i+x-left].array;
      if(ColumnToCheck == NULL)
         continue;

      //go through column, remove blocks
      for(int j=0; j<ColumnToCheck->used; ++j) {
         if(ColumnToCheck->array[j] < 0) {
            removeAtArray(ColumnToCheck, j);
            //store from which block on we have to perform a check
            if(LowesetRemovedBlockPerCol[i]==-1)
               LowesetRemovedBlockPerCol[i] = j;
            j--;
         }
      }
   }

}

int checkAndMark(long x, int y, int* left, int* right);

void checkMovedBlocks(long x, int y, int left, int right, int** LowesetRemovedBlockPerCol) {
   //repeat checking and removing until no further blocks are found
   while(1) {
      int foundRow = 0;
      //check all blocks in affected area, mark rows
      for(int i=0; i<left+right+1; ++i)  {
         Array* ColumnToCheck = Cols[i+x-left].array;
         if(ColumnToCheck==NULL)
            continue;
         int j = (*LowesetRemovedBlockPerCol)[i];
         if(j<0)
            continue;
         if(ColumnToCheck->used-j<=0)
            continue;
         while(j<ColumnToCheck->used) {
            int leftTmp = left;
            int rightTmp = right;
            foundRow += checkAndMark(i+x-left,j,&leftTmp,&rightTmp);
            j++;
         }
      }

      if(foundRow==0) {
         return;
      }

      //if rows are found, remove them
      //set new range
      left = left+ROW_LENGTH-1;
      if(x-left<0)
         left = x;
      right = right+ROW_LENGTH-1;
      if(x+right>size-1)
         right = size-1-x;

      //reallocate marker array
      *LowesetRemovedBlockPerCol = realloc(*LowesetRemovedBlockPerCol, (left+right+1)*sizeof(int));
      if(!*LowesetRemovedBlockPerCol)
         die("Could not reallocate memory for marker array");
      memset(*LowesetRemovedBlockPerCol, -1, (left+right+1)*sizeof(int));
      removeMarkedBlocks(x,y,left,right,*LowesetRemovedBlockPerCol);
   }
}

void checkToRemove(long x, int y) {
   int left, right = 0;
   if(!checkAndMark(x,y,&left,&right))
      return;

   int* LowesetRemovedBlockPerCol = malloc((2*ROW_LENGTH-1)*sizeof(int));
   if(!LowesetRemovedBlockPerCol)
      die("Could not reallocate memory for marker array");
   memset(LowesetRemovedBlockPerCol, -1, (2*ROW_LENGTH-1)*sizeof(int));

   removeMarkedBlocks(x,y,left,right,LowesetRemovedBlockPerCol);
   //start recursive checks for moved blocks
   checkMovedBlocks(x,y,left,right,&LowesetRemovedBlockPerCol);
   free(LowesetRemovedBlockPerCol);
}

int checkAndMark(long x, int y, int* left, int* right) {
   //get color at location
   Array* Column = Cols[x].array;
   short color = Column->array[y];
   int foundRow = 0;

   //check downwards
   int down = checkInDirection(color,x,y,0,-1);

   //check upwards
   int up = checkInDirection(color,x,y,0,1);

   if(down + up + 1 >= ROW_LENGTH) {
      foundRow = 1;
      markToRemove(color,x,y,0,-1);
      markToRemove(color,x,y,0,1);
      if(color>=0)
         Column->array[y] = 0-color-1;
   }

   //check left
   *left = checkInDirection(color,x,y,-1,0);
   //check right
   *right = checkInDirection(color,x,y,1,0);

   if(*left + *right + 1 >= ROW_LENGTH) {
      foundRow = 1;
      markToRemove(color,x,y,-1,0);
      markToRemove(color,x,y,1,0);
      if(color>=0)
         Column->array[y] = 0-color-1;
   }

   //check diagonal left-up
   int diagLeftUp = checkInDirection(color,x,y,-1,1);
   //check diagonal right-down
   int diagRightDown = checkInDirection(color,x,y,1,-1);

   if(diagLeftUp + diagRightDown + 1 >= ROW_LENGTH) {
      foundRow = 1;
      markToRemove(color,x,y,1,-1);
      markToRemove(color,x,y,-1,1);
      if(color>=0)
         Column->array[y] = 0-color-1;
   }

   //check diagonal right-up
   int diagRightUp = checkInDirection(color,x,y,1,1);
   //check diagonal left-down
   int diagLeftDown = checkInDirection(color,x,y,-1,-1);

   if(diagRightUp + diagLeftDown +1 >= ROW_LENGTH) {
      foundRow = 1;
      markToRemove(color,x,y,1,1);
      markToRemove(color,x,y,-1,-1);
      if(color>=0)
         Column->array[y] = 0-color-1;
   }

   //get highest values for columns to check in each direction
   if(diagLeftUp > *left)
      *left = diagLeftUp;
   if(diagLeftDown > *left)
      *left = diagLeftDown;

   if(diagRightUp > *right)
      *right = diagRightUp;
   if(diagRightDown > *right)
      *right = diagRightDown;

   return foundRow;
}

// --- main --- //

int main(int argc, char* argv[]) {
   //open file from first arg if there is one
   if(argc>1) {
      inputFile = fopen(argv[1], "r");
      if(!inputFile) {
         die("Could not open file");
      }
   }
   //or read from stdin
   else {
      inputFile = stdin;
   }

   //init list
   list = malloc(sizeof(ListElement));
   if(!list)
      die("malloc for list failed");
   list->block = malloc(sizeof(Block));
   if(!list->block)
      die("malloc for list block failed");
   list->next = NULL;

   //store pointer to first element to go through list later
   first = list;
   long max = 0;

   //reading loop
   while(readInputLine(list->block, inputFile)) {
      //store the smallest x in offset
      if(list->block->x < offset) {
         offset = list->block->x;
      }
      //store the largest x in max
      if(list->block->x > max) {
         max = list->block->x;
      }
      //build list
      ListElement* next = malloc(sizeof(ListElement));
      next->block = malloc(sizeof(Block));
      next->next = NULL;

      list->next = next;
      list = next;
   }
   if(errno) {
      die("Error while reading input");
   }

   offset = labs(offset);
   size = offset + max + 1;

   if(size > 2100000) {
      die("Input too large");
   }

   Cols = malloc(size * sizeof(NullableArray));
   if(!Cols) {
      die("Malloc for column array faild");
   }

   for(int i=0; i<size; ++i) {
      Cols[i].array = NULL;
   }

   while(first->next!=NULL) {
      Array* Column = Cols[(first->block->x + offset)].array;
      if(Column==NULL) {
         Column = malloc(sizeof(Array));
         Column = initArray(Column, ARRAYSIZE);
         Cols[(first->block->x + offset)].array = Column;
      }
      insertArray(Column, first->block->color);
      checkToRemove(first->block->x + offset, Column->used-1);
      ListElement* tmp = first;
      first = first->next;
      free(tmp->block);
      free(tmp);
   }

   free(list->block);
   free(list);
   list = NULL;

   printArrayState();

   //free arrays
   for(int i=0; i<size; ++i) {
      if(Cols[i].array!=NULL) {
         freeArray(Cols[i].array);
         free(Cols[i].array);
      }
   }
   free(Cols);

   //close file if needed
   if(inputFile!=stdin) {
      fclose(inputFile);
   }

   return 0;
}
