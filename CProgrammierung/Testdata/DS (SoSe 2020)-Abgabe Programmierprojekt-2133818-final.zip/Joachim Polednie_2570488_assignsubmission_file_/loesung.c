//
// Created by Joachim on 27.08.2020.
//

#include <stdio.h>
#include <stdint.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>


//#include "LinkedList.h"
//
// Created by Joachim on 19.07.2020.
//

#ifndef PROGRAMMIERPROJEKT__LINKEDLIST_H_
#define PROGRAMMIERPROJEKT__LINKEDLIST_H_

typedef struct LinkedList_ LinkedList_t;
typedef struct LinkedListNode_ LinkedListNode_t;

struct LinkedList_ {
	LinkedListNode_t *head;
	LinkedListNode_t *tail;
	long size;
};

struct LinkedListNode_ {
	void *list_element;
	LinkedListNode_t *next;
	LinkedListNode_t *previous;
};

int LinkedList_pushElement(LinkedList_t *list, void *element);
int LinkedList_addElementWithoutDuplicats(LinkedList_t *list, void *element);
void *LinkedList_popElement(LinkedList_t *list);
int LinkedList_removeElement(LinkedList_t *list, void* element);
LinkedList_t *LinkedList_merge(LinkedList_t *list, LinkedList_t **otherList);

LinkedList_t *LinkedList_create();
void LinkedList_delete(LinkedList_t **p_list);

#endif //PROGRAMMIERPROJEKT__LINKEDLIST_H_


//#include "GameElement.h"
//
// Created by Joachim on 19.07.2020.
//

#ifndef PROGRAMMIERPROJEKT__GAMEELEMENT_H_
#define PROGRAMMIERPROJEKT__GAMEELEMENT_H_

#include "LinkedList.h"

typedef struct GameElement_ GameElement_t;

typedef enum Direction_ {
	DIRECTION_HORIZONTAL,
	DIRECTION_VERTICAL,
	DIRECTION_LRDIAGONAL,
	DIRECTION_RLDIAGONAL,
	DIRECTION_COUNT,
} Direction_e;

typedef enum {
	NEIGHBOR_UPPER,
	NEIGHBOR_LOWER,
	NEIGHBOR_RIGHT,
	NEIGHBOR_LEFT,
	NEIGHBOR_UPPER_LEFT,
	NEIGHBOR_UPPER_RIGHT,
	NEIGHBOR_LOWER_LEFT,
	NEIGHBOR_LOWER_RIGHT,
	NEIGHBOR_BASE,
	NEIGHBOR_TOP,
	NEIGHBOR_COUNT,
} Neighbor_e;


struct GameElement_ {
	long column;
	int color;

	GameElement_t *topN;
	GameElement_t *baseN;


	GameElement_t *rightN;
	GameElement_t *leftN;
	GameElement_t *upperN;
	GameElement_t *upperLeftN;
	GameElement_t *upperRightN;
	GameElement_t *lowerN;
	GameElement_t *lowerRightN;
	GameElement_t *lowerLeftN;

	LinkedList_t *popList[DIRECTION_COUNT];

};

GameElement_t *GameElement_new(long column, int color);
void GameElement_delete(GameElement_t *element, LinkedList_t **p_list);

int GameElement_updateNeighbors(GameElement_t *element);
int GameElement_updateLeftNeighbors(GameElement_t *element);
int GameElement_updateRightNeighbors(GameElement_t *element);

void GameElement_addNeighbor(GameElement_t *element, GameElement_t *nElement, Neighbor_e neighbor);
int GameElement_removeAsNeighbor(GameElement_t *element, Neighbor_e neighbor);
int GameElement_removeInvalidReference(GameElement_t *element, void *reference);

#endif //PROGRAMMIERPROJEKT__GAMEELEMENT_H_


//#include "debug.h"
//
// Created by Joachim on 19.07.2020.
//

#ifndef PROGRAMMIERPROJEKT__DEBUG_H_
#define PROGRAMMIERPROJEKT__DEBUG_H_

#include <stdio.h>

#ifndef NDEBUG
#define DEBUG_OUT(format, ...) fprintf(stderr, "<%s()>: "format, __func__, ##__VA_ARGS__)
#else
#define DEBUG_OUT(...)
#endif

#ifndef NDEBUG
#define DEBUG_STATEMENT(...) __VA_ARGS__
#else
#define DEBUG_STATEMENT(...) {}
#endif

#define DO_PRAGMA(x) _Pragma (#x)
#define TODO(x) DO_PRAGMA(message ("TODO - " #x))


#endif //PROGRAMMIERPROJEKT__DEBUG_H_

//
// Created by Joachim on 01.08.2020.
//

long gameElementCount;


//#include "input.h"
//
// Created by Joachim on 19.07.2020.
//

#ifndef PROGRAMMIERPROJEKT__INPUT_H_
#define PROGRAMMIERPROJEKT__INPUT_H_

int Input_getNextLine(int *color, long *column);

#endif //PROGRAMMIERPROJEKT__INPUT_H_

//#include "output.h"
//
// Created by Joachim on 19.07.2020.
//

#ifndef PROGRAMMIERPROJEKT__OUTPUT_H_
#define PROGRAMMIERPROJEKT__OUTPUT_H_


void printElements(GameElement_t *head);

#endif //PROGRAMMIERPROJEKT__OUTPUT_H_


int PopList_updateLists(GameElement_t *element);

// GameElement.c
//
// Created by Joachim on 19.07.2020.
//
#include <stdlib.h>


GameElement_t *GameElement_new(long column, int color) {
	GameElement_t *newElement = calloc(1, sizeof(*newElement));
	if (newElement == NULL)
		return NULL;
	newElement->column = column;
	newElement->color = color;
	newElement->popList[DIRECTION_HORIZONTAL] = LinkedList_create();
	LinkedList_pushElement(newElement->popList[DIRECTION_HORIZONTAL], newElement);
	newElement->popList[DIRECTION_VERTICAL] = LinkedList_create();
	LinkedList_pushElement(newElement->popList[DIRECTION_VERTICAL], newElement);
	newElement->popList[DIRECTION_LRDIAGONAL] = LinkedList_create();
	LinkedList_pushElement(newElement->popList[DIRECTION_LRDIAGONAL], newElement);
	newElement->popList[DIRECTION_RLDIAGONAL] = LinkedList_create();
	LinkedList_pushElement(newElement->popList[DIRECTION_RLDIAGONAL], newElement);

	DEBUG_STATEMENT(gameElementCount++;)
	return newElement;
}

void GameElement_delete(GameElement_t *element, LinkedList_t** p_list) {
	if (element->popList[DIRECTION_HORIZONTAL]->size == 0 || (element->popList[DIRECTION_HORIZONTAL]->size == 1
		&& element->popList[DIRECTION_HORIZONTAL]->head->list_element == element)) {
		if (*p_list == element->popList[DIRECTION_HORIZONTAL])
			*p_list = NULL;
		LinkedList_delete(&element->popList[DIRECTION_HORIZONTAL]);
	}
	if (element->popList[DIRECTION_VERTICAL]->size == 0 || (element->popList[DIRECTION_VERTICAL]->size == 1
		&& element->popList[DIRECTION_VERTICAL]->head->list_element == element)) {
		if (*p_list == element->popList[DIRECTION_VERTICAL])
			*p_list = NULL;
		LinkedList_delete(&element->popList[DIRECTION_VERTICAL]);
	}
	if (element->popList[DIRECTION_LRDIAGONAL]->size == 0 || (element->popList[DIRECTION_LRDIAGONAL]->size == 1
		&& element->popList[DIRECTION_LRDIAGONAL]->head->list_element == element)) {
		if (*p_list == element->popList[DIRECTION_LRDIAGONAL])
			*p_list = NULL;
		LinkedList_delete(&element->popList[DIRECTION_LRDIAGONAL]);
	}
	if (element->popList[DIRECTION_RLDIAGONAL]->size == 0 || (element->popList[DIRECTION_RLDIAGONAL]->size == 1
		&& element->popList[DIRECTION_RLDIAGONAL]->head->list_element == element)) {
		if (*p_list == element->popList[DIRECTION_RLDIAGONAL])
			*p_list = NULL;
		LinkedList_delete(&element->popList[DIRECTION_RLDIAGONAL]);
	}

	free(element);

	DEBUG_STATEMENT(gameElementCount--;)
}

int GameElement_updateNeighbors(GameElement_t *element) {
	if (element == NULL) {
		return -1;
	}

	char do_right = 1;
	char do_left = 1;

	while (element) {
		if (element->lowerN != NULL) {
			if (element->rightN != NULL) {
				if (element->rightN->lowerN == element->lowerN->rightN) {
					// No change in neighbors
					do_right = 0;
					if (!do_left) {
						break;
					}
				} else {
					// Neighbors changed
					// Update Lower Right
					if (element->lowerRightN)
						element->lowerRightN->upperLeftN = NULL;
					element->lowerRightN = element->lowerN->rightN;
					if (element->lowerRightN) {
						element->lowerRightN->upperLeftN = element;
						// Right
						element->rightN->leftN = NULL;
						element->rightN = element->lowerRightN->upperN;
						if (element->rightN) {
							element->rightN->leftN = element;
							// Update Upper Right
							if (element->upperRightN)
								element->upperRightN->lowerLeftN = NULL;
							element->upperRightN = element->rightN->upperN;
							if (element->upperRightN)
								element->upperRightN->lowerLeftN = element;
						}
					}
				}
			} else {
				// No right neighbor before update
				if (element->lowerRightN)
					element->lowerRightN->upperLeftN = NULL;

				if (element->lowerN->rightN && element->lowerN->rightN->column != element->column + 1) {
					// if  lower neighbor is a baseline element
					// then the side neighbors are not necessarily bounding each other
					do_right = 0;
					if (!do_left) {
						break;
					}
				}
				element->lowerRightN = element->lowerN->rightN;
				if (element->lowerRightN) {
					element->rightN = element->lowerRightN->upperN;
					element->lowerRightN->upperLeftN = element;
				}
				if (element->rightN) {
					element->upperRightN = element->rightN->upperN;
					element->rightN->leftN = element;
				}
				if (element->upperRightN) {
					element->upperRightN->lowerLeftN = element;
				}
				do_right = 0;
				if (!do_left) {
					break;
				}
			}
			if (element->leftN != NULL) {
				if (element->leftN->lowerN == element->lowerN->leftN) {
					// No change in neighbors
					do_left = 0;
					if (!do_right) {
						break;
					}
				} else {
					// Neighbors changed
					// Update Lower Left
					if (element->lowerLeftN)
						element->lowerLeftN->upperRightN = NULL;
					element->lowerLeftN = element->lowerN->leftN;
					if (element->lowerLeftN) {
						element->lowerLeftN->upperRightN = element;
						// Left
						element->leftN->rightN = NULL;
						element->leftN = element->lowerLeftN->upperN;
						if (element->leftN) {
							element->leftN->rightN = element;
							// Update Upper Left
							if (element->upperLeftN)
								element->upperLeftN->lowerRightN = NULL;
							element->upperLeftN = element->leftN->upperN;
							if (element->upperLeftN)
								element->upperLeftN->lowerRightN = element;
						}
					}
				}
			} else {
				// No left neighbor before update
				if (element->lowerLeftN)
					element->lowerLeftN->upperRightN = NULL;

				if (element->lowerN->leftN && element->lowerN->leftN->column != element->column - 1) {
					// if  lower neighbor is a baseline element
					// then the side neighbors are not necessarily bounding each other
					do_left = 0;
					if (!do_right) {
						break;
					}
				}
				element->lowerLeftN = element->lowerN->leftN;
				if (element->lowerLeftN) {
					element->lowerLeftN->upperRightN = element;
					element->leftN = element->lowerLeftN->upperN;
				}
				if (element->leftN) {
					element->leftN->rightN = element;
					element->upperLeftN = element->leftN->upperN;
				}
				if (element->upperLeftN) {
					element->upperLeftN->lowerRightN = element;
				}
			}
		} else {
			// Baseline
			if (element->lowerRightN) {
				// Invalidate lower right neighbor if necessary
				element->lowerRightN->upperLeftN = NULL;
				element->lowerRightN = NULL;
			}
			if (element->rightN && element->rightN->column == element->column + 1) {
				if (element->rightN->leftN != element) {
					DEBUG_OUT("Wrong connection between elements!");
					return -1;
				}
				if (element->upperRightN)
					element->upperRightN->lowerLeftN = NULL;
				element->upperRightN = element->rightN->upperN;
				if (element->upperRightN) {
					element->upperRightN->lowerLeftN = element;
				}
			}
			// Baseline
			if (element->lowerLeftN) {
				// Invalidate lower left neighbor if necessary
				element->lowerLeftN->upperRightN = NULL;
				element->lowerLeftN = NULL;
			}
			if (element->leftN && element->leftN->column == element->column - 1) {
				if (element->leftN->rightN != element) {
					DEBUG_OUT("Wrong connection between elements!");
					return -1;
				}
				if (element->upperLeftN)
					element->upperLeftN->lowerRightN = NULL;
				element->upperLeftN = element->leftN->upperN;
				if (element->upperLeftN) {
					element->upperLeftN->lowerRightN = element;
				}
			}
		}
//		PopList_updateLists(element);
		element = element->upperN;
	}
	return 0;
}

int GameElement_updateRightNeighbors(GameElement_t *element) {
	if (element == NULL) {
		return -1;
	}

	if (element->lowerN != NULL) {
		if (element->rightN != NULL) {
			if (element->rightN->lowerN == element->lowerN->rightN) {
				// No change in neighbors
				return 0;
			} else {
				// Neighbors changed
				// Update Lower Right
				element->lowerRightN->upperLeftN = NULL;
				element->lowerRightN = element->lowerN->rightN;
				if (element->lowerRightN)
					element->lowerRightN->upperLeftN = element;
				// Right
				element->rightN->leftN = NULL;
				element->rightN = element->lowerRightN->upperN;
				if (element->rightN)
					element->rightN->leftN = element;
				// Update Upper Right
				if (element->upperRightN)
					element->upperRightN->lowerLeftN = NULL;
				element->upperRightN = element->rightN->upperN;
				if (element->upperRightN)
					element->upperRightN->lowerLeftN = element;
				if (element->upperN) {
					return GameElement_updateRightNeighbors(element->upperN);
				}
			}
		} else {
			// No right neighbor before update
			if (element->lowerRightN)
				element->lowerRightN->upperLeftN = NULL;

			if (element->lowerN->rightN && element->lowerN->rightN->column != element->column + 1) {
				// if  lower neighbor is a baseline element
				// then the side neighbors are not necessarily bounding each other
				return 0;
			}
			element->lowerRightN = element->lowerN->rightN;
			if (element->lowerRightN) {
				element->rightN = element->lowerRightN->upperN;
				element->lowerRightN->upperLeftN = element;
			}
			if (element->rightN) {
				element->upperRightN = element->rightN->upperN;
				element->rightN->leftN = element;
			}
			if (element->upperRightN) {
				element->upperRightN->lowerLeftN = element;
			}
			return 0;
		}
	} else {
		// Baseline
		if (element->lowerRightN) {
			// Invalidate lower right neighbor if necessary
			element->lowerRightN->upperLeftN = NULL;
			element->lowerRightN = NULL;
		}
		if (element->rightN && element->rightN->column == element->column + 1) {
			if (element->rightN->leftN != element) {
				DEBUG_OUT("Wrong connection between elements!");
				return -1;
			}
			if (element->upperRightN)
				element->upperRightN->lowerLeftN = NULL;
			element->upperRightN = element->rightN->upperN;
			if (element->upperRightN) {
				element->upperRightN->lowerLeftN = element;
			}
			if (element->upperN) {
				return GameElement_updateRightNeighbors(element->upperN);
			}
		}
	}
	return 0;
}



// LinkedList.c
//
// Created by Joachim on 19.07.2020.
//

#include <stdio.h>
#include <stdlib.h>

int LinkedList_pushElement(LinkedList_t *list, void *element) {
	if (list == NULL) {
		return -1;
	}
	if (element == NULL) {
		return -1;
	}

	LinkedListNode_t *newNode = calloc(1, sizeof(*newNode));
	if (newNode == NULL) {
		return -1;
	}
	newNode->list_element = element;

	// List empty, add as head and tail
	if (list->tail == NULL) {
		list->head = newNode;
		list->tail = newNode;
	}
		// List not empty, alter only tail
	else {
		list->tail->next = newNode;
		newNode->previous = list->tail;
		list->tail = newNode;
	}
	list->size++;
	return 0;
}

int LinkedList_addElementWithoutDuplicats(LinkedList_t *list, void *element) {
	if (list == NULL)
		return -1;
	if (element == NULL)
		return 0;
	LinkedListNode_t *current_node = list->head;
	while (current_node) {
		if (current_node->list_element == element)
			return 0;
		current_node = current_node->next;
	}
	return LinkedList_pushElement(list, element);
}

void *LinkedList_popElement(LinkedList_t *list) {
	if (list == NULL || list->head == NULL || list->tail == NULL) {
		return NULL;
	}
	if (list->size <= 0) {
		return NULL;
	}
	void *ret = list->head->list_element;
	if (list->head->next) {
		list->head = list->head->next;
		free(list->head->previous);
		list->head->previous = NULL;
	} else {
		free(list->head);
		list->head = NULL;
		list->tail = NULL;
	}
	list->size--;
	return ret;
}

int LinkedList_removeElement(LinkedList_t *list, void *element) {
	if (list == NULL)
		return -1;
	if (element == NULL)
		return 0;
	if (list->size == 0) {
		return -1;
	}
	LinkedListNode_t *current_node = list->head;
	while (current_node) {
		if (current_node->list_element == element) {
			if (current_node->previous)
				current_node->previous->next = current_node->next;
			else {
				list->head = current_node->next;
				if (list->head)
					list->head->previous = NULL;
			}
			if (current_node->next)
				current_node->next->previous = current_node->previous;
			else {
				list->tail = current_node->previous;
				if (list->tail)
					list->tail->next = NULL;
			}

			free(current_node);
			list->size--;
			// search for duplicats
			if (list->size) {
				current_node = list->head;
			}
			else {
				return 0;
			}
		}
		current_node = current_node->next;
	}
	return 0;
}

/**
 * Merge two LinkedList_t objects
 * @param list list to merge into
 * @param otherList pointer to second list, second list is freed and pointer is updated to first list
 * @return first list
 */
LinkedList_t *LinkedList_merge(LinkedList_t *list, LinkedList_t **otherList) {
	if (!list || !otherList)
		return NULL;
	if (list == *otherList) {
		return list;
	}
	while ((*otherList)->head) {
		list->tail->next = (*otherList)->head;
		list->tail->next->previous = list->tail;
		list->tail = list->tail->next;
		list->size++;
		(*otherList)->head = (*otherList)->head->next;
	}

	free(*otherList);
	*otherList = list;
	DEBUG_OUT("Merging Lists\n");
	return list;
}


LinkedList_t *LinkedList_create() {
	return calloc(1, sizeof(LinkedList_t));
}

void LinkedList_delete(LinkedList_t **p_list) {
	LinkedList_t *list = *p_list;
	while (LinkedList_popElement(list));
	free(list);
	*p_list = NULL;
}

// input.c

//
// Created by Joachim on 19.07.2020.
//
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>


int convertLine(char *buffer, int *color, long *column) {
	char *endptr;
	char *_buffer = buffer;
	int _color;
	long _column;
	_color = strtol(_buffer, &endptr, 10);
	if (endptr == _buffer) {
		fprintf(stderr, "Could not convert String to Number: %s\n", buffer);
		return -EINVAL;
	}
	if (_color < 0 || _color > 255) {
		fprintf(stderr, "Color Code out of Range: %d\n", _color);
		return -ERANGE;
	}
	if (*endptr != '\0') {
		_buffer = endptr;
		endptr = NULL;
		_column = strtol(_buffer, &endptr, 10);
		if (endptr == _buffer) {
			fprintf(stderr, "Could not convert String to Number: %s\n", buffer);
			return -EINVAL;
		}
	} else {
		fprintf(stderr, "Invalid Line format: %s\n", buffer);
		return -EINVAL;
	}
	if (endptr == buffer) {
		fprintf(stderr, "Could not convert String to Number: %s\n", buffer);
		return -EINVAL;
	}

	*color = _color;
	*column = _column;
	return 0;
}

char *rtrim(char *buf) {
	const char *separators = "\t\n\v\f\r ";
	size_t length = strlen(buf) - 1;
	while (strchr(separators, buf[length]) != NULL) {
		buf[length] = '\0';
		if (length == 0)
			break;
		length--;
	}
	return buf;
}

int Input_getNextLine(int *color, long *column) {
	char buffer[255];
	if (!fgets(buffer, 255, stdin)) {
		return 1;
	}

	// Remove trailing whitespaces and convert the read line to color and column integers
	// If line doesn't meet the requirements an errorcode is return and the execution of the program is halted

	rtrim(buffer);
	return convertLine(buffer, color, column);
}

// output.c
//
// Created by Joachim on 19.07.2020.
//

#include <stdio.h>

void printElements(GameElement_t *head) {
	GameElement_t *currentElement = head;
	if (!head) {
		return;
	}
	GameElement_t *rbase = head->rightN;
	GameElement_t *lbase = head->leftN;
	DEBUG_STATEMENT(long count = 1;)
	DEBUG_OUT("Added Element:\n");
	unsigned long row = 0;
	printf("\n");
	while (currentElement) {
		DEBUG_STATEMENT(DEBUG_OUT("Count = %ld, Color: %d, Column: %ld, Row: %ld\n",
								  count++,
								  currentElement->color,
								  currentElement->column,
								  row);)
		printf("%d %ld %ld\n",currentElement->color, currentElement->column, row);
		if (currentElement->upperN) {
			currentElement = currentElement->upperN;
			row++;
		} else {
			if (rbase) {
				currentElement = rbase;
				rbase = rbase->rightN;
			} else if (lbase) {
				currentElement = lbase;
				lbase = lbase->leftN;
			} else {
				break;
			}
			row = 0;
		}
	}
}




/*
 * Datenverarbeitung
 */


LinkedList_t *neighborUpdateList;
LinkedList_t *elementPopList;

GameElement_t *gHeadElement = NULL;

GameElement_t *popGameElementfromList(LinkedList_t *list) {
	return (GameElement_t *) LinkedList_popElement(list);
}

int removeGameElementFromList(LinkedList_t *list, GameElement_t *element) {
	if (list == NULL)
		return -1;
	if (element == NULL)
		return 0;
	LinkedListNode_t *current_node = list->head;
	while (current_node) {
		if (current_node->list_element == element) {
			if (current_node->previous)
				current_node->previous->next = current_node->next;
			else {
				list->head = current_node->next;
				if (list->head)
					list->head->previous = NULL;
			}
			if (current_node->next)
				current_node->next->previous = current_node->previous;
			else {
				list->tail = current_node->previous;
				if (list->tail)
					list->tail->next = NULL;
			}

			free(current_node);
			list->size--;
			if (list->size) {
				current_node = list->head;
			} else {
				return 0;
			}
		}
		current_node = current_node->next;
	}
	return -1;
}

LinkedList_t *popLinkedListfromList(LinkedList_t *list) {
	return (LinkedList_t *) LinkedList_popElement(list);
}

int updateNeighbors();
int popElements();

int removeGameElement(GameElement_t *element);

int PopList_updateAllinList(LinkedList_t *popList, Direction_e direction) {
	if (popList->size == 0) {
		return 0;
	}
	LinkedListNode_t *currentNode = popList->head->next;
	while (currentNode) {
		GameElement_t *element = currentNode->list_element;
		if (element->popList[direction] != popList) {
//			LinkedList_delete(&element->popList[direction]);
			element->popList[direction] = popList;
		}
		currentNode = currentNode->next;
	}
	return 0;
}

int PopList_updateLists(GameElement_t *element) {
	// Update poplist

	// Update vertical poplist
	// if the neighbors are matching merge the existing lists
	if (element->popList[DIRECTION_VERTICAL]->size > 1) {
		removeGameElementFromList(element->popList[DIRECTION_VERTICAL], element);
		element->popList[DIRECTION_VERTICAL] = LinkedList_create();
		LinkedList_pushElement(element->popList[DIRECTION_VERTICAL], element);
	}
	if (element->lowerN && element->lowerN->color == element->color) {
		element->popList[DIRECTION_VERTICAL] =
			LinkedList_merge(element->lowerN->popList[DIRECTION_VERTICAL], &element->popList[DIRECTION_VERTICAL]);
	}
	if (element->upperN && element->upperN->color == element->color) {
		element->popList[DIRECTION_VERTICAL] =
			LinkedList_merge(element->upperN->popList[DIRECTION_VERTICAL], &element->popList[DIRECTION_VERTICAL]);
	}

	PopList_updateAllinList(element->popList[DIRECTION_VERTICAL], DIRECTION_VERTICAL);
	// Update Horizontal PopList
	if (element->popList[DIRECTION_HORIZONTAL]->size > 1) {
		removeGameElementFromList(element->popList[DIRECTION_HORIZONTAL], element);
		element->popList[DIRECTION_HORIZONTAL] = LinkedList_create();
		LinkedList_pushElement(element->popList[DIRECTION_HORIZONTAL], element);
	}
	if (element->leftN
		&& element->leftN->color == element->color
		&& element->leftN->column == element->column - 1) {
		LinkedList_merge(element->leftN->popList[DIRECTION_HORIZONTAL], &element->popList[DIRECTION_HORIZONTAL]);
	}
	if (element->rightN
		&& element->rightN->color == element->color
		&& element->rightN->column == element->column + 1) {
		LinkedList_merge(element->rightN->popList[DIRECTION_HORIZONTAL], &element->popList[DIRECTION_HORIZONTAL]);
	}
	PopList_updateAllinList(element->popList[DIRECTION_HORIZONTAL], DIRECTION_HORIZONTAL);

	// Update LRDiagonal PopList
	if (element->popList[DIRECTION_LRDIAGONAL]->size > 1) {
		removeGameElementFromList(element->popList[DIRECTION_LRDIAGONAL], element);
		element->popList[DIRECTION_LRDIAGONAL] = LinkedList_create();
		LinkedList_pushElement(element->popList[DIRECTION_LRDIAGONAL], element);
	}
	if (element->lowerLeftN && element->lowerLeftN->color == element->color) {
		element->popList[DIRECTION_LRDIAGONAL] =
			LinkedList_merge(element->lowerLeftN->popList[DIRECTION_LRDIAGONAL],
							 &element->popList[DIRECTION_LRDIAGONAL]);
	}
	if (element->upperRightN && element->upperRightN->color == element->color) {
		element->popList[DIRECTION_LRDIAGONAL] =
			LinkedList_merge(element->upperRightN->popList[DIRECTION_LRDIAGONAL],
							 &element->popList[DIRECTION_LRDIAGONAL]);
	}
	PopList_updateAllinList(element->popList[DIRECTION_LRDIAGONAL], DIRECTION_LRDIAGONAL);
	// Update RLDiagonal Poplist
	if (element->popList[DIRECTION_RLDIAGONAL]->size > 1) {
		removeGameElementFromList(element->popList[DIRECTION_RLDIAGONAL], element);
		element->popList[DIRECTION_RLDIAGONAL] = LinkedList_create();
		LinkedList_pushElement(element->popList[DIRECTION_RLDIAGONAL], element);
	}
	if (element->lowerRightN && element->lowerRightN->color == element->color) {
		element->popList[DIRECTION_RLDIAGONAL] =
			LinkedList_merge(element->lowerRightN->popList[DIRECTION_RLDIAGONAL],
							 &element->popList[DIRECTION_RLDIAGONAL]);
	}
	if (element->upperLeftN && element->upperLeftN->color == element->color) {
		element->popList[DIRECTION_RLDIAGONAL] =
			LinkedList_merge(element->upperLeftN->popList[DIRECTION_RLDIAGONAL],
							 &element->popList[DIRECTION_RLDIAGONAL]);
	}
	PopList_updateAllinList(element->popList[DIRECTION_RLDIAGONAL], DIRECTION_RLDIAGONAL);

	if (element->popList[DIRECTION_VERTICAL]->size >= 4) {
		LinkedList_addElementWithoutDuplicats(elementPopList, element->popList[DIRECTION_VERTICAL]);
		DEBUG_OUT("Need to Pop Vertical, Count: %ld, color: %d\n",
				  element->popList[DIRECTION_VERTICAL]->size,
				  element->color);
	}
	if (element->popList[DIRECTION_HORIZONTAL]->size >= 4) {
		LinkedList_addElementWithoutDuplicats(elementPopList, element->popList[DIRECTION_HORIZONTAL]);
		DEBUG_OUT("Need to Pop Horizontal, Count: %ld, color: %d\n",
				  element->popList[DIRECTION_HORIZONTAL]->size,
				  element->color);
	}
	if (element->popList[DIRECTION_LRDIAGONAL]->size >= 4) {
		LinkedList_addElementWithoutDuplicats(elementPopList, element->popList[DIRECTION_LRDIAGONAL]);
		DEBUG_OUT("Need to Pop LRDiagonal, Count: %ld, color: %d\n",
				  element->popList[DIRECTION_LRDIAGONAL]->size,
				  element->color);
	}
	if (element->popList[DIRECTION_RLDIAGONAL]->size >= 4) {
		LinkedList_addElementWithoutDuplicats(elementPopList, element->popList[DIRECTION_RLDIAGONAL]);
		DEBUG_OUT("Need to Pop RLDiagonal, Count: %ld, color: %d\n",
				  element->popList[DIRECTION_RLDIAGONAL]->size,
				  element->color);
	}
	return 0;
}

int popElements() {
	if (elementPopList->size == 0) {
		return 0;
	}

	while (elementPopList->size > 0) {
		LinkedList_t *temp_popList = elementPopList;
		elementPopList = calloc(1, sizeof(*elementPopList));
		LinkedList_t *list = popLinkedListfromList(temp_popList);
		while (list) {

//			DEBUG_STATEMENT(printElements(gHeadElement);)
			GameElement_t *current_element = popGameElementfromList(list);
			while (current_element) {
				removeGameElement(current_element);
				GameElement_delete(current_element, &list);
				current_element = popGameElementfromList(list);
//				updateNeighbors();
			}


			list = popLinkedListfromList(temp_popList);

//			DEBUG_STATEMENT(printElements(gHeadElement);)
		}
		free(temp_popList);
		updateNeighbors();

	}

	return 0;
}

int removeGameElement(GameElement_t *element) {
	if (element == NULL)
		return -1;

	if (element->lowerN) {
		element->lowerN->upperN = element->upperN;
		if (element->upperN) {
			element->upperN->lowerN = element->lowerN;
		}
		if (element->lowerLeftN && element->lowerLeftN->upperRightN == element) {
			element->lowerLeftN->upperRightN = NULL;
		}
		if (element->lowerRightN && element->lowerRightN->upperLeftN == element) {
			element->lowerRightN->upperLeftN = NULL;
		}
		if (element->rightN && element->rightN->leftN == element) {
			element->rightN->leftN = NULL;
		}
		if (element->leftN && element->leftN->rightN == element) {
			element->leftN->rightN = NULL;
		}
		if (element->upperLeftN && element->upperLeftN->lowerRightN == element) {
			element->upperLeftN->lowerRightN = NULL;
		}
		if (element->upperRightN && element->upperRightN->lowerLeftN == element) {
			element->upperRightN->lowerLeftN = NULL;
		}
		if (element->baseN && element->baseN->topN == element) {
			if (element->upperN == NULL) {
				element->baseN->topN = element->lowerN;
				element->lowerN->baseN = element->baseN;
			}
			else {
				element->baseN->topN = NULL;
			}
		}
		if (element->topN && element->topN->baseN == element) {
			element->topN->baseN = NULL;
		}
	}
		// else also update right and left neighbor regardless of column (baseline element)
	else {
		if (element->upperN) {
			element->upperN->lowerN = NULL;
			if (element->upperN->leftN)
				element->upperN->leftN->rightN = NULL;
			element->upperN->leftN = element->leftN;
			if (element->upperN->rightN)
				element->upperN->rightN->leftN = NULL;
			element->upperN->rightN = element->rightN;
			if (element->rightN)
				element->rightN->leftN = element->upperN;
			if (element->leftN)
				element->leftN->rightN = element->upperN;
		} else {
			if (element->rightN) {
				element->rightN->leftN = element->leftN;
			}
			if (element->leftN) {
				element->leftN->rightN = element->rightN;
			}
		}
		if (element->lowerLeftN) {
			element->lowerLeftN->upperRightN = NULL;
		}
		if (element->lowerRightN) {
			element->lowerRightN->upperLeftN = NULL;
		}
		if (element->upperLeftN) {
			element->upperLeftN->lowerRightN = NULL;
		}
		if (element->upperRightN) {
			element->upperRightN->lowerLeftN = NULL;
		}
		if (element->topN && element->topN != element->baseN && element->topN->baseN == element) {
			element->topN->baseN = element->upperN;
			element->upperN->topN = element->topN;
		}

		if (element->baseN && element->baseN->topN == element) {
			element->baseN->topN = NULL;
		}

		if (gHeadElement == element) {
			if (element->rightN) {
				gHeadElement = element->rightN;
			} else if (element->leftN) {
				gHeadElement = element->leftN;
			} else {
				gHeadElement = element->upperN;
			}
		}
	}

	removeGameElementFromList(element->popList[0], element);
	removeGameElementFromList(element->popList[1], element);
	removeGameElementFromList(element->popList[2], element);
	removeGameElementFromList(element->popList[3], element);

	if (element->upperN) {
		LinkedList_addElementWithoutDuplicats(neighborUpdateList, element->upperN);
	}

	removeGameElementFromList(neighborUpdateList, element);
	return 0;
}

int insertGameElement(GameElement_t *newElement) {
	if (gHeadElement == NULL) {
		gHeadElement = newElement;
		return 0;
	}

	GameElement_t *currentElement = gHeadElement;

	if (newElement->column > currentElement->column) {
		while (currentElement->rightN && newElement->column >= currentElement->rightN->column)
			currentElement = currentElement->rightN;
	} else if (newElement->column < currentElement->column) {
		while (currentElement->leftN && newElement->column < currentElement->column)
			currentElement = currentElement->leftN;
	}
	// currentElement hat jetzt die gleiche oder nächstkleinere Spaltennummer als newElement
	// Ausnahme: Wir befinden uns am linken äußeren Ende der der List, dann kann die Spaltennummer
	// von currentElement auch noch größer sein als newElement.
	// Hier wird dann das neue Element links vom current Element eingefügt.

	// Das neue Element oberhalb des obersten Elements in der Spalte einfügen
	if (currentElement->column == newElement->column) {
		gHeadElement = currentElement;
		if (!gHeadElement->topN) {
			while (currentElement->upperN) {
				currentElement = currentElement->upperN;
			}
		} else {
			currentElement = currentElement->topN;
		}
		currentElement->upperN = newElement;
		newElement->lowerN = currentElement;
		currentElement->baseN = NULL;
		currentElement->topN = NULL;
		gHeadElement->topN = newElement;
		newElement->baseN = gHeadElement;
	}
		// das neue Element rechts neben dem letzten Element auf der Grundlinie einfügen
		// Da die Spalte leer ist, braucht man hier nicht nach oben suchen
	else if (currentElement->column < newElement->column) {
		newElement->leftN = currentElement;
		newElement->rightN = currentElement->rightN;
		if (currentElement->rightN)
			currentElement->rightN->leftN = newElement;
		currentElement->rightN = newElement;
		gHeadElement = newElement;
	}
		// wir befinden uns am linken Ende des Spielfeldes. currentElement hat die nächstgrößere Spaltennummer
	else {
		newElement->rightN = currentElement;
		currentElement->leftN = newElement;
		gHeadElement = newElement;
	}

	return LinkedList_pushElement(neighborUpdateList, newElement);
}

int updateNeighbors() {
	int ret = 0;
	// List Empty --> Nothing to do
	if (neighborUpdateList->size == 0) {
		return 0;
	}

	GameElement_t *currentElement = popGameElementfromList(neighborUpdateList);
	while (currentElement) {
		ret = GameElement_updateNeighbors(currentElement);
		if (ret)
			return ret;

		PopList_updateLists(currentElement);
		currentElement = popGameElementfromList(neighborUpdateList);
	}
	return ret;
}

//int updateNeighbors() {
//	// List Empty --> Nothing to do
//	if (neighborUpdateList->size == 0) {
//		return 0;
//	}
//
//	GameElement_t *currentElement = popGameElementfromList(neighborUpdateList);
//	while (currentElement) {
//		if (currentElement->lowerN) {
//			// Update Left Neighbors
//			// Lower Left
//			if (currentElement->lowerN->leftN && currentElement->lowerN->leftN->column == currentElement->column - 1) {
//				// Update previous neighbor
//				if (currentElement->lowerLeftN && currentElement->lowerLeftN != currentElement->lowerN->leftN) {
//					LinkedList_pushElement(neighborUpdateList, currentElement->lowerLeftN);
//					GameElement_removeAsNeighbor(currentElement, NEIGHBOR_LOWER_LEFT);
//				}
//				GameElement_addNeighbor(currentElement, currentElement->lowerN->leftN, NEIGHBOR_LOWER_LEFT);
//				// Left
//				if (currentElement->lowerLeftN->upperN) {
//					// Update previous neighbor
//					if (currentElement->leftN && currentElement->leftN != currentElement->lowerLeftN->upperN) {
//						LinkedList_pushElement(neighborUpdateList, currentElement->leftN);
//						GameElement_removeAsNeighbor(currentElement, NEIGHBOR_LEFT);
//					}
//					GameElement_addNeighbor(currentElement, currentElement->lowerLeftN->upperN, NEIGHBOR_LEFT);
//					// Upper Left
//					if (currentElement->leftN->upperN) {
//						// Update previous neighbor
//						if (currentElement->upperLeftN && currentElement->upperLeftN != currentElement->leftN->upperN) {
//							LinkedList_pushElement(neighborUpdateList, currentElement->upperLeftN);
//							GameElement_removeAsNeighbor(currentElement, NEIGHBOR_UPPER_LEFT);
//						}
//						GameElement_addNeighbor(currentElement, currentElement->leftN->upperN, NEIGHBOR_UPPER_LEFT);
//					}
//						// no Upper Left
//					else {
//						// if there was a neighbor before the update then it needs to update too
//						if (currentElement->upperLeftN) {
//							LinkedList_pushElement(neighborUpdateList, currentElement->upperLeftN);
//							GameElement_removeAsNeighbor(currentElement, NEIGHBOR_UPPER_LEFT);
//						}
//						currentElement->upperLeftN = NULL;
//					}
//				}
//					// no Left then no Upper Left
//				else {
//					if (currentElement->leftN) {
//						LinkedList_pushElement(neighborUpdateList, currentElement->leftN);
//						GameElement_removeAsNeighbor(currentElement, NEIGHBOR_LEFT);
//					}
//					currentElement->leftN = NULL;
//					if (currentElement->upperLeftN) {
//						LinkedList_pushElement(neighborUpdateList, currentElement->upperLeftN);
//						GameElement_removeAsNeighbor(currentElement, NEIGHBOR_UPPER_LEFT);
//					}
//					currentElement->upperLeftN = NULL;
//				}
//			}
//				// if there is no lower left neighbor then there are no neighbors above it.
//			else {
//				if (currentElement->lowerLeftN) {
//					LinkedList_pushElement(neighborUpdateList, currentElement->lowerLeftN);
//					GameElement_removeAsNeighbor(currentElement, NEIGHBOR_LOWER_LEFT);
//
//				}
//				currentElement->lowerLeftN = NULL;
//				if (currentElement->leftN) {
//					LinkedList_pushElement(neighborUpdateList, currentElement->leftN);
//					GameElement_removeAsNeighbor(currentElement, NEIGHBOR_LEFT);
//
//				}
//				currentElement->leftN = NULL;
//				if (currentElement->upperLeftN) {
//					LinkedList_pushElement(neighborUpdateList, currentElement->upperLeftN);
//					GameElement_removeAsNeighbor(currentElement, NEIGHBOR_UPPER_LEFT);
//
//				}
//				currentElement->upperLeftN = NULL;
//			}
//			// Same procedure as with left neighbors
//			if (currentElement->lowerN->rightN
//				&& currentElement->lowerN->rightN->column == currentElement->column + 1) {
//				if (currentElement->lowerRightN && currentElement->lowerRightN != currentElement->lowerN->rightN) {
//					LinkedList_pushElement(neighborUpdateList, currentElement->lowerRightN);
//					GameElement_removeAsNeighbor(currentElement, NEIGHBOR_LOWER_RIGHT);
//				}
//				GameElement_addNeighbor(currentElement, currentElement->lowerN->rightN, NEIGHBOR_LOWER_RIGHT);
//				if (currentElement->lowerRightN->upperN) {
//					if (currentElement->rightN && currentElement->rightN != currentElement->lowerRightN->upperN) {
//						LinkedList_pushElement(neighborUpdateList, currentElement->rightN);
//						GameElement_removeAsNeighbor(currentElement, NEIGHBOR_RIGHT);
//
//					}
//					GameElement_addNeighbor(currentElement, currentElement->lowerRightN->upperN, NEIGHBOR_RIGHT);
//					if (currentElement->rightN->upperN) {
//						if (currentElement->upperRightN && currentElement->upperRightN != currentElement->rightN->upperN) {
//							LinkedList_pushElement(neighborUpdateList, currentElement->upperRightN);
//							GameElement_removeAsNeighbor(currentElement, NEIGHBOR_UPPER_RIGHT);
//
//						}
//						GameElement_addNeighbor(currentElement, currentElement->rightN->upperN, NEIGHBOR_UPPER_RIGHT);
//					} else {
//						if (currentElement->upperRightN) {
//							LinkedList_pushElement(neighborUpdateList, currentElement->upperRightN);
//							GameElement_removeAsNeighbor(currentElement, NEIGHBOR_UPPER_RIGHT);
//
//						}
//						currentElement->upperRightN = NULL;
//					}
//				} else {
//					if (currentElement->rightN) {
//						LinkedList_pushElement(neighborUpdateList, currentElement->rightN);
//						GameElement_removeAsNeighbor(currentElement, NEIGHBOR_RIGHT);
//
//					}
//					currentElement->rightN = NULL;
//					if (currentElement->upperRightN) {
//						LinkedList_pushElement(neighborUpdateList, currentElement->upperRightN);
//						GameElement_removeAsNeighbor(currentElement, NEIGHBOR_UPPER_RIGHT);
//
//					}
//					currentElement->upperRightN = NULL;
//				}
//			} else {
//				if (currentElement->lowerRightN) {
//					LinkedList_pushElement(neighborUpdateList, currentElement->lowerRightN);
//					GameElement_removeAsNeighbor(currentElement, NEIGHBOR_LOWER_RIGHT);
//
//				}
//				currentElement->lowerRightN = NULL;
//				if (currentElement->rightN) {
//					LinkedList_pushElement(neighborUpdateList, currentElement->rightN);
//					GameElement_removeAsNeighbor(currentElement, NEIGHBOR_RIGHT);
//
//				}
//				currentElement->rightN = NULL;
//				if (currentElement->upperRightN) {
//					LinkedList_pushElement(neighborUpdateList, currentElement->upperRightN);
//					GameElement_removeAsNeighbor(currentElement, NEIGHBOR_UPPER_RIGHT);
//
//				}
//				currentElement->upperRightN = NULL;
//			}
//		}
//			// Special treatment of Row 0, there are no lower Neighbors
//			// and right and left neighbors are not necessarily bounding to each other
//		else {
//			if (currentElement->lowerLeftN) {
//				LinkedList_pushElement(neighborUpdateList, currentElement->lowerLeftN);
//				GameElement_removeAsNeighbor(currentElement, NEIGHBOR_LOWER_LEFT);
//			}
//			currentElement->lowerLeftN = NULL;
//			if (currentElement->lowerRightN) {
//				LinkedList_pushElement(neighborUpdateList, currentElement->lowerRightN);
//				GameElement_removeAsNeighbor(currentElement, NEIGHBOR_LOWER_RIGHT);
//			}
//			currentElement->lowerRightN = NULL;
//			if (currentElement->lowerN) {
//				LinkedList_pushElement(neighborUpdateList, currentElement->lowerN);
//				GameElement_removeAsNeighbor(currentElement, NEIGHBOR_LOWER);
//
//			}
//			currentElement->lowerN = NULL;
//
//			if (currentElement->leftN
//				&& currentElement->leftN->column == currentElement->column - 1
//				&& currentElement->leftN->upperN) {
//				if (currentElement->upperLeftN && currentElement->upperLeftN != currentElement->leftN->upperN) {
//					LinkedList_pushElement(neighborUpdateList, currentElement->upperLeftN);
//					GameElement_removeAsNeighbor(currentElement, NEIGHBOR_UPPER_LEFT);
//
//				}
//				GameElement_addNeighbor(currentElement, currentElement->leftN->upperN, NEIGHBOR_UPPER_LEFT);
//			} else {
//				if (currentElement->upperLeftN) {
//					LinkedList_pushElement(neighborUpdateList, currentElement->upperLeftN);
//					GameElement_removeAsNeighbor(currentElement, NEIGHBOR_UPPER_LEFT);
//				}
//				currentElement->upperLeftN = NULL;
//			}
//			if (currentElement->rightN
//				&& currentElement->rightN->column == currentElement->column + 1
//				&& currentElement->rightN->upperN) {
//				if (currentElement->upperRightN && currentElement->upperRightN != currentElement->rightN->upperN) {
//					LinkedList_pushElement(neighborUpdateList,currentElement->upperRightN);
//					GameElement_removeAsNeighbor(currentElement, NEIGHBOR_UPPER_RIGHT);
//
//				}
//				GameElement_addNeighbor(currentElement, currentElement->rightN->upperN, NEIGHBOR_UPPER_RIGHT);
//			} else {
//				if (currentElement->upperRightN) {
//					LinkedList_pushElement(neighborUpdateList, currentElement->upperRightN);
//					GameElement_removeAsNeighbor(currentElement, NEIGHBOR_UPPER_RIGHT);
//
//				}
//				currentElement->upperRightN = NULL;
//			}
//
//		}
//
//		PopList_updateLists(currentElement);
//		currentElement = popGameElementfromList(neighborUpdateList);
//	}
//
//	return 0;
//}

int main() {
	int ret = 0;
	int color;
	long column;
	DEBUG_STATEMENT(long count = 0;)

	neighborUpdateList = LinkedList_create();
	elementPopList = LinkedList_create();

	while ((ret = Input_getNextLine(&color, &column)) == 0) {

		DEBUG_OUT("Count %ld, Color %d, Column %ld\n", count++, color, column);
		// Throw the color in the matching column
		if (insertGameElement(GameElement_new(column, color))) {
			DEBUG_OUT("Could not insert Game Element");
		}
		updateNeighbors();

		popElements();

	}
	if (ret == 1)
		ret =0;

	printElements(gHeadElement);
	DEBUG_OUT("Remaining GameElements: %ld\n", gameElementCount);

	free(elementPopList);
	free(neighborUpdateList);

	return ret;
}
