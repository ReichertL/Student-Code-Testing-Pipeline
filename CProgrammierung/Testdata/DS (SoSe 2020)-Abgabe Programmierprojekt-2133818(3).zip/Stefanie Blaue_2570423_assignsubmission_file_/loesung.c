/*header*/
#define _POSIX_C_SOURCE  200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <ctype.h>
#include <assert.h> //kann raus?
#include <errno.h> //Kann raus?

/* internal structures*/
/* internal variables*/
typedef struct {
    int **columns;
    int *heights;
    int arraylength;
    int offset;
} board_t;
board_t board;

/*List for all stones that have to be deleted in board */
typedef struct matchedStone {
    int xcoord;
    int ycoord;
    int colour; //kann RAUSOPTIMIERT werden nach Fertigstellung
    struct matchedStone * next;
} matchedStone_t;
matchedStone_t *stoneList = NULL;

/*List for all columns that need to be checked afte deleting stones */
typedef struct columnsToCheck {
    int xcoord;
    struct columnsToCheck * next;
} columnsToCheck_t;
columnsToCheck_t *toCheckList = NULL;

/* internal functions*/
int addListEntry(int x, int y, int colour);
int removeListEntry(int x, int y);
int addCheckListEntry(int x);
int removeCheckListEntry(int x);
int readInput();
int buildField();
int upgradeField(int xcoord);
int upgradeFieldOffset(int xcoord);
int upgradeColumn(int xcoord);
int printField();
int placeStone(int colour, int xcoord);
int checkMatches(int xcoord, int ycoord, int mode);
int searchList(int xcoord, int ycoord);
int searchCheckList(int xNow);
int deleteStones();
int checkLoop();
void cleanUp();

/*function definitions*/
/* add matching stones to stoneList, called by checkMatches */
int addListEntry(int x, int y, int colour) {
    matchedStone_t *newEntry = NULL;
    newEntry = (matchedStone_t *) malloc(sizeof(matchedStone_t));
    if(newEntry == NULL) {
        fprintf(stderr,"Fehler bei malloc von newEntry in addListEntry\n");
        return EXIT_FAILURE;
    }
    newEntry->xcoord = x;
    newEntry->ycoord = y;
    newEntry->colour = colour;
    newEntry->next = NULL;
    //printf("eingefügt in stoneList x: %d, y: %d, colour: %d\n",newEntry->xcoord, newEntry->ycoord, newEntry->colour);

    if (stoneList == NULL) {
        stoneList = newEntry;
        return 1;
    }

    matchedStone_t *curEntry = stoneList;
    matchedStone_t *lastEntry = NULL;
    /* Nach y Wert sortiert in die Liste einfügen */
    while(curEntry != NULL) {
        if (curEntry->ycoord > newEntry->ycoord) { //solange einzufuegender Wert groesser als aktueller
            lastEntry = curEntry;
            curEntry = curEntry->next;
        } else {
            if (lastEntry == NULL) {
                stoneList = newEntry;
                newEntry->next = curEntry;
            } else {
                lastEntry->next = newEntry;
                newEntry->next = curEntry;
            }
            break;
        }
    }

    if (curEntry == NULL) {
        lastEntry->next = newEntry;
    }
    return 0;
}//END addListEntry

/* removes list entry from stoneList */ 
int removeListEntry(int x, int y){
    matchedStone_t *curEntry = stoneList;
    matchedStone_t *lastEntry = NULL;
    matchedStone_t *temp = NULL;
    
    while(curEntry != NULL){
        if (curEntry->xcoord == x && curEntry->ycoord == y){
            if(curEntry != stoneList){
                temp = lastEntry->next;
                lastEntry->next = curEntry->next;
                curEntry = curEntry->next;
                free(temp);
            }else{ //delete first node
                temp = curEntry->next;
                curEntry = curEntry->next;
                free(stoneList);
                stoneList = temp;
            }
        }else{
            lastEntry = curEntry;
            curEntry = curEntry->next;
        }
    }
    return 0;
}//END removeListEntry

/* add row to toCheckList, called by deleteStones*/
int addCheckListEntry(int x){
    columnsToCheck_t *newEntry = NULL;
    newEntry = (columnsToCheck_t *) malloc(sizeof(columnsToCheck_t));
    if(newEntry == NULL) {
        fprintf(stderr,"Fehler bei malloc von newEntry in addCheckListEntry\n");
        return EXIT_FAILURE;
    }
    newEntry->xcoord = x;
    newEntry->next = NULL;
    
    if (toCheckList == NULL) {
        toCheckList = newEntry;
        return 1;
    }
    columnsToCheck_t *curEntry = toCheckList;
    columnsToCheck_t *lastEntry = NULL;
    /* Nach x Wert sortiert in die Liste einfügen */
    while(curEntry != NULL) {
        if (curEntry->xcoord > newEntry->xcoord) { //while entry value is bigger than new value
            lastEntry = curEntry;
            curEntry = curEntry->next;
        } else {
            if (lastEntry == NULL) {
                toCheckList = newEntry;
                newEntry->next = curEntry;
            } else {
                lastEntry->next = newEntry;
                newEntry->next = curEntry;
            }
            break;
        }
    }

    if (curEntry == NULL) {
        lastEntry->next = newEntry;
    }
    return 0;
}//END addCheckListEntry
/* remove x value from toCheckList */
int removeCheckListEntry(int x){
    //pointer to iterate through list
    columnsToCheck_t *curEntry = toCheckList;
    columnsToCheck_t *lastEntry = NULL;
    columnsToCheck_t *temp = NULL;
    
    while(curEntry != NULL){ //from start to end of list
        if (curEntry->xcoord == x){ //searching for stone
            if(curEntry != toCheckList){ //delete normal node
                temp = lastEntry->next; //this stone will be deleted
                lastEntry->next = curEntry->next; //umbiegen
                curEntry = curEntry->next; //go to next node
                free(temp);
            }else{ //delete first node
                temp = curEntry->next;
                curEntry = curEntry->next;
                free(toCheckList);
                toCheckList = temp; //set pointer to new head
            }
        }else{
            lastEntry = curEntry;
            curEntry = curEntry->next;
        }
    }
    return 0;
}//END removeCheckListEntry
/* reads input with getline, called by main */
    int readInput(){
        char *line = NULL;
        size_t len = 0;
        ssize_t input;
        int lineNumber;
        int xcoord;
        int i;
        int j;
        int colour;
        long column;
        int negativeColumn;
        int columnStarted;
        char *columnpart;
        char *colourpart;
        //read input as long as there is another line in the inputfile
        while ((input = getline(&line, &len, stdin)) != -1) {
            i=0;
            j=0;
            lineNumber=0;
            colour=0;
            column=0;
            negativeColumn=0;
            columnStarted=0;
            colourpart = NULL;
            columnpart = NULL;

            colourpart = malloc(sizeof(char)*len);
            if(colourpart == NULL) {
                fprintf(stderr,"Fehler bei malloc von colourpart\n");
                return EXIT_FAILURE;
            }

            columnpart = malloc(sizeof(char)*len);
            if(columnpart == NULL) {
                fprintf(stderr,"Fehler bei malloc von columnpart\n");
                return EXIT_FAILURE;
            }

            /* test if input is empty, only first line of file is okay with that*/
            if(lineNumber==0){ //test first line only, terminate
                if(line[0] == '\0' || line[0] == '\n' || input<=1){
                //program should terminate normally whithout further processing              
                
                fprintf(stderr,"Leere Eingabe in einer Zeile.\n");
                exit(-1);
                }
            }
            lineNumber++;
            //printf("input %d line %s\n",(int) input, line);
            
            /*copy first number into var colour*/
            do{
                if(line[i]=='0' ||line[i]=='1' ||line[i]=='2' ||line[i]=='3' ||line[i]=='4' ||line[i]=='5' ||line[i]=='6' || line[i]=='7' ||line[i]=='8' ||line[i]=='9'){
                    colourpart[i]=line[i];
                }
                else{ //Each line must contain exactly two numbers
                    fprintf(stderr, "Fehler in der ersten Zahl aufgetreten.\n");
                    exit(-1);
                }
                i=i+1;
            } while(line[i]!=' ');

            colourpart[i] = '\0';
            colour = atoi(colourpart);
            if(0>colour||colour>254){
                fprintf(stderr, "Die 1.Zahl ist keine korrekte Farbe.\n");
                exit(-1);
            }

            /* read whitespaces in between*/ 
            do{
                if(line[i] == ' '){
                    if(columnStarted){//invalid character
                        fprintf(stderr, "Falsches Eingabeformat: Leerzeichen in zweiter Zahl.\n");
                        exit(-1);
                    }
                }
                else if(line[i] !=' '){
                    if(line[i]=='-'){
                        if(negativeColumn || columnStarted){
                            //invalid character
                        fprintf(stderr, "Falsches Eingabeformat: Zuviele Minus oder Minus an falscher Stelle in zweiter Zahl.\n");
                        exit(-1);
                        }
                        columnpart[j]=line[i];
                        negativeColumn = 1;
                        j = j+1;
                        columnStarted=1;
                    }else if(line[i]=='0' ||line[i]=='1' ||line[i]=='2' ||line[i]=='3' ||line[i]=='4' ||line[i]=='5' ||line[i]=='6' || line[i]=='7' ||line[i]=='8' ||line[i]=='9'){
                        columnpart[j]=line[i];
                        j = j+1;
                        columnStarted=1;
                    }
                    else{ //invalid character
                        fprintf(stderr, "Falsches Eingabeformat: Ungültiges Zeichen in zweiter Zahl.\n");
                        exit(-1);
                    }
                }
                i=i+1;
            }while(line[i]!='\n' && line[i]!=0);
            columnpart[j] = '\0';
            char* temp = NULL;
            column = strtol(columnpart,&temp,10); 
            //test if bigger than allowed
            if(labs(column)>(2<<19)){//invalid input for column
                        fprintf(stderr, "X-Koordinate groesser als erlaubt.\n");
                        exit(-1);
            }
            xcoord = (int) column;
            //printf("colour: %d column: %d\n",colour,xcoord);
            //free memory for columnpart and colourpart here
            if(colourpart)
                free(colourpart);
            if(columnpart)    
                free(columnpart);
            
            //cause of using 0 as -no stone there- we need to shift colour values +1
            //will be set back -1 in printField function before printing!
            colour = colour +1;
            
            //call function place stone
            placeStone(colour,xcoord);
        }
        free(line);
        return 0;
    }//END ReadInput
    /* initialize board, called by main */
    int buildField(){

        board.arraylength = 23; //array, random initial size
        int initial_height = 1; //columns initial size

        board.columns = NULL;
        board.columns = (int**)malloc(board.arraylength * sizeof(int*));
        if(board.columns == NULL) {
            fprintf(stderr,"Fehler bei malloc von board.columns\n");
            return EXIT_FAILURE;
        }
        board.heights = NULL;
        board.heights = (int*)malloc(board.arraylength * sizeof(int));
        if(board.heights == NULL) {
            fprintf(stderr,"Fehler bei malloc von board.heights\n");
            return EXIT_FAILURE;
        }

        for(int i = 0; i < board.arraylength; i++) {
            board.columns[i] = NULL;
            board.columns[i] = (int*) malloc(initial_height * sizeof(int));
            if(board.columns[i] == NULL) {
                fprintf(stderr,"Fehler bei malloc von board.columns[%d]\n", i);
                return EXIT_FAILURE;
            }
            memset(board.columns[i], 0, initial_height * sizeof(int));
            board.heights[i] = initial_height;
        } //columns ist das array, columns[i] sind die stacks im array
        return 0;
    }//END buildField
    /* place stone from input in board, called by readInput */
    int placeStone(int colour, int xcoord){
        if(xcoord<0 && abs(xcoord)>board.offset){
            upgradeFieldOffset(xcoord); //offset-resize
        }
        xcoord = xcoord + board.offset;

        if(xcoord >= board.arraylength){
            upgradeField(xcoord);
        }
        //comlumn height is the array length! Compare that to position of last stone and resize if full
        int i = 0;
        while(i < board.heights[xcoord]){
            if(board.columns[xcoord][i]!=0){
                i++;
            }else{
                break;
            }   
        }
        if(i>=board.heights[xcoord]){
            upgradeColumn(xcoord);
        }
        //place stone
        board.columns[xcoord][i] = colour;
        //do algorithm magic
        checkMatches(xcoord, i,0);
        return 0;
    }//END placeStone
    /* if there are not enough x values, resize board, called by placeStone */
    int upgradeField(int xcoord){ //this xcoord includes offset
//printf("Funktion upgradeField aufgerufen\n");
        //compute new array length
        //old array length plus how many positions you need to store incoming stone at right position
        int newArraylength = xcoord+1; //xcoord includes offset
        //resize array with columns
        board.columns = realloc(board.columns,newArraylength * sizeof(int*));
        if((board.columns) == NULL) {
            fprintf(stderr,"Fehler bei realloc von board.columns \n");
            return EXIT_FAILURE;
        }
        //resize array with heights
        board.heights = realloc(board.heights,newArraylength * sizeof(int));
        if((board.heights) == NULL) {
            fprintf(stderr,"Fehler bei realloc von board.heights \n");
            return EXIT_FAILURE;
        }
        //initialize
        for(int i = board.arraylength; i < newArraylength; i++) {
            board.heights[i] = 1;
            board.columns[i] = NULL;
            board.columns[i] = (int*) malloc(sizeof(int));
            if(board.columns[i] == NULL) {
                fprintf(stderr,"Fehler bei malloc von board.columns[%d]\n", i);
                return EXIT_FAILURE;
            }
            memset(board.columns[i], 0, sizeof(int)); 
        }
        board.arraylength = newArraylength;
        return 0;
    } //END upgradeField

    /* if theres not enough negative x values, called by placeStone */
    int upgradeFieldOffset(int xcoord){ // alloc new array, set new offset, shift array
        //this xcoord is without offset
        int oldOffset = 0;
        int diffOffset = 0;
        oldOffset = board.offset;
        diffOffset = abs(xcoord) - oldOffset;
        //resize array
        int newArraylength = board.arraylength + diffOffset;
        board.columns = realloc(board.columns,newArraylength * sizeof(int*));
        if((board.columns) == NULL) {
            fprintf(stderr,"Fehler bei realloc von board.columns \n");
            return EXIT_FAILURE;
        }
        //resize heights array 
        board.heights = realloc(board.heights,newArraylength * sizeof(int));
        if((board.heights) == NULL) {
            fprintf(stderr,"Fehler bei realloc von board.heights \n");
            return EXIT_FAILURE;
        }

        //shift array for new offset
        if(abs(xcoord) > board.offset){
            board.offset = abs(xcoord);
//printf("Offset ist %d, vorheriges Offset ist %d\n",board.offset, oldOffset);
            //array already shifted to old offset before, just add difference, not full new offset 
            //all values: rightshift for offset positions
            for(int i = newArraylength-1; (i-diffOffset)>=0; i--){
                board.columns[i] = board.columns[i-diffOffset];
                board.heights[i] = board.heights[i-diffOffset];
            }
         }

        //initialize both arrays from start to point of resizing
        for(int i = 0; i < diffOffset; i++) {
            board.heights[i] = 1;
            board.columns[i] = NULL;
            board.columns[i] = (int*) malloc(sizeof(int));
            if(board.columns[i] == NULL) {
                fprintf(stderr,"Fehler bei malloc von board.columns[%d]\n", i);
                return EXIT_FAILURE;
            }
            memset(board.columns[i], 0, sizeof(int));
        }
        board.arraylength = newArraylength; // update boardlength

        return 0;
    } //END upgradeFieldOffset

    /* resize columns if stone in placeStone does not fit, called by placestone */
    int upgradeColumn(int xcoord){ //resize
        int newHeight = board.heights[xcoord] +1;
        board.columns[xcoord] = realloc(board.columns[xcoord],newHeight*sizeof(int));
        //TODO pruefung ggf nicht vollstaendig
         if((board.columns[xcoord]) == NULL) {
            fprintf(stderr,"Fehler bei realloc von board.columns[xcoord] \n");
            return EXIT_FAILURE;
        }
        for(int i = board.heights[xcoord]; i < newHeight; i++){
            board.columns[xcoord][i] = 0;
        }
        board.heights[xcoord] = newHeight;
//printf("Funktion upgradeColumn an Stelle %d aufgerufen\n", xcoord);
        return 0;
    }//END upgradeColumn

    int printField(){
        //print all stones: outer loop goes through board, inner loop through columns
        int correctedColour=0;
        int i;
        int j;
        for(i = 0; i < board.arraylength; i++) {
            for(j = 0; j < board.heights[i]; j++){
                if(board.columns[i][j] != 0){
                    //cause of using 0 as -no stone there- we need to shift colour values -1
                    //set back -1 now, before printing
                    correctedColour = (board.columns[i][j])-1;
                    //offset-shift-back included in print
                    printf("%d %d %d\n", correctedColour, i-board.offset,j);
                }
            }
        }
/*         if(stoneList){
            matchedStone_t *temp = stoneList;
            while (temp){
               matchedStone_t *temp2 = temp;
               temp = temp->next;
               printf("Liste: X-Koordinate = %d, Y-Koordinate = %d, Farbe = %d\n", temp2->xcoord, temp2->ycoord, temp2->colour);
            }
        } */
        return 0;
    }//END printField
/* check column, row, diagonals starting from xcoord, ycoord, if theres a match greater 3, add stones to stoneList */
/* called by placeStone and checkLoop */
int checkMatches(int xcoord, int ycoord, int mode){
    int columnCheck = ycoord;
    int numberStonesMatchedColumn = 1;
    int numberStonesPerRow = 0;
    int nextColumnRight = xcoord+1;
    int nextColumnLeft = xcoord-1;
    int numberStonesMatchedRight = 1;
    int numberStonesMatchedLeft = 1;
    int nrOfStonesMatchedUR = 1;
    int nrOfStonesMatchedDR = 1;
    int nrOfStonesMatchedUL = 1;
    int nrOfStonesMatchedDL = 1;
    int nrOfStonesURDL = 0;
    int nrOfStonesULDR = 0;

    //check column down
    while(columnCheck>0){
        if(board.columns[xcoord][columnCheck] == board.columns[xcoord][columnCheck-1]){
            numberStonesMatchedColumn++;
            //printf("In Spalte %d liegen %d Steine in Farbe %d übereinander.\n", xcoord, numberStonesMatchedColumn, board.columns[xcoord][columnCheck]-1);
            columnCheck--;
        }else{//abort
            break;
        }
    }
    //check row to right
    while(nextColumnRight < board.arraylength && ycoord < board.heights[nextColumnRight]){
        if(board.columns[xcoord][ycoord] == board.columns[nextColumnRight][ycoord]){
            //printf("Stein in Spalte %d rechts hat gleiche Farbe wie platzierter Stein\n", nextColumnRight);
            nextColumnRight++;
            numberStonesMatchedRight++;
        }else{//abort
            break;
        }
    }
    //check row to left
    while(nextColumnLeft >= 0 && ycoord < board.heights[nextColumnLeft]){
        if(board.columns[xcoord][ycoord] == board.columns[nextColumnLeft][ycoord]){
            //printf("Vergleich Links: Stein in Spalte %d hat gleiche Farbe wie platzierter Stein\n", nextColumnLeft);
            nextColumnLeft--;
            numberStonesMatchedLeft++;
        }else{//abort
            break;
        }
    }
    //check diagonal UR = up right
    int nextYcoord= ycoord+1;
    nextColumnRight = xcoord+1;
    while(nextColumnRight < board.arraylength && nextYcoord < board.heights[nextColumnRight]){
        if(board.columns[xcoord][ycoord] == board.columns[nextColumnRight][nextYcoord]){
            //printf("Vergleich UR: Stein in X-Koordinate %d und Y-Koordinate %d hat gleiche Farbe wie platzierter Stein\n",nextColumnRight,nextYcoord+1);
            nrOfStonesMatchedUR++;
        }else{
            break;
        }
        nextColumnRight = nextColumnRight+1;
        nextYcoord = nextYcoord+1;
    }

    //check diagonal DR
    nextYcoord= ycoord-1;
    nextColumnRight = xcoord+1;
    while(nextColumnRight < board.arraylength && nextYcoord > 0 && nextYcoord < board.heights[nextColumnRight]){
        if(board.columns[xcoord][ycoord] == board.columns[nextColumnRight][nextYcoord]){ //invalid read of size 4
            //printf("Vergleich DR: Stein in X-Koordinate %d und Y-Koordinate %d hat gleiche Farbe wie platzierter Stein\n",nextColumnRight,nextYcoord+1);
            nrOfStonesMatchedDR++;
        }else{
            break;
        }
        nextColumnRight = nextColumnRight+1;
        nextYcoord = nextYcoord-1;
    }
    //check diagonal DL
    nextYcoord= ycoord-1;
    nextColumnLeft = xcoord-1;
    while(nextColumnLeft >= 0 && nextYcoord >= 0 && nextYcoord < board.heights[nextColumnLeft]){ //>0 wegen Ykoord, nicht Index als Vergleich
        if(board.columns[xcoord][ycoord] == board.columns[nextColumnLeft][nextYcoord]){
            //printf("Vergleich DL: Stein in X-Koordinate %d und Y-Koordinate %d hat gleiche Farbe wie platzierter Stein\n",nextColumnLeft,nextYcoord+1);
            nrOfStonesMatchedDL++;
        }else{
            break;
        }
        nextColumnLeft = nextColumnLeft-1;
        nextYcoord = nextYcoord-1;
    }
    //check diagonal UL
    nextYcoord= ycoord+1;
    nextColumnLeft = xcoord-1;
    while(nextColumnLeft >= 0 && nextYcoord < board.heights[nextColumnLeft]){
        if(board.columns[xcoord][ycoord] == board.columns[nextColumnLeft][nextYcoord]){
            //printf("Vergleich UL: Stein in X-Koordinate %d und Y-Koordinate %d hat gleiche Farbe wie platzierter Stein\n",nextColumnLeft,nextYcoord+1);
            nrOfStonesMatchedUL++;
        }else{
            break;
        }
        nextColumnLeft = nextColumnLeft-1;
        nextYcoord = nextYcoord+1;
    }
    
    //merge row and save stone
    numberStonesPerRow = numberStonesMatchedLeft + numberStonesMatchedRight -1;
    if(numberStonesPerRow>=4){
        //printf("In Zeile %d gibt es mindestens ein 4er-Match in Farbe %d!\n", ycoord, board.columns[xcoord][ycoord]);
        for(int i = xcoord; i< xcoord+numberStonesMatchedRight; i++){
            int stoneFound = 0;
            stoneFound = searchList(i,ycoord);
            if(stoneFound==0){ 
                addListEntry(i,ycoord,board.columns[i][ycoord]);
            }
        }
        for(int i = xcoord-1; i > xcoord-numberStonesMatchedLeft; i--){
            int stoneFound = 0;
            stoneFound = searchList(i,ycoord);
            if(stoneFound==0){ 
                addListEntry(i,ycoord,board.columns[i][ycoord]);
            }
        }

    }
    //merge column and save stones
    if(numberStonesMatchedColumn>=4){
        //printf("In Spalte %d gibt es mindestens ein 4er-Match!\n", xcoord);
        for(int i = numberStonesMatchedColumn-1; i>=0; i--){ //from top down
            int stoneFound = 0;
            stoneFound = searchList(xcoord,ycoord-i);
            if(stoneFound==0){ // check if stone already saved
                addListEntry(xcoord, ycoord-i, board.columns[xcoord][ycoord-i]);
            }
        }
    }
    //check if additional matches in diagonals and save stones
    nrOfStonesURDL = nrOfStonesMatchedUR + nrOfStonesMatchedDL -1;
    nrOfStonesULDR = nrOfStonesMatchedUL + nrOfStonesMatchedDR -1;
    //merge diagonal ULtoDR and save stones
    if(nrOfStonesULDR>=4){
        //printf("In der Diagonale ULDR gibt es mindestens ein 4er-Match!\n");
        int j = ycoord;
        for(int i = xcoord; i> xcoord - nrOfStonesMatchedUL; i--){
            int stoneFound = 0;
            stoneFound = searchList(i,j);
            if(stoneFound==0){ // check if stone already saved
                addListEntry(i,j,board.columns[i][j]);
            }
            j++;
        }
        j = ycoord;
        for(int i = xcoord; i< xcoord+nrOfStonesMatchedDR; i++){
            int stoneFound = 0;
            stoneFound = searchList(i,j);
            if(stoneFound==0){ // check if stone already saved
                addListEntry(i,j,board.columns[i][j]);
            }
            j--;
        }
    }

    //merge diagonal URtoDL and save stones
    if(nrOfStonesURDL>=4){
        //printf("In der Diagonale URDL gibt es mindestens ein 4er-Match!\n");
        int j = ycoord;
        for(int i = xcoord; i< xcoord + nrOfStonesMatchedUR; i++){
            int stoneFound = 0;
            stoneFound = searchList(i,j);
            if(stoneFound==0){ // check if stone already saved
                addListEntry(i,j,board.columns[i][j]);
            }
            j++;
        }
        j = ycoord;
        for(int i = xcoord; i> xcoord-nrOfStonesMatchedDL; i--){
            int stoneFound = 0;
            stoneFound = searchList(i,j);
            if(stoneFound==0){ // check if stone already saved
                addListEntry(i,j,board.columns[i][j]);
            }
            j--;
        }
    }
    if(mode==0){ //only if checkMatches is called by placeStone
        deleteStones();
        checkLoop();
    }
    return 0;
}//END checkMatches

/* go through stoneList and return 1 if stone found, 0 if not, called by checkMatches */
int searchList(int xcoord,int ycoord){
    matchedStone_t *curEntry = stoneList;    
    while(curEntry != NULL){ //go through list
        if (curEntry->xcoord == xcoord && curEntry->ycoord == ycoord){ //if stone found
            return 1;
        }else{
            if(curEntry->ycoord < ycoord){ //check only till you pass by a saved stone < lookup stone, why: sorted by y
                return 0;
            }
            curEntry = curEntry->next;
        }
    }
    return 0;
}//END searchList

/* go through toCheckList and return 1 if stone found, 0 if not, called by deleteStones */
int searchCheckList(int xNow){
    columnsToCheck_t *curEntry = toCheckList;    
    while(curEntry != NULL){
        if (curEntry->xcoord == xNow){
            return 1;
        }else{
            if(curEntry->xcoord < xNow){ //check only till you pass by a saved stone < lookup stone, why: sorted by x
                return 0;
            }
            curEntry = curEntry->next;
        }
    }
    return 0;
}//END searchCheckList 

/* go through stoneListe, delete a stone in board, shift stones upon it down */
/* set top stone to 0, update height, removeListEntry and add x to toCheckList, called by checkMatches */
int deleteStones(){
    matchedStone_t *curEntry = stoneList;
    int xNow = 0;
    int yNow = 0;
    while(curEntry != NULL){//delete stones in board, shift stones upon it down
        xNow = curEntry->xcoord;
        yNow = curEntry->ycoord;
        int height = board.heights[xNow]; //height in this column
        for(int i=yNow; i<=height-2;i++){ //go through column and copy all stones 1 down = implicit delete
            board.columns[xNow][i] = board.columns[xNow][i+1];
        }
        board.columns[xNow][height-1] = 0; //write 0 at top
        board.heights[xNow] = board.heights[xNow] -1; //board.heights aktualisieren
        curEntry = curEntry->next;
        removeListEntry(xNow,yNow); //delete stone in stoneList
        if((searchCheckList(xNow))==0){ //if not there, write column in toCheckList
            addCheckListEntry(xNow);
        }
    }
    return 0;
}//END deleteStones
/* go through toCheckList, call checkMatches (mode 1), if toCheckList is empty, stop and if stoneList */
/* is also empty, return, otherwise call deleteStones and call checkLoop, called by checkMatches ist mode 0 and checkloop (recursion) */
int checkLoop(){ //step 6 of algorithm after placeStone and deleteStones
    columnsToCheck_t *curEntry = toCheckList;    
    while(curEntry != NULL){
        for(int i=0; i< board.heights[curEntry->xcoord];i++){
            checkMatches(curEntry->xcoord, i,1);
        }
        curEntry = curEntry->next;
    }
    if(stoneList==NULL){ //nothing to check there
        return 0;
    }else{
        deleteStones();
        return checkLoop();
    }
}//END checkLoop
/*free heap structures, called by atexit*/
void cleanUp(){
    for(int i = 0; i < board.arraylength; i++) {
        if (board.columns[i])
            free(board.columns[i]);
    } //iterate board and call free per xcoord
    if (board.columns){
        free(board.columns);
    }
    if(board.heights){
        free(board.heights);
    }
    if(stoneList){
        matchedStone_t *temp = stoneList;
        while (temp){
            matchedStone_t *temp2 = temp;
            temp = temp->next;
            free(temp2);
        }
    }
    if(toCheckList){
        columnsToCheck_t *temp = toCheckList;
        while (temp){
            columnsToCheck_t *temp2 = temp;
            temp = temp->next;
            free(temp2);
        }
    }
}//END cleanUp

int main(void){
    atexit(&cleanUp); // register free-functions
    buildField();
    readInput();
    printField();
    return 0; //as per specification
}//END main