#include <locale.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <iso646.h>
#include <stdnoreturn.h>
#include <wchar.h>
#include <math.h>
#include <signal.h>
#include <errno.h>
#include <limits.h>

#ifdef TEST
#include "loesung.h"
#endif

#ifndef EXIT_ERR
#define EXIT_ERR 23
#endif
#ifndef EXIT_SUCC
#define EXIT_SUCC 0
#endif
#define COLOR_MAX 254
#define ERR_STR_LEN 255
#define TERM_COLOR 255
#define TO_LOWER 32
#define SPACE 20
#define MIN_X_RANGE -1048576
#define MAX_X_RANGE 1048576
#define CHAR_MAX_CAP 58
#define CHAR_MIN_CAP 9
#define X_AXIS_MIN_LENGTH 4
#define X_AXIS_MAX_LENGTH 2097152
#define Y_AXIS_INCREASE_CONST 4
#define X_CHAIN_INCREASE_CONST 13
#define Y_CHAIN_INCREASE_CONST 4
#define CHAIN_THRESHOLD_INDEX 3
#define BUFFER_LOCK 2099999
#define SUPRESS_UNUSED( X ) (void)( X )
/*=============================Globals( Pseudo Head )==========================*/
#ifndef TEST
#define VERTICAL 1
#define HORZONTAL 2
#define DIAGONALLR 4
#define DIAGONALRL 8

typedef unsigned char Color;
typedef int ValueOfX;
typedef size_t IndexOfX;
typedef size_t IndexOfY;
typedef size_t IndexOfChain;

void clear( void* Pointer );
noreturn void errorAndOut( const wchar_t* Message );
char* allocChar( size_t Amount );
wint_t readFromStdin(void);
void nextChar(void);
void uncappedNextChar(void);
bool isInRange( wint_t Char );
bool isNumerical( char Digit );
bool isSign( char Sign );
bool isSpace( char Space );
bool isLinefeed( char Linefeed );
bool isCarriageReturn( char CR );
bool isEOF( char Char );
char* makeEmptyString( bool* Error );
void initBuffer();
bool pushToBuffer( char** Buffer, char InputChar );
bool isPowerOf2( size_t Number );
void addToBuffer( char InputChar );
long toLong( char* Number );
bool checkColorBoundaries( long Color );
unsigned char readColor();
void consumeSeparator(void);
bool checkXBoundaries( long X );
int readX(void);
bool hasEndOfLine(void);
typedef struct XAxis
{
	ValueOfX X;
	Color* Colors;
	size_t Elements;
	size_t Length;
} XAxis;

typedef struct Matrix
{
	XAxis** XCoordinates;
	size_t Elements;
	size_t Length;
} Matrix;

typedef struct MarkedGamePice
{
	IndexOfX X;
	IndexOfY* IndicesOfY;
	size_t Length;
	size_t Elements;
} MarkedGamePice;

typedef struct ChainOfMarkedGamePices
{
	MarkedGamePice** GamePices;
	size_t Length;
	size_t Elements;
} ChainOfMarkedGamePices;

XAxis* allocXEntry(void);
XAxis** allocXEntries( XAxis** Ptr, size_t Size );
long findX( int Needle, XAxis** BagOfPoints, size_t SizeOfArray );
void initXAxis(void);

void increaseX(void);
Color* allocY( Color* Ptr, size_t NewSize );
void increaseY( XAxis* Entry );
void insertXEntry( ValueOfX X, IndexOfX XI );
void moveRight( void** BagOfStuff, size_t Size, size_t Start );
void insertX( ValueOfX X, IndexOfX XI );
void insertY( XAxis* Entry, Color Y );
void insertIntoMatrix( ValueOfX X, IndexOfX XI, Color Y, bool IsNewX );

MarkedGamePice** allocMarkedGamePices( MarkedGamePice** Chain, size_t NewSize );
MarkedGamePice* allocMarkedGamePice( void );
IndexOfY* allocIndicesOfY( IndexOfY* IndicesOfY, size_t NewSize );

void initMarkedGamePicesChain( ChainOfMarkedGamePices* Chain );
void increaseChain( ChainOfMarkedGamePices* Chain );
void initMarkedGamePice( MarkedGamePice* Pice );
void increaseIndiciesOfY( MarkedGamePice* Pice );
MarkedGamePice* createMarkedGamePice( void );
long findMarkedXInsertPosition( IndexOfX Needle, ChainOfMarkedGamePices* Chain );
long findMarkedYInsertPosition( IndexOfY Needle, MarkedGamePice* HaySack );
void insertMarkedY( MarkedGamePice* Pice, IndexOfY YI );
MarkedGamePice* insertMarkedX( ChainOfMarkedGamePices* Chain, IndexOfX YI );
void addToChain( ChainOfMarkedGamePices* Chain, IndexOfX XI, IndexOfY YI );
void purgeChain( ChainOfMarkedGamePices* Chain );
void clearChain( ChainOfMarkedGamePices* Chain );
void swap( ChainOfMarkedGamePices* Item1, ChainOfMarkedGamePices* Item2 );

bool pointExists( IndexOfX XI, IndexOfY YI );
bool matches( IndexOfX XI, IndexOfY YI, ValueOfX X, Color Y );
void probePoint( IndexOfX XI, IndexOfY YI, bool Use[ 8 ] );
void probeNewPoint( ValueOfX OrgX, ValueOfX XRight2Left, ValueOfX XLeft2Right, IndexOfX OrgXI, IndexOfX XIRight2Left, IndexOfX XILeft2Right, IndexOfY OrgYI, Color Y, bool UseVertical );

void moveUp( MarkedGamePice* Pice );
void moveThemAllUp();
long getLimitAt( IndexOfChain Index );
void cycle( void );
void findNewChains( void );
void readLine( void );
void resolveOrInsert( Color Y, ValueOfX X );
void readInput( void );

size_t getNewDecresingYSize( size_t AmoutOfDeletions );
void decreaseYByFactor( IndexOfX XI, size_t AmoutOfDeletions );
size_t getNewDecresingXSize( size_t CurrentPower, size_t TargetSize );
void decreaseX(void);
void collectXAxisGabage( void );
void removeXEntry( IndexOfX  XI );
void purgeMatrix( void );

void printEntry( Color Y, ValueOfX X, IndexOfY YI );
void printAndDestroy( void );
#endif
/*==============================private=========================================*/
typedef struct Point
{
	IndexOfX XI;
	IndexOfY YI;
} Point;
/*==============================private subroutines=============================*/
#ifndef TEST
static void tearDown( void );
static void tearGracefullyDown( int Signal );
static void registerAbortionSignals( void );
static void setup( void );
#endif
static void failOnInvalidSymbol(void);
static void failOnInvalidBufferValue( const wchar_t* Message );

static void cleanUpBuffer();

static void initXEntry( XAxis* Entry, ValueOfX X );

static long transformInsertPosition( long Index );

static long chainSearch( size_t Needle, void* BagOfPoints, size_t ( *getValueAtIndex )( size_t, void* ), size_t SizeOfArray );
static size_t getMarkedXAtIndex( size_t Index, void* Chain );
static size_t getMarkedYAtIndex( size_t Index, void* Pice );
static void insertNewMarkedY( MarkedGamePice* Pice, size_t InsertPosition,  IndexOfY YI );
static void insertNewMarkedX( ChainOfMarkedGamePices* Chain, size_t InsertPosition,  IndexOfX XI );
static void purgeMarkedGamePice( MarkedGamePice* Pice );

static bool Or8( bool B1, bool B2, bool B3, bool B4, bool B5, bool B6, bool B7, bool B8 );
static void intiChainBuffer( Point* Buffer );
static void addToMarkerBufferFull( Point* TmpBuffer, IndexOfX XI, IndexOfY YI, size_t Counter );
static void addToMarkerBufferTail( Point* TmpBuffer, IndexOfX XI, IndexOfY YI, size_t Counter );
static void writePartialBufferToChain( Point* PartialBuffer );
static void completeIncompleteBuffer( Point* PartialBuffer1, Point* PartialBuffer2 );
static void mergePartialBuffers( Point* PartialBuffer );
static void mergeOrSkipPartialBuffers( Point* PartialBuffer1, Point* PartialBuffer2 );
static void probe( IndexOfX XI, IndexOfY YI, ValueOfX X, Color Y, Point* Buffer, size_t Counter, bool* Flag, void (*adder)( Point*, IndexOfX, IndexOfY, size_t ) );

static bool hasDirectionalPremise( IndexOfX ExpectedX, IndexOfY ExpectedY, IndexOfChain JumpToX );
static bool mostLeftHorizontal( IndexOfX ExpectedX, IndexOfX LastX, IndexOfX LastIndexOfX, IndexOfY ExpectedY, IndexOfChain JumpToX );
static bool mostRightHorizontal( IndexOfX ExpectedX, IndexOfX NextX, IndexOfX NextIndexOfX, IndexOfY ExpectedY, int JumpToX );
static bool mostLeftDiagonalLR( IndexOfX ExpectedX, IndexOfX LastX, IndexOfX LastIndexOfX, IndexOfY ExpectedY, IndexOfChain JumpToX );
static bool mostRightDiagonalLR( IndexOfX ExpectedX, IndexOfX LastX, IndexOfX LastIndexOfX, IndexOfY ExpectedY, IndexOfChain JumpToX );
static bool mostLeftDiagonalRL( IndexOfX ExpectedX, IndexOfX LastX, IndexOfX LastIndexOfX, IndexOfY ExpectedY, IndexOfChain JumpToX );
static bool mostRightDiagonalRL( IndexOfX ExpectedX, IndexOfX LastX, IndexOfX LastIndexOfX, IndexOfY ExpectedY, IndexOfChain JumpToX );

static bool hasChain( void );
static void iterateThroughAll( size_t Start, IndexOfChain CXI );
static void iteratePartial( IndexOfChain CXI );

static void resetMatrix( void );
static void printYAxis( XAxis* Sector );
/*==============================Vars============================================*/
char CurrentChar;
char* Buffer = NULL;
Matrix TheMatrix;
ChainOfMarkedGamePices ChainOfDeath;
ChainOfMarkedGamePices ChainOfInspection;
/*===============================Programmflow===================================*/
#ifdef SHOW
static void printMatrix()
{
	printf( "-----------------------------------------" );
	printf( "\n" );
	for( size_t X = 0; X < TheMatrix.Elements; X++ )
	{
		printf( "%d|", TheMatrix.XCoordinates[ X ]->X );
		for( size_t Y = 0; Y < TheMatrix.XCoordinates[ X ]->Elements; Y++ )
		{
			printf( "%u ", TheMatrix.XCoordinates[ X ]->Colors[ Y ] );
		}

		printf( "\n" );
	}

	printf( "-----------------------------------------" );
	printf( "\n" );
}
#endif

static bool hasChain()	{ return ChainOfDeath.Elements != 0; }

static void iterateThroughAll( size_t Start, IndexOfChain CXI )
{
	IndexOfX XI = ChainOfInspection.GamePices[ CXI ]->X;
	IndexOfY YIStart = ChainOfInspection.GamePices[ CXI ]->IndicesOfY[ Start ];
	//TODO Make it better
	bool Locks[] = { true, true, true, true, true, true, true, true };

	for( size_t CYI = 0; CYI < Start; CYI++ )	
	{
		if( !pointExists( XI, ChainOfInspection.GamePices[ CXI ]->IndicesOfY[ CYI ] ) )	{ return; }

		probePoint( 
			CXI,
			ChainOfInspection.GamePices[ CXI ]->IndicesOfY[ CYI ],
			Locks
		);
	}

	if( XI < TheMatrix.Elements )
	{
		for( size_t YI = YIStart; YI < TheMatrix.XCoordinates[ XI ]->Elements; YI++ )
		{
			if( !pointExists( XI, YI ) )  { return; }

			probePoint(  
				XI,
				YI,
				Locks
			);
		}
	}
}

static void iteratePartial( IndexOfChain CXI )
{
	bool Locks[] = { true, true, true, true, true, true, true, true };

	for( size_t CYI = 0; CYI < ChainOfInspection.GamePices[ CXI ]->Elements; CYI++ )
	{
		if( !pointExists( ChainOfInspection.GamePices[ CXI ]->X, ChainOfInspection.GamePices[ CXI ]->IndicesOfY[ CYI ] ) ) { return; }
		probePoint(
			ChainOfInspection.GamePices[ CXI ]->X,
			ChainOfInspection.GamePices[ CXI ]->IndicesOfY[ CYI ],
			Locks                                                          
		);		
	}
}

void findNewChains( void )
{
	long Limit;
	
	for( size_t Index = 0; Index < ChainOfInspection.Elements; Index++ )
	{
		Limit = getLimitAt( Index );
		if( -1 == Limit )	{ iteratePartial( Index ); }
		else 				{ iterateThroughAll( (size_t) Limit, Index ); }
	}
}

void cycle( void )
{
	do
	{
		moveThemAllUp();
		swap( &ChainOfDeath, &ChainOfInspection );
		clearChain( &ChainOfDeath );
		findNewChains();
	}
	while( hasChain() );
}

void readLine( void )
{
	static size_t LineCounter = 0;

	LineCounter++;
	Color Y = readColor();
	consumeSeparator();
	ValueOfX X =  readX();
	#ifdef SHOW
		printf( "C:%d,X:%d\nBefore:\n", Y, X );
		printMatrix();
	#endif
	resolveOrInsert( Y,X );
	#ifdef SHOW
		printf( "After:\n" );
		printMatrix();
	#endif
}

void resolveOrInsert( Color Y, ValueOfX X ) 
{
	long Index = findX( X, TheMatrix.XCoordinates, TheMatrix.Elements );
	bool NewX = false;
	size_t NewXI;	

	if( Index < 0 )
	{
		NewXI = transformInsertPosition( Index );
		NewX = true;

		probeNewPoint(
			X,
			X-1,
			X+1,
			NewXI,
			NewXI-1,
			NewXI,
			0,
			Y,
			false
		);
	}
	else
	{
		NewXI = (size_t)Index,
		probeNewPoint(
			X,
			X-1,
			X+1,
			NewXI,
			NewXI-1,
			NewXI+1,
			TheMatrix.XCoordinates[ Index ]->Elements,
			Y,
			true
		);
	}

	if( hasChain() )	{ cycle(); }
	else				{ insertIntoMatrix( X, NewXI, Y, NewX ); }
}

void readInput( void )
{
	nextChar();
	while( !isEOF( CurrentChar ) )
	{
		readLine();
		if( !hasEndOfLine() )	{ errorAndOut( L"Expected line break." ); }
	}
}

#ifndef TEST
int main()
{
	setlocale( LC_ALL, "" );
	setup();
	readInput();
	printAndDestroy();
	return EXIT_SUCC;
}
/**
 * alias for free
 */
void clear( void* Pointer ) { free( Pointer ); }
/**
 * reads a single character from stdin
 */
wint_t readFromStdin() { return fgetwc( stdin ); }
/**
 * allocates memory for chars with the given size
 * @param Size | size_t | the amount of chars
 */
char* allocChar( size_t Amount ) { return calloc( Amount, sizeof( char ) ); }
/**
 * Prints a error-message to stderr and quits the programm
 * @param Message | const char* | the message
 */
void errorAndOut( const wchar_t* Message )
{
	fprintf( stderr, "\n%ls\n", Message );
	fflush( stderr );
	exit( EXIT_ERR );
}
/**
 * tears the application down
 */
static void tearDown( void )
{
	purgeChain( &ChainOfDeath );
	purgeChain( &ChainOfInspection );
	cleanUpBuffer();
	purgeMatrix();
}
/**
 * tears the application on interupt down
 */
static void tearGracefullyDown( int Signal ) 
{
	SUPRESS_UNUSED( Signal );
	exit( EXIT_ERR ); 
}
/**
 * registers signals to intercept
 */
static void registerAbortionSignals( void )
{
	signal( SIGINT, tearGracefullyDown );
	signal( SIGILL, tearGracefullyDown );
	signal( SIGABRT, tearGracefullyDown );
	signal( SIGTERM, tearGracefullyDown );
}
/**
 * setups things
 */
static void setup( void )
{
	registerAbortionSignals();
	atexit( tearDown );

	initXAxis();
	initBuffer( &ChainOfInspection );
	initBuffer( &ChainOfDeath );
}
#endif
/**
 * housekeeping
 */
static void cleanUpBuffer()
{
	if( NULL != Buffer )	{ clear( Buffer ); }
}

static void failOnInvalidSymbol(void)
{
	wchar_t ErrorMsg[ ERR_STR_LEN ];
	swprintf( ErrorMsg, ERR_STR_LEN, L"Unexpected symbol (%c).", CurrentChar );
	errorAndOut( ErrorMsg );
}

static void failOnInvalidBufferValue( const wchar_t* Message )
{
	wchar_t ErrorMsg[ ERR_STR_LEN ];
	swprintf( ErrorMsg, ERR_STR_LEN, Message, Buffer );
	errorAndOut( ErrorMsg );
}
/**
 * transforms a given insertPosition
 * @param the insertposition
 * @return index
 */
static long transformInsertPosition( long Index ) { return -( Index+1 ); }
/* 
 * creates a empty string
 * @param Error flag
 */
char* makeEmptyString( bool* Error ) 
{
	char* EmptyString;
	
	EmptyString = allocChar( 1 );
	if( NULL == EmptyString )
	{
		*Error = true;
		return NULL;
	}
	
	EmptyString[ 0 ] = '\0';
	return EmptyString;
}
/**
 * makes a empty buffer and fails, if the memory is insufficient
 * @return char* | the string buffer
 */
void initBuffer()
{
	char* NewBuffer;
	bool Error = false;

	cleanUpBuffer();

	NewBuffer = makeEmptyString( &Error );

	if( true == Error ) { errorAndOut( L"No - there is no memory left." ); }
	Buffer = NewBuffer;
}
/**
 * adds a new char to a given charbuffer
 * @param Buffer | the charbuffer
 * @param InputChat | the new Char
 * @return bool | if the operation was successful
 */
bool pushToBuffer( char** Buffer, char InputChar )
{
	size_t NewSize, OldSize;
	char* Tmp;

	OldSize = strlen( *Buffer );
	if( isPowerOf2( OldSize+1 ) == true )
	{
		NewSize = ( ( OldSize+1 )<<1 )+1;
		Tmp = allocChar( NewSize );//new char + \0
		if( NULL == Tmp ) { return NULL; }
		
		memset( Tmp, '\0', NewSize );
		if( 0 < OldSize ) { memmove( Tmp, *Buffer, OldSize ); }

		Tmp[ OldSize ] = InputChar;
		free( *Buffer );
		*Buffer = Tmp;
	}
	else { 
		Tmp = *Buffer;
		Tmp[ OldSize ] = InputChar; 
	}
	
	return true;
}
/**
 * Checks if a number is a power of 2
 * @param size_t | a number
 * @return bool
 */
bool isPowerOf2( size_t Number ) { return !( Number& ( Number-1 ) ); }
/**
 * adds a new char to a given charbuffer
 * @param InputChat | the new Char
 */
void addToBuffer( char InputChar )
{
	if ( Buffer == NULL ) { errorAndOut( L"You forgot to initialize the StringBuffer." ); }
	else 
	{
		if ( pushToBuffer( &Buffer, InputChar ) == false ) { errorAndOut( L"End of the line...memory." ); }
	}
}
/**
 * checks a given char for the defintion range
 */
bool isInRange( wint_t Char ) { return CHAR_MIN_CAP < Char and CHAR_MAX_CAP > Char; }
/**
 * reads a single character form stdin and assigns it to CurrentChar.
 * it fails on symbols beyond our definition range
 */
void nextChar( void ) 
{ 
	wint_t Char = readFromStdin();

	if( false == isInRange( Char ) ) 
	{
		if( WEOF == Char )	{ CurrentChar = EOF; }//errorAndOut( L"Unexpected end of input." ); }
		else 				
		{
			wchar_t ErrorMsg[ ERR_STR_LEN ];
			swprintf( ErrorMsg, ERR_STR_LEN, L"Unexpected symbol (%lc).", (wchar_t) Char );
			errorAndOut( ErrorMsg );
		}
	}

	CurrentChar = (char) Char;
}

/**
 * reads a single character from stdin and assigns it to CurrentChar.
 * It reads without checking for the definition range
 */
void uncappedNextChar(void) { CurrentChar = (char)readFromStdin(); }
/**
 * checks if a given char is numerical
 * @param Digit | potentical digit
 */
bool isNumerical( char Digit ) { return 48 <= Digit and 57 >= Digit; }

/**
 * checks if a given char is a sign
 * @param Sign | potentical sign
 *
 */
bool isSign( char Sign ) { return Sign == '-'; }
/**
 * checks if a given char is a space
 * @param Space | potentical space
*/
bool isSpace( char Space ) { return Space == ' '; }
/**
 * checks if a given char is a linefeed.
 * @param Linefeed | potentical linefeed
 */
bool isLinefeed( char Linefeed ) { return Linefeed == '\n'; }
/**
 * checks if a given char is a carriage return.
 * @param CR | potentical carriage return
*/
bool isCarriageReturn( char CR ) { return CR == 13; }
/**
 * checks if a given char signals a EOF.
 * @param Char | potentical EOF
 */
bool isEOF( char Char ) { return (int)Char == -1; }
/**
 * reads and validates via stdin a given color
 * color should be in int range 0-254
 * @return Color | unsigned char | the color
 */
long toLong( char* Number )
{
	char* End = NULL;
	errno = 0;
	long New = strtol( Number, &End, 10 );

   /* Check for various possible errors */

   if ( (errno == ERANGE and ( New  == LONG_MAX or New == LONG_MIN) ) or ( errno != 0 and New == 0) or strlen( End ) != 0 ) 
   {
	   errorAndOut( L"Unexpected numeric input." ); 
   }

	return New;
}
/**
 * checks if a given number is in the boundaries of color
 * @return bool
 */
bool checkColorBoundaries( long Color ) { return 0 <= Color and COLOR_MAX >= Color; }
/**
 * reads and validates via stdin a given color
 * color should be in int range 0-254
 * @return Color | unsigned char | the color
 */
unsigned char readColor()
{
	long Color = TERM_COLOR;

	if( false == isNumerical( CurrentChar ) )    { failOnInvalidSymbol(); }
	else
	{
		initBuffer();

		do
		{
			addToBuffer( CurrentChar );
			nextChar(); 
		}
		while( true == isNumerical( CurrentChar ) );
	
		Color = toLong( Buffer );

		if( false == checkColorBoundaries( Color ) ) { failOnInvalidBufferValue( L"The given number(%s) is no valid encoded color." ); }
	}

	return (unsigned char) Color;
}

/**
 * eats spaces.
 * However it fails if no single space was given.
 */
void consumeSeparator(void)
{
	if( false == isSpace( CurrentChar ) ) { failOnInvalidSymbol(); } 
	else
	{
		do { nextChar(); }
		while( true == isSpace( CurrentChar ) );
	}
}
/**
 * checks against the Boundary restriction of X
 * @return bool
 */
bool checkXBoundaries( long X ) { return MIN_X_RANGE <= X and MAX_X_RANGE >= X; }
/**
 * reads the given x coordinate
 * Howerever it fails, if the given input is no valid number or exceeds the cap of 2^20
 */
int readX(void)
{
	bool Signed = false;
	long X = 1048577;

	if( true == isSign( CurrentChar ) ) 
	{ 
		Signed = true;
		nextChar();
	}

	if( false == isNumerical( CurrentChar ) ) { failOnInvalidSymbol(); }
	else
	{
		initBuffer();
		if( true  == Signed ) { addToBuffer( '-' ); }	

		do
		{
			addToBuffer( CurrentChar );
			nextChar();
		}
		while( true == isNumerical( CurrentChar ) );
		
		X = toLong( Buffer );

		if( false == checkXBoundaries( X ) ) { failOnInvalidBufferValue( L"The given number (%s) is no valid encoded x-coordinate." ); }
	}

	return (int)X;
}
/**
 * checks if there is a next line to parse or not
 * @return bool
 */
bool hasEndOfLine(void)
{
	bool Return = false;
	if( isCarriageReturn( CurrentChar ) ) 
	{
		nextChar(); 
		Return = true;
	}

	if( isLinefeed( CurrentChar ) )
	{
		nextChar();
		Return = true;
	}

	if( isEOF( CurrentChar ) )	{ Return = true; }

	return Return;
}
/**
 * Mix binSearch with IntpolSearch,
 * InterpolSearch runs only the first round, which increases the efficency especally at uniformly distributed arrays. However is a bit slower then vanilla binSearch in totally random distribution, but not in a remarkable manor.
 * @param int | the x, what we are looking for
 * @param XAxis** | the haystack
 * @param size_t | size of the given Array
 * @return	> 0 | match index at the given position
 * 			< 0 | insertposition [ -(x+1) ]
*/
long findX( int X, XAxis** BagOfPoints, size_t SizeOfArray )
{
	size_t Start = 0;
	size_t End;
	// BinSearch
	size_t Middle;
	// IntpolSearch
	long double Denominator;
	size_t Interpolation;
	bool OutOfBounce;

	if( SizeOfArray == 0 )				{ return -1; }

	if( BagOfPoints[ Start ]->X == X )	{ return 0; }

	if( BagOfPoints[ Start ]->X > X )	{ return -1; }

	Start++;
	End = SizeOfArray-1;

	if( BagOfPoints[ End ]->X == X )	{ return End; }

	if( BagOfPoints[ End ]->X < X )		{ return transformInsertPosition( SizeOfArray ); }

	End--;

	Denominator = BagOfPoints[ End ]->X - BagOfPoints[ Start ]->X;

	if( 0 == Denominator ) { OutOfBounce = true; }
	else
	{
		Interpolation = (size_t)( (long double)Start + ( (long double)( X - BagOfPoints[ Start ]->X )*(long double)( End-Start ) / Denominator ) );
		OutOfBounce = (bool)( Interpolation > End );
	}

	if( OutOfBounce == false )
	{
		if( BagOfPoints[ Interpolation ]->X == X )		{ return Interpolation; }
		else if( BagOfPoints[ Interpolation ]->X > X )	{ End = Interpolation-1; }
		else											{ Start = Interpolation+1; }
	}

	while( Start <= End )
	{
		Middle = (Start+End)>>1;
		
		if( BagOfPoints[ Middle ]->X == X )		{ return Middle; }
		else if( BagOfPoints[ Middle ]->X > X )	{ End = --Middle; }
		else									{ Start = ++Middle; }
	}

	return transformInsertPosition( Start );
}
#ifndef TEST
/**
 * Allocates memory for a new entry on the XAxis
 * @return pointer of XAxis
 */
XAxis* allocXEntry(void) { return malloc( sizeof( struct XAxis ) ); }
/**
 * Al/Delocates memory for XAxis entries
 * @param pointer of pointer of XAxis | original Array
 * @param size_t | new size
 * @return pointer of pointer of XAxis
 */
XAxis** allocXEntries( XAxis** Ptr, size_t Size ) { return realloc( Ptr, sizeof( struct XAxis* )*Size ); }
#endif
/**
 * Intializes the XAxis
 */
void initXAxis(void) 
{
	TheMatrix.XCoordinates = allocXEntries( TheMatrix.XCoordinates, X_AXIS_MIN_LENGTH );

	if( TheMatrix.XCoordinates == NULL ) { errorAndOut( L"The memory is full, Jim." ); }

	TheMatrix.Elements = 0;
	TheMatrix.Length = X_AXIS_MIN_LENGTH;
}
/**
 * Increases the amount of fields for X-coordinates
 */
void increaseX(void)
{
	size_t NewSize;
	XAxis** Tmp;

	if( TheMatrix.Elements < TheMatrix.Length )	{ return; }
	

	NewSize = TheMatrix.Length<<1;
	Tmp = allocXEntries( TheMatrix.XCoordinates, NewSize );
	if( Tmp == NULL )	{ errorAndOut( L"No, no, no - there is no memory left." ); }
	else
	{
		TheMatrix.XCoordinates = Tmp;
		TheMatrix.Length = NewSize;
	}
}
#ifndef TEST
/**
 * Allocates memory for y values
 * @param pointer of unsigned chars
 * @param size_t | new size
 * @return pointer of unsigned char
 */
Color* allocY( Color* Ptr, size_t NewSize )	{ return realloc( Ptr, NewSize*sizeof( Color ) ); }
#endif
/**
 * Adds a new field for Y to a given X
 */
void increaseY( XAxis* Entry )
{
	Color* Tmp;
	size_t NewSize;

	if( Entry->Elements < Entry->Length )	{ return; }

	NewSize = Entry->Length + Y_AXIS_INCREASE_CONST;

	Tmp = allocY(
			Entry->Colors,
			NewSize
	);

	if( Tmp == NULL )   { errorAndOut( L"Memory or no memory is currently not a question." ); }
	else
	{
		Entry->Length = NewSize;
		Entry->Colors = Tmp;
	}
}
/**
 * Initalizes a XAxis entry
 * @param pointer of XAxis
 * @param value of X
 */
static void initXEntry( XAxis* Entry, ValueOfX X )
{
	Entry->Colors = NULL;
	Entry->Length = 0;
	Entry->Elements = 0;
	Entry->X = X;
}
/**
 * creates a new XAxis entry on a given coordinate of the XAxis
 * @param int | the value of X
 * @param size_t | the index of X
 */
void insertXEntry( ValueOfX X, IndexOfX XI )
{
	XAxis* Tmp = allocXEntry();

	if( Tmp == NULL )	{ errorAndOut( L"Nope, no - all memory is gone." ); }
	else
	{
		initXEntry( Tmp, X );
		TheMatrix.XCoordinates[ XI ] = Tmp;
	}
}
/**
 * moves elements of a Matrix one place to right
 * @param size_t start index to move from
 */
void moveRight( void** BagOfStuff, size_t Size, size_t Start )
{
	size_t I;
	for( I = Size; I > Start; I-- ) { BagOfStuff[ I ] = BagOfStuff[ I-1 ]; }
}
/**
 * inserts given value of x at a given index. 
 * @param int value of x
 * @param size_t index of x
 */
void insertX( ValueOfX X, IndexOfX XI )
{
	increaseX();

	if( XI != TheMatrix.Elements ) { moveRight( (void*)TheMatrix.XCoordinates, TheMatrix.Elements, XI ); }

	insertXEntry( X, XI );
	TheMatrix.Elements++;
}
/** inserts a given Y value on a given XEntry
 * @param the Entry where to insert
 * @param the value of the new y
 */
void insertY( XAxis* Entry, Color Y )
{
	increaseY( Entry );

	Entry->Colors[ Entry->Elements ] = Y;
	Entry->Elements++;
}
/** inserts a given X and Y into the matrix
 * @param value of x
 * @param insert position
 * @param value of y
 */
void insertIntoMatrix( ValueOfX X, IndexOfX XI, Color Y, bool IsNewX )
{
	if( IsNewX )	{ insertX( X, XI ); }
	insertY( TheMatrix.XCoordinates[ XI ], Y );
}
/**
 * initializes a ChainOfMarkedGamePices
 * @param pointer of ChainOfMarkedGamePices
 */
void initMarkedGamePicesChain( ChainOfMarkedGamePices* Chain )
{
	Chain->Elements = 0;
	Chain->Length = 0;
	Chain->GamePices = NULL;
}
#ifndef TEST
/**
 * Allocates Memory for MakredGamePice Chain
 * @param pointer of pointers of GamePices
 * @param new size
 * @return pointer of pointers of GamamePices
 */
MarkedGamePice** allocMarkedGamePices( MarkedGamePice** Chain, size_t NewSize )	{ return realloc( Chain, NewSize*sizeof( struct GamePices* ) ); }
/**
 * Allocates Memory for a MarkedGamePice
 */
MarkedGamePice* allocMarkedGamePice( void )	{ return malloc( sizeof( struct MarkedGamePice ) ); }
/**
 * Allocates memory for y indicies of a MarkedGamePice
 * @param pointer of size_t
 * @param new size
 * @return pointer of size_t
 */
size_t* allocIndicesOfY( size_t* IndicesOfY, size_t NewSize )	{ return realloc( IndicesOfY, NewSize*sizeof( size_t ) ); }
#endif
/**
 * increases the amount of Itemes in a ChainOfMarkedGamePices
 * @param pointer of ChainOfMarkedGamePices
 */
void increaseChain( ChainOfMarkedGamePices* Chain )
{
	size_t NewSize;
	MarkedGamePice** Tmp;

	if( Chain->Elements < Chain->Length )		{ return; }
	
	NewSize = Chain->Length+X_CHAIN_INCREASE_CONST;
	Tmp = allocMarkedGamePices( Chain->GamePices, NewSize );

	if( Tmp == NULL )	{ errorAndOut( L"No memory, left...lalalala" ); }
	else
	{
		Chain->GamePices = Tmp;
		Chain->Length = NewSize;
	}
}
/**
 * initialzes a MarkedGamePice
 * @param pointer of MarkedGamePice
 */
void initMarkedGamePice( MarkedGamePice* Pice )
{
	Pice->Elements = 0;
	Pice->Length = 0;
	Pice->IndicesOfY = NULL;
}
/**
 * increases the amout of indicies of y
 * @param pointer MarkedGamePice
 */
void increaseIndiciesOfY( MarkedGamePice* Pice )
{
	size_t NewSize;
	size_t* Tmp;
	if( Pice->Elements < Pice->Length )			{ return; }

	NewSize = Pice->Length+Y_CHAIN_INCREASE_CONST;

	Tmp = allocIndicesOfY( Pice->IndicesOfY, NewSize );
	
	if( Tmp == NULL )   { errorAndOut( L"Where have all the memory gone, long time passing?" ); }
	else
	{
		Pice->IndicesOfY = Tmp;
		Pice->Length = NewSize;
	}
}
/**
 * creates a new MarkedGamePice item
 */
MarkedGamePice* createMarkedGamePice( void )
{
	MarkedGamePice* Tmp;

	Tmp = allocMarkedGamePice();

	if( Tmp == NULL )	{ errorAndOut( L"Yet another out of memory error message." ); }
	else				{ initMarkedGamePice( Tmp ); }

	return Tmp;
}
/**
 * Returns the value of X in ChainOfMarkedGamePices at the given Index
 * @param Index of Item
 * @return value of X
 */
static size_t getMarkedXAtIndex( size_t Index, void* Chain )	{ return ( (MarkedGamePice**) Chain )[ Index ]->X; }
/**
 * finds a x elment in a ChainOfMarkedGamePices
 * @param Pointer of ChainOfMarkedGamePices
 * @return > 0 | match index at the given position
 *         < 0 | insertposition [ -(x+1) ]
 */
long findMarkedXInsertPosition( IndexOfX Needle, ChainOfMarkedGamePices* Chain )	
{ 
	return chainSearch( 
			Needle, 
			(void*) Chain->GamePices,
			&getMarkedXAtIndex,
			Chain->Elements
	);
}

/**
 * Returns the value of Y in MarkedGamePice at the given Index
 * @param Index of Item
 * @return value of Y
 */
static size_t getMarkedYAtIndex( size_t Index, void* Pice )		{ return ( (size_t*) Pice )[ Index ]; }
/**
 * finds a y elment in a MarkedGamePice
 * @param Pointer of MarkedGamePice
 * @return > 0 | match index at the given position
 *         < 0 | insertposition [ -(x+1) ]
 */
long findMarkedYInsertPosition( IndexOfY Needle, MarkedGamePice* HaySack )
{
	return chainSearch(
			Needle,
			(void*) HaySack->IndicesOfY,
			getMarkedYAtIndex,
			HaySack->Elements
	);
}			
/**
 * binSearch,
 * @param size_t | the x, what we are looking for
 * @param ChainOfMarkedGamePices* | the haystack
 * @param size_t | size of the given Array
 * @return	> 0 | match index at the given position
 * 			< 0 | insertposition [ -(x+1) ]
*/
static long chainSearch( size_t Needle, void* BagOfPoints, size_t ( *getValueAtIndex )( size_t, void* ), size_t SizeOfArray )
{
	size_t Start = 0;
	size_t End;
	// BinSearch
	size_t Middle;
	size_t Value;

	if( SizeOfArray == 0 )	{ return -1; }

	Value = getValueAtIndex( Start, (void*) BagOfPoints );

	if( Value == Needle )	{ return 0; }

	if( Value > Needle )	{ return -1; }

	Start++;
	End = SizeOfArray - 1;
	Value = getValueAtIndex( End, (void*) BagOfPoints );

	if( Value == Needle )	{ return End; }

	if( Value < Needle )	{ return transformInsertPosition( SizeOfArray ); }

	End--;

	while( Start <= End )
	{
		Middle = (Start+End)>>1;
		
		Value = getValueAtIndex( Middle, (void*) BagOfPoints );

		if		( Value == Needle )		{ return Middle; }
		else if	( Value > Needle )		{ End = --Middle; }
		else							{ Start = ++Middle; }
	}

	return transformInsertPosition( Start );
}
/**
 * Inserts a new y on a MarkedGamePice
 * @param pointer of MarkedGamePice
 * @param insertPosition
 * @param index of y
 */
static void insertNewMarkedY( MarkedGamePice* Pice, size_t InsertPosition,  IndexOfY YI )
{
	increaseIndiciesOfY( Pice );
	
	moveRight( (void**) Pice->IndicesOfY, Pice->Elements, InsertPosition );
	Pice->Elements++;

	Pice->IndicesOfY[ InsertPosition ] = YI;
}
/**
 * inserts a y on a MarkedGamePice
 * @param pointer of MarkedGamePice
 * @param index of y
 */
void insertMarkedY( MarkedGamePice* Pice, IndexOfY YI )
{
	long InsertPosition = findMarkedYInsertPosition( YI, Pice );

	if( InsertPosition >= 0 )	{ return; }
	else 						{ insertNewMarkedY( Pice, (size_t)transformInsertPosition( InsertPosition ), YI ); }
}
/**
 * Inserts a new y on a MarkedGamePice
 * @param pointer of MarkedGamePice
 * @param insertPosition
 * @param index of y
 */
static void insertNewMarkedX( ChainOfMarkedGamePices* Chain, size_t InsertPosition,  IndexOfX XI )
{
	increaseChain( Chain );

	moveRight( (void**) Chain->GamePices, Chain->Elements, InsertPosition );
	Chain->Elements++;

	Chain->GamePices[ InsertPosition ] = createMarkedGamePice();
	Chain->GamePices[ InsertPosition ]->X = XI;
}
/**
 * Inserts a x in a ChainOfMarkedGamePices
 * @param the chain
 * @param the value/index of x
 * @return pointer to the item
 */
MarkedGamePice* insertMarkedX( ChainOfMarkedGamePices* Chain, IndexOfX XI )
{
	size_t Index;
	long InsertPosition = findMarkedXInsertPosition( XI, Chain );

	if( InsertPosition < 0 )	{ Index = (size_t)transformInsertPosition( InsertPosition ); insertNewMarkedX( Chain, Index, XI ); }
	else						{ Index = (size_t)InsertPosition; }
	
	return Chain->GamePices[ Index ];
}
/**
 * adds a new pair of x,y indicies into a ChaonOfMarkedGamePices
 * @param chain
 * @param index of x
 * @param index of y
 */
void addToChain( ChainOfMarkedGamePices* Chain, IndexOfX XI, IndexOfY YI )
{
	insertMarkedY( insertMarkedX( Chain, XI ), YI );
}
/**
 * purges a given MarkedGamePice
 * @param the MarkedGamePice
 */
static void purgeMarkedGamePice( MarkedGamePice* Pice )
{
	free( Pice->IndicesOfY );
	free( Pice );
}
/**
 * clears a given chain
 * @param chain to clear
 */
void clearChain( ChainOfMarkedGamePices* Chain )
{
	for( size_t Index = 0; Index < Chain->Elements; Index++ )
	{
		purgeMarkedGamePice( Chain->GamePices[ Index ] );
	}

	Chain->Elements = 0;
}
/**
 * purges a given chain
 */
void purgeChain( ChainOfMarkedGamePices* Chain )
{
	clearChain( Chain );
	free( Chain->GamePices );
	Chain->GamePices = NULL;
	Chain->Length = 0;
}
/**
 * Swaps values of pointers of ChainOfMarkedGamePices
 * @param pointer 1
 * @pointer 2
 */
void swap( ChainOfMarkedGamePices* Item1, ChainOfMarkedGamePices* Item2 )
{
	ChainOfMarkedGamePices Tmp = *Item1;
	*Item1 = *Item2;
	*Item2 = Tmp;
}
/**
 * ors 8 bools
 * @param 1-8 bool
 * @param bool
 */
static bool Or8( bool B1, bool B2, bool B3, bool B4, bool B5, bool B6, bool B7, bool B8 ) { return B1|B2|B3|B4|B5|B6|B7|B8; }
/**
 * adds matched temporary Point Buffer, depending on the Counter
 * @param the tmp Buffer
 * @param value/index of x
 * @param value/index of y
 * @param Counter
 */
static void addToMarkerBufferFull( Point* TmpBuffer, IndexOfX XI, IndexOfY YI, size_t Counter )
{
	if( Counter < CHAIN_THRESHOLD_INDEX )	
	{
		TmpBuffer[ Counter ].XI = XI;
		TmpBuffer[ Counter ].YI = YI;
	}
	else if ( Counter > CHAIN_THRESHOLD_INDEX )
	{
		addToChain( &ChainOfDeath, XI, YI );
	}
	else
	{
		addToChain( &ChainOfDeath, TmpBuffer[ 0 ].XI, TmpBuffer[ 0 ].YI );
		addToChain( &ChainOfDeath, TmpBuffer[ 1 ].XI, TmpBuffer[ 1 ].YI );
		addToChain( &ChainOfDeath, TmpBuffer[ 2 ].XI, TmpBuffer[ 2 ].YI );
		addToChain( &ChainOfDeath, XI, YI );
		
		TmpBuffer[ Counter ].XI = XI;
		TmpBuffer[ Counter ].YI = YI;
	}
}
/**
 * checks if a point in the matrix exists
 * @param index of x
 * @param index of y
 * @return  bool
 */
bool pointExists( IndexOfX XI, IndexOfY YI )	 
{
	if( XI < TheMatrix.Elements )
	{
		if( YI < TheMatrix.XCoordinates[ XI ]->Elements )	{ return true; }
	}
	
	return false;
}
/**
 * Matches a given point against a Expected X Value and Color
 * @param given Index of X
 * @param given Index of Y
 * @param expected Value of X
 * @param expected Color
 * @return bool
 */
bool matches( IndexOfX XI, IndexOfY YI, ValueOfX X, Color Y )
{
	if( pointExists( XI, YI ) == false )	{ return false; }
	return X == TheMatrix.XCoordinates[ XI ]->X and Y == TheMatrix.XCoordinates[ XI ]->Colors[ YI ];
}
/**
 * probes at a given point
 * @param the index of x
 * @param the index of y
 * @param the value of x
 * @param the vlaue of color (start)
 * @param Buffer of Points
 * @param Counter, how many rounds
 * @param pointer of bool -> Flag/Lock
 * @param pointer of function -> the ChainAdd Routine
 */
static void probe( 
	IndexOfX XI,
	IndexOfY YI,
	ValueOfX X,
	Color Y,
	Point* Buffer,
	size_t Counter,
	bool* Flag,
	void (*adder)( Point*, IndexOfX, IndexOfY, size_t )
)
{
	if( *Flag == false )			{ return; }
	if( matches( XI, YI, X, Y ) )	{ adder( Buffer, XI, YI, Counter ); }
	else							{ *Flag = false; }
}
/**
 * writes garbages to a given chain buffer
 */
static void intiChainBuffer( Point* Buffer )
{
	for( size_t Index = 0; Index < CHAIN_THRESHOLD_INDEX+1; Index++ )
	{
		Buffer[ Index ].XI = BUFFER_LOCK;
		Buffer[ Index ].YI = 0;
	}
}
/**
 * writes a part of a found chain to a buffer
 */
static void writePartialBufferToChain( Point* PartialBuffer )
{
	if( PartialBuffer[ 1 ].XI != BUFFER_LOCK )   { addToChain( &ChainOfDeath, PartialBuffer[ 1 ].XI, PartialBuffer[ 1 ].YI ); }
	if( PartialBuffer[ 2 ].XI != BUFFER_LOCK )   { addToChain( &ChainOfDeath, PartialBuffer[ 2 ].XI, PartialBuffer[ 2 ].YI ); }
}
/**
 * merges partial chain buffers in to the chain of death
 */
static void mergePartialBuffers( Point* PartialBuffer )
{
	if(PartialBuffer[ 2 ].XI != BUFFER_LOCK )		{ writePartialBufferToChain( PartialBuffer ); }
	else											{ addToChain( &ChainOfDeath, PartialBuffer[ 1 ].XI, PartialBuffer[ 1 ].YI ); }
}
/**
 * evaluates partial chain buffers
 */
static void mergeOrSkipPartialBuffers( Point* PartialBuffer1, Point* PartialBuffer2 )
{
	if( 
		( PartialBuffer1[ 1 ].XI != BUFFER_LOCK and PartialBuffer1[ 2 ].XI != BUFFER_LOCK and PartialBuffer2[ 1 ].XI != BUFFER_LOCK )
	or
		( PartialBuffer2[ 1 ].XI != BUFFER_LOCK and PartialBuffer2[ 2 ].XI != BUFFER_LOCK and PartialBuffer1[ 1 ].XI != BUFFER_LOCK )
	) 	
	{
		mergePartialBuffers( PartialBuffer1 );
		mergePartialBuffers( PartialBuffer2 );

		if( PartialBuffer1[ 0 ].XI != BUFFER_LOCK )//exception are new elements
		{
			addToChain( &ChainOfDeath, PartialBuffer1[ 0 ].XI, PartialBuffer1[ 0 ].YI );
		}
	}
}
/**
 * it completes incomplete partial chains
 */
static void completeIncompleteBuffer( Point* PartialBuffer1, Point* PartialBuffer2 )
{
	if		( PartialBuffer1[ 3 ].XI != BUFFER_LOCK and PartialBuffer2[ 3 ].XI == BUFFER_LOCK ) { writePartialBufferToChain( PartialBuffer2 ); }
	else if	( PartialBuffer2[ 3 ].XI != BUFFER_LOCK and PartialBuffer1[ 3 ].XI == BUFFER_LOCK ) { writePartialBufferToChain( PartialBuffer1 ); }
	else																						{ mergeOrSkipPartialBuffers( PartialBuffer1, PartialBuffer2 ); }
}
/**
 * it probes a given (existing) Point for matches
 * @param the start index of x
 * @param the start index of y
 */
void probePoint( IndexOfX XI, IndexOfY YI, bool Use[ 8 ] )
{
	size_t Counter = 1;

	bool VerticalButtomUp = Use[ 0 ];
	bool VerticalTopDown = Use[ 1 ];

	bool HorizontalRightLeft = Use[ 2 ];
	bool HorizontalLeftRight = Use[ 3 ];

	bool DiagonalButtomUpLR = Use[ 4 ];
	bool DiagonalTopDownLR = Use[ 5 ];
	
	bool DiagonalButtomUpRL = Use[ 6 ];
	bool DiagonalTopDownRL = Use[ 7 ];


	Point VerticalButtomUpBuffer[ CHAIN_THRESHOLD_INDEX+1 ];
	intiChainBuffer( (Point*) VerticalButtomUpBuffer );
	
	Point VerticalTopDownBuffer[ CHAIN_THRESHOLD_INDEX+1 ];
	intiChainBuffer( (Point*) VerticalTopDownBuffer );

	Point HorizontalRightLeftBuffer[ CHAIN_THRESHOLD_INDEX+1 ];
	intiChainBuffer( (Point*) HorizontalRightLeftBuffer );
	
	Point HorizontalLeftRightBuffer[ CHAIN_THRESHOLD_INDEX+1 ];
	intiChainBuffer( (Point*) HorizontalLeftRightBuffer );

	Point DiagonalButtomUpLRBuffer[ CHAIN_THRESHOLD_INDEX+1 ];
	intiChainBuffer( (Point*) DiagonalButtomUpLRBuffer );

	Point DiagonalTopDownLRBuffer[ CHAIN_THRESHOLD_INDEX+1 ];
	intiChainBuffer( (Point*) DiagonalTopDownLRBuffer );

	Point DiagonalButtomUpRLBuffer[ CHAIN_THRESHOLD_INDEX+1 ];
	intiChainBuffer( (Point*) DiagonalButtomUpRLBuffer );

	Point DiagonalTopDownRLBuffer[ CHAIN_THRESHOLD_INDEX+1 ];
	intiChainBuffer( (Point*) DiagonalTopDownRLBuffer );

	VerticalButtomUpBuffer[ 0 ].XI = XI;
	VerticalButtomUpBuffer[ 0 ].YI = YI;
	VerticalTopDownBuffer[ 0 ].XI = XI;
	VerticalTopDownBuffer[ 0 ].YI = YI;

	HorizontalLeftRightBuffer[ 0 ].XI = XI;
	HorizontalLeftRightBuffer[ 0 ].YI = YI;
	HorizontalRightLeftBuffer[ 0 ].XI = XI;
	HorizontalRightLeftBuffer[ 0 ].YI = YI;

	DiagonalButtomUpLRBuffer[ 0 ].XI = XI;
	DiagonalButtomUpLRBuffer[ 0 ].YI = YI;
	DiagonalTopDownLRBuffer[ 0 ].XI = XI;
	DiagonalTopDownLRBuffer[ 0 ].YI = YI;

	DiagonalButtomUpRLBuffer[ 0 ].XI = XI;
	DiagonalButtomUpRLBuffer[ 0 ].YI = YI;
	DiagonalTopDownRLBuffer[ 0 ].XI = XI;
	DiagonalTopDownRLBuffer[ 0 ].YI = YI;

	ValueOfX OrgX = TheMatrix.XCoordinates[ XI ]->X;
	ValueOfX XRight2Left = OrgX-1;
	ValueOfX XLeft2Right = OrgX+1;

	Color Y = TheMatrix.XCoordinates[ XI ]->Colors[ YI ];

	IndexOfX OrgXI = XI;
	IndexOfY OrgYI = YI;
	
	IndexOfX XIRight2Left = XI-1;
	IndexOfX XILeft2Right = XI+1;

	IndexOfY YIUp = YI;
	IndexOfY YIDown = YI;

	do
	{
		YIUp++;
		YIDown--;

		if( YIDown > OrgYI )
		{
			VerticalTopDown = false;
			DiagonalTopDownLR = false;
			DiagonalTopDownRL = false;
		}

		//Vertical ButtomUp
		probe( OrgXI, YIUp, OrgX, Y, (Point*) VerticalButtomUpBuffer, Counter, &VerticalButtomUp, addToMarkerBufferFull );
		//Vertival TopDown
		probe( OrgXI, YIDown, OrgX, Y, (Point*) VerticalTopDownBuffer, Counter, &VerticalTopDown, addToMarkerBufferFull );
		//Horizontal Right2Left
		probe( XIRight2Left, OrgYI, XRight2Left, Y, (Point*) HorizontalRightLeftBuffer, Counter, &HorizontalRightLeft, addToMarkerBufferFull );
		//Horizontal Left2Right
		probe( XILeft2Right, OrgYI, XLeft2Right, Y, (Point*) HorizontalLeftRightBuffer, Counter, &HorizontalLeftRight, addToMarkerBufferFull );
		//Diagonal Buttom Up Left to Right
		probe( XILeft2Right, YIUp, XLeft2Right, Y, (Point*) DiagonalButtomUpLRBuffer, Counter, &DiagonalButtomUpLR, addToMarkerBufferFull );
		//Diagonal Top Down Left to Right
		probe( XILeft2Right, YIDown, XLeft2Right, Y, (Point*) DiagonalTopDownLRBuffer, Counter, &DiagonalTopDownLR, addToMarkerBufferFull );
		//Diagonal Buttom Up Right to Left
		probe( XIRight2Left, YIUp, XRight2Left, Y, (Point*) DiagonalButtomUpRLBuffer, Counter, &DiagonalButtomUpRL, addToMarkerBufferFull );
		//Diagonal top down Right to Left	
		probe( XIRight2Left, YIDown, XRight2Left, Y, (Point*) DiagonalTopDownRLBuffer, Counter, &DiagonalTopDownRL, addToMarkerBufferFull );

		XLeft2Right++;
		XILeft2Right++;

		XRight2Left--;
		XIRight2Left--;

		if( XIRight2Left > OrgXI )
		{
			HorizontalRightLeft = false;
			DiagonalButtomUpRL = false;
			DiagonalTopDownRL = false;
		}

		Counter++;
	}
	while( Or8( VerticalButtomUp, VerticalTopDown, HorizontalLeftRight, HorizontalRightLeft, DiagonalButtomUpLR, DiagonalTopDownLR, DiagonalButtomUpRL, DiagonalTopDownRL ) );

	completeIncompleteBuffer( (Point*) VerticalButtomUpBuffer, (Point*) VerticalTopDownBuffer );
	completeIncompleteBuffer( (Point*) HorizontalLeftRightBuffer, (Point*) HorizontalRightLeftBuffer );
	completeIncompleteBuffer( (Point*) DiagonalButtomUpLRBuffer, (Point*) DiagonalTopDownRLBuffer );
	completeIncompleteBuffer( (Point*) DiagonalButtomUpRLBuffer, (Point*) DiagonalTopDownLRBuffer );
}
/**
 * adds matched temporary Point Buffer, depending on the Counter
 * @param the tmp Buffer
 * @param value/index of x
 * @param value/index of y
 * @param Counter
 */
static void addToMarkerBufferTail( Point* TmpBuffer, IndexOfX XI, IndexOfY YI, size_t Counter )
{
	if( Counter < CHAIN_THRESHOLD_INDEX )	
	{
		TmpBuffer[ Counter ].XI = XI;
		TmpBuffer[ Counter ].YI = YI;
	}
	else if ( Counter > CHAIN_THRESHOLD_INDEX )
	{
		addToChain( &ChainOfDeath, XI, YI );
	}
	else
	{
		addToChain( &ChainOfDeath, TmpBuffer[ 1 ].XI, TmpBuffer[ 1 ].YI );
		addToChain( &ChainOfDeath, TmpBuffer[ 2 ].XI, TmpBuffer[ 2 ].YI );
		addToChain( &ChainOfDeath, XI, YI );

		TmpBuffer[ Counter ].XI = XI;
		TmpBuffer[ Counter ].YI = YI;
	}
}
/**
 * it probes a given new Point for matches
 * @param the start index of x
 * @param the start index of y
 */
void probeNewPoint(
	ValueOfX OrgX,
	ValueOfX XRight2Left,
	ValueOfX XLeft2Right,
	IndexOfX OrgXI,
	IndexOfX XIRight2Left,
	IndexOfX XILeft2Right,
	IndexOfY OrgYI,
	Color Y,
	bool UseVertical
)
{
	size_t Counter = 1;

	bool VerticalTopDown = UseVertical;

	bool HorizontalRightLeft = true;
	bool HorizontalLeftRight = true;

	bool DiagonalButtomUpLR = true;
	bool DiagonalTopDownLR = true;
	
	bool DiagonalButtomUpRL = true;
	bool DiagonalTopDownRL = true;

	Point VerticalTopDownBuffer[ CHAIN_THRESHOLD_INDEX+1 ];

	Point HorizontalRightLeftBuffer[ CHAIN_THRESHOLD_INDEX+1 ];
	intiChainBuffer( (Point*) HorizontalRightLeftBuffer );
	
	Point HorizontalLeftRightBuffer[ CHAIN_THRESHOLD_INDEX+1 ];
	intiChainBuffer( (Point*) HorizontalLeftRightBuffer );

	Point DiagonalButtomUpLRBuffer[ CHAIN_THRESHOLD_INDEX+1 ];
	intiChainBuffer( (Point*) DiagonalButtomUpLRBuffer );

	Point DiagonalTopDownLRBuffer[ CHAIN_THRESHOLD_INDEX+1 ];
	intiChainBuffer( (Point*) DiagonalTopDownLRBuffer );

	Point DiagonalButtomUpRLBuffer[ CHAIN_THRESHOLD_INDEX+1 ];
	intiChainBuffer( (Point*) DiagonalButtomUpRLBuffer );

	Point DiagonalTopDownRLBuffer[ CHAIN_THRESHOLD_INDEX+1 ];
	intiChainBuffer( (Point*) DiagonalTopDownRLBuffer );

	IndexOfY YIUp = OrgYI;
	IndexOfY YIDown = OrgYI;

	do
	{
		YIUp++;
		YIDown--;

		if( YIDown > OrgYI )
		{
			VerticalTopDown = false;
			DiagonalTopDownLR = false;
			DiagonalTopDownRL = false;
		}

		//Vertival TopDown
		probe( OrgXI, YIDown, OrgX, Y, (Point*) VerticalTopDownBuffer, Counter, &VerticalTopDown, addToMarkerBufferTail );
		//Horizontal Right2Left
		probe( XIRight2Left, OrgYI, XRight2Left, Y, (Point*) HorizontalRightLeftBuffer, Counter, &HorizontalRightLeft, addToMarkerBufferTail );
		//Horizontal Left2Right
		probe( XILeft2Right, OrgYI, XLeft2Right, Y, (Point*) HorizontalLeftRightBuffer, Counter, &HorizontalLeftRight, addToMarkerBufferTail );
		//Diagonal Buttom Up Left to Right
		probe( XILeft2Right, YIUp, XLeft2Right, Y, (Point*) DiagonalButtomUpLRBuffer, Counter, &DiagonalButtomUpLR, addToMarkerBufferTail );
		//Diagonal Top Down Left to Right
		probe( XILeft2Right, YIDown, XLeft2Right, Y, (Point*) DiagonalTopDownLRBuffer, Counter, &DiagonalTopDownLR, addToMarkerBufferTail );
		//Diagonal Buttom Up Right to Left
		probe( XIRight2Left, YIUp, XRight2Left, Y, (Point*) DiagonalButtomUpRLBuffer, Counter, &DiagonalButtomUpRL, addToMarkerBufferTail );
		//Diagonal top down Right to Left	
		probe( XIRight2Left, YIDown, XRight2Left, Y, (Point*) DiagonalTopDownRLBuffer, Counter, &DiagonalTopDownRL, addToMarkerBufferTail );

		XLeft2Right++;
		XILeft2Right++;

		XRight2Left--;
		XIRight2Left--;

		if( XIRight2Left > OrgXI )
		{
			HorizontalRightLeft = false;
			DiagonalButtomUpRL = false;
			DiagonalTopDownRL = false;
		}

		Counter++;
	}
	while( Or8( false, VerticalTopDown, HorizontalLeftRight, HorizontalRightLeft, DiagonalButtomUpLR, DiagonalTopDownLR, DiagonalButtomUpRL, DiagonalTopDownRL ) );

	completeIncompleteBuffer( (Point*) HorizontalLeftRightBuffer, (Point*) HorizontalRightLeftBuffer );
	completeIncompleteBuffer( (Point*) DiagonalButtomUpLRBuffer, (Point*) DiagonalTopDownRLBuffer );
	completeIncompleteBuffer( (Point*) DiagonalButtomUpRLBuffer, (Point*) DiagonalTopDownLRBuffer );
}
/**
 * moves the given y's up in the y-axis, aka let game pices fall through
 * @param MarkedGamePice -> which pice should be moved up
 */
void moveUp( MarkedGamePice* Pice )
{
	size_t EndOfAxis = TheMatrix.XCoordinates[ Pice->X ]->Elements;
	size_t Counter = 0;
	size_t AnCounter;

	for( size_t Index = Pice->IndicesOfY[ 0 ]; Index+Counter < EndOfAxis; Index++ )
	{
		if( Counter < Pice->Elements and Pice->IndicesOfY[ Counter ] == Index )	
		{
			AnCounter = 0;
			do
			{
				Counter++;
				AnCounter++;
				if( Index+Counter >= EndOfAxis )  { return; }

			} while( Counter < Pice->Elements and Pice->IndicesOfY[ Counter ] == Index + AnCounter );
		}

		TheMatrix.XCoordinates[ Pice->X ]->Colors[ Index ] = TheMatrix.XCoordinates[ Pice->X ]->Colors[ Index+Counter ];
	}
}
/**
 * moves all items of the ChainOfDeath up
 */
void moveThemAllUp( void )
{
	for( size_t Index = 0; Index < ChainOfDeath.Elements; Index++ ) 
	{
		moveUp( ChainOfDeath.GamePices[ Index ] ); 
		decreaseYByFactor( ChainOfDeath.GamePices[ Index ]->X, ChainOfDeath.GamePices[ Index ]->Elements );
	}

	collectXAxisGabage();
}

/**
 * checks if the given point was triggert by a vertical chain
 */
static bool wasVertical( MarkedGamePice* Pice, IndexOfY ExpectedY, IndexOfChain JumpToY )
{
	if( JumpToY >= Pice->Elements )					{ return false; }
	if( Pice->IndicesOfY[ JumpToY ] == ExpectedY )	{ return true; }
	
	return false;
}
/**
 * checks the common premise of all directional checks
 */
static bool hasDirectionalPremise( IndexOfX ExpectedX, IndexOfY ExpectedY, IndexOfChain JumpToX )
{
	return ChainOfInspection.GamePices[ JumpToX ]->X == ExpectedX and -1 < findMarkedYInsertPosition( ExpectedY, ChainOfInspection.GamePices[ JumpToX ] );
}
/**
 * checks if the given is the most left element in a horizontal chain
 */
static bool mostLeftHorizontal( IndexOfX ExpectedX, IndexOfX LastX, IndexOfX LastIndexOfX, IndexOfY ExpectedY, IndexOfChain JumpToX )
{
	if( hasDirectionalPremise( ExpectedX, ExpectedY, JumpToX ) )
	{
		if( 0 > findMarkedYInsertPosition( ExpectedY, ChainOfInspection.GamePices[ JumpToX-1 ] ) )	{ return false; }
		if( 0 > findMarkedYInsertPosition( ExpectedY, ChainOfInspection.GamePices[ JumpToX-2 ] ) )	{ return false; }

		return ChainOfInspection.GamePices[ LastIndexOfX ]->X != LastX or 0 > findMarkedYInsertPosition( ExpectedY, ChainOfInspection.GamePices[ LastIndexOfX ] );
	}

	return false;
}
/**
 * checks if the given is the most left element in a horizontal chain
 */
static bool mostRightHorizontal( IndexOfX ExpectedX, IndexOfX NextX, IndexOfX NextIndexOfX, IndexOfY ExpectedY, int JumpToX )
{
	if( hasDirectionalPremise( ExpectedX, ExpectedY, JumpToX ) )	
	{
		if( 0 > findMarkedYInsertPosition( ExpectedY, ChainOfInspection.GamePices[ JumpToX+1 ] ) ) { return false; }
		if( 0 > findMarkedYInsertPosition( ExpectedY, ChainOfInspection.GamePices[ JumpToX+2 ] ) ) { return false; }

		return ChainOfInspection.GamePices[ NextIndexOfX ]->X != NextX or 0 > findMarkedYInsertPosition( ExpectedY, ChainOfInspection.GamePices[ NextIndexOfX ] );
	}

	return false;
}
/**
 * checks if the given is the most left element of a diagonale (LR)
 */
static bool mostLeftDiagonalLR( IndexOfX ExpectedX, IndexOfX LastX, IndexOfX LastIndexOfX, IndexOfY ExpectedY, IndexOfChain JumpToX )
{
	if( hasDirectionalPremise( ExpectedX, ExpectedY, JumpToX ) )
	{
		if( 0 > findMarkedYInsertPosition( ExpectedY-1, ChainOfInspection.GamePices[ JumpToX-1 ] ) )	{ return false; }
		if( 0 > findMarkedYInsertPosition( ExpectedY-2, ChainOfInspection.GamePices[ JumpToX-2 ] ) )	{ return false; }
		
		return ChainOfInspection.GamePices[ LastIndexOfX ]->X != LastX or 0 > findMarkedYInsertPosition( ExpectedY-4, ChainOfInspection.GamePices[ LastIndexOfX ] );
	}

	return  false;
}
/**
 * checks if the given is the most right element of a diagonale (LR)
 */
static bool mostRightDiagonalLR( IndexOfX ExpectedX, IndexOfX NextX, IndexOfX NextIndexOfX, IndexOfY ExpectedY, IndexOfChain JumpToX )
{
	if( hasDirectionalPremise( ExpectedX, ExpectedY, JumpToX ) )
	{
		if( 0 > findMarkedYInsertPosition( ExpectedY+1, ChainOfInspection.GamePices[ JumpToX+1 ] ) )	{ return false; }
		if( 0 > findMarkedYInsertPosition( ExpectedY+2, ChainOfInspection.GamePices[ JumpToX+2 ] ) )	{ return false; }
		
		return ChainOfInspection.GamePices[ NextIndexOfX ]->X != NextX or 0 > findMarkedYInsertPosition( ExpectedY+4, ChainOfInspection.GamePices[ NextIndexOfX ] );
	}

	return  false;
}
/**
 * checks if the given is the most left element of a diagonale (RL)
 */
static bool mostLeftDiagonalRL( IndexOfX ExpectedX, IndexOfX LastX, IndexOfX LastIndexOfX, IndexOfY ExpectedY, IndexOfChain JumpToX )
{
	if( hasDirectionalPremise( ExpectedX, ExpectedY, JumpToX ) )
	{
		if( 0 > findMarkedYInsertPosition( ExpectedY+1, ChainOfInspection.GamePices[ JumpToX-1 ] ) )	{ return false; }
		if( 0 > findMarkedYInsertPosition( ExpectedY+2, ChainOfInspection.GamePices[ JumpToX-2 ] ) )	{ return false; }
		
		return ChainOfInspection.GamePices[ LastIndexOfX ]->X != LastX or 0 > findMarkedYInsertPosition( ExpectedY+4, ChainOfInspection.GamePices[ LastIndexOfX ] );
	}

	return  false;
}
/**
 * checks if the given is the most right element of a diagonale (RL)
 */
static bool mostRightDiagonalRL( IndexOfX ExpectedX, IndexOfX LastX, IndexOfX LastIndexOfX, IndexOfY ExpectedY, IndexOfChain JumpToX )
{
	if( hasDirectionalPremise( ExpectedX, ExpectedY, JumpToX ) )
	{
		if( 0 > findMarkedYInsertPosition( ExpectedY-1, ChainOfInspection.GamePices[ JumpToX+1 ] ) )	{ return false; }
		if( 0 > findMarkedYInsertPosition( ExpectedY-2, ChainOfInspection.GamePices[ JumpToX+2 ] ) )	{ return false; }
		
		return ChainOfInspection.GamePices[ LastIndexOfX ]->X != LastX or 0 > findMarkedYInsertPosition( ExpectedY-4, ChainOfInspection.GamePices[ LastIndexOfX ] );
	}

	return  false;
}
/**
 * checks for given ChainIndex if is a limit present and where it starts
 * @param index of chain
 */
long getLimitAt( IndexOfX XI )
{
	IndexOfY ExpectedYUp;
	IndexOfY ExpectedYDown;
	IndexOfChain JumpToYUp;
	
	IndexOfX NextX;
	IndexOfX NextIndexOfX;
	IndexOfX ExpectedXLeft;
	int JumpToXLeft;

	IndexOfX LastX;
	IndexOfX LastIndexOfX;
	IndexOfX ExpectedXRight;
	IndexOfChain JumpToXRight;

	// Begin of Chain
	if( XI == 0 )								{ return 0; }
	// End of Chain
	if( XI == ChainOfInspection.Elements-1 )	{ return 0; }

	ExpectedXRight = ChainOfInspection.GamePices[ XI ]->X+3;
	JumpToXRight = XI+3;
	LastX = ChainOfInspection.GamePices[ XI ]->X-1;
	LastIndexOfX = XI-1;

	ExpectedXLeft = ChainOfInspection.GamePices[ XI ]->X-3;
	JumpToXLeft = XI-3;
	NextX = ChainOfInspection.GamePices[ XI ]->X+1;
	NextIndexOfX = XI+1;

	for( size_t YI = 0; YI < ChainOfInspection.GamePices[ XI ]->Elements; YI++ )
	{
		ExpectedYUp = ChainOfInspection.GamePices[ XI ]->IndicesOfY[ YI ]+3;
		ExpectedYDown = ChainOfInspection.GamePices[ XI ]->IndicesOfY[ YI ]-3;
		JumpToYUp = YI+3;
		
		if( ChainOfInspection.Elements > JumpToXRight )
		{
			if( mostLeftHorizontal( ExpectedXRight, LastX, LastIndexOfX, ChainOfInspection.GamePices[ XI ]->IndicesOfY[ YI ], JumpToXRight )	)	{ return YI; }
			//LR
			if( mostLeftDiagonalLR( ExpectedXRight, LastX, LastIndexOfX, ExpectedYUp, JumpToXRight ) )												{ return YI; }
			//RL
			if( mostLeftDiagonalRL( ExpectedXRight, LastX, LastIndexOfX, ExpectedYDown, JumpToXRight ) )											{ return YI; }
		}

		if( JumpToXLeft >= 0 )   
		{
			if( mostRightHorizontal( ExpectedXLeft, NextX, NextIndexOfX, ChainOfInspection.GamePices[ XI ]->IndicesOfY[ YI ], JumpToXLeft ) )		{ return YI; }
			//LR
			if( mostRightDiagonalLR( ExpectedXLeft, NextX, NextIndexOfX, ExpectedYDown, JumpToXLeft ) )												{ return YI; }
			//RL
			if( mostRightDiagonalRL( ExpectedXLeft, NextX, NextIndexOfX, ExpectedYUp, JumpToXLeft ) )												{ return YI; }
		}

		if( wasVertical( ChainOfInspection.GamePices[ XI ], ExpectedYUp, JumpToYUp ) ) 																{ return YI; }
	}

	return -1;
}
/**
 * finds the nearest power of tow, which is equal or greater then given Amount of Elements
 * @param start power
 * @param target amount
 * @return nearest power
 */
size_t getNewDecresingXSize( size_t CurrentPower, size_t TargetSize )
{
	size_t Greater = CurrentPower;
	size_t Half = CurrentPower>>1;
	size_t Factor = 1;

	if( TargetSize == 0 )	{ return 1; }

	while( Half >= TargetSize and Half >= X_AXIS_MIN_LENGTH )
	{ 
		Greater = CurrentPower>>Factor;
		Factor++;
		Half = CurrentPower>>Factor;
	}

	return Greater;
}
/**
 * Decreases the amount of fields for X-coordinates
 * However, it decreases by the nearest a power of tow, which is greater then the amount of elements.
 */
void decreaseX(void)
{
	size_t NewSize;
	XAxis** Tmp;

	NewSize = getNewDecresingXSize( TheMatrix.Length, TheMatrix.Elements );

	Tmp = allocXEntries( TheMatrix.XCoordinates, NewSize );
	if( Tmp == NULL )   { errorAndOut( L"WTF - this should never happen - there is no memory left." ); }
	else
	{
		TheMatrix.XCoordinates = Tmp;
		TheMatrix.Length = NewSize;
	}
}
/**
 * destroys a XAxis entry for a given Index
 */
void removeXEntry( IndexOfX XI )
{
	if( TheMatrix.XCoordinates[ XI ]->Colors != NULL )	{ free( TheMatrix.XCoordinates[ XI ]->Colors ); }
	free( TheMatrix.XCoordinates[ XI ] );
	TheMatrix.XCoordinates[ XI ] = NULL;
}
/**
 * collects empty Entries on the end of the XAxis
 */
void collectXAxisGabage( void )
{
	if( TheMatrix.Elements < X_AXIS_MIN_LENGTH )	{ return; }

	size_t TombIndex = TheMatrix.Elements-1;
	while( TheMatrix.XCoordinates[ TombIndex ]->Elements == 0 )
	{
		removeXEntry( TombIndex );
		TheMatrix.Elements--;
		TombIndex--;
	}

	decreaseX();
}
/**
 * Calculates the Factor for decreasing a Y Axis
 * @param the Amount of item, which should be removed from the axis
 * @return Amount, which should be deletet from the axis
 */
size_t getNewDecresingYSize( size_t NonPadded ) 
{
	short Rest;
	if( NonPadded < Y_AXIS_INCREASE_CONST )	{ return Y_AXIS_INCREASE_CONST; }
	else									
	{
		Rest = NonPadded % Y_AXIS_INCREASE_CONST;
		if( Rest == 0 )		{ return NonPadded; }
		else				{ return NonPadded + ( Y_AXIS_INCREASE_CONST  - Rest ); }
	}
}
/**
 * Removes n y coordinates by a given amount
 * @param size_t Index of where y should be decreased
 * @param size_t Amount of y, which should be deleted
 */
void decreaseYByFactor( IndexOfX XI, size_t AmountOfDeletions )
{
	unsigned char* Tmp;
	size_t NewLength;
	bool Zero = false;	

	if( AmountOfDeletions >= TheMatrix.XCoordinates[ XI ]->Elements )	
	{
		TheMatrix.XCoordinates[ XI ]->Elements = 0;
		NewLength = 0; 
		Zero = true; 
	}
	else				
	{
		TheMatrix.XCoordinates[ XI ]->Elements -= AmountOfDeletions;
		NewLength = getNewDecresingYSize( TheMatrix.XCoordinates[ XI ]->Elements ); 
	}

	if( NewLength == 0 )	
	{
		if( !Zero ) { return;  } 
	}

	Tmp = allocY(
			TheMatrix.XCoordinates[ XI ]->Colors,
			NewLength
	);

	if( Tmp == NULL and !Zero )   { errorAndOut( L"No, that cannot be true, something crushed the memory." ); }
	else 
	{
		TheMatrix.XCoordinates[ XI ]->Length = NewLength;
		TheMatrix.XCoordinates[ XI ]->Colors = Tmp;
	}
}
/**
 * resets TheMatrix
 */
static void resetMatrix( void )
{
	free( TheMatrix.XCoordinates );
	TheMatrix.XCoordinates = NULL;
	TheMatrix.Elements = 0;
	TheMatrix.Length = 0;
}
/**
 * purges all entries of TheMatrix
 */
void purgeMatrix( void )
{
	if( TheMatrix.XCoordinates == NULL )	{ return; }

	for( size_t Index = 0; Index < TheMatrix.Elements; Index++ ) { removeXEntry( Index ); }
	resetMatrix();
}

#ifndef TEST
/**
 * Wrapper for printf( %d, %d, %d )
 */
void printEntry( Color Y, ValueOfX X, IndexOfY YI )	{ printf( "%d %d %lu\n", Y, X, YI ); }
#endif
/**
 * prints all entries on a given sector of the xaxis
 */
static void printYAxis( XAxis* Sector )
{
	for( size_t Index = 0; Index < Sector->Elements; Index++ )	{ printEntry( Sector->Colors[ Index ], Sector->X, Index ); }
}
/**
 * travels through the matrix, delegates the sectors to print and deletes them afterwards
 */
void printAndDestroy( void )
{
	if( TheMatrix.XCoordinates == NULL )	{ return; }

	for( size_t Index = 0; Index < TheMatrix.Elements; Index++ )
	{
		printYAxis( TheMatrix.XCoordinates[ Index ] );
		removeXEntry( Index );
	}
	
	resetMatrix();
}
