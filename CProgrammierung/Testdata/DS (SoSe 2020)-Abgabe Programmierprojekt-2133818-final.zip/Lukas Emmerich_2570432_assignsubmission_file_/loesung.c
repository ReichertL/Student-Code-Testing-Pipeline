#include <signal.h>
#include <stdio.h>
#include <stdlib.h>

#define usize long long int

#define MAX_X 1048576
// error codes
#define MEM_ALLOC 1
#define INVALID_CHAR 2
#define INVALID_COLOR 3
#define MISSING_COLUMN_ID 4
#define INVALID_X_VALUE 5
#define USER_INTERRUPTED 99
#define SEGFAULT 100

#define MIN_VEC_SIZE 20

void clean_up();
int get_color(int column, usize row);
typedef struct coordinate
{
    int x;
    usize y;
} coordinate;

/**
 *  struct storing a variable amount of coordinates
 */
typedef struct coordinate_list
{
    usize length;
    usize max_length;
    struct coordinate **elements;
} coordinate_list;

coordinate *coordinate_init(int x, usize y)
{
    coordinate *co = malloc(sizeof(coordinate));
    if( co == NULL)
    {
        fprintf(stderr, "Failed to allocate memory for coordinates (%i,%lld)\n", x, y);
        clean_up();
        exit(MEM_ALLOC);
    }
    co->x = x;
    co->y = y;
    return co;
}

struct coordinate_list *coordinate_list_init()
{
    coordinate_list *co_list = malloc(sizeof(coordinate_list));
    if( co_list == NULL)
    {
        fprintf(stderr, "Failed to allocate memory for list of coordinates\n");
        clean_up();
        exit(MEM_ALLOC);
    }
    co_list->elements = malloc(sizeof(coordinate *) * 2);
    if( co_list->elements == NULL)
    {
        fprintf(stderr, "Failed to allocate memory for list of coordinates\n");
        clean_up();
        exit(MEM_ALLOC);
    }
    co_list->length = 0;
    co_list->max_length = 2;
    return co_list;
}

void coordinate_list_destroy(coordinate_list *to_destroy)
{
    for(usize i=0; i<to_destroy->length; i++)
    {
        free(to_destroy->elements[i]);
    }
    free(to_destroy->elements);
    free(to_destroy);
}

int coordinate_list_has_element(struct coordinate_list *list, int x, usize y)
{
    for( usize i = 0; i < list->length; i++ )
    {
        if( list->elements[i]->x == x && list->elements[i]->y == y )
        {
            return 1;
        }
    }
    return 0;
}
void coordinate_list_push(struct coordinate_list *list, int x, usize y)
{
    if( coordinate_list_has_element(list, x, y))
    {
        return; // if the element is already in the list, don't add it again.
    }
    coordinate *coord = coordinate_init(x, y);
    if( list->length < list->max_length )
    {
        //just add the new element
        list->elements[list->length] = coord;
        list->length = list->length + 1;
    }
    else
    {
        list->elements = realloc(list->elements, sizeof(coordinate *) * ( list->max_length *2));
        if( list->elements == NULL)
        {
            fprintf(stderr, "Failed to resize coordinate list\n");
            clean_up();
            exit(MEM_ALLOC);
        }
        list->elements[list->length] = coord;
        list->length = list->length + 1;
        list->max_length = list->max_length * 2;
    }
}


// exclude signal handling from being compiled, because it does not work with -Werror unused
// signal handlers
static void handle_SIGINT(__attribute__((unused)) int sig)
{
    clean_up();
    exit(USER_INTERRUPTED);
}
static void handle_SEGFAULT(__attribute__((unused)) int sig)
{
    clean_up();
    fprintf(stderr, "Encountered segmentation fault. Exiting\n");
    exit(SEGFAULT);
}

//global board variable
int ** positive_board = NULL;
int ** negative_board = NULL;
usize *positive_actual_length = NULL;
usize *positive_allocated_length = NULL;
usize *negative_actual_length = NULL;
usize *negative_allocated_length = NULL;
int board_right_border = 0;
int board_left_border = 0;
coordinate_list * search_results = NULL;
coordinate_list * vectors_to_shorten = NULL;

void print_board()
{
    if(negative_board != NULL)
    {
        for(int i=1; i<=board_left_border; i++)
        {
            int current_column = board_left_border - i;
            if(negative_allocated_length[current_column]>0)
            {
                if(negative_actual_length[current_column]>0)
                {
                    for(usize row = 0; row < negative_actual_length[current_column]; row++)
                    {
                        usize col_id = current_column;
                        col_id += 1;
                        col_id = col_id *-1;

                        printf("%i %lli %lli\n",(int) get_color(col_id, row), col_id, row);
                    }
                }
            }
        }
    }
    if(positive_board != NULL)
    {
        for(int current_column = 0; current_column < board_right_border; current_column ++)
        {
            if( positive_allocated_length[current_column] > 0 )
            {
                if( positive_actual_length[current_column] > 0 )
                {
                    for( usize row = 0; row < positive_actual_length[current_column]; row++ )
                    {
                        printf("%i %i %lli\n", get_color(current_column, row), current_column, row);
                    }
                }
            }
        }

    }
}


void clean_up()
{
    if(positive_board != NULL)
    {

        for(usize i = 0; i<board_right_border; i++)
        {
            if(positive_allocated_length[i]>0)
            {
                free(positive_board[i]);
            }
        }
    }
    free(positive_board);
    free(positive_actual_length);
    free(positive_allocated_length);

    if(negative_board != NULL)
    {
        for(usize i=0; i < board_left_border; i++)
        {
            if(negative_allocated_length[i]>0)
            {
                free(negative_board[i]);
            }
        }
    }
    free(negative_board);
    free(negative_actual_length);
    free(negative_allocated_length);

    if(search_results != NULL)
    {
        coordinate_list_destroy(search_results);
    }
    if(vectors_to_shorten != NULL)
    {
        coordinate_list_destroy(vectors_to_shorten);
    }
}

int get_num_val(int c)
{
    if( c >= '0' && c <= '9' )
    {
        return ( c - '0' );
    }
    return -1;
}

int read_column_id(unsigned long long int line_index)
{
    int c;
    int number = 0;
    int is_negative = 0;
    c = fgetc(stdin);
    if(c=='\0')
    {
        fprintf(stderr, "Illegal character '\\0' in line %llu\n", line_index );
        clean_up();
        exit(INVALID_CHAR);
    }
    while( c == ' ' )
    {
        //skip those
        c = fgetc(stdin);
    }
    if( c == '-' )
    {
        is_negative = 1;
    }
    else
    {
        int val = get_num_val((int) c);
        if( val == -1 )
        {
            if( c == '\n' )
            {
                fprintf(stderr, "Column id missing in line %lld\n", line_index);
                clean_up();
                exit(MISSING_COLUMN_ID);
            }
            else
            {
                fprintf(stderr, "Illegal character '%c' in line %lld\n", c, line_index);
                clean_up();
                exit(INVALID_CHAR);
            }
        }
        number = val;
    }
    c = fgetc(stdin);
    while( c != '\n' && c != EOF)
    {
        if(c=='\0')
        {
            fprintf(stderr, "Illegal character '\\0' in line %llu\n", line_index );
            clean_up();
            exit(INVALID_CHAR);
        }
        int val = get_num_val((int) c);
        if( val == -1 )
        {
            fprintf(stderr, "Illegal character '%c' in line %lld\n", c, line_index);
            clean_up();
            exit(INVALID_CHAR);
        }
        number = ( number * 10 ) + val;
        if(number > MAX_X)
        {
            fprintf(stderr, "Invalid x coordinate in line %llu\n", line_index);
            clean_up();
            exit(INVALID_X_VALUE);
        }
        c = fgetc(stdin);
    }
    if( is_negative )
    {
        number = number * -1;
    }

    return number;
}

int read_color(unsigned long long int line_index)
{
    int color = 0;
    int c = fgetc(stdin);
    if( c == EOF)
    {
        return -1;
    }
    while( c != ' ' )
    {
        if(c=='\0')
        {
            fprintf(stderr, "Illegal character '\\0' in line %llu\n", line_index );
            clean_up();
            exit(INVALID_CHAR);
        }
        if( c == '\n' )
        {
            fprintf(stderr, "Column id missing in line %lld\n", line_index);
            clean_up();
            exit(MISSING_COLUMN_ID);
        }
        int val = get_num_val((int) c);
        if( val < 0 )
        {
            fprintf(stderr, "Illegal character '%c' in color in line %lld\n", c, line_index);
            clean_up();
            exit(INVALID_CHAR);
        }
        color = ( color * 10 ) + val;
        if(color > 254)
        {
            fprintf(stderr, "Invalid color in line %llu\n", line_index);
            clean_up();
            exit(INVALID_COLOR);
        }
        c = fgetc(stdin);
    }
    return color;
}

void board_init()
{
    // Initialize positive part of the board.
    positive_board = malloc(sizeof(int*) * MIN_VEC_SIZE);
    if(positive_board == NULL)
    {
        fprintf(stderr, "Failed to allocate memory for positive_board\n");
        clean_up();
        exit(MEM_ALLOC);
    }
    board_right_border = MIN_VEC_SIZE;
//    positive_actual_length = calloc(0, sizeof(usize) * MIN_VEC_SIZE);
    positive_actual_length = malloc(sizeof(usize) * MIN_VEC_SIZE);
    if( positive_actual_length == NULL)
    {
        fprintf(stderr, "Failed to allocate memory for positive_actual_length\n");
        clean_up();
        exit(MEM_ALLOC);
    }
    positive_allocated_length = malloc(sizeof(usize) * MIN_VEC_SIZE);
    if(positive_allocated_length == NULL)
    {
        fprintf(stderr, "Failed to allocate memory for positive_allocated_length\n");
        clean_up();
        exit(MEM_ALLOC);
    }
    for(int i=0; i<MIN_VEC_SIZE; i++)
    {
        positive_board[i] = NULL;
        positive_allocated_length[i] = MIN_VEC_SIZE;
        positive_actual_length[i] = 0;
    }

    // handle negative part
    negative_board = malloc(sizeof(int*) * MIN_VEC_SIZE);
    if(negative_board == NULL)
    {
        fprintf(stderr, "Failed to allocate memory for negative_board\n");
        clean_up();
        exit(MEM_ALLOC);
    }
    board_left_border = MIN_VEC_SIZE;
//    negative_actual_length = calloc(0, sizeof(usize) * MIN_VEC_SIZE);
    negative_actual_length = malloc(sizeof(usize) * MIN_VEC_SIZE);
    if( negative_actual_length == NULL)
    {
        fprintf(stderr, "Failed to allocate memory for negative_actual_length\n");
        clean_up();
        exit(MEM_ALLOC);
    }
    negative_allocated_length = malloc(sizeof(usize) * MIN_VEC_SIZE);
    if(negative_allocated_length == NULL)
    {
        fprintf(stderr, "Failed to allocate memory for negative_allocated_length\n");
        clean_up();
        exit(MEM_ALLOC);
    }
    for(int i=0; i<MIN_VEC_SIZE; i++)
    {
        negative_board[i] = NULL;
        negative_allocated_length[i] = MIN_VEC_SIZE;
        negative_actual_length[i] = 0;
    }
}

void board_enlarge(int pos_board, usize new_max)
{
    if(pos_board == 1){
        positive_board = realloc(positive_board, sizeof(int*) * new_max);
        if(positive_board == NULL)
        {
            fprintf(stderr, "Failed to resize positive_board\n");
            clean_up();
            exit(MEM_ALLOC);
        }
        positive_actual_length = realloc(positive_actual_length, sizeof(usize) * new_max);
        if( positive_actual_length == NULL)
        {
            fprintf(stderr, "Failed to resize positive_actual_length\n");
            clean_up();
            exit(MEM_ALLOC);
        }
        positive_allocated_length = realloc(positive_allocated_length, sizeof(usize) * new_max);
        if(positive_allocated_length == NULL)
        {
            fprintf(stderr, "Failed to resize positive_allocated_length\n");
            clean_up();
            exit(MEM_ALLOC);
        }
        //int difference = new_max - board_right_border;
        for(usize i = board_right_border; i<new_max; i++)
        {
            positive_board[i] = NULL;
            positive_actual_length[i] = 0;
            positive_allocated_length[i] = 0;
        }
        board_right_border = new_max;
    }
    else{
        negative_board = realloc(negative_board, sizeof(int*) * new_max);
        if(negative_board == NULL)
        {
            fprintf(stderr, "Failed to resize negative_board\n");
            clean_up();
            exit(MEM_ALLOC);
        }
        negative_actual_length = realloc(negative_actual_length, sizeof(usize) * new_max);
        if( negative_actual_length == NULL)
        {
            fprintf(stderr, "Failed to resize negative_actual_length\n");
            clean_up();
            exit(MEM_ALLOC);
        }
        negative_allocated_length = realloc(negative_allocated_length, sizeof(usize) * new_max);
        if(negative_allocated_length == NULL)
        {
            fprintf(stderr, "Failed to resize negative_allocated_length\n");
            clean_up();
            exit(MEM_ALLOC);
        }
        for(usize i = board_left_border ; i<new_max; i++)
        {
            negative_board[i] = NULL;
            negative_actual_length[i] = 0;
            negative_allocated_length[i] = 0;
        }
        board_left_border = new_max;
    }
}

void column_init(int column)
{
    if(column >=0)
    {
        //work in positive board.
        if((usize) column >= board_right_border)
        {
            board_enlarge(1, column + 10);
        }
        positive_board[column] = malloc(sizeof(int) * MIN_VEC_SIZE);
        if(positive_board[column] == NULL)
        {
            fprintf(stderr, "Failed to initialize column with id %i\n", column);
            clean_up();
            exit(MEM_ALLOC);
        }
        positive_allocated_length[column] = MIN_VEC_SIZE;
    }
    else {
        //handle negative board
        column = column * -1;
        column = column -1;
        if((usize) column +1 > board_left_border)
        {
            board_enlarge(0, column + 10);
        }
        negative_board[column] = malloc(sizeof(int) * MIN_VEC_SIZE);
        if(negative_board[column] == NULL)
        {
            fprintf(stderr, "Failed to initialize column with id %i\n", column);
            clean_up();
            exit(MEM_ALLOC);
        }
        negative_allocated_length[column] = MIN_VEC_SIZE;
    }
}

void enlarge_column(int column)
{
    if(column >= 0)
    {
        usize current_size = positive_allocated_length[column];
//        usize new_size = current_size + ADD_VEC_SIZE;
        usize new_size = current_size + (current_size / 2);
        positive_board[column] = realloc(positive_board[column], sizeof(int) * new_size);
        if(positive_board[column] == NULL)
        {
            fprintf(stderr, "Failed to resize column %i from %lli to %lli\n", column, current_size, new_size);
            clean_up();
            exit(MEM_ALLOC);
        }
        positive_allocated_length[column] = new_size;
    }
    else
    {
        int real_column = column;
        column = column * -1;
        column = column - 1;
        usize current_size = negative_allocated_length[column];
//        usize new_size = current_size + ADD_VEC_SIZE;
        usize new_size = current_size + (current_size/2);
        negative_board[column] = realloc(negative_board[column], sizeof(int) * new_size);
        if(negative_board[column] == NULL)
        {
            fprintf(stderr, "Failed to resize column %i from %lli to %lli\n", real_column, current_size, new_size);
            clean_up();
            exit(MEM_ALLOC);
        }
        negative_allocated_length[column] = new_size;
    }
}

usize add_stone(int column, int color)
{
    if(column >= 0)
    {
        if((usize) column >= board_right_border)
        {
            column_init(column);
        }
        else if(positive_board[column]==NULL)
        {
            column_init(column);
        }
        if(positive_actual_length[column] + 1 >= positive_allocated_length[column])
        {
            enlarge_column(column);
        }
        positive_board[column][positive_actual_length[column]] = color;
        positive_actual_length[column] += 1;
        return positive_actual_length[column]-1;
    }
    else
    {
        int real_column = column;
        column = column * -1;
        column = column -1; //negative_board[0] refers to -1 on the board.
        if((usize) column >= board_left_border)
        {
            column_init(real_column);
        }
        else if(negative_board[column]==NULL)
        {
            column_init(real_column);
        }
        if(negative_actual_length[column] == negative_allocated_length[column] - 1)
        {
            enlarge_column(real_column);
        }
        negative_board[column][negative_actual_length[column]] = color;
        negative_actual_length[column] += 1;
        return negative_actual_length[column] -1 ;
    }
}


int get_color(int column, usize row)
{
    if(column >= 0)
    {
        if(row < 0 || column >= board_right_border /*|| positive_board[column] == NULL*/ || positive_allocated_length[column] <= row || positive_actual_length[column] <= row)
        {
            return -1;
        }
        else
        {
            return positive_board[column][row];
        }
    }
    else
    {
        column = column * -1;
        column = column - 1;
        // search in negative board
        if(row < 0 || column >= board_left_border /*|| negative_board[column] == NULL */||
           negative_allocated_length[column] <= row || negative_actual_length[column] <= row )
        {
            return -1;
        }
        else
        {
            return negative_board[column][row];
        }
    }
}

int local_vertical_search(int column, usize row)
{
    usize counter = 0;
    usize offset = 0;
    int current_color = get_color(column, row);
    if(current_color < 0)
    {
        return 0;
    }
    // go up first.
    while(get_color(column, row + 1) == current_color)
    {
        row ++;
    }
    while(get_color(column, row-offset) == current_color)
    {
        counter ++;
        offset ++;
    }
    if(counter > 3)
    {
        for(usize i=0; i<counter; i++)
        {
            coordinate_list_push(search_results, column, row-i);
        }
        return 1;
    }
    return 0;

}

int local_horizontal_search(int column, usize row)
{
    usize counter = 0;
    int current_color = get_color(column, row);
    if(current_color < 0)
    {
        return 0;
    }
    while(get_color(column - 1, row) == current_color)
    {
        column --;
    }
    while(get_color(column, row) == current_color)
    {
        counter++;
        column++;
    }
    if(counter > 3)
    {
        column = column -1;
        for(usize i=0; i<counter; i++)
        {
            coordinate_list_push(search_results, (usize) column - i, row);
        }
        return 1;
    }
    return 0;
}

int local_diagonal_search_up(int column, usize row)
{
    usize counter = 0;
    int current_color = get_color(column, row);
    if(current_color < 0)
    {
        return 0;
    }
    // go down and left first
    while(get_color(column -1, row -1) == current_color)
    {
        column --;
        row --;
    }
    while(get_color(column, row) == current_color)
    {
        counter ++;
        column ++;
        row ++;
    }
    if(counter > 3)
    {
        column --;
        row --;
        for(usize i=0; i<counter; i++)
        {
            coordinate_list_push(search_results, (usize) column - i, row - i);
        }
        return 1;
    }
    return 0;
}

int local_diagonal_search_down(int column, usize row)
{
    usize counter = 0;
    int current_color = get_color(column, row);
    if(current_color < 0)
    {
        return 0;
    }
    // go up and left first
    while(get_color(column -1, row +1) == current_color)
    {
        column --;
        row ++;
    }
    while(get_color(column, row) == current_color)
    {
        counter ++;
        column ++;
        row --;
    }
    if(counter > 3)
    {
        column --;
        row ++;
        for(usize i=0; i<counter; i++)
        {
            coordinate_list_push(search_results, (usize) column - i, row + i);
        }
        return 1;
    }
    return 0;

}

void delete(int column, usize row)
{
    if(column >= 0)
    {
        positive_board[column][row] = -2;
    }
    else{
        column = column * -1;
        column = column - 1;
        negative_board[column][row] = -2;
    }
}

void vector_close_gaps(int column)
{
    usize i = 0;
    usize counter = 0;

    if(column >= 0){
        if(i >= board_right_border)
        {
            return;
        }
        while(i<positive_allocated_length[column] && i < positive_actual_length[column])
        {
            if(get_color(column, i) < 0)
            {
                counter = 0;
                while(i<positive_actual_length[column] - 1 && get_color(column, i) < 0)
                {
                    counter ++;
                    i ++;
                }
                while(i < positive_actual_length[column] && get_color(column, i) >= 0)
                {
                    positive_board[column][i-counter] = positive_board[column][i];
                    positive_board[column][i] = -2;
                    i++;
                }
                if( i == positive_actual_length[column] -1)
                {
                    break;
                }
                i = i - counter - 1;
            }
            i++;
        }
        usize len = positive_actual_length[column] -1;
        for(usize j = len; j>=0; j--)
        {
            if(positive_board[column][j] < 0)
            {
                positive_actual_length[column]--;
            }
            else{
                break;
            }
        }
        if(positive_actual_length[column] == 0)
        {
            free(positive_board[column]);
            positive_board[column] = NULL;
            positive_allocated_length[column] = 0;
            if(column == board_right_border-1)
            {
                //shift right border left
                int current_column = column;
                while(positive_allocated_length[current_column] == 0 || positive_board[current_column] == NULL)
                {
                    current_column--;
                }
                board_right_border = current_column + 1;
            }
        }
    }
    else
    {
        int real_column = column;
        column = column * -1;
        column = column -1;
        if(column >= board_left_border){
            return;
        }
        while(i<negative_allocated_length[column] && i < negative_actual_length[column])
        {
            if(get_color(real_column, i) < 0)
            {
                counter = 0;
                while(i<negative_actual_length[column] - 1 && get_color(real_column, i) < 0)
                {
                    counter ++;
                    i ++;
                }
                while(i < negative_actual_length[column] && get_color(real_column, i) >= 0)
                {
                    negative_board[column][i-counter] = negative_board[column][i];
                    negative_board[column][i] = -2;
                    i++;
                }
                if( i == negative_actual_length[column] -1)
                {
                    break;
                }
                i = i - counter - 1;
            }
            i++;
        }
        usize len = negative_actual_length[column] -1;
        for(usize j = len; j>=0; j--)
        {
            if(get_color(real_column, j) < 0)
            {
                negative_actual_length[column]--;
            }
            else{
                break;
            }
        }
        if(negative_actual_length[column] == 0)
        {
            free(negative_board[column]);
            negative_board[column] = NULL;
            negative_allocated_length[column] = 0;
            if(column == board_left_border-1)
            {
                //shift right border left
                int current_column = column;
                while(negative_allocated_length[current_column] == 0 || negative_board[current_column] == NULL)
                {
                    current_column--;
                }
                board_left_border = current_column + 1;
            }
        }
    }
}

usize get_column_length(int column)
{
    if(column>=0)
    {
        if(column >= board_right_border)
        {
            return 0;
        }
        if(positive_allocated_length[column] == 0)
        {
            return 0;
        }
        return positive_actual_length[column];
    }
    else{
        column = column * -1;
        column = column -1;
        if(column >= board_left_border)
        {
            return 0;
        }
        if(negative_allocated_length[column] == 0)
        {
            return 0;
        }
        return negative_actual_length[column];
    }
}


usize local_search(int column, usize row)
{
    usize found_lines = 0;
    found_lines += local_vertical_search(column, row);
    found_lines += local_horizontal_search(column, row);
    found_lines += local_diagonal_search_up(column, row);
    found_lines += local_diagonal_search_down(column, row);
    return found_lines;

}


usize column_search(int column)
{
    usize found_lines = 0;
    if(get_column_length(column) < 4)
    {
        return 0;
    }
    int current_color = get_color(column, 0);
    usize counter = 0;
    for(usize row = 0; row<get_column_length(column); row++)
    {
        if(get_color(column, row) != current_color){
            if(counter > 3)
            {
                found_lines ++;
                for( usize i = 0; i < counter; i++ )
                {
                    coordinate_list_push(search_results, column, row - i -1);
                }
            }
            counter = 1;
            current_color = get_color(column, row);
        }
        else{
            counter ++;
        }
    }
    if(counter > 3)
    {
        found_lines ++;
        for( usize i = 0; i < counter; i++ )
        {
            coordinate_list_push(search_results, column, get_column_length(column) - i - 1);
        }
    }
    return found_lines;
}

usize global_search()
{
    usize found_lines = 0;
    for(int col_id = (board_left_border +1) * -1; col_id <= board_right_border; col_id++ )
    {
        usize current_length = get_column_length(col_id) -1;
        //usize current_length = 0;
        for(usize row_id = current_length; row_id >= 0; row_id--)
        {
            found_lines += local_horizontal_search(col_id, row_id);
            found_lines += local_diagonal_search_down(col_id, row_id);
            found_lines += local_diagonal_search_up(col_id, row_id);
        }
        found_lines += column_search(col_id);

    }
    return found_lines;
}

void search_and_delete(int column, usize row, int local)
{
    if(search_results == NULL)
    {
        search_results = coordinate_list_init();
    }
    if(vectors_to_shorten == NULL)
    {
        vectors_to_shorten = coordinate_list_init();
    }
    usize found_lines = 0;
    if(local == 1)
    {
        found_lines += local_search(column, row);
    }
    else
    {
        found_lines += global_search();
    }

    while(found_lines > 0)
    {
        for(usize i = 0; i<search_results->length; i++)
        {
            delete(search_results->elements[i]->x, search_results->elements[i]->y);
            coordinate_list_push(vectors_to_shorten, search_results->elements[i]->x, 0);
        }
        for(usize i = 0; i<vectors_to_shorten->length; i++)
        {
            vector_close_gaps(vectors_to_shorten->elements[i]->x);
        }
        if(search_results != NULL)
        {
            coordinate_list_destroy(search_results);
            search_results = NULL;
            search_results = coordinate_list_init();
        }
        if(vectors_to_shorten != NULL)
        {
            coordinate_list_destroy(vectors_to_shorten);
            vectors_to_shorten = NULL;
            vectors_to_shorten = coordinate_list_init();
        }
        found_lines = 0;
        // TODO search globally until nothing new found...
        found_lines += global_search();
    }
    if(search_results != NULL)
    {
        coordinate_list_destroy(search_results);
        search_results = NULL;
    }
    if(vectors_to_shorten != NULL)
    {
        coordinate_list_destroy(vectors_to_shorten);
        vectors_to_shorten = NULL;
    }
}

int main()
{
    signal(SIGINT, handle_SIGINT);
    signal(SIGSEGV, handle_SEGFAULT);

    board_init();
    unsigned long long int current_line_index = 1;
    // read input
    int color, column;
    while( 1 )
    {
        color = read_color(current_line_index);
        if( color == -1 )
        {
            //reached end of file/input
            break;
        }

        column = read_column_id(current_line_index);
        current_line_index++;
        if(color < 0)
        {
            fprintf(stderr, "Trying to add a negative color\n");
            clean_up();
            exit(INVALID_COLOR);
        }
        usize row = add_stone(column, (int) color);
        if(row)
        {
            row = row;
        }
        search_and_delete(column, row, 1);
    }
    //search_and_delete(0,0,0);
    print_board();
    clean_up();
    return 0;
}
