#include<stdio.h>
#include<stdlib.h>

int** array = NULL;
int X = 0;

void readInput();
void add(int color, int x);
void removePairs();
int findPair();
void moveDown();
void removeUnusedSpace();
void printOutput();
void deallocate();

void readInput()
{
	int color, x, success;
	while (1)
	{
		success = scanf("%d%d", &color, &x);
		if (success != 2)
		{
			if (success == -1)
			{
				break;
			}
			if (success == 0)
			{
				fprintf(stderr, "Error while reading color number.\n");
			}
			if (success == 1)
			{
				fprintf(stderr, "Error while reading column number.\n");
			}
			deallocate();
			exit(1);
		}
		if (color < 0 || color > 254)
		{
			fprintf(stderr, "Error: color number out of range.\n");
			deallocate();
			exit(1);
		}
		add(color, x);
		removePairs();
	}
}

void add(int color, int x)
{
	for (int i = 0; i < X; i++)
	{
		if (array[i][0] == x)
		{
			int* temp = array[i];
			array[i] = (int*)calloc(2 + temp[1] + 1, sizeof(int));
			for (int j = 0; j < 2 + temp[1]; j++)
			{
				array[i][j] = temp[j];
			}
			array[i][2 + temp[1]] = color;
			array[i][1]++;
			free(temp);
			return;
		}
	}
	int**temp = array;
	array = (int**)calloc(++X, sizeof(int*));
	for (int i = 0; i < X; i++)
	{
		if (i < X - 1 && temp[i][0] < x)
		{
			array[i] = temp[i];
		}
		else
		{
			array[i] = (int*)calloc(3, sizeof(int));
			array[i][0] = x;
			array[i][1] = 1;
			array[i][2] = color;
			while (++i < X)
			{
				array[i] = temp[i - 1];
			}
			break;
		}
	}
	if (temp != NULL)
	{
		free(temp);
	}
}

void removePairs()
{
	while (findPair() != 0)
	{
		moveDown();
	}
	removeUnusedSpace();
}

int findPair()
{
	int pair = 0;
	for (int x = 0; x < X - 3; x++)
	{
		for (int y = 2; y < 2 + array[x][1]; y++)
		{
			if (array[x][0] == array[x + 1][0] - 1 && array[x][0] == array[x + 2][0] - 2 && array[x][0] == array[x + 3][0] - 3)
			{
				if (y < 2 + array[x + 1][1] && y < 2 + array[x + 2][1] && y < 2 + array[x + 3][1])
				{
					if (array[x][y] % 1000 == array[x + 1][y] % 1000 && array[x][y] % 1000 == array[x + 2][y] % 1000 && array[x][y] % 1000 == array[x + 3][y] % 1000)
					{
						array[x][y] = array[x + 1][y] = array[x + 2][y] = array[x + 3][y] = array[x][y] + 1000;
						pair = 1;
					}
				}
			}
		}
	}
	for (int x = 0; x < X; x++)
	{
		for (int y = 2; y < 2 + array[x][1] - 3; y++)
		{
			if (array[x][y] % 1000 == array[x][y + 1] % 1000 && array[x][y] % 1000 == array[x][y + 2] % 1000 && array[x][y] % 1000 == array[x][y + 3] % 1000)
			{
				array[x][y] = array[x][y + 1] = array[x][y + 2] = array[x][y + 3] = array[x][y] + 1000;
				pair = 1;
			}
		}
	}
	for (int x = 0; x < X - 3; x++)
	{
		for (int y = 0; y < 2 + array[x][1]; y++)
		{
			if (array[x][0] == array[x + 1][0] - 1 && array[x][0] == array[x + 2][0] - 2 && array[x][0] == array[x + 3][0] - 3)
			{
				if (y + 1 < 2 + array[x + 1][1] && y + 2 < 2 + array[x + 2][1] && y + 3 < 2 + array[x + 3][1])
				{
					if (array[x][y] % 1000 == array[x + 1][y + 1] % 1000 && array[x][y] % 1000 == array[x + 2][y + 2] % 1000 && array[x][y] % 1000 == array[x + 3][y + 3] % 1000)
					{
						array[x][y] = array[x + 1][y + 1] = array[x + 2][y + 2] = array[x + 3][y + 3] = array[x][y] + 1000;
						pair = 1;
					}
				}
			}
		}
	}
	for (int x = X - 1; x >= 3; x--)
	{
		for (int y = 0; y < 2 + array[x][1]; y++)
		{
			if (array[x][0] == array[x - 1][0] + 1 && array[x][0] == array[x - 2][0] + 2 && array[x][0] == array[x - 3][0] + 3)
			{
				if (y + 1 < 2 + array[x - 1][1] && y + 2 < 2 + array[x - 2][1] && y + 3 < 2 + array[x - 3][1])
				{
					if (array[x][y] % 1000 == array[x - 1][y + 1] % 1000 && array[x][y] % 1000 == array[x - 2][y + 2] % 1000 && array[x][y] % 1000 == array[x - 3][y + 3] % 1000)
					{
						array[x][y] = array[x - 1][y + 1] = array[x - 2][y + 2] = array[x - 3][y + 3] = array[x][y] + 1000;
						pair = 1;
					}
				}
			}
		}
	}
	return pair;
}

void moveDown()
{
	for (int x = 0; x < X; x++)
	{
		int z = 2;
		for (int y = 2; y < 2 + array[x][1]; y++)
		{
			if (array[x][y] < 1000)
			{
			    array[x][z] = array[x][y];
			    z++;
			}
		}
		array[x][1] = z - 2;
	}
}

void removeUnusedSpace()
{
	int x = 0;
	for (int i = 0; i < X; i++)
	{
		if (array[i][1] > 0)
		{
			x++;
		}
	}
	if (x == 0)
	{
		deallocate();
		return;
	}
	X = x;
	int** temp = array;
	array = (int**)calloc(X, sizeof(int*));
	for (int i = 0, x = 0; x < X; i++)
	{
		if (temp[i][1] > 0)
		{
			array[x] = (int*)calloc(2 + temp[i][1], sizeof(int));
			for (int j = 0; j < 2 + temp[i][1]; j++)
			{
				array[x][j] = temp[i][j];
			}
			x++;
		}
		free(temp[i]);
	}
	if (temp != NULL)
	{
		free(temp);
	}
}

void printOutput()
{
	if (X == 0) return;
	for (int i = 0; i < X - 1; i++)
	{
		int min_idx = i;
		for (int j = i + 1; j < X; j++)
		{
			if (abs(array[j][0]) < abs(array[min_idx][0]))
			{
				min_idx = j;
			}
		}
		int* temp = array[min_idx];
		array[min_idx] = array[i];
		array[i] = temp;
	}
	for (int c = 0; c < 255; c++)
	{
		for (int i = 0; i < X; i++)
		{
			if (array[i][0] >= 0 || i == X - 1 || array[i][0] != array[i+1][0])
			{
				for (int j = 2; j < 2 + array[i][1]; j++)
				{
					if (array[i][j] == c)
						printf("%d %d %d\n", array[i][j], array[i][0], j - 2);
				}
			}
			else
			{
				for (int j = 2, k = 2; j < 2 + array[i][1] || k < 2 + array[i + 1][1]; j++, k++)
				{
					if (j < 2 + array[i][1] && array[i][j] == c)
						printf("%d %d %d\n", array[i][j], array[i][0], j - 2);
					if (k < 2 + array[i + 1][1] && array[i + 1][k] == c)
						printf("%d %d %d\n", array[i + 1][k], array[i + 1][0], k - 2);
				}
				i++;
			}
		}
	}
}

void deallocate()
{
	if (X > 0)
	{
		for (int i = 0; i < X; i++)
		{
			free(array[i]);
		}
		free(array);
	}
	array = NULL;
	X = 0;
}

int main()
{
	readInput();
	printOutput();
	deallocate();
	return 0;
}
