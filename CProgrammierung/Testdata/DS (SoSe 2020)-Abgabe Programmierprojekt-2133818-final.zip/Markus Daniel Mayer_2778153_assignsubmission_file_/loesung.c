#define  _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
//Dies ist noch nicht meine Finale abgabe.
//Ich wollte nur mal schon etwas hochladen, da ich gerade mit 4 fehlern nicht weiterkomme.

//Fehler nummer 1:
//Bei reallocX bekomme ich eine invalid new size

//Fehler nummer 2:
//Bei reallocY bekomme ich eine invalid old size

//Fehler nummer 3:
//Bei in dem spielfeld habe ich in meiner matrix an stelle field[0][0] eine zufällige zahl, obwohl ich mit calloc arbeite

//Fehler nummer 4:
//er bricht ab mit double free or corruption out ab nachdem das erste free() ausgeführt wird


//Ich weiß im moment nicht weiter, vieleicht können sie mir einen Hinweis geben was ich falsch mache
//Bisher gebe ich noch farbe und spalte über die kommandozeile ein, und einfach ein enter wenn ich das spielfeld ausgegeben haben möchte.
//MfG Markus Mayer


// Representation vom Spielfeld:
// [x][y]
// x Werte = [0, -1, 1, -2, 2, -3, 3, ...usw]
// y Werte = [0, 1, 2, 3, 4, ...usw]

int fieldX; 
int fieldY; 
int** field;


int enlargeX(int new_x) {
    printf("enlarge x \n");
    field = (int **)realloc(field, sizeof(int)*(new_x));
    if (field == NULL) {
        return 1;
    }
    for (int i = fieldX; i <= new_x; i++) {
        field[i] = (int *)calloc(fieldY, sizeof(int));
        if (field[i] == NULL){
            return 1;
        }
    }
    fieldX = new_x;
    return 0;
}

int enlargeY(int new_y) {
    printf("enlarge y \n");
    for (int i = 0; i<= 2 * fieldX; i++) {
        printf("%d", i);
        field[i] = (int *)realloc(field[i], sizeof(int)*new_y+1);
        if (field[i] == NULL){
            return 1;
        }
    }
    fieldY = new_y;
    return 0;
}

int insert(int column, int color) {
    int ret;
    printf("insert startet \n");
    if (column > fieldX) {
        printf("column greater than before \n");
        ret = enlargeX( column);
        if (ret) {
            return ret;
        }
        printf("enlarge done\n");
    }
    while (1) {
        for (int j = 0; j < fieldY; j++) {
            printf("if\n");
            if (field[column][j] == 0) {
                printf("got so far\n");
                field[column][j] = color;
                printf("insert done\n");
                return 0;
            }
            printf("if done\n");
        }
        ret = enlargeY(fieldY * 2);
        if (ret) {
            return ret;
        }
    }
}

int slide() {
    for (int i = 0; i <= fieldX; i++) {
        for (int j = 0; j < fieldY; j++) {
            if (field[i][j] <= 0) { //hier werden die negativen, und damit die die "zerstört" wurden, auch gleich gelöscht
                for (int k = j; k < fieldY; k++) {
                    if(k+1 == fieldY) {
                        field[i][k] = 0;
                    } else {
                        field[i][k] = field[i][k+1];
                    }
                }
            }
        }
    }
    return 0;
}

int connect4() {
    int ret = 2;
    //idea: Gehe durch alle felder durch und suche die viererketten. bei match schreibe alle auf -farbwert
    //return 2 wenn keine gefunden
    //return 1 wenn fehler

    //vertikal
    for (int i = 0; i <= fieldX; i++) {
        for (int j = 0; j < fieldY - 4; j++) {
            if ((((abs(field[i][j]) == abs(field[i][j+1]))
                  == abs(field[i][j+2])) == abs(field[i][j+3])) != 0) {
                ret = 0;
                for (int k = 0; k < 4; k++) {
                    if (field[i][j + k] > 0) {
                        field[i][j + k] = field[i][j + k] * -1;
                    }
                }
            }
        }
    }

    //horizontal
    for (int j = 0; j < fieldY; j++) {
        //-3;-2;-1;0
        if (abs(field[5][j]) == abs(field[3][j]) && abs(field[1][j]) == abs(field[0][j]) && abs(field[5][j]) == abs(field[1][j]) && abs(field[5][j]) != 0) {
            ret = 0;
            if (field[5][j] > 0) {
                field[5][j] = field[5][j] * -1;
            }
            if (field[3][j] > 0) {
                field[3][j] = field[3][j] * -1;
            }
            if (field[1][j] > 0) {
                field[1][j] = field[1][j] * -1;
            }
            if (field[0][j] > 0) {
                field[0][j] = field[0][j] * -1;
            }
        }
        //-2;-1;0;1
        if (abs(field[3][j]) == abs(field[1][j]) && abs(field[0][j]) == abs(field[2][j]) && abs(field[3][j]) == abs(field[0][j]) && abs(field[3][j]) != 0) {
            ret = 0;
            if (field[3][j] > 0) {
                field[3][j] = field[3][j] * -1;
            }
            if (field[1][j] > 0) {
                field[1][j] = field[1][j] * -1;
            }
            if (field[0][j] > 0) {
                field[0][j] = field[0][j] * -1;
            }
            if (field[2][j] > 0) {
                field[2][j] = field[2][j] * -1;
            }
        }
        //-1;0;1;2
        if (abs(field[1][j]) == abs(field[0][j]) && abs(field[2][j]) == abs(field[4][j]) && abs(field[1][j]) == abs(field[2][j]) && abs(field[1][j]) != 0) {
            ret = 0;
            if (field[1][j] > 0) {
                field[1][j] = field[1][j] * -1;
            }
            if (field[0][j] > 0) {
                field[0][j] = field[0][j] * -1;
            }
            if (field[2][j] > 0) {
                field[2][j] = field[2][j] * -1;
            }
            if (field[4][j] > 0) {
                field[4][j] = field[4][j] * -1;
            }
        }
        //0;1;2;3
        if (abs(field[0][j]) == abs(field[2][j]) && abs(field[4][j]) == abs(field[6][j]) && abs(field[0][j]) == abs(field[4][j]) && abs(field[0][j]) != 0) {
            ret = 0;
            if (field[0][j] > 0) {
                field[0][j] = field[0][j] * -1;
            }
            if (field[2][j] > 0) {
                field[2][j] = field[2][j] * -1;
            }
            if (field[4][j] > 0) {
                field[4][j] = field[4][j] * -1;
            }
            if (field[6][j] > 0) {
                field[6][j] = field[6][j] * -1;
            }
        }
        //rest
        for (int k = 1; k <= (fieldX/2) - 3; k++) {
            if (abs(field[2*k][j]) == abs(field[2*(k+1)][j]) && abs(field[2*(k+2)][j]) == abs(field[2*(k+3)][j]) && abs(field[2*k][j]) == abs(field[2*(k+2)][j]) && abs(field[2*k][j]) != 0) {
                ret = 0;
                if (field[2*k][j] > 0) {
                    field[2*k][j] = field[2*k][j] * -1;
                }
                if (field[2*(k+1)][j] > 0) {
                    field[2*(k+1)][j] = field[2*(k+1)][j] * -1;
                }
                if (field[2*(k+2)][j] > 0) {
                    field[2*(k+2)][j] = field[2*(k+2)][j] * -1;
                }
                if (field[2*(k+3)][j] > 0) {
                    field[2*(k+3)][j] = field[2*(k+3)][j] * -1;
                }
            }
            if (abs(field[2*k-1][j]) == abs(field[2*(k+1)-1][j]) && abs(field[2*(k+2)-1][j]) == abs(field[2*(k+3)-1][j]) && abs(field[2*k-1][j]) == abs(field[2*(k+2)-1][j]) && abs(field[2*k-1][j]) != 0) {
                ret = 0;
                if (field[2*k-1][j] > 0) {
                    field[2*k-1][j] = field[2*k-1][j] * -1;
                }
                if (field[2*(k+1)-1][j] > 0) {
                    field[2*(k+1)-1][j] = field[2*(k+1)-1][j] * -1;
                }
                if (field[2*(k+2)-1][j] > 0) {
                    field[2*(k+2)-1][j] = field[2*(k+2)-1][j] * -1;
                }
                if (field[2*(k+3)-1][j] > 0) {
                    field[2*(k+3)-1][j] = field[2*(k+3)-1][j] * -1;
                }
            }
        }
    }

    //diagonal hoch
    for (int j = 0; j < fieldY - 3; j++) {
        //-3;-2;-1;0
        if (abs(field[5][j]) == abs(field[3][j+1]) && abs(field[1][j]+2) == abs(field[0][j+3]) && abs(field[5][j]) == abs(field[1][j+2]) && abs(field[5][j]) != 0) {
            ret = 0;
            if (field[5][j] > 0) {
                field[5][j] = field[5][j] * -1;
            }
            if (field[3][j+1] > 0) {
                field[3][j+1] = field[3][j+1] * -1;
            }
            if (field[1][j+2] > 0) {
                field[1][j+2] = field[1][j+2] * -1;
            }
            if (field[0][j+3] > 0) {
                field[0][j+3] = field[0][j+3] * -1;
            }
        }
        //-2;-1;0;1
        if (abs(field[3][j]) == abs(field[1][j+1]) && abs(field[0][j+2]) == abs(field[2][j+3]) && abs(field[3][j]) == abs(field[0][j+2]) && abs(field[3][j]) != 0) {
            ret = 0;
            if (field[3][j] > 0) {
                field[3][j] = field[3][j] * -1;
            }
            if (field[1][j+1] > 0) {
                field[1][j+1] = field[1][j+1] * -1;
            }
            if (field[0][j+2] > 0) {
                field[0][j+2] = field[0][j+2] * -1;
            }
            if (field[2][j+3] > 0) {
                field[2][j+3] = field[2][j+3] * -1;
            }
        }
        //-1;0;1;2
        if (abs(field[1][j]) == abs(field[0][j+1]) && abs(field[2][j+2]) == abs(field[4][j+3]) && abs(field[1][j]) == abs(field[2][j+2]) && abs(field[1][j]) != 0) {
            ret = 0;
            if (field[1][j] > 0) {
                field[1][j] = field[1][j] * -1;
            }
            if (field[0][j+1] > 0) {
                field[0][j+1] = field[0][j+1] * -1;
            }
            if (field[2][j+2] > 0) {
                field[2][j+2] = field[2][j+2] * -1;
            }
            if (field[4][j+3] > 0) {
                field[4][j+3] = field[4][j+3] * -1;
            }
        }
        //0;1;2;3
        if (abs(field[0][j]) == abs(field[2][j+1]) && abs(field[4][j+2]) == abs(field[6][j+3]) && abs(field[0][j]) == abs(field[4][j+2]) && abs(field[0][j]) != 0) {
            ret = 0;
            if (field[0][j] > 0) {
                field[0][j] = field[0][j] * -1;
            }
            if (field[2][j+1] > 0) {
                field[2][j+1] = field[2][j+1] * -1;
            }
            if (field[4][j+2] > 0) {
                field[4][j+2] = field[4][j+2] * -1;
            }
            if (field[6][j+3] > 0) {
                field[6][j+3] = field[6][j+3] * -1;
            }
        }
        //rest
        for (int k = 1; k <= (fieldX/2) - 3; k++) {
            if (abs(field[2*k][j]) == abs(field[2*(k+1)][j+1]) && abs(field[2*(k+2)][j+2]) == abs(field[2*(k+3)][j+3]) && abs(field[2*k][j]) == abs(field[2*(k+2)][j+2]) && abs(field[2*k][j]) != 0) {
                ret = 0;
                if (field[2*k][j] > 0) {
                    field[2*k][j] = field[2*k][j] * -1;
                }
                if (field[2*(k+1)][j+1] > 0) {
                    field[2*(k+1)][j+1] = field[2*(k+1)][j+1] * -1;
                }
                if (field[2*(k+2)][j+2] > 0) {
                    field[2*(k+2)][j+2] = field[2*(k+2)][j+2] * -1;
                }
                if (field[2*(k+3)][j+3] > 0) {
                    field[2*(k+3)][j+3] = field[2*(k+3)][j+3] * -1;
                }
            }
            if (abs(field[2*k-1][j]) == abs(field[2*(k+1)-1][j+1]) && abs(field[2*(k+2)-1][j+2]) == abs(field[2*(k+3)-1][j+3]) && abs(field[2*k-1][j]) == abs(field[2*(k+2)-1][j+2]) && abs(field[2*k-1][j]) != 0) {
                ret = 0;
                if (field[2*k-1][j] > 0) {
                    field[2*k-1][j] = field[2*k-1][j] * -1;
                }
                if (field[2*(k+1)-1][j+1] > 0) {
                    field[2*(k+1)-1][j+1] = field[2*(k+1)-1][j+1] * -1;
                }
                if (field[2*(k+2)-1][j+2] > 0) {
                    field[2*(k+2)-1][j+2] = field[2*(k+2)-1][j+2] * -1;
                }
                if (field[2*(k+3)-1][j+3] > 0) {
                    field[2*(k+3)-1][j+3] = field[2*(k+3)-1][j+3] * -1;
                }
            }
        }
    }

    //diagonal runter
    for (int j = 0; j < fieldY -3; j++) {
        //-3;-2;-1;0
        if (abs(field[5][j]) == abs(field[3][j-1]) && abs(field[1][j-2]) == abs(field[0][j-3]) && abs(field[5][j]) == abs(field[1][j-2]) && abs(field[5][j]) != 0) {
            ret = 0;
            if (field[5][j] > 0) {
                field[5][j] = field[5][j] * -1;
            }
            if (field[3][j-1] > 0) {
                field[3][j-1] = field[3][j-1] * -1;
            }
            if (field[1][j-2] > 0) {
                field[1][j-2] = field[1][j-2] * -1;
            }
            if (field[0][j-3] > 0) {
                field[0][j-3] = field[0][j-3] * -1;
            }
        }
        //-2;-1;0;1
        if (abs(field[3][j]) == abs(field[1][j-1]) && abs(field[0][j-2]) == abs(field[2][j-3]) && abs(field[3][j]) == abs(field[0][j-2]) && abs(field[3][j]) != 0) {
            ret = 0;
            if (field[3][j] > 0) {
                field[3][j] = field[3][j] * -1;
            }
            if (field[1][j-1] > 0) {
                field[1][j-1] = field[1][j-1] * -1;
            }
            if (field[0][j-2] > 0) {
                field[0][j-2] = field[0][j-2] * -1;
            }
            if (field[2][j-3] > 0) {
                field[2][j-3] = field[2][j-3] * -1;
            }
        }
        //-1;0;1;2
        if (abs(field[1][j]) == abs(field[0][j-1]) && abs(field[2][j-2]) == abs(field[4][j-3]) && abs(field[1][j]) == abs(field[2][j-2]) && abs(field[1][j]) != 0) {
            ret = 0;
            if (field[1][j] > 0) {
                field[1][j] = field[1][j] * -1;
            }
            if (field[0][j-1] > 0) {
                field[0][j-1] = field[0][j-1] * -1;
            }
            if (field[2][j-2] > 0) {
                field[2][j-2] = field[2][j-2] * -1;
            }
            if (field[4][j-3] > 0) {
                field[4][j-3] = field[4][j-3] * -1;
            }
        }
        //0;1;2;3
        if (abs(field[0][j]) == abs(field[2][j-1]) && abs(field[4][j-2]) == abs(field[6][j-3]) && abs(field[0][j]) == abs(field[4][j-2]) && abs(field[0][j]) != 0) {
            ret = 0;
            if (field[0][j] > 0) {
                field[0][j] = field[0][j] * -1;
            }
            if (field[2][j-1] > 0) {
                field[2][j-1] = field[2][j-1] * -1;
            }
            if (field[4][j-2] > 0) {
                field[4][j-2] = field[4][j-2] * -1;
            }
            if (field[6][j-3] > 0) {
                field[6][j-3] = field[6][j-3] * -1;
            }
        }
        //rest
        for (int k = 1; k <= (fieldX/2) - 3; k++) {
            if (abs(field[2*k][j]) == abs(field[2*(k+1)][j-1]) && abs(field[2*(k+2)][j-2]) == abs(field[2*(k+3)][j-3]) && abs(field[2*k][j]) == abs(field[2*(k+2)][j-2]) && abs(field[2*k][j]) != 0) {
                ret = 0;
                if (field[2*k][j] > 0) {
                    field[2*k][j] = field[2*k][j] * -1;
                }
                if (field[2*(k+1)][j-1] > 0) {
                    field[2*(k+1)][j-1] = field[2*(k+1)][j-1] * -1;
                }
                if (field[2*(k+2)][j-2] > 0) {
                    field[2*(k+2)][j-2] = field[2*(k+2)][j-2] * -1;
                }
                if (field[2*(k+3)][j-3] > 0) {
                    field[2*(k+3)][j-3] = field[2*(k+3)][j-3] * -1;
                }
            }
            if (abs(field[2*k-1][j]) == abs(field[2*(k+1)-1][j-1]) && abs(field[2*(k+2)-1][j-2]) == abs(field[2*(k+3)-1][j-3]) && abs(field[2*k-1][j]) == abs(field[2*(k+2)-1][j-2]) && abs(field[2*k-1][j]) != 0) {
                ret = 0;
                if (field[2*k-1][j] > 0) {
                    field[2*k-1][j] = field[2*k-1][j] * -1;
                }
                if (field[2*(k+1)-1][j-1] > 0) {
                    field[2*(k+1)-1][j-1] = field[2*(k+1)-1][j-1] * -1;
                }
                if (field[2*(k+2)-1][j-2] > 0) {
                    field[2*(k+2)-1][j-2] = field[2*(k+2)-1][j-2] * -1;
                }
                if (field[2*(k+3)-1][j-3] > 0) {
                    field[2*(k+3)-1][j-3] = field[2*(k+3)-1][j-3] * -1;
                }
            }
        }
    }

    return ret;
}

int game_round(int column, int color) {
    int ret;
    printf("insert %d %d \n", column, color);
    ret = insert( column, color);
    if (ret) {
        return ret;
    }
    while (ret != 2) {
        printf("now slide \n");
        ret = slide();
        printf("slide done\n");
        if (ret) {
            return ret;
        }
        printf("connect \n");
        ret = connect4();
        printf("connect done \n");
        if (ret == 1) {
            return 1;
        }
    }
    return 0;
}

void print_field() {
    for (int j = fieldY - 1; j >= 0; j--) {
        for (int i = 0; i <= fieldX; i++) {
            printf(" | %d", field[i][j]);
        }
        printf(" |\n");
    }
}

void delete() {
    for (int i = 0; i < fieldX; i++) {
        printf("free %d \n", i);
        free(field[i]);
    }
    print_field("free x\n");
    free(field);
}

int main() {

    //init game board one
    fieldX = 8; // x muss mind 8 sein.
    fieldY = 4; // y muss mind 4 sein.
    field = (int **)calloc(fieldX + 1, sizeof(int));
    if (field == NULL){
        return 1;
    }
    for (int i = 0; i <= fieldX; i++) {
        field[i] = (int *)calloc(fieldY, sizeof(int));
        if (field[i] == NULL){
            return 1;
        }
    }

    //do stuff
    char *line = NULL;
    size_t len = 0;
    int color, column;
    int eof = 0;
    while (!eof) {
        getline(&line, &len, stdin); //beinhaltet malloc für line
        if (sscanf(line, "%d %d", &color, &column) == 2) {
            if (column < 0) {
                game_round(column* -2 -1, color);
            } else {
                game_round(column * 2, color);
            }
        } else {
            eof=1;
        }
        free(line);
    }
    print_field();

    //free stuff
    delete();
    return 0;
}
