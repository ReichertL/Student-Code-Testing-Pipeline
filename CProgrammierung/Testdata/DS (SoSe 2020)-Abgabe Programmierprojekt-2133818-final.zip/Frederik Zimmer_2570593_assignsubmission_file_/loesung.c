#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
//TODO: delete
#include <time.h>
clock_t t0 = 0, t1 = 0, t2 = 0, t3 = 0;
clock_t sum0 = 0, sum1 = 0, sum2 = 0, sum3 = 0;
long count = 0;

//TODO: change color type from short to uchar

// global structure for playing field
unsigned char** field;
unsigned char** delete_field;
int field_width = 4;
int field_height = 4;

typedef struct stone {
	int x;
	int y;
	struct stone* next;
} stone;
stone* changed_stones = NULL;


//stores the current height of each column
int* top_stone = NULL;

//list of stone to delete
//stone* delete_list = NULL;

void print_field();
int read_line();
void place_stone(unsigned char color, long position);
void add_changed_line(int x, int y);
void find_lines();
//void delete_stones(int x, int y, int length);
void delete_stone(int x, int y);
int sift_down();
void debug_print_field();

int main() {
	if ((field = malloc(field_width * sizeof(char*))) == NULL) {
		printf("Allocation error 0.0");
		return 1;
	}
	for (int i = 0; i < field_width; i++) {
		if ((field[i] = malloc(field_height * sizeof(char))) == NULL) {
			printf("Allocation error 1");
			return 1;
		}
		memset(field[i], 255, field_height * sizeof(char));
	}

	if ((delete_field = malloc(field_width * sizeof(char*))) == NULL) {
		printf("Allocation error 0.1");
		return 1;
	}
	for (int i = 0; i < field_width; i++) {
		if ((delete_field[i] = malloc(field_height * sizeof(char))) == NULL) {
			printf("Allocation error 1.1");
			return 1;
		}
		memset(delete_field[i], 0, field_height * sizeof(char));
	}

	if ((top_stone = malloc(field_width * sizeof(int))) == NULL) {
		printf("Allocation error 2");
		return 1;
	}
	//TODO?
	for (int i = 0; i < field_width; i++) {
		top_stone[i] = 0;
	}
	while (!read_line()) {
		do {
			t1 = clock();
			find_lines();
			sum1 += clock() - t1;
		} while (sift_down());
		if ((count % 10000) == 0) {
			//printf("%d. steps took:(finding lines) %d, from that (deletion): %d, from that (memcpy/for-loop/memset): %d, (sifting down) %d\n", count, sum1, sum0, sum3, sum2);
			sum0 = sum1 = sum2 = sum3 = 0;
		}
		count++;
		//debug_print_field();
	}
	print_field();
	//debug_print_field();
	return 0;
}

void print_field() {
	for (int x = 0; x < field_width; x++) {
		for (int y = 0; y < field_height; y++) {
			int color = field[x][y];
			if (color != 255) {
				printf("%d %d %d\n", color, x - field_width / 2, y);
			}
		}
	}
}

int read_line() {
	char line[256];
	long c, p;
	if (!fgets(line, sizeof(line), stdin))
	{
		//reading input failed:
		return 1;
	}

	char* endptr;

	errno = 0;
	c = strtol(line, &endptr, 10);
	if (errno == ERANGE) {
		printf("(first)Number too small or too large.\n");
		return 1;
	}
	else if (endptr == line) {
		//TODO: delete all error prints or just this one?
		printf("(first)Nothing was read.\n");
		return 1;
	}

	// read second number after endptr
	p = strtol(endptr, &endptr, 10);
	if (errno == ERANGE) {
		printf("(second)Number too small or too large.\n");
		return 1;
	}
	else if (endptr == line) {
		printf("(second)Nothing was read.\n");
		return 1;
	}
	else if (*endptr && *endptr != '\n') {
		printf("Wrong formatted line.\n");
		return 1;
	}
	//printf("First number:%d, second number:%d\n", c, p);

	//checking numbers:
	if (c < 0 || c > 254) {
		printf("not in color range\n");
		return 1;
	}
	place_stone((unsigned char)c, p);

	return 0;
}

void place_stone(unsigned char color, long position) {
	int offset = field_width / 2;
	if (position > offset - 1 || position < -offset) {
		//TODO: (+change width of first_changed)
		//reallocate the field
		int new_width = 2 * field_width;
		int new_offset = field_width;
		while (position > new_offset - 1 || position < -new_offset) {
			new_width *= 2;
			new_offset *= 2;
		}
		void** temp = malloc(new_width * sizeof(char*));
		if (!temp) {
			printf("Reallocation error: 0.0");
			//TODO:?
			exit(1);
		}
		memcpy((char**)temp + new_offset - offset, field, field_width * sizeof(char*));
		free(field);
		field = (unsigned char**)temp;
		for (int i = 0; i < (new_offset - offset); i++) {
			//set columns on the positive side
			if ((field[i] = malloc(field_height * sizeof(char))) == NULL) {
				printf("Reallocation error: 0.1");
				exit(1);
			}
			memset(field[i], 255, field_height * sizeof(char));
			//set columns on the negative side
			if ((field[new_width - i - 1] = malloc(field_height * sizeof(char))) == NULL) {
				printf("Reallocation error: 0.1");
				exit(1);
			}
			memset(field[new_width - i - 1], 255, field_height * sizeof(char));
		}

		//readjust top_stone
		temp = malloc(new_width * sizeof(int));
		if (temp == NULL) {
			printf("Reallocation error: 0.2");
			//TODO:?
			exit(1);
		}
		for (int i = 0; i < (new_offset - offset); i++) {
			//*(((int*)temp)+i) = -1;
			((int*)temp)[i] = 0;
			((int*)temp)[new_width - i - 1] = 0;
		}
		memcpy((int*)temp + new_offset - offset, top_stone, field_width * sizeof(int));
		free(top_stone);
		top_stone = (int*)temp;

		//readjust delete_field
		if ((temp = realloc(delete_field, new_width * sizeof(char*))) == NULL) {
			printf("Reallocation error 0.3");
			exit(1);
		}
		for (int i = field_width; i < new_width; i++) {
			if ((temp[i] = malloc(field_height * sizeof(char))) == NULL) {
				printf("Allocation error 1");
				exit(1);
			}
			memset(temp[i], 0, field_height * sizeof(char));
		}
		delete_field = (unsigned char**)temp;

		offset = new_offset;
		field_width = new_width;
	}
	int x = position + offset;

	int t = (top_stone[x])++;
	if (t == field_height) {
		//reallocate the columns
		field_height *= 2;
		for (int x = 0; x < field_width; x++) {
			void* temp = realloc(field[x], field_height * sizeof(char));
			if (temp == NULL) {
				printf("Reallocation error: 1.0");
				//TODO?
				exit(1);
			}
			field[x] = temp;

			temp = realloc(delete_field[x], field_height * sizeof(char));
			if (temp == NULL) {
				printf("Reallocation error: 1.1");
				//TODO?
				exit(1);
			}
			delete_field[x] = temp;

			for (int y = t; y < field_height; y++) {
				field[x][y] = 255;
				delete_field[x][y] = 0;
			}
		}
	}
	field[x][t] = color;
	add_changed_line(x, t);
}

void add_changed_line(int x, int y) {
	if (changed_stones) {
		stone* tmp = changed_stones;
		while (1) {
			//do not add entry, if line is already in the list. Only adjust value y
			if (tmp->x == x) {
				if (tmp->y > y) {
					tmp->y = y;
				}
				return;
			}

			if (tmp->next) {
				tmp = tmp->next;
			}
			else {
				break;
			}
		}
		stone* newstone = malloc(sizeof(stone));
		newstone->x = x;
		newstone->y = y;
		newstone->next = NULL;
		//append newstone to the list to remember the changed line
		tmp->next = newstone;
	}else {
		stone* newstone = malloc(sizeof(stone));
		newstone->x = x;
		newstone->y = y;
		newstone->next = NULL;
		changed_stones = newstone;
	}
}
//void add_changed_stone

//TODO: optimization
void find_lines() {
	//using changed lines in this function and clearing the list, lines will be used to track lines with deleted stones (which need to be shifted down)
	stone* clines = changed_stones;
	changed_stones = NULL;

	if (clines) {
		do
		{
			int x = clines->x;
			if (top_stone[x] >= 0) {
				for (int y = clines->y; y < top_stone[x]; y++) {
					//break if highest stone has been checked
					if (field[x][y] == 255) {
						break;
					}

					int up, down, left, left_up, left_down, right, right_up, right_down;
					up = down = left = left_up = left_down = right = right_up = right_down = 0;

					int up_max = (field_height-1 - y) >= 3 ? 3 : (field_height-1 - y);
					int down_max = (y >= 3) ? 3 : y;
					int left_max = (x >= 3) ? 3 : x;
					int right_max = ((field_width - 1 - x) > 3) ? 3 : (field_width - 1 - x);
					//int already_deleted = 0; // keeps track if the stone at (x,y) was already deleted -> in this case it's not necessary to check horizontally

					//check for same-colored stones horizontally and diagonally
					//left
					for (int i = 1; i <= left_max; i++) {
						if (field[x - i][y] == field[x][y]) {
							left++;
						}
						else { break; }
					}
					for (int i = 1; i <= (left_max < up_max ? left_max : up_max); i++) {
						if (field[x - i][y + i] == field[x][y]) {
							left_up++;
						}
						else { break; }
					}
					for (int i = 1; i <= (left_max < down_max ? left_max : down_max); i++) {
						if (field[x - i][y - i] == field[x][y]) {
							left_down++;
						}
						else { break; }
					}
					//right
					for (int i = 1; i <= right_max; i++) {
						if (field[x + i][y] == field[x][y]) {
							right++;
						}
						else { break; }
					}
					for (int i = 1; i <= (right_max < up_max ? right_max : up_max); i++) {
						if (field[x + i][y + i] == field[x][y]) {
							right_up++;
						}
						else { break; }
					}
					for (int i = 1; i <= (right_max < down_max ? right_max : down_max); i++) {
						if (field[x + i][y - i] == field[x][y]) {
							right_down++;
						}
						else { break; }
					}
					//check if there are connected stones and delete them
					if (left + right >= 3) {
						for (int i = -left; i <= right; i++) {
							delete_stone(x + i, y);
							//already_deleted = 1;
						}
					}
					if (left_down + right_up >= 3) {
						for (int i = -left_down; i <= right_up; i++) {
							delete_stone(x + i, y + i);
							//already_deleted = 1;
						}
					}
					if (left_up + right_down >= 3) {
						for (int i = -left_up; i <= right_down; i++) {
							delete_stone(x + i, y - i);
							//already_deleted = 1;
						}
					}

					for (int i = 1; i <= up_max; i++) {
						if (field[x][y + i] == field[x][y]) {
							up++;
						}
						else { break; }
					}
					for (int i = 1; i <= down_max; i++) {
						if (field[x][y - i] == field[x][y]) {
							down++;
						}
						else { break;; }
					}
					if (up + down >= 3) {
						for (int i = -down; i <= up; i++) {
							delete_stone(x, y + i);
						}
					}
					/*
					//check up only if its necessary
					if (new_field[x] != NULL) {
						already_deleted = (new_field[x][y] == 255) || already_deleted;
					}
					if (!already_deleted) {
						for (int i = 1; i <= up_max; i++) {
							if (field[x][y + i] == field[x][y]) {
								up++;
							}
							else { break; }
						}
						for (int i = 1; i <= down_max; i++) {
							if (field[x][y - i] == field[x][y]) {
								down++;
							}
							else { break;; }
						}
						if (up + down >= 3) {
							for (int i = -down; i <= up; i++) {
								delete_stone(x, y + i);
							}
						}
					}
					*/
				}
			}

			stone* tmp = clines;
			clines = clines->next;
			free(tmp);
		} while (clines);
	}
}


void delete_stone(int x, int y) {
	t0 = clock();
	/*
	if (!(delete_field[x])) {
		if ((delete_field[x] = malloc(field_height * sizeof(char))) == NULL) {
			printf("Allocation error: delete_stone()");
			//TODO: return 1;
			return;
		}
		t3 = clock();
		//memcpy(delete_field[x], field[x], field_height);
		
		//for (int y = 0; y < field_height; y++) {
		//	delete_field[x][y] = 0;
		//}
		
		memset(delete_field[x], 0, field_height * sizeof(char));
		sum3 += clock() - t3;
	}
	*/
	delete_field[x][y] = 1;
	//adding to lines (now used for lines with deleted elements)
	//lines should be empty on the first call of delete_stone() (lines got cleared at the start of find_lines()
	//lines can be added more than one time, maybe fix that or change delete_stone() and sift_down() to delete stones in a different way
	add_changed_line(x, y);

	sum0 += clock() - t0;
}
int sift_down() {
	t2 = clock();
	char changed = 0;

	//dlines goes through all lines, which have deleted elements in them
	stone* dlines = changed_stones;

	while (dlines) {
		changed = 1;
		int x = dlines->x;
		int new_y = dlines->y;

		//delete values equal to 255
		for (int y = new_y; y < top_stone[x]; y++) {
			if (!delete_field[x][y]) {
				field[x][new_y] = field[x][y];
				new_y++;
			}
			else
			{
				delete_field[x][y] = 0;
			}
		}
		for (int i = new_y; i < top_stone[x]; i++) {
			field[x][i] = 255;
		}
		top_stone[x] = new_y;

		dlines = dlines->next;
	}

	sum2 += clock() - t2;
	return changed;
}

void debug_print_field() {
	FILE* f = fopen("output.txt", "w");
	if (f == NULL)
	{
		printf("Error opening file!\n");
		exit(1);
	}
	for (int y = field_height - 1; y >= 0; y--) {
		for (int x = 0; x < field_width; x++) {
			fprintf(f, "%3i ", field[x][y]);
		}
		fprintf(f, "\n");
	}
	fprintf(f, "----------------------------------------------\n");
	fclose(f);
	/*
	for (int y = field_height - 1; y >= 0; y--) {
		for (int x = 0; x < field_width; x++) {
			printf("%3i ", field[x][y]);
		}
		printf("\n");
	}
	*/
}