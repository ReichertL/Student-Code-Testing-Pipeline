#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main (void){

    //vorab start

    //Hilfsvariable fuer strtok
    char* haelfte2;

    //Hilfsvariable fuer strtok 
    char* haelfte1;

    //Variable die die Farbe repraesentiert
    int farbe;

    //Variable die die X-Koordinate repraesentiert
    int xko;

    //Groesse zur Erzeugung des Feldes x-Laenge
    int size = 1024;

    //zur Erzeugung des Feldes y-Laenge
    int laenge = 100;

    //Feld fuer positive X-Koordinaten (inkulsive 0)
    int** feld;

    //Feld fuer negative X-Koordinaten
    int** neg;

    //Array dass Fuellstand des positiven Feldes anzeigt
    int *extra;

    //Array dass Fuellstand des negativen Feldes anzeigt
    int *extraneg;

    //Hilfsvariable um Betrag der negativen X-Koordinaten zu brechnen
    int negx;

    //Puffer fuer Input
    char input[100] = "";

    //Array dass X-Koordinate von feld der zu entfernenen Steine speichert
    int* entfernenxpos;

    //Array dass Y-Koordinate von feld der zu entfernenen Steine speichert
    int* entfernenypos;

    //Array dass X-Koordinate von neg der zu entfernenen Steine speichert
    int* entfernenxneg;

    //Array dass Y-Koordinate von neg der zu entfernenen Steine speichert
    int* entfernenyneg;

    //Array dass X-Koordinate von feld der zu entfernenen Steine speichert
    int* entfernenxposzwei;

    //Array dass Y-Koordinate von feld der zu entfernenen Steine speichert
    int* entfernenyposzwei;

    //Array dass X-Koordinate von neg der zu entfernenen Steine speichert
    int* entfernenxnegzwei;

    //Array dass Y-Koordinate von neg der zu entfernenen Steine speichert
    int* entfernenynegzwei;

    //Counter der die Position im pos entfernen Array angibt
    int entfernencounterpos = 0;

    //Counter der die Position im neg entfernen Array angibt
    int entfernencounterneg = 0;

    //Counter der die Position im pos entfernen Array angibt
    int entfernencounterposzwei = 0;

    //Counter der die Position im neg entfernen Array angibt
    int entfernencounternegzwei = 0;

    //Hilfvariable fuer vielseitige Nutzung
    int help;

    //fuer strpbrk benoetigt
    char fehler[] = "!\"#$%&\'()*+,./:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";

    //fuer split benoetigt
    char *marker;

    //Variable, die die loop stoppt, wenn es keine weiteren Aenderungen gibt
    int aenderungen = 0;

    //zaehlt die Durchlaeufe
    int durchlaeufe = 0;

    int* zwischenspeicher;
    int* verw;
    int* verwneg;

    int pos = 0;
    char c;
    int exit = 0;
    int first = 1;
    int count = 0;

    int hitcounterWag = 0;
    int hitcounterSen = 0;
    int hitcounterDiaLR = 0;
    int hitcounterDiaRL = 0;
    int hitcounterWagneg = 0;
    int hitcounterSenneg = 0;
    int hitcounterDiaLRneg = 0;
    int hitcounterDiaRLneg = 0;
    int k = 1;
    int l = 0;

    extra = (int *) malloc((size+1)*sizeof(int));
    extraneg = (int *) malloc((size+1)*sizeof(int));
    verw = (int *) malloc((size+1)*sizeof(int));
    verwneg = (int *) malloc((size+1)*sizeof(int));

    entfernenxpos = (int *) malloc(((size+1)) * sizeof(int));
    entfernenypos = (int *) malloc(((size+1)) * sizeof(int));
    int entfernenposmax = size;
    entfernenxneg = (int *) malloc(((size+1)) * sizeof(int));
    entfernenyneg = (int *) malloc(((size+1)) * sizeof(int));
    int entfernennegmax = size;
    entfernenxposzwei = (int *) malloc(((size+1)) * sizeof(int));
    entfernenyposzwei = (int *) malloc(((size+1)) * sizeof(int));
    int entfernenposmaxzwei = size;
    entfernenxnegzwei = (int *) malloc(((size+1)) * sizeof(int));
    entfernenynegzwei = (int *) malloc(((size+1)) * sizeof(int));
    int entfernennegmaxzwei = size;

    //Ä 
    memset(extra,0,(size+1)*4);
    memset(extraneg,0,(size+1)*4);
    memset(verw,0,(size+1)*4);
    memset(verwneg,0,(size+1)*4);

    feld = (int **)malloc(sizeof(int *)*(size+1));
    neg = (int **)malloc(sizeof(int *)*(size+1));
    for(int i = 0;i < (size+1);i++){
        feld[i] = (int *)malloc(sizeof(int)*(laenge+1));
        neg[i] = (int *)malloc(sizeof(int)*(laenge+1));
        memset(feld[i],-1,(laenge+1)*4);
        memset(neg[i],-1,(laenge+1)*4);
    }

    //vorab ende

    //einlesen start
    while(1){
        //Teil 1
        /*
        if(fgets(input, 100, stdin) == NULL){
            break;
        }
        */
        while(1){
         c = getc(stdin);
         if(c == '\0'){
            free(verwneg);
            free(verw);
            free(entfernenxnegzwei);
            free(entfernenxposzwei);
            free(entfernenynegzwei);
            free(entfernenyposzwei);
            free(entfernenxneg);
            free(entfernenxpos);
            free(entfernenyneg);
            free(entfernenypos);
            free(extra);
            free(extraneg);
            for(int i = 0;i < (size+1);i++){
                free(feld[i]);
                free(neg[i]);
            }
            free(feld);
            free(neg);
            fprintf(stderr,"%s","Zeile enthaelt unzulaessinge Zeichen.\n");
            return 1;
         }
         if(c == EOF || c == '\n'){
            //printf("%s\n",input);
            if(c == EOF && pos == 0 && first == 1){//leere Eingabe
                free(verwneg);
                free(verw);
                free(entfernenxnegzwei);
                free(entfernenxposzwei);
                free(entfernenynegzwei);
                free(entfernenyposzwei);
                free(entfernenxneg);
                free(entfernenxpos);
                free(entfernenyneg);
                free(entfernenypos);
                free(extra);
                free(extraneg);
                for(int i = 0;i < (size+1);i++){
                    free(feld[i]);
                    free(neg[i]);
                }
                free(feld);
                free(neg);
                //printf("Ende\n");
                //fprintf(stderr,"%s","Zeile enthaelt unzulaessinge Zeichen.\n");
                return 1;
            }
            first = 0;
            if(c == EOF && pos == 0){
                exit = 1;
                break;
            }
            if(c == '\n' && pos == 0){//\n an erster Stelle
                free(verwneg);
                free(verw);
                free(entfernenxnegzwei);
                free(entfernenxposzwei);
                free(entfernenynegzwei);
                free(entfernenyposzwei);
                free(entfernenxneg);
                free(entfernenxpos);
                free(entfernenyneg);
                free(entfernenypos);
                free(extra);
                free(extraneg);
                for(int i = 0;i < (size+1);i++){
                    free(feld[i]);
                    free(neg[i]);
                }
                free(feld);
                free(neg);
                fprintf(stderr,"%s","Unzulaessinge Eingabe.\n");
                return 1;
            }
        if(strpbrk(input, fehler) != NULL){
            free(verwneg);
            free(verw);
            free(entfernenxnegzwei);
            free(entfernenxposzwei);
            free(entfernenynegzwei);
            free(entfernenyposzwei);
            free(entfernenxneg);
            free(entfernenxpos);
            free(entfernenyneg);
            free(entfernenypos);
            free(extra);
            free(extraneg);
            for(int i = 0;i < (size+1);i++){
                free(feld[i]);
                free(neg[i]);
            }
            free(feld);
            free(neg);
            fprintf(stderr,"%s","Zeile enthaelt unzulaessinge Zeichen.\n");
            return 1;
            //etwas anderes als Ziffern
        }
        if(strchr(input, ' ') == NULL){
            free(verwneg);
            free(verw);
            free(entfernenxnegzwei);
            free(entfernenxposzwei);
            free(entfernenynegzwei);
            free(entfernenyposzwei);
            free(entfernenxneg);
            free(entfernenxpos);
            free(entfernenyneg);
            free(entfernenypos);
            free(extra);
            free(extraneg);
            for(int i = 0;i < (size+1);i++){
                free(feld[i]);
                free(neg[i]);
            }
            free(feld);
            free(neg);
            fprintf(stderr,"%s","Zeile enthaelt nur eine Zahl.\n");
            return 1;
            //nur eine Zahl
        }

        marker = strchr(input,' ');
        *marker = 'A';
        //printf("Input: %s\n",input);
        haelfte1 = strtok(input,"A");
        haelfte2 = strtok(NULL, "A");
        if(strchr(haelfte2, ' ') != NULL){
            free(verwneg);
            free(verw);
            free(entfernenxnegzwei);
            free(entfernenxposzwei);
            free(entfernenynegzwei);
            free(entfernenyposzwei);
            free(entfernenxneg);
            free(entfernenxpos);
            free(entfernenyneg);
            free(entfernenypos);
            free(extra);
            free(extraneg);
            for(int i = 0;i < (size+1);i++){
                free(feld[i]);
                free(neg[i]);
            }
            free(feld);
            free(neg);
            fprintf(stderr, "%s", "Zeile enthaelt mehr als zwei Zahlen.\n");
            return 1;
            //mehr als 2 Zahlen
        }
        if(strlen(haelfte1) > 4 || strlen(haelfte2) > 8){//3 bzw 7 Stellen plus Vorzeichen
            free(verwneg);
            free(verw);
            free(entfernenxnegzwei);
            free(entfernenxposzwei);
            free(entfernenynegzwei);
            free(entfernenyposzwei);
            free(entfernenxneg);
            free(entfernenxpos);
            free(entfernenyneg);
            free(entfernenypos);
            free(extra);
            free(extraneg);
            for(int i = 0;i < (size+1);i++){
                free(feld[i]);
                free(neg[i]);
            }
            free(feld);
            free(neg);
            fprintf(stderr,"%s","Zeile enthaelt zu große Werte bei Farbe oder x-Koordinate.\n");
            return 1;
        }
        //Teil 2
        farbe = atoi(haelfte1);
        xko = atoi(haelfte2);
        //printf("Farbe: %i, xKo: %i\n",farbe,xko);
        if(farbe < 0 || farbe > 254){
            free(verwneg);
            free(verw);
            free(entfernenxnegzwei);
            free(entfernenxposzwei);
            free(entfernenynegzwei);
            free(entfernenyposzwei);
            free(entfernenxneg);
            free(entfernenxpos);
            free(entfernenyneg);
            free(entfernenypos);
            free(extra);
            free(extraneg);
            for(int i = 0;i < (size+1);i++){
                free(feld[i]);
                free(neg[i]);
            }
            free(feld);
            free(neg);
            fprintf(stderr, "%s", "Farbe liegt in unzulaessigem Zahlbereich.\n");
            return 1;
        }
        if(xko > 1048576 || xko < -1048576){
            free(verwneg);
            free(verw);
            free(entfernenxnegzwei);
            free(entfernenxposzwei);
            free(entfernenynegzwei);
            free(entfernenyposzwei);
            free(entfernenxneg);
            free(entfernenxpos);
            free(entfernenyneg);
            free(entfernenypos);
            free(extra);
            free(extraneg);
            for(int i = 0;i < (size+1);i++){
                free(feld[i]);
                free(neg[i]);
            }
            free(feld);
            free(neg);
            fprintf(stderr,"%s", "Eine X-Koordinate liegt außerhalb des Bereiches [-1048576,1048576].\n");
            return 1;
        }
        if(xko >= 0){
            if(xko > size){//weiterhier
                //nur x erhöhen

                int alt = 0;
                if(xko < 1024){
                    alt = size;
                    size = 1024;
                }
                if(xko >= 1024 && xko < 2048){
                    alt = size;
                    size = 2048;
                }
                if(xko >= 2048 && xko < 4096){
                    alt = size;
                    size = 4096;
                }
                if(xko >= 4096 && xko < 8192){
                    alt = size;
                    size = 8192;
                }
                if(xko >= 8192 && xko < 16384){
                    alt = size;
                    size = 16384;
                }
                if(xko >= 16384 && xko < 32768){
                    alt = size;
                    size = 32768;
                }
                if(xko >= 32768 && xko < 65536){
                    alt = size;
                    size = 65536;
                }
                if(xko >= 65536 && xko < 131072){
                    alt = size;
                    size = 131072;
                }
                if(xko >= 131072 && xko < 262144){
                    alt = size;
                    size = 262144;
                }
                if(xko >= 262144 && xko < 524288){
                    alt = size;
                    size = 524288;
                }
                if(xko >= 524288 && xko <= 1048576){
                    alt = size;
                    size = 1048576;
                }
                zwischenspeicher = (int *)malloc(sizeof(int)*(laenge+1));

                feld = (int**)realloc(feld, (size+1)*sizeof(int*));
                neg = (int**)realloc(neg, (size+1)*sizeof(int*));

                for(int i = alt+1; i < (size+1); i++){
                    feld[i] = NULL;
                    neg[i] = NULL;
                }

                int on = 0;

                for (int i = 0; i < (size+1); i++){
                    if(feld[i] != NULL){
                        on = 1;
                    }
                    if(on == 1){
                        memmove(zwischenspeicher,feld[i],(laenge+1)*4);
                    }
                    feld[i] = (int*)realloc(feld[i], (laenge+1)*sizeof(int));
                    memset(feld[i],-1,(laenge+1)*4);
                    if(on == 1){
                        memmove(feld[i],zwischenspeicher,(laenge+1)*4);
                    }
                    on = 0;

                    if(neg[i] != NULL){
                        on = 1;
                    }
                    if(on == 1){
                        memmove(zwischenspeicher,neg[i],(laenge+1)*4);
                    }
                    neg[i] = (int*)realloc(neg[i], (laenge+1)*sizeof(int));
                    memset(neg[i],-1,(laenge+1)*4);
                    if(on == 1){
                        memmove(neg[i],zwischenspeicher,(laenge+1)*4);
                    }
                    on = 0;
                }
                free(zwischenspeicher);
                zwischenspeicher = (int *)malloc(sizeof(int)*(alt+1));
                memmove(zwischenspeicher,extra,(alt+1)*4);
                extra = (int*)realloc(extra,(size+1)*sizeof(int));
                memset(extra,0,(size+1)*4);
                memmove(extra,zwischenspeicher,(alt+1)*4);

                memmove(zwischenspeicher,extraneg,(alt+1)*4);
                extraneg = (int*)realloc(extraneg,(size+1)*sizeof(int));
                memset(extraneg,0,(size+1)*4);
                memmove(extraneg,zwischenspeicher,(alt+1)*4);
                free(zwischenspeicher);

                verw = (int*)realloc(verw,(size+1)*sizeof(int));
                verwneg = (int*)realloc(verw,(size+1)*sizeof(int));
                memset(verw,0,(size+1)*4);
                memset(verwneg,0,(size+1)*4);
            }
            //printf(".\n");
            feld[xko][extra[xko]] = farbe;
            extra[xko]++;
            //printf("extra[xko] = %i\n",extra[xko]);
            if(extra[xko] == laenge){//weiterhier
                //nur y erhöhen

                zwischenspeicher = (int *)malloc(sizeof(int)*(laenge+1));

                for (int i = 0; i < (size+1); i++){
                    memmove(zwischenspeicher,feld[i],(laenge+1)*4);
                    feld[i] = (int*)realloc(feld[i], (laenge*2+1)*sizeof(int));
                    memset(feld[i],-1,(laenge*2+1)*4);
                    memmove(feld[i],zwischenspeicher,(laenge+1)*4);

                    memmove(zwischenspeicher,neg[i],(laenge+1)*4);
                    neg[i] = (int*)realloc(neg[i], (laenge*2+1)*sizeof(int));
                    memset(neg[i],-1,(laenge*2+1)*4);
                    memmove(neg[i],zwischenspeicher,(laenge+1)*4);
                }

                laenge = laenge*2;
                free(zwischenspeicher);
            }
            //printf("%i\n",extra[xko]);
        //}
            
            hitcounterWag = 0;
            hitcounterWagneg = 0;
            l = 0;
            k = 1;
            while(1){//suche Wagerecht in pos Richtung
                if((xko+l) >= (size+1)){
                    break;
                }
                if(feld[xko][extra[xko]-1] != feld[xko+l][extra[xko]-1]){
                    break;
                }
                hitcounterWag++;
                l++;
            }
            l = 0;
            while(1){//suche Wagerecht in neg Richtung
                if((xko-l) < 0){
                    break;
                }
                if((xko-l) == 0){
                    if((xko-l+k) < 0 || (xko-l+k) >= (size+1)){
                        break;
                    }
                    if(k == 1 && feld[xko][extra[xko]-1] == feld[xko-l][extra[xko]-1] && feld[xko][extra[xko]-1] != neg[xko-l+k][extra[xko]-1]){
                        hitcounterWagneg++;
                        break;
                    }
                    if(k == 1 && feld[xko][extra[xko]-1] == neg[xko-l+k][extra[xko]-1] && feld[xko][extra[xko]-1] == feld[xko-l][extra[xko]-1]){
                        hitcounterWagneg++;
                        hitcounterWagneg++;
                    }
                    if(k == 1 && (feld[xko][extra[xko]-1] != feld[xko-l][extra[xko]-1] || feld[xko][extra[xko]-1] != neg[xko-l+k][extra[xko]-1])){
                        break;
                    }
                    //davor k++ hier
                    if(feld[xko][extra[xko]-1] != neg[xko-l+k][extra[xko]-1]){
                        break;
                    }
                    k++;
                }else{
                    if(feld[xko][extra[xko]-1] != feld[xko-l][extra[xko]-1]){
                        break;
                    }
                }
                hitcounterWagneg++;
                if(k == 1){
                    l++;
                }
            }
            if((hitcounterWag + hitcounterWagneg) >= 5){
                //printf("Hit: Feld: Wag: Durchlauf: %i\n",durchlaeufe);
                entfernenxpos[entfernencounterpos] = xko;
                entfernenypos[entfernencounterpos] = extra[xko]-1;
                entfernencounterpos++;
                if(entfernencounterpos == entfernenposmax){
                    entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                    entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                    entfernenposmax = entfernenposmax*2;
                }
                //loop für hitcounter
                for(int m = 1;m < hitcounterWag;m++){
                    entfernenxpos[entfernencounterpos] = xko+m;
                    entfernenypos[entfernencounterpos] = extra[xko]-1;
                    entfernencounterpos++;
                    if(entfernencounterpos == entfernenposmax){
                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                        entfernenposmax = entfernenposmax*2;
                    }
                }
                //loop für hitcounterneg
                int n = 1;
                for(int m = 1;m < hitcounterWagneg;m++){
                    if((xko-m) < 0){
                        entfernenxneg[entfernencounterneg] = n;
                        entfernenyneg[entfernencounterneg] = extra[xko]-1;
                        entfernencounterneg++;
                        n++;
                        if(entfernencounterneg == entfernennegmax){
                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                            entfernennegmax = entfernennegmax*2;
                        }
                        //weiter
                    }
                    if((xko-m) >= 0){
                        entfernenxpos[entfernencounterpos] = xko-m;
                        entfernenypos[entfernencounterpos] = extra[xko]-1;
                        entfernencounterpos++;
                        if(entfernencounterpos == entfernenposmax){
                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                            entfernenposmax = entfernenposmax*2;
                        }
                    }
                }
                //printf("hi Wag+\n");
            }
            hitcounterSen = 0;
            hitcounterSenneg = 0;
            l = 0;
            k = 1;
            while(1){//suche Senkrecht in pos Richtung
                if((extra[xko]-1+l) >= (laenge+1)){
                    break;
                }
                if(feld[xko][extra[xko]-1] != feld[xko][extra[xko]-1+l]){
                    break;
                }
                hitcounterSen++;
                l++;
            }
            l = 0;
            while(1){//suche Senkrecht in neg Richtung
                if((extra[xko]-1-l) < 0){
                    break;
                }
                if(feld[xko][extra[xko]-1] != feld[xko][extra[xko]-1-l]){
                    break;
                }
                hitcounterSenneg++;
                l++;
            }
            if((hitcounterSen + hitcounterSenneg) >= 5){
                //printf("Hit: Feld: Sen: Durchlauf: %i\n",durchlaeufe);
                entfernenxpos[entfernencounterpos] = xko;
                entfernenypos[entfernencounterpos] = extra[xko]-1;
                entfernencounterpos++;
                if(entfernencounterpos == entfernenposmax){
                    entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                    entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                    entfernenposmax = entfernenposmax*2;
                }
                //loop für hitcounter
                for(int m = 1;m < hitcounterSen;m++){
                    entfernenxpos[entfernencounterpos] = xko;
                    entfernenypos[entfernencounterpos] = extra[xko]-1+m;
                    entfernencounterpos++;
                    if(entfernencounterpos == entfernenposmax){
                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                        entfernenposmax = entfernenposmax*2;
                    }
                }
                //loop für hitcounterneg
                for(int m = 1;m < hitcounterSenneg;m++){
                    entfernenxpos[entfernencounterpos] = xko;
                    entfernenypos[entfernencounterpos] = extra[xko]-1-m;
                    entfernencounterpos++;
                    if(entfernencounterpos == entfernenposmax){
                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                        entfernenposmax = entfernenposmax*2;
                    }
                }
                //printf("hi Sen+\n");
            }
            hitcounterDiaLR = 0;
            hitcounterDiaLRneg = 0;
            l = 0;
            k = 1;
            while(1){//suche Diagonal LR in pos Richtung
                if((xko+l) >= (size+1) || (extra[xko]-1+l) >= (laenge+1)){
                    break;
                }
                if(feld[xko][extra[xko]-1] != feld[xko+l][extra[xko]-1+l]){
                    break;
                }
                hitcounterDiaLR++;
                l++;
            }
            l = 0;
            while(1){//suche Diagonal LR in neg Richtung
                if((xko-l) < 0 || (extra[xko]-1-l) < 0){
                    break;
                }
                if((xko-l) == 0){
                    if((xko-l+k) < 0 || (xko-l+k) >= (size+1) || (extra[xko]-1-l-k) < 0 || (extra[xko]-1-l-k) >= (laenge+1)){
                        break;
                    }
                    if(k == 1 && feld[xko][extra[xko]-1] == feld[xko-l][extra[xko]-1-l] && feld[xko][extra[xko]-1] != neg[xko-l+k][extra[xko]-1-l+k]){
                        hitcounterDiaLRneg++;
                        break;
                    }
                    if(k == 1 && feld[xko][extra[xko]-1] == neg[xko-l+k][extra[xko]-1-l-k] && feld[xko][extra[xko]-1] == feld[xko-l][extra[xko]-1-l]){
                        hitcounterDiaLRneg++;
                        hitcounterDiaLRneg++;
                    }
                    if(k ==1 && (feld[xko][extra[xko]-1] != feld[xko-l][extra[xko]-1-l] || feld[xko][extra[xko]-1] != neg[xko-l+k][extra[xko]-1-l+k])){
                        break;
                    }
                    //davor k++ hier
                    if(feld[xko][extra[xko]-1] != neg[xko-l+k][extra[xko]-1-l-k]){
                        break;
                    }
                    k++;
                }else{
                    if(feld[xko][extra[xko]-1] != feld[xko-l][extra[xko]-1-l]){
                        break;
                    }
                }
                hitcounterDiaLRneg++;
                if(k == 1){
                    l++;
                }
            }
            if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                //printf("Hit: Feld: DiaLR: Durchlauf: %i\n",durchlaeufe);
                entfernenxpos[entfernencounterpos] = xko;
                entfernenypos[entfernencounterpos] = extra[xko]-1;
                entfernencounterpos++;
                if(entfernencounterpos == entfernenposmax){
                    entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                    entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                    entfernenposmax = entfernenposmax*2;
                }
                //loop für hitcounter
                for(int m = 1;m < hitcounterDiaLR;m++){
                    entfernenxpos[entfernencounterpos] = xko+m;
                    entfernenypos[entfernencounterpos] = extra[xko]-1+m;
                    entfernencounterpos++;
                    if(entfernencounterpos == entfernenposmax){
                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                        entfernenposmax = entfernenposmax*2;
                    }
                }
                //loop für hitcounterneg
                int n = 1;
                for(int m = 1;m < hitcounterDiaLRneg;m++){
                    if((xko-m) < 0){
                        entfernenxneg[entfernencounterneg] = n;
                        entfernenyneg[entfernencounterneg] = extra[xko]-1-m;
                        entfernencounterneg++;
                        n++;
                        if(entfernencounterneg == entfernennegmax){
                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                            entfernennegmax = entfernennegmax*2;
                        }
                        //weiter
                    }
                    if((xko-m) >= 0){
                        entfernenxpos[entfernencounterpos] = xko-m;
                        entfernenypos[entfernencounterpos] = extra[xko]-1-m;
                        entfernencounterpos++;
                        if(entfernencounterpos == entfernenposmax){
                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                            entfernenposmax = entfernenposmax*2;
                        }
                    }
                }
                //printf("hi LR+\n");
            }
            hitcounterDiaRL = 0;
            hitcounterDiaRLneg = 0;
            l = 0;
            k = 1;
            while(1){//suche Diagonal RL in pos Richtung (bei (j+l) >= (laenge+1) war es davor ein -)
                if((xko-l) < 0 || (extra[xko]-1+l) >= (laenge+1)){
                    break;
                }
                if((xko-l) <= 0){
                    if((xko-l+k) < 0 || (xko-l+k) >= (size+1) || (extra[xko]-1+l+k) < 0 || (extra[xko]-1+l+k) >= (laenge+1)){
                        break;
                    }
                    if(k == 1 && feld[xko][extra[xko]-1] == feld[xko-l][extra[xko]-1+l] && feld[xko][extra[xko]-1] != neg[xko-l+k][extra[xko]-1+l+k]){//neu
                        hitcounterDiaRL++;
                        break;
                    }
                    if(k == 1 && feld[xko][extra[xko]-1] == neg[xko-l+k][extra[xko]-1+l+k] && feld[xko][extra[xko]-1] == feld[xko-l][extra[xko]-1+l]){//bearbeitet
                        hitcounterDiaRL++;
                        hitcounterDiaRL++;
                    }
                    if(k == 1 && (feld[xko][extra[xko]-1] != neg[xko-l+k][extra[xko]-1+l+k] || feld[xko][extra[xko]-1] != feld[xko-l][extra[xko]-1+l])){//neu
                        break;
                    }
                    //davor k++ hier
                    if(feld[xko][extra[xko]-1] != neg[xko-l+k][extra[xko]-1+l+k]){
                        break;
                    }
                    k++;
                }else{
                    if(feld[xko][extra[xko]-1] != feld[xko-l][extra[xko]-1+l]){
                        break;
                    }
                }
                hitcounterDiaRL++;
                if(k == 1){
                    l++;
                }
            }
            l = 0;
            while(1){//suche Diagonal RL in neg Richtung
                if((xko+l) >= (size+1) || (extra[xko]-1-l) < 0){
                    break;
                }
                if(feld[xko][extra[xko]-1] != feld[xko+l][extra[xko]-1-l]){
                    break;
                }
                hitcounterDiaRLneg = hitcounterDiaRLneg + 1;
                l++;
            }
            if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                //printf("Hit: Feld: DiaRL: Durchlauf: %i\n",durchlaeufe);
                entfernenxpos[entfernencounterpos] = xko;
                entfernenypos[entfernencounterpos] = extra[xko]-1;
                entfernencounterpos++;
                if(entfernencounterpos == entfernenposmax){
                    entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                    entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                    entfernenposmax = entfernenposmax*2;
                }
                //loop für hitcounter
                int n = 1;
                for(int m = 1;m < hitcounterDiaRL;m++){
                    if((xko-m) < 0){//davor: (xko+m)
                        entfernenxneg[entfernencounterneg] = n;
                        entfernenyneg[entfernencounterneg] = extra[xko]-1+m;
                        entfernencounterneg++;
                        n++;
                        if(entfernencounterneg == entfernennegmax){
                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                            entfernennegmax = entfernennegmax*2;
                        }
                        //weiter
                    }
                    if((xko-m) >= 0){
                        entfernenxpos[entfernencounterpos] = xko-m;
                        entfernenypos[entfernencounterpos] = extra[xko]-1+m;
                        entfernencounterpos++;
                        if(entfernencounterpos == entfernenposmax){
                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                            entfernenposmax = entfernenposmax*2;
                        }
                    }
                }
                //loop für hitcounterneg
                for(int m = 1;m < hitcounterDiaRLneg;m++){
                    entfernenxpos[entfernencounterpos] = xko+m;
                    entfernenypos[entfernencounterpos] = extra[xko]-1-m;
                    entfernencounterpos++;
                    if(entfernencounterpos == entfernenposmax){
                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                        entfernenposmax = entfernenposmax*2;
                    }
                }
                //printf("hi RL+\n");
            }
            //printf("Angekommen\n");
            durchlaeufe = 1;

            if(entfernencounterpos > 0){//neu: entfernencounterneg > 0 || entfernt
                aenderungen = 1;
            }
            
            help = entfernencounterpos;
            while(help > 0){
                feld[entfernenxpos[help-1]][entfernenypos[help-1]] = 255;
                //printf("POS X: %i Y: %i\n", entfernenxpos[help-1], entfernenypos[help-1]);
                help--;
            }
            help = entfernencounterneg;
            while(help > 0){
                neg[entfernenxneg[help-1]][entfernenyneg[help-1]] = 255;
                //printf("NEG X: %i Y: %i\n", entfernenxneg[help-1], entfernenyneg[help-1]);
                help--;
            }
            
            help = entfernencounterpos;
            while(help > 0){
                int k = 0;
                //printf("Aktueller Block: %i mit (%i,%i), wobei k = %i\n",feld[entfernenxpos[help-1]][extra[entfernenxpos[help-1]]-k-1],entfernenxpos[help-1],extra[entfernenxpos[help-1]]-k-1,k);
                //printf("%i\n",extra[entfernenxpos[help-1]]);
                while((extra[entfernenxpos[help-1]]-k-1) >= 0 && verw[entfernenxpos[help-1]] == 0){
                    //printf("1.Aktueller Block: %i mit (%i,%i), wobei k = %i\n",feld[entfernenxpos[help-1]][extra[entfernenxpos[help-1]]-k-1],entfernenxpos[help-1],extra[entfernenxpos[help-1]]-k-1,k);
                    if(feld[entfernenxpos[help-1]][extra[entfernenxpos[help-1]]-k-1] == 255){
                        memmove(feld[entfernenxpos[help-1]]+(extra[entfernenxpos[help-1]]-k-1),feld[entfernenxpos[help-1]]+(extra[entfernenxpos[help-1]]-k-1)+1,(laenge-(extra[entfernenxpos[help-1]]-k-1)-1)*sizeof(*feld[entfernenxpos[help-1]]));
                        count++;
                    }
                    k++;
                }
                if(count > 0){
                    extra[entfernenxpos[help-1]] = extra[entfernenxpos[help-1]] - count;
                    count = 0;
                    verw[entfernenxpos[help-1]] = 1;
                }
                help--;
            }

            help = entfernencounterneg;
            while(help > 0){
                int k = 0;
                while((extraneg[entfernenxneg[help-1]]-k-1) >= 0 && verwneg[entfernenxneg[help-1]] == 0){
                    //printf("1.Aktueller Block: %i mit (-%i,%i), wobei k = %i\n",neg[entfernenxneg[help-1]][extraneg[entfernenxneg[help-1]]-k-1],entfernenxneg[help-1],extraneg[entfernenxneg[help-1]]-k-1,k);
                    if(neg[entfernenxneg[help-1]][extraneg[entfernenxneg[help-1]]-k-1] == 255){
                        memmove(neg[entfernenxneg[help-1]]+(extraneg[entfernenxneg[help-1]]-k-1),neg[entfernenxneg[help-1]]+(extraneg[entfernenxneg[help-1]]-k-1)+1,(laenge-(extraneg[entfernenxneg[help-1]]-k-1)-1)*sizeof(*neg[entfernenxneg[help-1]]));
                        count++;
                    }
                    k++;
                }
                if(count > 0){
                    extraneg[entfernenxneg[help-1]] = extraneg[entfernenxneg[help-1]] - count;
                    count = 0;
                    verwneg[entfernenxneg[help-1]] = 1;
                }
                help--;
            }
            //printf("\n");
            
            memset(verw,0,(size+1)*4);
            memset(verwneg,0,(size+1)*4);
            /*
            if(aenderungen == 1){//hilfe
                for(int i = 0;i < (size+1);i++){
                    //printf("%i\n",extra[i]);
                    if(feld[i][0] != -1){
                        //printf("%i mit i = %i\n",extra[i],i);
                        int j = 0;
                        while(feld[i][j] != -1){
                            fprintf(stdout,"%i %i %i\n",feld[i][j], i,j);
                            j++;
                        }
                    }
                    //printf("%i\n",extraneg[i]);
                    if(neg[i][0] != -1){
                        int j = 0;
                        while(neg[i][j] != -1){
                            fprintf(stdout,"%i -%i %i\n",neg[i][j], i,j);
                            j++;
                        }
                    }
                }
                printf("\n");
                for(int i = 0;i < entfernencounterpos;i++){
                    printf("+(%i,%i)\n",entfernenxpos[i],entfernenypos[i]);
                }
                printf("\n");
                for(int i = 0;i < entfernencounterneg;i++){
                    printf("-(%i,%i)\n",entfernenxneg[i],entfernenyneg[i]);
                }
                printf("1\n");
            }
            */

            //loop start
            
            while(1){
                //printf("Aendrungen: %i\n",aenderungen);
                if(aenderungen == 0){
                    break;
                }else{
                    aenderungen = 0;
                }

                //loop vergleich start

                if((durchlaeufe % 2) == 0){
                    if(durchlaeufe == 1000000){
                        durchlaeufe = 2;
                    }
                    //printf("Gerade Anzahl an Durchläufen.\n");
                    help = entfernencounterposzwei;
                    while(help > 0){
                        int i = 0;
                        int k = 1;
                        for(int j = 0;(j+entfernenyposzwei[(help-1)]) < (laenge+1);j++){
                            if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1){
                                break;
                            }
                            hitcounterWag = 0;
                            hitcounterWagneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Wagerecht in pos Richtung
                                if((entfernenxposzwei[(help-1)]+i) >= (size+1)){
                                    break;
                                }
                                if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]+i][entfernenyposzwei[(help-1)]+j]){
                                    break;
                                }
                                hitcounterWag++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Wagerecht in neg Richtung
                                if((entfernenxposzwei[(help-1)]-i) < 0){
                                    break;
                                }
                                if((entfernenxposzwei[(help-1)]-i) == 0){
                                    if((entfernenxposzwei[(help-1)]-i+k) < 0 || (entfernenxposzwei[(help-1)]-i+k) >= (size+1)){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == feld[0][entfernenyposzwei[(help-1)]+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k][entfernenyposzwei[(help-1)]+j]){
                                        hitcounterWagneg++;
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[0][entfernenyposzwei[(help-1)]+j]){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == neg[k][entfernenyposzwei[(help-1)]+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                        hitcounterWagneg++;
                                        hitcounterWagneg++;
                                    }
                                    if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k+1][entfernenyposzwei[(help-1)]+j]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]-i][entfernenyposzwei[(help-1)]+j]){
                                        break;
                                    }
                                }
                                hitcounterWagneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            if((hitcounterWag + hitcounterWagneg) >= 5){
                                //printf("Hit: Feld: Wag: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop(0) Wag\n");
                                //printf("Treffer: Loop(%i), Feld Wag X: %i Y: %i => %i\n",durchlaeufe,entfernenxposzwei[(help-1)],entfernenyposzwei[(help-1)]+j,feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j]);
                                entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                                entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                                entfernencounterpos++;
                                if(entfernencounterpos == entfernenposmax){
                                    entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenposmax = entfernenposmax*2;
                                }
                                int m = 1;
                                while(m < hitcounterWag){
                                    entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]+m;
                                    entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                                    entfernencounterpos++;
                                    m++;
                                    if(entfernencounterpos == entfernenposmax){
                                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenposmax = entfernenposmax*2;
                                    }
                                }
                                m = 1;
                                int n = 1;//vielleich 1?
                                while(m < hitcounterWagneg){
                                    if((entfernenxposzwei[(help-1)]-m) < 0){
                                        entfernenxneg[entfernencounterneg] = n;
                                        n++;
                                        entfernenyneg[entfernencounterneg] = entfernenyposzwei[(help-1)]+j;
                                        entfernencounterneg++;
                                        if(entfernencounterneg == entfernennegmax){
                                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernennegmax = entfernennegmax*2;
                                        }
                                    }else{
                                        entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]-m;
                                        entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                                        entfernencounterpos++;
                                        if(entfernencounterpos == entfernenposmax){
                                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenposmax = entfernenposmax*2;
                                        }
                                    }
                                    m++;
                                }
                                
                            }
                            hitcounterSen = 0;
                            hitcounterSenneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Senkrecht in pos Richtung
                                if((entfernenyposzwei[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterSen++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Senkrecht in neg Richtung
                                if((entfernenyposzwei[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterSenneg++;
                                i++;
                            }
                            if((hitcounterSen + hitcounterSenneg) >= 5){
                                //printf("Hit: Feld: Sen: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop(0) Sen\n");
                                //printf("Treffer: Loop(%i), Feld Sen X: %i Y: %i => %i\n",durchlaeufe,entfernenxposzwei[(help-1)],entfernenyposzwei[(help-1)]+j,feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j]);
                                entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                                entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                                entfernencounterpos++;
                                if(entfernencounterpos == entfernenposmax){
                                    entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenposmax = entfernenposmax*2;
                                }
                                int m = 1;
                                while(m < hitcounterSen){
                                    entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                                    entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j+m;
                                    entfernencounterpos++;
                                    m++;
                                    if(entfernencounterpos == entfernenposmax){
                                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenposmax = entfernenposmax*2;
                                    }
                                }
                                m = 1;
                                while(m < hitcounterSenneg){
                                    entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                                    entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j-m;
                                    entfernencounterpos++;
                                    m++;
                                    if(entfernencounterpos == entfernenposmax){
                                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenposmax = entfernenposmax*2;
                                    }
                                }
                            }
                            hitcounterDiaLR = 0;
                            hitcounterDiaLRneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal LR in pos Richtung
                                if((entfernenxposzwei[(help-1)]+i) >= (size+1) || (entfernenyposzwei[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]+i][entfernenyposzwei[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterDiaLR++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Diagonal LR in neg Richtung
                                if((entfernenxposzwei[(help-1)]-i) < 0 || (entfernenyposzwei[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if((entfernenxposzwei[(help-1)]-i) == 0){
                                    if((entfernenxposzwei[(help-1)]-i+k) < 0 || (entfernenxposzwei[(help-1)]-i+k) >= (size+1) || (entfernenyposzwei[(help-1)]-i+j-k) < 0 || (entfernenyposzwei[(help-1)]-i+j-k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == feld[0][entfernenyposzwei[(help-1)]-i+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k][entfernenyposzwei[(help-1)]-i+j-k]){
                                        hitcounterDiaLRneg++;
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[0][entfernenyposzwei[(help-1)]-i+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == neg[k][entfernenyposzwei[(help-1)]-i+j-k] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                        hitcounterDiaLRneg++;
                                        hitcounterDiaLRneg++;
                                    }
                                    if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k+1][entfernenyposzwei[(help-1)]-i+j-k-1]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]-i][entfernenyposzwei[(help-1)]-i+j]){
                                        break;
                                    }
                                }
                                hitcounterDiaLRneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                                //printf("Hit: Feld: DiaLR: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop(0) DiaLR\n");
                                //printf("Treffer: Loop(%i), Feld DiaLR X: %i Y: %i => %i\n",durchlaeufe,entfernenxposzwei[(help-1)],entfernenyposzwei[(help-1)]+j,feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j]);
                                entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                                entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                                entfernencounterpos++;
                                if(entfernencounterpos == entfernenposmax){
                                    entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenposmax = entfernenposmax*2;
                                }
                                int m = 1;
                                while(m < hitcounterDiaLR){
                                    entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]+m;
                                    entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j+m;
                                    entfernencounterpos++;
                                    m++;
                                    if(entfernencounterpos == entfernenposmax){
                                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenposmax = entfernenposmax*2;
                                    }
                                }
                                m = 1;
                                int n = 1;//vielleicht 1?
                                while(m < hitcounterDiaLRneg){
                                    if((entfernenxposzwei[(help-1)]-m) < 0){
                                        entfernenxneg[entfernencounterneg] = n;
                                        n++;
                                        entfernenyneg[entfernencounterneg] = entfernenyposzwei[(help-1)]+j+m;
                                        entfernencounterneg++;
                                        if(entfernencounterneg == entfernennegmax){
                                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernennegmax = entfernennegmax*2;
                                        }
                                    }else{
                                        entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]-m;
                                        entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j-m;
                                        entfernencounterpos++;
                                        if(entfernencounterpos == entfernenposmax){
                                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenposmax = entfernenposmax*2;
                                        }
                                    }
                                    m++;
                                }
                            }
                            hitcounterDiaRL = 0;
                            hitcounterDiaRLneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal RL in pos Richtung
                                if((entfernenxposzwei[(help-1)]-i) < 0 || (entfernenyposzwei[(help-1)]-i+j) >= (laenge+1)){
                                    break;
                                }
                                if((entfernenxposzwei[(help-1)]-i) == 0){
                                    if((entfernenxposzwei[(help-1)]-i+k) < 0 || (entfernenxposzwei[(help-1)]-i+k) >= (size+1) || (entfernenyposzwei[(help-1)]+i+j+k) < 0 || (entfernenyposzwei[(help-1)]+i+j+k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == feld[0][entfernenyposzwei[(help-1)]+i+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k][entfernenyposzwei[(help-1)]+i+j+k]){
                                        hitcounterDiaRL++;
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[0][entfernenyposzwei[(help-1)]+i+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == neg[k][entfernenyposzwei[(help-1)]+i+j+k] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                        hitcounterDiaRL++;
                                        hitcounterDiaRL++;
                                    }
                                    if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k+1][entfernenyposzwei[(help-1)]+i+j+k+1]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]-i][entfernenyposzwei[(help-1)]+i+j]){
                                        break;
                                    }
                                }
                                hitcounterDiaRL++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            i = 0;
                            while(1){//suche Diagonal RL in neg Richtung
                                if((entfernenxposzwei[(help-1)]+i) >= (size+1) || (entfernenyposzwei[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]+i][entfernenyposzwei[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterDiaRLneg++;
                                i++;
                            }
                            if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                                //printf("Hit: Feld: DiaRL: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop(0) DiaRL\n");
                                //printf("Treffer: Loop(%i), Feld DiaRL X: %i Y: %i => %i\n",durchlaeufe,entfernenxposzwei[(help-1)],entfernenyposzwei[(help-1)]+j,feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j]);
                                entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                                entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                                entfernencounterpos++;
                                if(entfernencounterpos == entfernenposmax){
                                    entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenposmax = entfernenposmax*2;
                                }
                                int m = 1;
                                int n = 1;//vielleicht 1?
                                while(m < hitcounterDiaRL){
                                    if((entfernenxposzwei[(help-1)]-m) < 0){
                                        entfernenxneg[entfernencounterneg] = n;
                                        n++;
                                        entfernenyneg[entfernencounterneg] = entfernenyposzwei[(help-1)]+j+m;
                                        entfernencounterneg++;
                                        if(entfernencounterneg == entfernennegmax){
                                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernennegmax = entfernennegmax*2;
                                        }
                                    }else{
                                        entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]-m;
                                        entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j+m;
                                        entfernencounterpos++;
                                        if(entfernencounterpos == entfernenposmax){
                                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenposmax = entfernenposmax*2;
                                        }
                                    }
                                    m++;
                                }
                                m = 1;
                                while(m < hitcounterDiaRLneg){
                                    entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]+m;
                                    entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j-m;
                                    entfernencounterpos++;
                                    m++;
                                    if(entfernencounterpos == entfernenposmax){
                                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenposmax = entfernenposmax*2;
                                    }
                                }
                            }
                        }
                        help--;
                    }
                    
                    help = entfernencounternegzwei;
                    while(help > 0){
                        int i = 0;
                        int k = 1;
                        for(int j = 0;(j+entfernenynegzwei[(help-1)]) < (laenge+1);j++){
                            if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1){
                                break;
                            }
                            //printf("Aktuelles Neg: X: %i Y: %i Farbe: %i\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j]);
                            hitcounterWag = 0;
                            hitcounterWagneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Wagerecht in pos Richtung
                                if((entfernenxnegzwei[(help-1)]+i) >= (size+1)){
                                    break;
                                }
                                if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]+i][entfernenynegzwei[(help-1)]+j]){
                                    break;
                                }
                                hitcounterWag++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Wagerecht in neg Richtung
                                if((entfernenxnegzwei[(help-1)]-i) < 1){
                                    //printf("break 1\n");
                                    break;
                                }
                                if((entfernenxnegzwei[(help-1)]-i) == 1){
                                    if((entfernenxnegzwei[(help-1)]-i+k) < 1 || (entfernenxnegzwei[(help-1)]-i+k) >= (size+1)){
                                        //printf("break 2\n");
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == neg[1][entfernenynegzwei[(help-1)]+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k-1][entfernenynegzwei[(help-1)]+j]){
                                        hitcounterWagneg++;
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[1][entfernenynegzwei[(help-1)]+j]){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == feld[k-1][entfernenynegzwei[(help-1)]+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                        //printf("hi\n");
                                        hitcounterWagneg++;
                                        hitcounterWagneg++;
                                    }
                                    if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k][entfernenynegzwei[(help-1)]+j]){
                                        //printf("break 3\n");
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]-i][entfernenynegzwei[(help-1)]+j]){
                                        //printf("break 4\n");
                                        break;
                                    }
                                }
                                hitcounterWagneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            //printf("Hit Wag: %i\n", hitcounterWag);
                            //printf("Hit Wag Neg: %i\n", hitcounterWagneg);
                            if((hitcounterWag + hitcounterWagneg) >= 5){
                                //printf("Hit: Neg: Wag: Durchlauf: %i\n",durchlaeufe);
                                //printf("Treffer: Loop(%i), Neg Wag X: %i Y: %i => %i\n",durchlaeufe,entfernenxnegzwei[(help-1)],entfernenynegzwei[(help-1)]+j,neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j]);
                                //printf("Gefunden Loop(0) Wag\n");
                                //printf("1) speichere: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                                entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                                entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                                entfernencounterneg++;
                                if(entfernencounterneg == entfernennegmax){
                                    entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernennegmax = entfernennegmax*2;
                                }
                                //printf("entfernt 982\n");
                                //printf("neu in neg entfernen: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                                //printf("entfernen NEG aktuelle Position: (%i,%i)\n",entfernenxnegzwei[entfernencounternegzwei-1],entfernenynegzwei[entfernencounternegzwei-1]);
                                int m = 1;
                                while(m < hitcounterWag){
                                    //printf("2) speichere: (%i,%i)\n",entfernenxneg[(help-1)]+m,entfernenyneg[(help-1)]+j);
                                    entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]+m;
                                    entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                                    entfernencounterneg++;
                                    //printf("entfernt 990\n");
                                    m++;
                                    if(entfernencounterneg == entfernennegmax){
                                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernennegmax = entfernennegmax*2;
                                    }
                                }
                                m = 1;
                                int n = 0;
                                while(m < hitcounterWagneg){
                                    if((entfernenxnegzwei[(help-1)]-m) < 1){
                                        //printf("3) speichere: (%i,%i)\n",n,entfernenyneg[(help-1)]+j);
                                        entfernenxpos[entfernencounterpos] = n;
                                        n++;
                                        entfernenypos[entfernencounterpos] = entfernenynegzwei[(help-1)]+j;
                                        entfernencounterpos++;
                                        if(entfernencounterpos == entfernenposmax){
                                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenposmax = entfernenposmax*2;
                                        }
                                        //printf("neu in entfernen: (%i,%i)\n",n-1,entfernenyneg[(help-1)]+j);
                                        //printf("entfernen aktuelle Position: (%i,%i)\n",entfernenxposzwei[entfernencounterposzwei-1],entfernenyposzwei[entfernencounterposzwei-1]);
                                    }else{
                                        //printf("4) speichere: (%i,%i)\n",entfernenxneg[(help-1)]-m,entfernenyneg[(help-1)]+j);
                                        entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]-m;
                                        entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                                        entfernencounterneg++;
                                        if(entfernencounterneg == entfernennegmax){
                                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernennegmax = entfernennegmax*2;
                                        }
                                        //printf("entfernt 1008\n");
                                    }
                                    m++;
                                }
                                
                            }
                            hitcounterSen = 0;
                            hitcounterSenneg = 0;
                            i = 0;
                            while(1){//suche Senkrecht in pos Richtung
                                if((entfernenynegzwei[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterSen++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Senkrecht in neg Richtung
                                if((entfernenynegzwei[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterSenneg++;
                                i++;
                            }
                            if((hitcounterSen + hitcounterSenneg) >= 5){
                                //printf("Hit: Neg: Sen: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop(0) Sen\n");
                                //printf("Treffer: Loop(%i), Neg Sen X: %i Y: %i => %i\n",durchlaeufe,entfernenxnegzwei[(help-1)],entfernenynegzwei[(help-1)]+j,neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j]);
                                entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                                entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                                entfernencounterneg++;
                                if(entfernencounterneg == entfernennegmax){
                                    entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernennegmax = entfernennegmax*2;
                                }
                                //printf("entfernt 1143\n");
                                int m = 1;
                                while(m < hitcounterSen){
                                    entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                                    entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j+m;
                                    entfernencounterneg++;
                                    //printf("entfernt 1048\n");
                                    m++;
                                    if(entfernencounterneg == entfernennegmax){
                                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernennegmax = entfernennegmax*2;
                                    }
                                }
                                m = 1;
                                while(m < hitcounterSenneg){
                                    entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                                    entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j-m;
                                    entfernencounterneg++;
                                    //printf("entfernt 1055\n");
                                    m++;
                                    if(entfernencounterneg == entfernennegmax){
                                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernennegmax = entfernennegmax*2;
                                    }
                                }
                            }
                            hitcounterDiaLR = 0;
                            hitcounterDiaLRneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal LR in pos Richtung
                                if((entfernenxnegzwei[(help-1)]+i) >= (size+1) || (entfernenynegzwei[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]+i][entfernenynegzwei[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterDiaLR++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Diagonal LR in neg Richtung
                                if((entfernenxnegzwei[(help-1)]-i) < 1 || (entfernenynegzwei[(help-1)]-i+j) < 1){
                                    break;
                                }
                                if((entfernenxnegzwei[(help-1)]-i) == 1){
                                    if((entfernenxnegzwei[(help-1)]-i+k) < 1 || (entfernenxnegzwei[(help-1)]-i+k) >= (size+1) || (entfernenynegzwei[(help-1)]-i+j-k) < 0 || (entfernenynegzwei[(help-1)]-i+j-k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == neg[1][entfernenynegzwei[(help-1)]-i+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k-1][entfernenynegzwei[(help-1)]-i+j-k]){
                                        hitcounterDiaLRneg++;
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[1][entfernenynegzwei[(help-1)]-i+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == feld[k-1][entfernenynegzwei[(help-1)]-i+j-k] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                        hitcounterDiaLRneg++;
                                        hitcounterDiaLRneg++;
                                    }
                                    if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k][entfernenynegzwei[(help-1)]-i+j-k-1]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]-i][entfernenynegzwei[(help-1)]-i+j]){
                                        break;
                                    }
                                }
                                hitcounterDiaLRneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                                //printf("Hit: Neg: DiaLR: Durchlauf: %i\n",durchlaeufe);
                                //printf("Treffer: Loop(%i), Neg DiaLR X: %i Y: %i => %i\n",durchlaeufe,entfernenxnegzwei[(help-1)],entfernenynegzwei[(help-1)]+j,neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j]);
                                //printf("Gefunden Loop(0) DiaLR\n");
                                entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                                entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                                entfernencounterneg++;
                                if(entfernencounterneg == entfernennegmax){
                                    entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernennegmax = entfernennegmax*2;
                                }
                                //printf("entfernt 1112\n");
                                int m = 1;
                                while(m < hitcounterDiaLR){
                                    entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]+m;
                                    entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j+m;
                                    entfernencounterneg++;
                                    //printf("entfernt 1117\n");
                                    m++;
                                    if(entfernencounterneg == entfernennegmax){
                                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernennegmax = entfernennegmax*2;
                                    }
                                }
                                m = 1;
                                int n = 0;
                                while(m < hitcounterDiaLRneg){
                                    if((entfernenxnegzwei[(help-1)]-m) < 1){
                                        entfernenxpos[entfernencounterpos] = n;
                                        n++;
                                        entfernenypos[entfernencounterpos] = entfernenynegzwei[(help-1)]+j+m;
                                        entfernencounterpos++;
                                        if(entfernencounterpos == entfernenposmax){
                                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenposmax = entfernenposmax*2;
                                        }
                                    }else{
                                        entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]-m;
                                        entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j-m;
                                        entfernencounterneg++;
                                        if(entfernencounterneg == entfernennegmax){
                                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernennegmax = entfernennegmax*2;
                                        }
                                        //printf("entfernt 1131\n");
                                    }
                                    m++;
                                }
                            }
                            hitcounterDiaRL = 0;
                            hitcounterDiaRLneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal RL in pos Richtung
                                if((entfernenxnegzwei[(help-1)]-i) < 1 || (entfernenynegzwei[(help-1)]-i+j) >= (laenge+1)){
                                    break;
                                }
                                if((entfernenxnegzwei[(help-1)]-i) == 1){
                                    //printf("3 wird verglichen mit: %i\n",neg[entfernenxneg[(help-1)]-i+k][entfernenyneg[(help-1)]+i+j+k]);
                                    if((entfernenxnegzwei[(help-1)]-i+k) < 1 || (entfernenxnegzwei[(help-1)]-i+k) >= (size+1) || (entfernenynegzwei[(help-1)]+i+j+k) < 0 || (entfernenynegzwei[(help-1)]+i+j+k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == neg[1][entfernenynegzwei[(help-1)]+i+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k-1][entfernenynegzwei[(help-1)]+i+j+k]){
                                        hitcounterDiaRL++;
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[1][entfernenynegzwei[(help-1)]+i+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == feld[k-1][entfernenynegzwei[(help-1)]+i+j+k] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                        hitcounterDiaRL++;
                                        hitcounterDiaRL++;
                                        //printf("erhöhe um 2\n");
                                    }
                                    if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k][entfernenynegzwei[(help-1)]+i+j+k+1]){
                                        break;
                                    }
                                    //printf("erhöhe um 1 (Übergang)\n");
                                    k++;
                                }else{
                                    //printf("3 wird verglichen mit: %i\n",neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j]);
                                    if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]-i][entfernenynegzwei[(help-1)]+i+j]){
                                        break;
                                    }
                                    //printf("erhöhe um 1 (kein Übergang)\n");
                                    //printf("%i bei (%i,%i) und %ibei (%i,%i)\n",neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j],entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j],entfernenxneg[(help-1)]-i,entfernenyneg[(help-1)]+i+j);
                                }
                                hitcounterDiaRL++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            i = 0;
                            while(1){//suche Diagonal RL in neg Richtung
                                if((entfernenxnegzwei[(help-1)]+i) >= (size+1) || (entfernenynegzwei[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]+i][entfernenynegzwei[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterDiaRLneg++;
                                i++;
                            }
                            //printf("hit DiaRL pos: %i\n", hitcounterDiaRL);
                            //printf("hit DiaRL neg: %i\n", hitcounterDiaRLneg);
                            if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                                //printf("Hit: Neg: DiaRL: Durchlauf: %i\n",durchlaeufe);
                                //printf("Treffer: Loop(%i), Neg DiaRL X: %i Y: %i => %i\n",durchlaeufe,entfernenxnegzwei[(help-1)],entfernenynegzwei[(help-1)]+j,neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j]);
                                //printf("Gefunden Loop(0) DiaRL\n");
                                //printf("1) speichere: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                                entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                                entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                                entfernencounterneg++;
                                if(entfernencounterneg == entfernennegmax){
                                    entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernennegmax = entfernennegmax*2;
                                }
                                //printf("entfernt 1198\n");
                                int m = 1;
                                int n =0;
                                while(m < hitcounterDiaRL){
                                    if((entfernenxnegzwei[(help-1)]-m) < 1){
                                        //printf("2) speichere: (%i,%i)\n",n,entfernenyneg[(help-1)]+j+m);
                                        entfernenxpos[entfernencounterpos] = n;
                                        n++;
                                        entfernenypos[entfernencounterpos] = entfernenynegzwei[(help-1)]+j+m;
                                        entfernencounterpos++;
                                        if(entfernencounterpos == entfernenposmax){
                                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenposmax = entfernenposmax*2;
                                        }
                                    }else{
                                        //printf("3) speichere: (%i,%i)\n",entfernenxneg[(help-1)]-m,entfernenyneg[(help-1)]+j+m);
                                        entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]-m;
                                        entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j+m;
                                        entfernencounterneg++;
                                        if(entfernencounterneg == entfernennegmax){
                                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernennegmax = entfernennegmax*2;
                                        }
                                        //printf("entfernt 1212\n");
                                    }
                                    m++;
                                }
                                m = 1;
                                while(m < hitcounterDiaRLneg){
                                    //printf("4) speichere: (%i,%i)\n",entfernenxneg[(help-1)]+m,entfernenyneg[(help-1)]+j-m);
                                    entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]+m;
                                    entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j-m;
                                    entfernencounterneg++;
                                    //printf("entfernt 1221\n");
                                    m++;
                                    if(entfernencounterneg == entfernennegmax){
                                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernennegmax = entfernennegmax*2;
                                    }
                                }
                            }
                        }
                        help--;
                    }
                    help = 0;

                    if(entfernencounterneg > 0 || entfernencounterpos > 0){
                        aenderungen = 1;
                    }
                    //printf("entfernenPOS: %i\n", entfernencounterpos);
                    //printf("entfernenNEG: %i\n", entfernencounterneg);
                    help = entfernencounterpos;
                    while(help > 0){
                        feld[entfernenxpos[help-1]][entfernenypos[help-1]] = 255;
                        //printf("Loop(0) POS X: %i Y: %i\n", entfernenxposzwei[help-1], entfernenyposzwei[help-1]);
                        help--;
                    }

                    help = entfernencounterneg;
                    while(help > 0){
                        neg[entfernenxneg[help-1]][entfernenyneg[help-1]] = 255;
                        //printf("NEG X: %i Y: %i\n", entfernenxnegzwei[help-1], entfernenynegzwei[help-1]);
                        help--;
                    }
                    help = entfernencounterpos;
                    while(help > 0){
                        int k = 0;
                        while((extra[entfernenxpos[help-1]]-k-1) >= 0 && verw[entfernenxpos[help-1]] == 0){
                            //printf("2.Aktueller Block: %i mit (%i,%i), wobei k = %i\n",feld[entfernenxpos[help-1]][extra[entfernenxpos[help-1]]-k-1],entfernenxpos[help-1],extra[entfernenxpos[help-1]]-k-1,k);
                            if(feld[entfernenxpos[help-1]][extra[entfernenxpos[help-1]]-k-1] == 255){
                                memmove(feld[entfernenxpos[help-1]]+(extra[entfernenxpos[help-1]]-k-1),feld[entfernenxpos[help-1]]+(extra[entfernenxpos[help-1]]-k-1)+1,(laenge-(extra[entfernenxpos[help-1]]-k-1)-1)*sizeof(*feld[entfernenxpos[help-1]]));
                                count++;
                            }
                            k++;
                        }
                        if(count > 0){
                            extra[entfernenxpos[help-1]] = extra[entfernenxpos[help-1]] - count;
                            count = 0;
                            verw[entfernenxpos[help-1]] = 1;
                        }
                        help--;
                    }

                    help = entfernencounterneg;
                    while(help > 0){
                        int k = 0;
                        while((extraneg[entfernenxneg[help-1]]-k-1) >= 0 && verwneg[entfernenxneg[help-1]] == 0){
                            //printf("2.Aktueller Block: %i mit (-%i,%i), wobei k = %i\n",neg[entfernenxneg[help-1]][extraneg[entfernenxneg[help-1]]-k-1],entfernenxneg[help-1],extraneg[entfernenxneg[help-1]]-k-1,k);
                            if(neg[entfernenxneg[help-1]][extraneg[entfernenxneg[help-1]]-k-1] == 255){
                                memmove(neg[entfernenxneg[help-1]]+(extraneg[entfernenxneg[help-1]]-k-1),neg[entfernenxneg[help-1]]+(extraneg[entfernenxneg[help-1]]-k-1)+1,(laenge-(extraneg[entfernenxneg[help-1]]-k-1)-1)*sizeof(*neg[entfernenxneg[help-1]]));
                                count++;
                            }
                            k++;
                        }
                        if(count > 0){
                            extraneg[entfernenxneg[help-1]] = extraneg[entfernenxneg[help-1]] - count;
                            count = 0;
                            verwneg[entfernenxneg[help-1]] = 1;
                        }
                        help--;
                    }
                    //printf("\n");

                    help = 0;
                    entfernencounterposzwei = 0;
                    entfernencounternegzwei = 0;

                    memset(verw,0,(size+1)*4);
                    memset(verwneg,0,(size+1)*4);

                    /*
                    if(aenderungen == 1){//hilfe
                        for(int i = 0;i < (size+1);i++){
                            //printf("%i\n",extra[i]);
                            if(feld[i][0] != -1){
                                //printf("%i mit i = %i\n",extra[i],i);
                                int j = 0;
                                while(feld[i][j] != -1){
                                    fprintf(stdout,"%i %i %i\n",feld[i][j], i,j);
                                    j++;
                                }
                            }
                            //printf("%i\n",extraneg[i]);
                            if(neg[i][0] != -1){
                                int j = 0;
                                while(neg[i][j] != -1){
                                    fprintf(stdout,"%i -%i %i\n",neg[i][j], i,j);
                                    j++;
                                }
                            }
                        }
                        printf("\n");
                        for(int i = 0;i < entfernencounterpos;i++){
                            printf("+(%i,%i)\n",entfernenxpos[i],entfernenypos[i]);
                        }
                        printf("\n");
                        for(int i = 0;i < entfernencounterneg;i++){
                            printf("-(%i,%i)\n",entfernenxneg[i],entfernenyneg[i]);
                        }
                        printf("2\n");
                    }
                    */
                }
                if((durchlaeufe % 2) == 1){
                    //printf("Ungerade Anzahl an Durchläufen.\n");
                    help = entfernencounterpos;
                    while(help > 0){
                        int i = 0;
                        int k = 1;
                        for(int j = 0;(j+entfernenypos[(help-1)]) < (laenge+1);j++){
                            if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1){
                                break;
                            }
                            hitcounterWag = 0;
                            hitcounterWagneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Wagerecht in pos Richtung
                                if((entfernenxpos[(help-1)]+i) >= (size+1)){
                                    break;
                                }
                                if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]+i][entfernenypos[(help-1)]+j]){
                                    break;
                                }
                                hitcounterWag++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Wagerecht in neg Richtung
                                if((entfernenxpos[(help-1)]-i) < 0){
                                    break;
                                }
                                if((entfernenxpos[(help-1)]-i) == 0){
                                    if((entfernenxpos[(help-1)]-i+k) < 0 || (entfernenxpos[(help-1)]-i+k) >= (size+1)){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == feld[0][entfernenypos[(help-1)]+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k][entfernenypos[(help-1)]+j]){
                                        hitcounterWagneg++;
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[0][entfernenypos[(help-1)]+j]){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == neg[k-1][entfernenypos[(help-1)]+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                        hitcounterWagneg++;
                                        hitcounterWagneg++;
                                    }
                                    if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k+1][entfernenypos[(help-1)]+j]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]-i][entfernenypos[(help-1)]+j]){
                                        break;
                                    }
                                }
                                hitcounterWagneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            if((hitcounterWag + hitcounterWagneg) >= 5){
                                //printf("Hit: Feld: Wag: Durchlauf: %i\n",durchlaeufe);
                                //printf("Treffer: Loop(%i), Feld Wag X: %i Y: %i => %i\n",durchlaeufe,entfernenxpos[(help-1)],entfernenypos[(help-1)]+j,feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j]);
                                //printf("Gefunden Loop Wag\n");
                                entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                                entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                                entfernencounterposzwei++;
                                if(entfernencounterposzwei == entfernenposmaxzwei){
                                    entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenposmaxzwei = entfernenposmaxzwei*2;
                                }
                                int m = 1;
                                while(m < hitcounterWag){
                                    entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]+m;
                                    entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                                    entfernencounterposzwei++;
                                    m++;
                                    if(entfernencounterposzwei == entfernenposmaxzwei){
                                        entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenposmaxzwei = entfernenposmaxzwei*2;
                                    }
                                }
                                m = 1;
                                int n = 1;//vielleicht 1?
                                while(m < hitcounterWagneg){
                                    if((entfernenxpos[(help-1)]-m) < 0){
                                        entfernenxnegzwei[entfernencounternegzwei] = n;
                                        n++;
                                        entfernenynegzwei[entfernencounternegzwei] = entfernenypos[(help-1)]+j;
                                        entfernencounternegzwei++;
                                        if(entfernencounternegzwei == entfernennegmaxzwei){
                                            entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernennegmaxzwei = entfernennegmaxzwei*2;
                                        }
                                    }else{
                                        entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]-m;
                                        entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                                        entfernencounterposzwei++;
                                        if(entfernencounterposzwei == entfernenposmaxzwei){
                                            entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenposmaxzwei = entfernenposmaxzwei*2;
                                        }
                                    }
                                    m++;
                                }
                                
                            }
                            hitcounterSen = 0;
                            hitcounterSenneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Senkrecht in pos Richtung
                                if((entfernenypos[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterSen++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Senkrecht in neg Richtung
                                if((entfernenypos[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterSenneg++;
                                i++;
                            }
                            if((hitcounterSen + hitcounterSenneg) >= 5){
                                //printf("Hit: Feld: Sen: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop Sen\n");
                                //printf("Treffer: Loop(%i), Feld Sen X: %i Y: %i => %i\n",durchlaeufe,entfernenxpos[(help-1)],entfernenypos[(help-1)]+j,feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j]);
                                entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                                entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                                entfernencounterposzwei++;
                                if(entfernencounterposzwei == entfernenposmaxzwei){
                                    entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenposmaxzwei = entfernenposmaxzwei*2;
                                }
                                int m = 1;
                                while(m < hitcounterSen){
                                    entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                                    entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j+m;
                                    entfernencounterposzwei++;
                                    m++;
                                    if(entfernencounterposzwei == entfernenposmaxzwei){
                                        entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenposmaxzwei = entfernenposmaxzwei*2;
                                    }
                                }
                                m = 1;
                                while(m < hitcounterSenneg){
                                    entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                                    entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j-m;
                                    entfernencounterposzwei++;
                                    m++;
                                    if(entfernencounterposzwei == entfernenposmaxzwei){
                                        entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenposmaxzwei = entfernenposmaxzwei*2;
                                    }
                                }
                            }
                            hitcounterDiaLR = 0;
                            hitcounterDiaLRneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal LR in pos Richtung
                                if((entfernenxpos[(help-1)]+i) >= (size+1) || (entfernenypos[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]+i][entfernenypos[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterDiaLR++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Diagonal LR in neg Richtung
                                if((entfernenxpos[(help-1)]-i) < 0 || (entfernenypos[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if((entfernenxpos[(help-1)]-i) == 0){
                                    if((entfernenxpos[(help-1)]-i+k) < 0 || (entfernenxpos[(help-1)]-i+k) >= (size+1) || (entfernenypos[(help-1)]-i+j-k) < 0 || (entfernenypos[(help-1)]-i+j-k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == feld[0][entfernenypos[(help-1)]-i+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k][entfernenypos[(help-1)]-i+j-k]){
                                        hitcounterDiaLRneg++;
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[0][entfernenypos[(help-1)]-i+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == neg[k][entfernenypos[(help-1)]-i+j-k] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                        hitcounterDiaLRneg++;
                                        hitcounterDiaLRneg++;
                                    }
                                    if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k+1][entfernenypos[(help-1)]-i+j-k-1]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]-i][entfernenypos[(help-1)]-i+j]){
                                        break;
                                    }
                                }
                                hitcounterDiaLRneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                                //printf("Hit: Feld: DiaLR: Durchlauf: %i\n",durchlaeufe);
                                //printf("Treffer: Loop(%i), Feld DiaLR X: %i Y: %i => %i\n",durchlaeufe,entfernenxpos[(help-1)],entfernenypos[(help-1)]+j,feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j]);
                                //printf("Gefunden Loop DiaLR\n");
                                entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                                entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                                entfernencounterposzwei++;
                                if(entfernencounterposzwei == entfernenposmaxzwei){
                                    entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenposmaxzwei = entfernenposmaxzwei*2;
                                }
                                int m = 1;
                                while(m < hitcounterDiaLR){
                                    entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]+m;
                                    entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j+m;
                                    entfernencounterposzwei++;
                                    m++;
                                    if(entfernencounterposzwei == entfernenposmaxzwei){
                                        entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenposmaxzwei = entfernenposmaxzwei*2;
                                    }
                                }
                                m = 1;
                                int n = 1;//vielleicht 1?
                                while(m < hitcounterDiaLRneg){
                                    if((entfernenxpos[(help-1)]-m) < 0){
                                        entfernenxnegzwei[entfernencounternegzwei] = n;
                                        n++;
                                        entfernenynegzwei[entfernencounternegzwei] = entfernenypos[(help-1)]+j+m;
                                        entfernencounternegzwei++;
                                        if(entfernencounternegzwei == entfernennegmaxzwei){
                                            entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernennegmaxzwei = entfernennegmaxzwei*2;
                                        }
                                    }else{
                                        entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]-m;
                                        entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j-m;
                                        entfernencounterposzwei++;
                                        if(entfernencounterposzwei == entfernenposmaxzwei){
                                            entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenposmaxzwei = entfernenposmaxzwei*2;
                                        }
                                    }
                                    m++;
                                }
                            }
                            hitcounterDiaRL = 0;
                            hitcounterDiaRLneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal RL in pos Richtung
                                if((entfernenxpos[(help-1)]-i) < 0 || (entfernenypos[(help-1)]-i+j) >= (laenge+1)){
                                    break;
                                }
                                if((entfernenxpos[(help-1)]-i) == 0){
                                    if((entfernenxpos[(help-1)]-i+k) < 0 || (entfernenxpos[(help-1)]-i+k) >= (size+1) || (entfernenypos[(help-1)]+i+j+k) < 0 || (entfernenypos[(help-1)]+i+j+k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == feld[0][entfernenypos[(help-1)]+i+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k][entfernenypos[(help-1)]+i+j+k]){
                                        hitcounterDiaRL++;
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[0][entfernenypos[(help-1)]+i+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == neg[k][entfernenypos[(help-1)]+i+j+k] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                        hitcounterDiaRL++;
                                        hitcounterDiaRL++;
                                    }
                                    if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k+1][entfernenypos[(help-1)]+i+j+k+1]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]-i][entfernenypos[(help-1)]+i+j]){
                                        break;
                                    }
                                }
                                hitcounterDiaRL++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            i = 0;
                            while(1){//suche Diagonal RL in neg Richtung
                                if((entfernenxpos[(help-1)]+i) >= (size+1) || (entfernenypos[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]+i][entfernenypos[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterDiaRLneg++;
                                i++;
                            }
                            if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                                //printf("Hit: Feld: DiaRL: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop DiaRL\n");
                                //printf("Treffer: Loop(%i), Feld DiaRL X: %i Y: %i => %i\n",durchlaeufe,entfernenxpos[(help-1)],entfernenypos[(help-1)]+j,feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j]);
                                entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                                entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                                entfernencounterposzwei++;
                                if(entfernencounterposzwei == entfernenposmaxzwei){
                                    entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenposmaxzwei = entfernenposmaxzwei*2;
                                }
                                int m = 1;
                                int n = 1;//vielleicht 1?
                                while(m < hitcounterDiaRL){
                                    if((entfernenxpos[(help-1)]-m) < 0){
                                        entfernenxnegzwei[entfernencounternegzwei] = n;
                                        n++;
                                        entfernenynegzwei[entfernencounternegzwei] = entfernenypos[(help-1)]+j+m;
                                        entfernencounternegzwei++;
                                        if(entfernencounternegzwei == entfernennegmaxzwei){
                                            entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernennegmaxzwei = entfernennegmaxzwei*2;
                                        }
                                    }else{
                                        entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]-m;
                                        entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j+m;
                                        entfernencounterposzwei++;
                                        if(entfernencounterposzwei == entfernenposmaxzwei){
                                            entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenposmaxzwei = entfernenposmaxzwei*2;
                                        }
                                    }
                                    m++;
                                }
                                m = 1;
                                while(m < hitcounterDiaRLneg){
                                    entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]+m;
                                    entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j-m;
                                    entfernencounterposzwei++;
                                    m++;
                                    if(entfernencounterposzwei == entfernenposmaxzwei){
                                        entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenposmaxzwei = entfernenposmaxzwei*2;
                                    }
                                }
                            }
                        }
                        help--;
                    }
                    
                    help = entfernencounterneg;
                    //printf("NegCounter: %i\n", entfernencounterneg);
                    while(help > 0){
                        int i = 0;
                        int k = 1;
                        for(int j = 0;(j+entfernenyneg[(help-1)]) < (laenge+1);j++){
                            if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1){
                                break;
                            }
                            //printf("Aktuelles Neg: X: %i Y: %i Farbe: %i\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j]);
                            hitcounterWag = 0;
                            hitcounterWagneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Wagerecht in pos Richtung
                                if((entfernenxneg[(help-1)]+i) >= (size+1)){
                                    break;
                                }
                                if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]+i][entfernenyneg[(help-1)]+j]){
                                    break;
                                }
                                hitcounterWag++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Wagerecht in neg Richtung
                                if((entfernenxneg[(help-1)]-i) < 1){
                                    //printf("break 1\n");
                                    break;
                                }
                                if((entfernenxneg[(help-1)]-i) == 1){
                                    if((entfernenxneg[(help-1)]-i+k) < 1 || (entfernenxneg[(help-1)]-i+k) >= (size+1)){
                                        //printf("break 2\n");
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == neg[1][entfernenyneg[(help-1)]+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k-1][entfernenyneg[(help-1)]+j]){
                                        hitcounterWagneg++;
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[1][entfernenyneg[(help-1)]+j]){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == feld[k-1][entfernenyneg[(help-1)]+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                        //printf("hi\n");
                                        hitcounterWagneg++;
                                        hitcounterWagneg++;
                                    }
                                    if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k][entfernenyneg[(help-1)]+j]){
                                        //printf("break 3\n");
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+j]){
                                        //printf("break 4\n");
                                        break;
                                    }
                                }
                                hitcounterWagneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            //printf("Hit Wag: %i\n", hitcounterWag);
                            //printf("Hit Wag Neg: %i\n", hitcounterWagneg);
                            if((hitcounterWag + hitcounterWagneg) >= 5){
                                //printf("Hit: Neg: Wag: Durchlauf: %i\n",durchlaeufe);
                                //printf("Treffer: Loop(%i), Neg Wag X: %i Y: %i => %i\n",durchlaeufe,entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j]);
                                //printf("Gefunden Loop Wag\n");
                                //printf("1) speichere: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                                entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                                entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                                entfernencounternegzwei++;
                                if(entfernencounternegzwei == entfernennegmaxzwei){
                                    entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernennegmaxzwei = entfernennegmaxzwei*2;
                                }
                                //printf("neu in neg entfernen: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                                //printf("entfernen NEG aktuelle Position: (%i,%i)\n",entfernenxnegzwei[entfernencounternegzwei-1],entfernenynegzwei[entfernencounternegzwei-1]);
                                int m = 1;
                                while(m < hitcounterWag){
                                    //printf("2) speichere: (%i,%i)\n",entfernenxneg[(help-1)]+m,entfernenyneg[(help-1)]+j);
                                    entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]+m;
                                    entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                                    entfernencounternegzwei++;
                                    m++;
                                    if(entfernencounternegzwei == entfernennegmaxzwei){
                                        entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernennegmaxzwei = entfernennegmaxzwei*2;
                                    }
                                }
                                m = 1;
                                int n = 0;
                                while(m < hitcounterWagneg){
                                    if((entfernenxneg[(help-1)]-m) < 1){
                                        //printf("3) speichere: (%i,%i)\n",n,entfernenyneg[(help-1)]+j);
                                        entfernenxposzwei[entfernencounterposzwei] = n;
                                        n++;
                                        entfernenyposzwei[entfernencounterposzwei] = entfernenyneg[(help-1)]+j;
                                        entfernencounterposzwei++;
                                        if(entfernencounterposzwei == entfernenposmaxzwei){
                                            entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenposmaxzwei = entfernenposmaxzwei*2;
                                        }
                                        //printf("neu in entfernen: (%i,%i)\n",n-1,entfernenyneg[(help-1)]+j);
                                        //printf("entfernen aktuelle Position: (%i,%i)\n",entfernenxposzwei[entfernencounterposzwei-1],entfernenyposzwei[entfernencounterposzwei-1]);
                                    }else{
                                        //printf("4) speichere: (%i,%i)\n",entfernenxneg[(help-1)]-m,entfernenyneg[(help-1)]+j);
                                        entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]-m;
                                        entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                                        entfernencounternegzwei++;
                                        if(entfernencounternegzwei == entfernennegmaxzwei){
                                            entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernennegmaxzwei = entfernennegmaxzwei*2;
                                        }
                                    }
                                    m++;
                                }
                                
                            }
                            hitcounterSen = 0;
                            hitcounterSenneg = 0;
                            i = 0;
                            while(1){//suche Senkrecht in pos Richtung
                                if((entfernenyneg[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterSen++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Senkrecht in neg Richtung
                                if((entfernenyneg[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterSenneg++;
                                i++;
                            }
                            if((hitcounterSen + hitcounterSenneg) >= 5){
                                //printf("Hit: Neg: Sen: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop Sen\n");
                                //printf("Treffer: Loop(%i), Neg Sen X: %i Y: %i => %i\n",durchlaeufe,entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j]);
                                entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                                entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                                entfernencounternegzwei++;
                                if(entfernencounternegzwei == entfernennegmaxzwei){
                                    entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernennegmaxzwei = entfernennegmaxzwei*2;
                                }
                                int m = 1;
                                while(m < hitcounterSen){
                                    entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                                    entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j+m;
                                    entfernencounternegzwei++;
                                    m++;
                                    if(entfernencounternegzwei == entfernennegmaxzwei){
                                        entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernennegmaxzwei = entfernennegmaxzwei*2;
                                    }
                                }
                                m = 1;
                                while(m < hitcounterSenneg){
                                    entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                                    entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j-m;
                                    entfernencounternegzwei++;
                                    m++;
                                    if(entfernencounternegzwei == entfernennegmaxzwei){
                                        entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernennegmaxzwei = entfernennegmaxzwei*2;
                                    }
                                }
                            }
                            hitcounterDiaLR = 0;
                            hitcounterDiaLRneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal LR in pos Richtung
                                if((entfernenxneg[(help-1)]+i) >= (size+1) || (entfernenyneg[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]+i][entfernenyneg[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterDiaLR++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Diagonal LR in neg Richtung
                                if((entfernenxneg[(help-1)]-i) < 1 || (entfernenyneg[(help-1)]-i+j) < 1){
                                    break;
                                }
                                if((entfernenxneg[(help-1)]-i) == 1){
                                    if((entfernenxneg[(help-1)]-i+k) < 1 || (entfernenxneg[(help-1)]-i+k) >= (size+1) || (entfernenyneg[(help-1)]-i+j-k) < 0 || (entfernenyneg[(help-1)]-i+j-k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == neg[1][entfernenyneg[(help-1)]-i+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k-1][entfernenyneg[(help-1)]-i+j-k]){
                                        hitcounterDiaLRneg++;
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[1][entfernenyneg[(help-1)]-i+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == feld[k-1][entfernenyneg[(help-1)]-i+j-k] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                        hitcounterDiaLRneg++;
                                        hitcounterDiaLRneg++;
                                    }
                                    if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k][entfernenyneg[(help-1)]-i+j-k-1]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]-i+j]){
                                        break;
                                    }
                                }
                                hitcounterDiaLRneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                                //printf("Hit: Neg: DiaLR: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop DiaLR\n");
                                //printf("Treffer: Loop(%i), Neg DiaLR X: %i Y: %i => %i\n",durchlaeufe,entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j]);
                                entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                                entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                                entfernencounternegzwei++;
                                if(entfernencounternegzwei == entfernennegmaxzwei){
                                    entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernennegmaxzwei = entfernennegmaxzwei*2;
                                }
                                int m = 1;
                                while(m < hitcounterDiaLR){
                                    entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]+m;
                                    entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j+m;
                                    entfernencounternegzwei++;
                                    m++;
                                    if(entfernencounternegzwei == entfernennegmaxzwei){
                                        entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernennegmaxzwei = entfernennegmaxzwei*2;
                                    }
                                }
                                m = 1;
                                int n = 0;
                                while(m < hitcounterDiaLRneg){
                                    if((entfernenxneg[(help-1)]-m) < 1){
                                        entfernenxposzwei[entfernencounterposzwei] = n;
                                        n++;
                                        entfernenyposzwei[entfernencounterposzwei] = entfernenyneg[(help-1)]+j+m;
                                        entfernencounterposzwei++;
                                        if(entfernencounterposzwei == entfernenposmaxzwei){
                                            entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenposmaxzwei = entfernenposmaxzwei*2;
                                        }
                                    }else{
                                        entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]-m;
                                        entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j-m;
                                        entfernencounternegzwei++;
                                        if(entfernencounternegzwei == entfernennegmaxzwei){
                                            entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernennegmaxzwei = entfernennegmaxzwei*2;
                                        }
                                    }
                                    m++;
                                }
                            }
                            hitcounterDiaRL = 0;
                            hitcounterDiaRLneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal RL in pos Richtung
                                if((entfernenxneg[(help-1)]-i) < 1 || (entfernenyneg[(help-1)]-i+j) >= (laenge+1)){
                                    break;
                                }
                                if((entfernenxneg[(help-1)]-i) == 1){
                                    //printf("3 wird verglichen mit: %i\n",neg[entfernenxneg[(help-1)]-i+k][entfernenyneg[(help-1)]+i+j+k]);
                                    if((entfernenxneg[(help-1)]-i+k) < 1 || (entfernenxneg[(help-1)]-i+k) >= (size+1) || (entfernenyneg[(help-1)]+i+j+k) < 0 || (entfernenyneg[(help-1)]+i+j+k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == neg[1][entfernenyneg[(help-1)]+i+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k-1][entfernenyneg[(help-1)]+i+j+k]){
                                        hitcounterDiaRL++;
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[1][entfernenyneg[(help-1)]+i+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == feld[k-1][entfernenyneg[(help-1)]+i+j+k] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                        hitcounterDiaRL++;
                                        hitcounterDiaRL++;
                                        //printf("erhöhe um 2\n");
                                    }
                                    if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k][entfernenyneg[(help-1)]+i+j+k+1]){
                                        break;
                                    }
                                    //printf("erhöhe um 1 (Übergang)\n");
                                    k++;
                                }else{
                                    //printf("3 wird verglichen mit: %i\n",neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j]);
                                    if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j]){
                                        break;
                                    }
                                    //printf("erhöhe um 1 (kein Übergang)\n");
                                    //printf("%i bei (%i,%i) und %ibei (%i,%i)\n",neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j],entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j],entfernenxneg[(help-1)]-i,entfernenyneg[(help-1)]+i+j);
                                }
                                hitcounterDiaRL++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            i = 0;
                            while(1){//suche Diagonal RL in neg Richtung
                                if((entfernenxneg[(help-1)]+i) >= (size+1) || (entfernenyneg[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]+i][entfernenyneg[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterDiaRLneg++;
                                i++;
                            }
                            //printf("hit DiaRL pos: %i\n", hitcounterDiaRL);
                            //printf("hit DiaRL neg: %i\n", hitcounterDiaRLneg);
                            if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                                //printf("Hit: Neg: DiaRL: Durchlauf: %i\n",durchlaeufe);
                                //printf("Treffer: Loop(%i), Neg DiaRL X: %i Y: %i => %i\n",durchlaeufe,entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j]);
                                //printf("Gefunden Loop DiaRL\n");
                                //printf("1) speichere: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                                entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                                entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                                entfernencounternegzwei++;
                                if(entfernencounternegzwei == entfernennegmaxzwei){
                                    entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernennegmaxzwei = entfernennegmaxzwei*2;
                                }
                                int m = 1;
                                int n = 0;
                                while(m < hitcounterDiaRL){
                                    if((entfernenxneg[(help-1)]-m) < 1){
                                        //printf("2) speichere: (%i,%i)\n",n,entfernenyneg[(help-1)]+j+m);
                                        entfernenxposzwei[entfernencounterposzwei] = n;
                                        n++;
                                        entfernenyposzwei[entfernencounterposzwei] = entfernenyneg[(help-1)]+j+m;
                                        entfernencounterposzwei++;
                                        if(entfernencounterposzwei == entfernenposmaxzwei){
                                            entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenposmaxzwei = entfernenposmaxzwei*2;
                                        }
                                    }else{
                                        //printf("3) speichere: (%i,%i)\n",entfernenxneg[(help-1)]-m,entfernenyneg[(help-1)]+j+m);
                                        entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]-m;
                                        entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j+m;
                                        entfernencounternegzwei++;
                                        if(entfernencounternegzwei == entfernennegmaxzwei){
                                            entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernennegmaxzwei = entfernennegmaxzwei*2;
                                        }
                                    }
                                    m++;
                                }
                                m = 1;
                                while(m < hitcounterDiaRLneg){
                                    //printf("4) speichere: (%i,%i)\n",entfernenxneg[(help-1)]+m,entfernenyneg[(help-1)]+j-m);
                                    entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]+m;
                                    entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j-m;
                                    entfernencounternegzwei++;
                                    m++;
                                    if(entfernencounternegzwei == entfernennegmaxzwei){
                                        entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernennegmaxzwei = entfernennegmaxzwei*2;
                                    }
                                }
                            }
                    }
                    help--;
                }
                help = 0;

                if(entfernencounternegzwei > 0 || entfernencounterposzwei > 0){
                    aenderungen = 1;
                }
                //printf("entfernenPOS: %i\n", entfernencounterposzwei);
                //printf("entfernenNEG: %i\n", entfernencounternegzwei);
                help = entfernencounterposzwei;
                while(help > 0){
                    feld[entfernenxposzwei[help-1]][entfernenyposzwei[help-1]] = 255;
                    //printf("Loop(1) POS X: %i Y: %i\n", entfernenxposzwei[help-1], entfernenyposzwei[help-1]);
                    help--;
                }
                help = entfernencounternegzwei;
                while(help > 0){
                    neg[entfernenxnegzwei[help-1]][entfernenynegzwei[help-1]] = 255;
                    //printf("NEG X: %i Y: %i\n", entfernenxnegzwei[help-1], entfernenynegzwei[help-1]);
                    help--;
                }

                help = entfernencounterposzwei;
                while(help > 0){
                    int k = 0;
                    while((extra[entfernenxposzwei[help-1]]-k-1) >= 0 && verw[entfernenxposzwei[help-1]] == 0){
                        //printf("3.Aktueller Block: %i mit (%i,%i), wobei k = %i\n",feld[entfernenxposzwei[help-1]][extra[entfernenxposzwei[help-1]]-k-1],entfernenxposzwei[help-1],extra[entfernenxposzwei[help-1]]-k-1,k);
                        if(feld[entfernenxposzwei[help-1]][extra[entfernenxposzwei[help-1]]-k-1] == 255){
                            memmove(feld[entfernenxposzwei[help-1]]+(extra[entfernenxposzwei[help-1]]-k-1),feld[entfernenxposzwei[help-1]]+(extra[entfernenxposzwei[help-1]]-k-1)+1,(laenge-(extra[entfernenxposzwei[help-1]]-k-1)-1)*sizeof(*feld[entfernenxposzwei[help-1]]));
                            count++;
                        }
                        k++;
                    }
                    if(count > 0){
                        extra[entfernenxposzwei[help-1]] = extra[entfernenxposzwei[help-1]] - count;
                        count = 0;
                        verw[entfernenxposzwei[help-1]] = 1;
                    }
                    help--;
                }

                help = entfernencounternegzwei;
                while(help > 0){
                    int k = 0;
                    while((extraneg[entfernenxnegzwei[help-1]]-k-1) >= 0 && verwneg[entfernenxnegzwei[help-1]] == 0){
                        //printf("3.Aktueller Block: %i mit (-%i,%i), wobei k = %i\n",neg[entfernenxnegzwei[help-1]][extraneg[entfernenxnegzwei[help-1]]-k-1],entfernenxnegzwei[help-1],extraneg[entfernenxnegzwei[help-1]]-k-1,k);
                        if(neg[entfernenxnegzwei[help-1]][extraneg[entfernenxnegzwei[help-1]]-k-1] == 255){
                            memmove(neg[entfernenxnegzwei[help-1]]+(extraneg[entfernenxnegzwei[help-1]]-k-1),neg[entfernenxnegzwei[help-1]]+(extraneg[entfernenxnegzwei[help-1]]-k-1)+1,(laenge-(extraneg[entfernenxnegzwei[help-1]]-k-1)-1)*sizeof(*neg[entfernenxnegzwei[help-1]]));
                            count++;
                        }
                        k++;
                    }
                    if(count > 0){
                        extraneg[entfernenxnegzwei[help-1]] = extraneg[entfernenxnegzwei[help-1]] - count;
                        count = 0;
                        verwneg[entfernenxnegzwei[help-1]] = 1;
                    }
                    help--;
                }
                //printf("\n");
                
                help = 0;
                entfernencounterpos = 0;
                entfernencounterneg = 0;

                memset(verw,0,(size+1)*4);
                memset(verwneg,0,(size+1)*4);

                /*
                if(aenderungen == 1){//hilfe
                    for(int i = 0;i < (size+1);i++){
                        //printf("%i\n",extra[i]);
                        if(feld[i][0] != -1){
                            //printf("%i mit i = %i\n",extra[i],i);
                            int j = 0;
                            while(feld[i][j] != -1){
                                fprintf(stdout,"%i %i %i\n",feld[i][j], i,j);
                                j++;
                            }
                        }
                        //printf("%i\n",extraneg[i]);
                        if(neg[i][0] != -1){
                            int j = 0;
                            while(neg[i][j] != -1){
                                fprintf(stdout,"%i -%i %i\n",neg[i][j], i,j);
                                j++;
                            }
                        }
                    }
                    printf("\n");
                    for(int i = 0;i < entfernencounterposzwei;i++){
                        printf("+(%i,%i)\n",entfernenxposzwei[i],entfernenyposzwei[i]);
                    }
                    printf("\n");
                    for(int i = 0;i < entfernencounternegzwei;i++){
                        printf("-(%i,%i)\n",entfernenxnegzwei[i],entfernenynegzwei[i]);
                    }
                    printf("3\n");
                }
                */
            }

            //loop vergleich ende

                durchlaeufe++;
            }
        }
        if(xko < 0){
            negx = (int)fabsf(xko);
            if(negx > size){//weiterhier
                //nur x erhöhen
                int alt = 0;
                if(negx < 1024){
                    alt = size;
                    size = 1024;
                }
                if(negx >= 1024 && negx < 2048){
                    alt = size;
                    size = 2048;
                }
                if(negx >= 2048 && negx < 4096){
                    alt = size;
                    size = 4096;
                }
                if(negx >= 4096 && negx < 8192){
                    alt = size;
                    size = 8192;
                }
                if(negx >= 8192 && negx < 16384){
                    alt = size;
                    size = 16384;
                }
                if(negx >= 16384 && negx < 32768){
                    alt = size;
                    size = 32768;
                }
                if(negx >= 32768 && negx < 65536){
                    alt = size;
                    size = 65536;
                }
                if(negx >= 65536 && negx < 131072){
                    alt = size;
                    size = 131072;
                }
                if(negx >= 131072 && negx < 262144){
                    alt = size;
                    size = 262144;
                }
                if(negx >= 262144 && negx < 524288){
                    alt = size;
                    size = 524288;
                }
                if(negx >= 524288 && negx <= 1048576){
                    alt = size;
                    size = 1048576;
                }
                zwischenspeicher = (int *)malloc(sizeof(int)*(laenge+1));

                feld = (int**)realloc(feld, (size+1)*sizeof(int*));
                neg = (int**)realloc(neg, (size+1)*sizeof(int*));

                for(int i = alt+1; i < (size+1); i++){
                    feld[i] = NULL;
                    neg[i] = NULL;
                }

                int on = 0;

                for (int i = 0; i < (size+1); i++){
                    if(feld[i] != NULL){
                        on = 1;
                    }
                    if(on == 1){
                        memmove(zwischenspeicher,feld[i],(laenge+1)*4);
                    }
                    feld[i] = (int*)realloc(feld[i], (laenge+1)*sizeof(int));
                    memset(feld[i],-1,(laenge+1)*4);
                    if(on == 1){
                        memmove(feld[i],zwischenspeicher,(laenge+1)*4);
                    }
                    on = 0;

                    if(neg[i] != NULL){
                        on = 1;
                    }
                    if(on == 1){
                        memmove(zwischenspeicher,neg[i],(laenge+1)*4);
                    }
                    neg[i] = (int*)realloc(neg[i], (laenge+1)*sizeof(int));
                    memset(neg[i],-1,(laenge+1)*4);
                    if(on == 1){
                        memmove(neg[i],zwischenspeicher,(laenge+1)*4);
                    }
                    on = 0;
                }
                //free(zwischenspeicher);
                free(zwischenspeicher);
                zwischenspeicher = (int *)malloc(sizeof(int)*(alt+1));
                memmove(zwischenspeicher,extra,(alt+1)*4);
                extra = (int*)realloc(extra,(size+1)*sizeof(int));
                memset(extra,0,(size+1)*4);
                memmove(extra,zwischenspeicher,(alt+1)*4);

                memmove(zwischenspeicher,extraneg,(alt+1)*4);
                extraneg = (int*)realloc(extraneg,(size+1)*sizeof(int));
                memset(extraneg,0,(size+1)*4);
                memmove(extraneg,zwischenspeicher,(alt+1)*4);
                free(zwischenspeicher);

                verw = (int*)realloc(verw,(size+1)*sizeof(int));
                verwneg = (int*)realloc(verw,(size+1)*sizeof(int));
                memset(verw,0,(size+1)*4);
                memset(verwneg,0,(size+1)*4);
            }
            //printf("..\n");
            neg[negx][extraneg[negx]] = farbe;
            extraneg[negx]++;
            //printf("extraneg[negx] = %i\n",extraneg[negx]);
            if(extraneg[negx] == laenge){//weiterhier
                //nur y erhöhen

                zwischenspeicher = (int *)malloc(sizeof(int)*(laenge+1));

                for (int i = 0; i < (size+1); i++){
                    memmove(zwischenspeicher,feld[i],(laenge+1)*4);
                    feld[i] = (int*)realloc(feld[i], (laenge*2+1)*sizeof(int));
                    memset(feld[i],-1,(laenge*2+1)*4);
                    memmove(feld[i],zwischenspeicher,(laenge+1)*4);

                    memmove(zwischenspeicher,neg[i],(laenge+1)*4);
                    neg[i] = (int*)realloc(neg[i], (laenge*2+1)*sizeof(int));
                    memset(neg[i],-1,(laenge*2+1)*4);
                    memmove(neg[i],zwischenspeicher,(laenge+1)*4);
                }

                laenge = laenge*2;
                free(zwischenspeicher);
            }
            
            hitcounterWag = 0;
            hitcounterWagneg = 0;
            l = 0;
            k = 1;
            while(1){//suche Wagerecht in pos Richtung
                if((negx+l) >= (size+1)){
                    break;
                }
                if(neg[negx][extraneg[negx]-1] != neg[negx+l][extraneg[negx]-1]){
                    break;
                }
                hitcounterWag++;
                l++;
            }
            l = 0;
            while(1){//suche Wagerecht in neg Richtung
                if((negx-l) < 0){
                    break;
                }
                if((negx-l) == 1){
                    if((negx-l+k) < 0 || (negx-l+k) >= (size+1)){
                        break;
                    }
                    if(k == 1 && neg[negx][extraneg[negx]-1] == neg[1][extraneg[negx]-1] && neg[negx][extraneg[negx]-1] != feld[k-1][extraneg[negx]-1]){
                        hitcounterWagneg++;
                        break;
                    }
                    if(k == 1 && neg[negx][extraneg[negx]-1] == feld[k-1][extraneg[negx]-1] && neg[negx][extraneg[negx]-1] == neg[1][extraneg[negx]-1]){
                        hitcounterWagneg++;
                        hitcounterWagneg++;
                    }
                    if(k == 1 && (neg[negx][extraneg[negx]-1] != neg[1][extraneg[negx]-1] || neg[negx][extraneg[negx]-1] != feld[k][extraneg[negx]-1])){
                        break;
                    }
                    //davor k++ hier
                    if(neg[negx][extraneg[negx]-1] != feld[k][extraneg[negx]-1]){
                        break;
                    }
                    k++;
                }else{
                    if(neg[negx][extraneg[negx]-1] != neg[negx-l][extraneg[negx]-1]){
                        break;
                    }
                }
                hitcounterWagneg++;
                if(k == 1){
                    l++;
                }
            }

            if((hitcounterWag + hitcounterWagneg) >= 5){
                //printf("Hit: Neg: Wag: Durchlauf: %i\n",durchlaeufe);
                entfernenxneg[entfernencounterneg] = negx;
                entfernenyneg[entfernencounterneg] = extraneg[negx]-1;
                entfernencounterneg++;
                if(entfernencounterneg == entfernennegmax){
                    entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                    entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                    entfernennegmax = entfernennegmax*2;
                }
                //loop für hitcounter
                for(int m = 1;m < hitcounterWag;m++){
                    entfernenxneg[entfernencounterneg] = negx+m;
                    entfernenyneg[entfernencounterneg] = extraneg[negx]-1;
                    entfernencounterneg++;
                    if(entfernencounterneg == entfernennegmax){
                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                        entfernennegmax = entfernennegmax*2;
                    }
                }
                //loop für hitcounterneg
                int n = 0;
                for(int m = 1;m < hitcounterWagneg;m++){
                    if((negx-m) < 1){
                        entfernenxpos[entfernencounterpos] = n;
                        entfernenypos[entfernencounterpos] = extraneg[negx]-1;
                        entfernencounterpos++;
                        n++;
                        if(entfernencounterpos == entfernenposmax){
                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                            entfernenposmax = entfernenposmax*2;
                        }
                        //weiter
                    }
                    if((negx-m) >= 1){
                        entfernenxneg[entfernencounterneg] = negx-m;
                        entfernenyneg[entfernencounterneg] = extraneg[negx]-1;
                        entfernencounterneg++;
                        if(entfernencounterneg == entfernennegmax){
                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                            entfernennegmax = entfernennegmax*2;
                        }
                    }
                }
                //printf("hi Wag-\n");
            }
            hitcounterSen = 0;
            hitcounterSenneg = 0;
            l = 0;
            k = 1;
            while(1){//suche Senkrecht in pos Richtung
                if((extraneg[negx]-1+l) >= (laenge+1)){
                    break;
                }
                if(neg[negx][extraneg[negx]-1] != neg[negx][extraneg[negx]-1+l]){
                    break;
                }
                hitcounterSen++;
                l++;
            }
            l = 0;
            while(1){//suche Senkrecht in neg Richtung
                if((extraneg[negx]-1-l) < 0){
                    break;
                }
                if(neg[negx][extraneg[negx]-1] != neg[negx][extraneg[negx]-1-l]){
                    break;
                }
                hitcounterSenneg++;
                l++;
            }
            if((hitcounterSen + hitcounterSenneg) >= 5){
                //printf("Hit: Neg: Sen: Durchlauf: %i\n",durchlaeufe);
                entfernenxneg[entfernencounterneg] = negx;
                entfernenyneg[entfernencounterneg] = extraneg[negx]-1;
                entfernencounterneg++;
                if(entfernencounterneg == entfernennegmax){
                    entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                    entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                    entfernennegmax = entfernennegmax*2;
                }
                //loop für hitcounter
                for(int m = 1;m < hitcounterSen;m++){
                    entfernenxneg[entfernencounterneg] = negx;
                    entfernenyneg[entfernencounterneg] = extraneg[negx]-1+m;
                    entfernencounterneg++;
                    if(entfernencounterneg == entfernennegmax){
                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                        entfernennegmax = entfernennegmax*2;
                    }
                }
                //loop für hitcounterneg
                for(int m = 1;m < hitcounterSenneg;m++){
                    entfernenxneg[entfernencounterneg] = negx;
                    entfernenyneg[entfernencounterneg] = extraneg[negx]-1-m;
                    entfernencounterneg++;
                    if(entfernencounterneg == entfernennegmax){
                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                        entfernennegmax = entfernennegmax*2;
                    }
                }
                //printf("hi Sen-\n");
            }
            hitcounterDiaLR = 0;
            hitcounterDiaLRneg = 0;
            l = 0;
            k = 1;
            while(1){//suche Diagonal LR in pos Richtung
                if((negx+l) >= (size+1) || (extraneg[negx]-1+l) >= (laenge+1)){
                    break;
                }
                if(neg[negx][extraneg[negx]-1] != neg[negx+l][extraneg[negx]-1+l]){
                    break;
                }
                hitcounterDiaLR++;
                l++;
            }
            l = 0;
            while(1){//suche Diagonal LR in neg Richtung
                if((negx-l) < 0 || (extraneg[negx]-1-l) < 0){
                    break;
                }
                if((negx-l) == 1){
                    if((negx-l+k) < 0 || (negx-l+k) >= (size+1) || (extraneg[negx]-1-l-k) < 0 || (extraneg[negx]-1-l-k) >= (laenge+1)){
                        break;
                    }
                    if(k == 1 && neg[negx][extraneg[negx]-1] == neg[1][extraneg[negx]-1-l] && neg[negx][extraneg[negx]-1] != feld[k-1][extraneg[negx]-1-l+k]){
                        hitcounterDiaLRneg++;
                        break;
                    }
                    if(k == 1 && neg[negx][extraneg[negx]-1] == feld[k-1][extraneg[negx]-1-l-k] && neg[negx][extraneg[negx]-1] == neg[1][extraneg[negx]-1-l]){
                        hitcounterDiaLRneg++;
                        hitcounterDiaLRneg++;
                    }
                    if(k ==1 && (neg[negx][extraneg[negx]-1] != neg[1][extraneg[negx]-1-l] || neg[negx][extraneg[negx]-1] != feld[k][extraneg[negx]-1-l+k])){
                        break;
                    }
                    //davor k++ hier
                    if(neg[negx][extraneg[negx]-1] != feld[k][extraneg[negx]-1-l-k]){
                        break;
                    }
                    k++;
                }else{
                    if(neg[negx][extraneg[negx]-1] != neg[negx-l][extraneg[negx]-1-l]){
                        break;
                    }
                }
                hitcounterDiaLRneg++;
                if(k == 1){
                    l++;
                }
            }
            if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                //printf("Hit: Neg: DiaLR: Durchlauf: %i\n",durchlaeufe);
                entfernenxneg[entfernencounterneg] = negx;
                entfernenyneg[entfernencounterneg] = extraneg[negx]-1;
                entfernencounterneg++;
                if(entfernencounterneg == entfernennegmax){
                    entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                    entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                    entfernennegmax = entfernennegmax*2;
                }
                //loop für hitcounter
                for(int m = 1;m < hitcounterDiaLR;m++){
                    entfernenxneg[entfernencounterneg] = negx+m;
                    entfernenyneg[entfernencounterneg] = extraneg[negx]-1+m;
                    entfernencounterneg++;
                    if(entfernencounterneg == entfernennegmax){
                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                        entfernennegmax = entfernennegmax*2;
                    }
                }
                //loop für hitcounterneg
                int n = 0;
                for(int m = 1;m < hitcounterDiaLRneg;m++){
                    if((negx-m) < 1){
                        entfernenxpos[entfernencounterpos] = n;
                        entfernenypos[entfernencounterpos] = extraneg[negx]-1-m;
                        entfernencounterpos++;
                        n++;
                        if(entfernencounterpos == entfernenposmax){
                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                            entfernenposmax = entfernenposmax*2;
                        }
                        //weiter
                    }
                    if((negx-m) >= 1){ 
                        entfernenxneg[entfernencounterneg] = negx-m;
                        entfernenyneg[entfernencounterneg] = extraneg[negx]-1-m;
                        entfernencounterneg++;
                        if(entfernencounterneg == entfernennegmax){
                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                            entfernennegmax = entfernennegmax*2;
                        }
                    }
                }
                //printf("hi LR-\n");
            }
            hitcounterDiaRL = 0;
            hitcounterDiaRLneg = 0;
            l = 0;
            k = 1;
            while(1){//suche Diagonal RL in pos Richtung (bei (j+l) >= (laenge+1) war es davor ein -)
                if((negx-l) < 0 || (extraneg[negx]-1+l) >= (laenge+1)){
                    break;
                }
                if((negx-l) == 1){
                    if((negx-l+k) < 0 || (negx-l+k) >= (size+1) || (extraneg[negx]-1+l+k) < 0 || (extraneg[negx]-1+l+k) >= (laenge+1)){
                        break;
                    }
                    if(k == 1 && neg[negx][extraneg[negx]-1] == neg[1][extraneg[negx]-1+l] && neg[negx][extraneg[negx]-1] != feld[k-1][extraneg[negx]-1+l+k]){//neu
                        hitcounterDiaRL++;
                        break;
                    }
                    if(k == 1 && neg[negx][extraneg[negx]-1] == feld[k-1][extraneg[negx]-1+l+k] && neg[negx][extraneg[negx]-1] == neg[1][extraneg[negx]-1+l]){//bearbeitet
                        hitcounterDiaRL++;
                        hitcounterDiaRL++;
                    }
                    if(k == 1 && (neg[negx][extraneg[negx]-1] != feld[k][extraneg[negx]-1+l+k] || neg[negx][extraneg[negx]-1] != neg[1][extraneg[negx]-1+l])){//neu
                        break;
                    }
                    //davor k++ hier
                    if(neg[negx][extraneg[negx]-1] != feld[k][extraneg[negx]-1+l+k]){
                        break;
                    }
                    k++;
                }else{
                    if(neg[negx][extraneg[negx]-1] != neg[negx-l][extraneg[negx]-1+l]){
                        break;
                    }
                }
                hitcounterDiaRL++;
                if(k == 1){
                    l++;
                }
            }
            l = 0;
            while(1){//suche Diagonal RL in neg Richtung
                if((negx+l) >= (size+1) || (extraneg[negx]-1-l) < 0){
                    break;
                }
                if(neg[negx][extraneg[negx]-1] != neg[negx+l][extraneg[negx]-1-l]){
                    break;
                }
                hitcounterDiaRLneg = hitcounterDiaRLneg + 1;
                l++;
            }
            if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                //printf("Hit: Neg: DiaRL: Durchlauf: %i\n",durchlaeufe);
                entfernenxneg[entfernencounterneg] = negx;
                entfernenyneg[entfernencounterneg] = extraneg[negx]-1;
                entfernencounterneg++;
                if(entfernencounterneg == entfernennegmax){
                    entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                    entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                    entfernennegmax = entfernennegmax*2;
                }
                //loop für hitcounter
                int n = 0;
                for(int m = 1;m < hitcounterDiaRL;m++){
                    if((negx-m) < 1){//davor (negx+m)
                        entfernenxpos[entfernencounterpos] = n;
                        entfernenypos[entfernencounterpos] = extraneg[negx]-1+m;
                        entfernencounterpos++;
                        n++;
                        if(entfernencounterpos == entfernenposmax){
                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                            entfernenposmax = entfernenposmax*2;
                        }
                        //weiter
                    }
                    if((negx-m) >= 1){
                        entfernenxneg[entfernencounterneg] = negx-m;
                        entfernenyneg[entfernencounterneg] = extraneg[negx]-1+m;
                        entfernencounterneg++;
                        if(entfernencounterneg == entfernennegmax){
                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                            entfernennegmax = entfernennegmax*2;
                        }
                    }
                }
                //loop für hitcounterneg
                for(int m = 1;m < hitcounterDiaRLneg;m++){
                    entfernenxneg[entfernencounterneg] = negx+m;
                    entfernenyneg[entfernencounterneg] = extraneg[negx]-1-m;
                    entfernencounterneg++;
                    if(entfernencounterneg == entfernennegmax){
                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                        entfernennegmax = entfernennegmax*2;
                    }
                }
                //printf("hi RL-\n");
            }

            durchlaeufe = 1;

            if(entfernencounterneg > 0){//neu || entfernencounterpos > 0 entfernt
                aenderungen = 1;
            }
            //printf("entfernencounterneg: %i\n", entfernencounterneg);

            help = entfernencounterneg;
            while(help > 0){
                neg[entfernenxneg[help-1]][entfernenyneg[help-1]] = 255;
                //printf("NEG X: %i Y: %i\n", entfernenxneg[help-1], entfernenyneg[help-1]);
                help--;
            }
            help = entfernencounterpos;
            while(help > 0){
                feld[entfernenxpos[help-1]][entfernenypos[help-1]] = 255;
                //printf("POS X: %i Y: %i\n", entfernenxpos[help-1], entfernenypos[help-1]);
                help--;
            }
            help = entfernencounterpos;
            while(help > 0){
                int k = 0;
                while((extra[entfernenxpos[help-1]]-k-1) >= 0 && verw[entfernenxpos[help-1]] == 0){
                    //printf("4.Aktueller Block: %i mit (%i,%i), wobei k = %i\n",feld[entfernenxpos[help-1]][extra[entfernenxpos[help-1]]-k-1],entfernenxpos[help-1],extra[entfernenxpos[help-1]]-k-1,k);
                    if(feld[entfernenxpos[help-1]][extra[entfernenxpos[help-1]]-k-1] == 255){
                        memmove(feld[entfernenxpos[help-1]]+(extra[entfernenxpos[help-1]]-k-1),feld[entfernenxpos[help-1]]+(extra[entfernenxpos[help-1]]-k-1)+1,(laenge-(extra[entfernenxpos[help-1]]-k-1)-1)*sizeof(*feld[entfernenxpos[help-1]]));
                        count++;
                    }
                    k++;
                }
                if(count > 0){
                    extra[entfernenxpos[help-1]] = extra[entfernenxpos[help-1]] - count;
                    count = 0;
                    verw[entfernenxpos[help-1]] = 1;
                }
                help--;
            }

            help = entfernencounterneg;
            while(help > 0){
                int k = 0;
                while((extraneg[entfernenxneg[help-1]]-k-1) >= 0 && verwneg[entfernenxneg[help-1]] == 0){
                    //printf("4.Aktueller Block: %i mit (-%i,%i), wobei k = %i\n",neg[entfernenxneg[help-1]][extraneg[entfernenxneg[help-1]]-k-1],entfernenxneg[help-1],extraneg[entfernenxneg[help-1]]-k-1,k);
                    if(neg[entfernenxneg[help-1]][extraneg[entfernenxneg[help-1]]-k-1] == 255){
                        memmove(neg[entfernenxneg[help-1]]+(extraneg[entfernenxneg[help-1]]-k-1),neg[entfernenxneg[help-1]]+(extraneg[entfernenxneg[help-1]]-k-1)+1,(laenge-(extraneg[entfernenxneg[help-1]]-k-1)-1)*sizeof(*neg[entfernenxneg[help-1]]));
                        count++;
                    }
                    k++;
                }
                if(count > 0){
                    extraneg[entfernenxneg[help-1]] = extraneg[entfernenxneg[help-1]] - count;
                    count = 0;
                    verwneg[entfernenxneg[help-1]] = 1;
                }
                help--;
            }
            //printf("\n");

            memset(verw,0,(size+1)*4);
            memset(verwneg,0,(size+1)*4);

            /*
            if(aenderungen == 1){//hilfe
                for(int i = 0;i < (size+1);i++){
                    //printf("%i\n",extra[i]);
                    if(feld[i][0] != -1){
                        //printf("%i mit i = %i\n",extra[i],i);
                        int j = 0;
                        while(feld[i][j] != -1){
                            fprintf(stdout,"%i %i %i\n",feld[i][j], i,j);
                            j++;
                        }
                    }
                    //printf("%i\n",extraneg[i]);
                    if(neg[i][0] != -1){
                        int j = 0;
                        while(neg[i][j] != -1){
                            fprintf(stdout,"%i -%i %i\n",neg[i][j], i,j);
                            j++;
                        }
                    }
                }
                printf("\n");
                for(int i = 0;i < entfernencounterpos;i++){
                    printf("+(%i,%i)\n",entfernenxpos[i],entfernenypos[i]);
                }
                printf("\n");
                for(int i = 0;i < entfernencounterneg;i++){
                    printf("-(%i,%i)\n",entfernenxneg[i],entfernenyneg[i]);
                }
                printf("4\n");
            }
            */
            
            while(1){
                //printf("Aendrungen: %i\n",aenderungen);
                if(aenderungen == 0){
                    break;
                }else{
                    aenderungen = 0;
                }

                //loop vergleich start
                //printf("NegCounter davor 621: %i\n", entfernencounterneg);

                if((durchlaeufe % 2) == 0){
                    if(durchlaeufe == 1000000){
                        durchlaeufe = 2;
                    }
                    //printf("Gerade Anzahl an Durchläufen.\n");
                    help = entfernencounterposzwei;
                    while(help > 0){
                        int i = 0;
                        int k = 1;
                        for(int j = 0;(j+entfernenyposzwei[(help-1)]) < (laenge+1);j++){
                            if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1){
                                break;
                            }
                            hitcounterWag = 0;
                            hitcounterWagneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Wagerecht in pos Richtung
                                if((entfernenxposzwei[(help-1)]+i) >= (size+1)){
                                    break;
                                }
                                if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]+i][entfernenyposzwei[(help-1)]+j]){
                                    break;
                                }
                                hitcounterWag++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Wagerecht in neg Richtung
                                if((entfernenxposzwei[(help-1)]-i) < 0){
                                    break;
                                }
                                if((entfernenxposzwei[(help-1)]-i) == 0){
                                    if((entfernenxposzwei[(help-1)]-i+k) < 0 || (entfernenxposzwei[(help-1)]-i+k) >= (size+1)){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == feld[0][entfernenyposzwei[(help-1)]+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k][entfernenyposzwei[(help-1)]+j]){
                                        hitcounterWagneg++;
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[0][entfernenyposzwei[(help-1)]+j]){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == neg[k][entfernenyposzwei[(help-1)]+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                        hitcounterWagneg++;
                                        hitcounterWagneg++;
                                    }
                                    if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k+1][entfernenyposzwei[(help-1)]+j]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]-i][entfernenyposzwei[(help-1)]+j]){
                                        break;
                                    }
                                }
                                hitcounterWagneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            if((hitcounterWag + hitcounterWagneg) >= 5){
                                //printf("Hit: Feld: Wag: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop(0) Wag\n");
                                //printf("Treffer: Loop(%i), Feld Wag X: %i Y: %i => %i\n",durchlaeufe,entfernenxposzwei[(help-1)],entfernenyposzwei[(help-1)]+j,feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j]);
                                entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                                entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                                entfernencounterpos++;
                                if(entfernencounterpos == entfernenposmax){
                                    entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenposmax = entfernenposmax*2;
                                }
                                int m = 1;
                                while(m < hitcounterWag){
                                    entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]+m;
                                    entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                                    entfernencounterpos++;
                                    m++;
                                    if(entfernencounterpos == entfernenposmax){
                                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenposmax = entfernenposmax*2;
                                    }
                                }
                                m = 1;
                                int n = 1;//vielleicht = 1?
                                while(m < hitcounterWagneg){
                                    if((entfernenxposzwei[(help-1)]-m) < 0){
                                        entfernenxneg[entfernencounterneg] = n;
                                        n++;
                                        entfernenyneg[entfernencounterneg] = entfernenyposzwei[(help-1)]+j;
                                        entfernencounterneg++;
                                        if(entfernencounterneg == entfernennegmax){
                                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernennegmax = entfernennegmax*2;
                                        }
                                    }else{
                                        entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]-m;
                                        entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                                        entfernencounterpos++;
                                        if(entfernencounterpos == entfernenposmax){
                                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenposmax = entfernenposmax*2;
                                        }
                                    }
                                    m++;
                                }
                                
                            }
                            hitcounterSen = 0;
                            hitcounterSenneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Senkrecht in pos Richtung
                                if((entfernenyposzwei[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterSen++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Senkrecht in neg Richtung
                                if((entfernenyposzwei[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterSenneg++;
                                i++;
                            }
                            if((hitcounterSen + hitcounterSenneg) >= 5){
                                //printf("Hit: Feld: Sen: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop(0) Sen\n");
                                //printf("Treffer: Loop(%i), Feld Sen X: %i Y: %i => %i\n",durchlaeufe,entfernenxposzwei[(help-1)],entfernenyposzwei[(help-1)]+j,feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j]);
                                entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                                entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                                entfernencounterpos++;
                                if(entfernencounterpos == entfernenposmax){
                                    entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenposmax = entfernenposmax*2;
                                }
                                int m = 1;
                                while(m < hitcounterSen){
                                    entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                                    entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j+m;
                                    entfernencounterpos++;
                                    m++;
                                    if(entfernencounterpos == entfernenposmax){
                                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenposmax = entfernenposmax*2;
                                    }
                                }
                                m = 1;
                                while(m < hitcounterSenneg){
                                    entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                                    entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j-m;
                                    entfernencounterpos++;
                                    m++;
                                    if(entfernencounterpos == entfernenposmax){
                                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenposmax = entfernenposmax*2;
                                    }
                                }
                            }
                            hitcounterDiaLR = 0;
                            hitcounterDiaLRneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal LR in pos Richtung
                                if((entfernenxposzwei[(help-1)]+i) >= (size+1) || (entfernenyposzwei[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]+i][entfernenyposzwei[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterDiaLR++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Diagonal LR in neg Richtung
                                if((entfernenxposzwei[(help-1)]-i) < 0 || (entfernenyposzwei[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if((entfernenxposzwei[(help-1)]-i) == 0){
                                    if((entfernenxposzwei[(help-1)]-i+k) < 0 || (entfernenxposzwei[(help-1)]-i+k) >= (size+1) || (entfernenyposzwei[(help-1)]-i+j-k) < 0 || (entfernenyposzwei[(help-1)]-i+j-k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == feld[0][entfernenyposzwei[(help-1)]-i+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k][entfernenyposzwei[(help-1)]-i+j-k]){
                                        hitcounterDiaLRneg++;
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[0][entfernenyposzwei[(help-1)]-i+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == neg[k][entfernenyposzwei[(help-1)]-i+j-k] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                        hitcounterDiaLRneg++;
                                        hitcounterDiaLRneg++;
                                    }
                                    if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k+1][entfernenyposzwei[(help-1)]-i+j-k-1]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]-i][entfernenyposzwei[(help-1)]-i+j]){
                                        break;
                                    }
                                }
                                hitcounterDiaLRneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                                //printf("Hit: Feld: DiaLR: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop(0) DiaLR\n");
                                //printf("Treffer: Loop(%i), Feld DiaLR X: %i Y: %i => %i\n",durchlaeufe,entfernenxposzwei[(help-1)],entfernenyposzwei[(help-1)]+j,feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j]);
                                entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                                entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                                entfernencounterpos++;
                                if(entfernencounterpos == entfernenposmax){
                                    entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenposmax = entfernenposmax*2;
                                }
                                int m = 1;
                                while(m < hitcounterDiaLR){
                                    entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]+m;
                                    entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j+m;
                                    entfernencounterpos++;
                                    m++;
                                    if(entfernencounterpos == entfernenposmax){
                                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenposmax = entfernenposmax*2;
                                    }
                                }
                                m = 1;
                                int n = 1;//vielleicht = 1?
                                while(m < hitcounterDiaLRneg){
                                    if((entfernenxposzwei[(help-1)]-m) < 0){
                                        entfernenxneg[entfernencounterneg] = n;
                                        n++;
                                        entfernenyneg[entfernencounterneg] = entfernenyposzwei[(help-1)]+j+m;
                                        entfernencounterneg++;
                                        if(entfernencounterneg == entfernennegmax){
                                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernennegmax = entfernennegmax*2;
                                        }
                                    }else{
                                        entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]-m;
                                        entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j-m;
                                        entfernencounterpos++;
                                        if(entfernencounterpos == entfernenposmax){
                                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenposmax = entfernenposmax*2;
                                        }
                                    }
                                    m++;
                                }
                            }
                            hitcounterDiaRL = 0;
                            hitcounterDiaRLneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal RL in pos Richtung
                                if((entfernenxposzwei[(help-1)]-i) < 0 || (entfernenyposzwei[(help-1)]-i+j) >= (laenge+1)){
                                    break;
                                }
                                if((entfernenxposzwei[(help-1)]-i) == 0){
                                    if((entfernenxposzwei[(help-1)]-i+k) < 0 || (entfernenxposzwei[(help-1)]-i+k) >= (size+1) || (entfernenyposzwei[(help-1)]+i+j+k) < 0 || (entfernenyposzwei[(help-1)]+i+j+k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == feld[0][entfernenyposzwei[(help-1)]+i+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k][entfernenyposzwei[(help-1)]+i+j+k]){
                                        hitcounterDiaRL++;
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[0][entfernenyposzwei[(help-1)]+i+j] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == neg[k][entfernenyposzwei[(help-1)]+i+j+k] && feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != -1){
                                        hitcounterDiaRL++;
                                        hitcounterDiaRL++;
                                    }
                                    if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != neg[k+1][entfernenyposzwei[(help-1)]+i+j+k+1]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]-i][entfernenyposzwei[(help-1)]+i+j]){
                                        break;
                                    }
                                }
                                hitcounterDiaRL++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            i = 0;
                            while(1){//suche Diagonal RL in neg Richtung
                                if((entfernenxposzwei[(help-1)]+i) >= (size+1) || (entfernenyposzwei[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] == -1 || feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j] != feld[entfernenxposzwei[(help-1)]+i][entfernenyposzwei[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterDiaRLneg++;
                                i++;
                            }
                            if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                                //printf("Hit: Feld: DiaRL: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop(0) DiaRL\n");
                                //printf("Treffer: Loop(%i), Feld DiaRL X: %i Y: %i => %i\n",durchlaeufe,entfernenxposzwei[(help-1)],entfernenyposzwei[(help-1)]+j,feld[entfernenxposzwei[(help-1)]][entfernenyposzwei[(help-1)]+j]);
                                entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)];
                                entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j;
                                entfernencounterpos++;
                                if(entfernencounterpos == entfernenposmax){
                                    entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                    entfernenposmax = entfernenposmax*2;
                                }
                                int m = 1;
                                int n = 1;//vielleicht = 1?
                                while(m < hitcounterDiaRL){
                                    if((entfernenxposzwei[(help-1)]-m) < 0){
                                        entfernenxneg[entfernencounterneg] = n;
                                        n++;
                                        entfernenyneg[entfernencounterneg] = entfernenyposzwei[(help-1)]+j+m;
                                        entfernencounterneg++;
                                        if(entfernencounterneg == entfernennegmax){
                                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernennegmax = entfernennegmax*2;
                                        }
                                    }else{
                                        entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]-m;
                                        entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j+m;
                                        entfernencounterpos++;
                                        if(entfernencounterpos == entfernenposmax){
                                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenposmax = entfernenposmax*2;
                                        }
                                    }
                                    m++;
                                }
                                m = 1;
                                while(m < hitcounterDiaRLneg){
                                    entfernenxpos[entfernencounterpos] = entfernenxposzwei[(help-1)]+m;
                                    entfernenypos[entfernencounterpos] = entfernenyposzwei[(help-1)]+j-m;
                                    entfernencounterpos++;
                                    m++;
                                    if(entfernencounterpos == entfernenposmax){
                                        entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                        entfernenposmax = entfernenposmax*2;
                                    }
                                }
                            }
                        }
                        help--;
                    }
                    
                    help = entfernencounternegzwei;
                    while(help > 0){
                        int i = 0;
                        int k = 1;
                        for(int j = 0;(j+entfernenynegzwei[(help-1)]) < (laenge+1);j++){
                            if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1){
                                break;
                            }
                            //printf("Aktuelles Neg: X: %i Y: %i Farbe: %i\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j]);
                            hitcounterWag = 0;
                            hitcounterWagneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Wagerecht in pos Richtung
                                if((entfernenxnegzwei[(help-1)]+i) >= (size+1)){
                                    break;
                                }
                                if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]+i][entfernenynegzwei[(help-1)]+j]){
                                    break;
                                }
                                hitcounterWag++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Wagerecht in neg Richtung
                                if((entfernenxnegzwei[(help-1)]-i) < 1){
                                    //printf("break 1\n");
                                    break;
                                }
                                if((entfernenxnegzwei[(help-1)]-i) == 1){
                                    if((entfernenxnegzwei[(help-1)]-i+k) < 1 || (entfernenxnegzwei[(help-1)]-i+k) >= (size+1)){
                                        //printf("break 2\n");
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == neg[1][entfernenynegzwei[(help-1)]+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k-1][entfernenynegzwei[(help-1)]+j]){
                                        hitcounterWagneg++;
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[1][entfernenynegzwei[(help-1)]+j]){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == feld[k-1][entfernenynegzwei[(help-1)]+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                        //printf("hi\n");
                                        hitcounterWagneg++;
                                        hitcounterWagneg++;
                                    }
                                    if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k][entfernenynegzwei[(help-1)]+j]){
                                        //printf("break 3\n");
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]-i][entfernenynegzwei[(help-1)]+j]){
                                        //printf("break 4\n");
                                        break;
                                    }
                                }
                                hitcounterWagneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            //printf("Hit Wag: %i\n", hitcounterWag);
                            //printf("Hit Wag Neg: %i\n", hitcounterWagneg);
                            if((hitcounterWag + hitcounterWagneg) >= 5){
                                //printf("Hit: Neg: Wag: Durchlauf: %i\n",durchlaeufe);
                                //printf("Treffer: Loop(%i), Neg Wag X: %i Y: %i => %i\n",durchlaeufe,entfernenxnegzwei[(help-1)],entfernenynegzwei[(help-1)]+j,neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j]);
                                //printf("Gefunden Loop(0) Wag\n");
                                //printf("1) speichere: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                                entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                                entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                                entfernencounterneg++;
                                if(entfernencounterneg == entfernennegmax){
                                    entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernennegmax = entfernennegmax*2;
                                }
                                //printf("entfernt 982\n");
                                //printf("neu in neg entfernen: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                                //printf("entfernen NEG aktuelle Position: (%i,%i)\n",entfernenxnegzwei[entfernencounternegzwei-1],entfernenynegzwei[entfernencounternegzwei-1]);
                                int m = 1;
                                while(m < hitcounterWag){
                                    //printf("2) speichere: (%i,%i)\n",entfernenxneg[(help-1)]+m,entfernenyneg[(help-1)]+j);
                                    entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]+m;
                                    entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                                    entfernencounterneg++;
                                    //printf("entfernt 990\n");
                                    m++;
                                    if(entfernencounterneg == entfernennegmax){
                                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernennegmax = entfernennegmax*2;
                                    }
                                }
                                m = 1;
                                int n = 0;
                                while(m < hitcounterWagneg){
                                    if((entfernenxnegzwei[(help-1)]-m) < 1){
                                        //printf("3) speichere: (%i,%i)\n",n,entfernenyneg[(help-1)]+j);
                                        entfernenxpos[entfernencounterpos] = n;
                                        n++;
                                        entfernenypos[entfernencounterpos] = entfernenynegzwei[(help-1)]+j;
                                        entfernencounterpos++;
                                        if(entfernencounterpos == entfernenposmax){
                                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenposmax = entfernenposmax*2;
                                        }
                                        //printf("neu in entfernen: (%i,%i)\n",n-1,entfernenyneg[(help-1)]+j);
                                        //printf("entfernen aktuelle Position: (%i,%i)\n",entfernenxposzwei[entfernencounterposzwei-1],entfernenyposzwei[entfernencounterposzwei-1]);
                                    }else{
                                        //printf("4) speichere: (%i,%i)\n",entfernenxneg[(help-1)]-m,entfernenyneg[(help-1)]+j);
                                        entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]-m;
                                        entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                                        entfernencounterneg++;
                                        if(entfernencounterneg == entfernennegmax){
                                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernennegmax = entfernennegmax*2;
                                        }
                                        //printf("entfernt 1008\n");
                                    }
                                    m++;
                                }
                                
                            }
                            hitcounterSen = 0;
                            hitcounterSenneg = 0;
                            i = 0;
                            while(1){//suche Senkrecht in pos Richtung
                                if((entfernenynegzwei[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterSen++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Senkrecht in neg Richtung
                                if((entfernenynegzwei[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterSenneg++;
                                i++;
                            }
                            if((hitcounterSen + hitcounterSenneg) >= 5){
                                //printf("Hit: Neg: Sen: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop(0) Sen\n");
                                //printf("Treffer: Loop(%i), Neg Sen X: %i Y: %i => %i\n",durchlaeufe,entfernenxnegzwei[(help-1)],entfernenynegzwei[(help-1)]+j,neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j]);
                                entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                                entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                                entfernencounterneg++;
                                if(entfernencounterneg == entfernennegmax){
                                    entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernennegmax = entfernennegmax*2;
                                }
                                //printf("entfernt 1143\n");
                                int m = 1;
                                while(m < hitcounterSen){
                                    entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                                    entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j+m;
                                    entfernencounterneg++;
                                    //printf("entfernt 1048\n");
                                    m++;
                                    if(entfernencounterneg == entfernennegmax){
                                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernennegmax = entfernennegmax*2;
                                    }
                                }
                                m = 1;
                                while(m < hitcounterSenneg){
                                    entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                                    entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j-m;
                                    entfernencounterneg++;
                                    //printf("entfernt 1055\n");
                                    m++;
                                    if(entfernencounterneg == entfernennegmax){
                                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernennegmax = entfernennegmax*2;
                                    }
                                }
                            }
                            hitcounterDiaLR = 0;
                            hitcounterDiaLRneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal LR in pos Richtung
                                if((entfernenxnegzwei[(help-1)]+i) >= (size+1) || (entfernenynegzwei[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]+i][entfernenynegzwei[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterDiaLR++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Diagonal LR in neg Richtung
                                if((entfernenxnegzwei[(help-1)]-i) < 1 || (entfernenynegzwei[(help-1)]-i+j) < 1){
                                    break;
                                }
                                if((entfernenxnegzwei[(help-1)]-i) == 1){
                                    if((entfernenxnegzwei[(help-1)]-i+k) < 1 || (entfernenxnegzwei[(help-1)]-i+k) >= (size+1) || (entfernenynegzwei[(help-1)]-i+j-k) < 0 || (entfernenynegzwei[(help-1)]-i+j-k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == neg[1][entfernenynegzwei[(help-1)]-i+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k-1][entfernenynegzwei[(help-1)]-i+j-k]){
                                        hitcounterDiaLRneg++;
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[1][entfernenynegzwei[(help-1)]-i+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == feld[k-1][entfernenynegzwei[(help-1)]-i+j-k] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                        hitcounterDiaLRneg++;
                                        hitcounterDiaLRneg++;
                                    }
                                    if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k][entfernenynegzwei[(help-1)]-i+j-k-1]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]-i][entfernenynegzwei[(help-1)]-i+j]){
                                        break;
                                    }
                                }
                                hitcounterDiaLRneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                                //printf("Hit: Neg: DiaLR: Durchlauf: %i\n",durchlaeufe);
                                //printf("Treffer: Loop(%i), Neg DiaLR X: %i Y: %i => %i\n",durchlaeufe,entfernenxnegzwei[(help-1)],entfernenynegzwei[(help-1)]+j,neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j]);
                                //printf("Gefunden Loop(0) DiaLR\n");
                                entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                                entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                                entfernencounterneg++;
                                if(entfernencounterneg == entfernennegmax){
                                    entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernennegmax = entfernennegmax*2;
                                }
                                //printf("entfernt 1112\n");
                                int m = 1;
                                while(m < hitcounterDiaLR){
                                    entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]+m;
                                    entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j+m;
                                    entfernencounterneg++;
                                    //printf("entfernt 1117\n");
                                    m++;
                                    if(entfernencounterneg == entfernennegmax){
                                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernennegmax = entfernennegmax*2;
                                    }
                                }
                                m = 1;
                                int n = 0;
                                while(m < hitcounterDiaLRneg){
                                    if((entfernenxnegzwei[(help-1)]-m) < 1){
                                        entfernenxpos[entfernencounterpos] = n;
                                        n++;
                                        entfernenypos[entfernencounterpos] = entfernenynegzwei[(help-1)]+j+m;
                                        entfernencounterpos++;
                                        if(entfernencounterpos == entfernenposmax){
                                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenposmax = entfernenposmax*2;
                                        }
                                    }else{
                                        entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]-m;
                                        entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j-m;
                                        entfernencounterneg++;
                                        if(entfernencounterneg == entfernennegmax){
                                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernennegmax = entfernennegmax*2;
                                        }
                                        //printf("entfernt 1131\n");
                                    }
                                    m++;
                                }
                            }
                            hitcounterDiaRL = 0;
                            hitcounterDiaRLneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal RL in pos Richtung
                                if((entfernenxnegzwei[(help-1)]-i) < 1 || (entfernenynegzwei[(help-1)]-i+j) >= (laenge+1)){
                                    break;
                                }
                                if((entfernenxnegzwei[(help-1)]-i) == 1){
                                    //printf("3 wird verglichen mit: %i\n",neg[entfernenxneg[(help-1)]-i+k][entfernenyneg[(help-1)]+i+j+k]);
                                    if((entfernenxnegzwei[(help-1)]-i+k) < 1 || (entfernenxnegzwei[(help-1)]-i+k) >= (size+1) || (entfernenynegzwei[(help-1)]+i+j+k) < 0 || (entfernenynegzwei[(help-1)]+i+j+k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == neg[1][entfernenynegzwei[(help-1)]+i+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k-1][entfernenynegzwei[(help-1)]+i+j+k]){
                                        hitcounterDiaRL++;
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[1][entfernenynegzwei[(help-1)]+i+j] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == feld[k-1][entfernenynegzwei[(help-1)]+i+j+k] && neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != -1){
                                        hitcounterDiaRL++;
                                        hitcounterDiaRL++;
                                        //printf("erhöhe um 2\n");
                                    }
                                    if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != feld[k][entfernenynegzwei[(help-1)]+i+j+k+1]){
                                        break;
                                    }
                                    //printf("erhöhe um 1 (Übergang)\n");
                                    k++;
                                }else{
                                    //printf("3 wird verglichen mit: %i\n",neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j]);
                                    if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]-i][entfernenynegzwei[(help-1)]+i+j]){
                                        break;
                                    }
                                    //printf("erhöhe um 1 (kein Übergang)\n");
                                    //printf("%i bei (%i,%i) und %ibei (%i,%i)\n",neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j],entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j],entfernenxneg[(help-1)]-i,entfernenyneg[(help-1)]+i+j);
                                }
                                hitcounterDiaRL++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            i = 0;
                            while(1){//suche Diagonal RL in neg Richtung
                                if((entfernenxnegzwei[(help-1)]+i) >= (size+1) || (entfernenynegzwei[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] == -1 || neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j] != neg[entfernenxnegzwei[(help-1)]+i][entfernenynegzwei[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterDiaRLneg++;
                                i++;
                            }
                            //printf("hit DiaRL pos: %i\n", hitcounterDiaRL);
                            //printf("hit DiaRL neg: %i\n", hitcounterDiaRLneg);
                            if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                                //printf("Hit: Neg: DiaRL: Durchlauf: %i\n",durchlaeufe);
                                //printf("Treffer: Loop(%i), Neg DiaRL X: %i Y: %i => %i\n",durchlaeufe,entfernenxnegzwei[(help-1)],entfernenynegzwei[(help-1)]+j,neg[entfernenxnegzwei[(help-1)]][entfernenynegzwei[(help-1)]+j]);
                                //printf("Gefunden Loop(0) DiaRL\n");
                                //printf("1) speichere: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                                entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)];
                                entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j;
                                entfernencounterneg++;
                                if(entfernencounterneg == entfernennegmax){
                                    entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                    entfernennegmax = entfernennegmax*2;
                                }
                                //printf("entfernt 1198\n");
                                int m = 1;
                                int n = 0;
                                while(m < hitcounterDiaRL){
                                    if((entfernenxnegzwei[(help-1)]-m) < 1){
                                        //printf("2) speichere: (%i,%i)\n",n,entfernenyneg[(help-1)]+j+m);
                                        entfernenxpos[entfernencounterpos] = n;
                                        n++;
                                        entfernenypos[entfernencounterpos] = entfernenynegzwei[(help-1)]+j+m;
                                        entfernencounterpos++;
                                        if(entfernencounterpos == entfernenposmax){
                                            entfernenxpos = (int*)realloc(entfernenxpos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenypos = (int*)realloc(entfernenypos,(entfernenposmax*2+1)*sizeof(int));
                                            entfernenposmax = entfernenposmax*2;
                                        }
                                    }else{
                                        //printf("3) speichere: (%i,%i)\n",entfernenxneg[(help-1)]-m,entfernenyneg[(help-1)]+j+m);
                                        entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]-m;
                                        entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j+m;
                                        entfernencounterneg++;
                                        if(entfernencounterneg == entfernennegmax){
                                            entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                            entfernennegmax = entfernennegmax*2;
                                        }
                                        //printf("entfernt 1212\n");
                                    }
                                    m++;
                                }
                                m = 1;
                                while(m < hitcounterDiaRLneg){
                                    //printf("4) speichere: (%i,%i)\n",entfernenxneg[(help-1)]+m,entfernenyneg[(help-1)]+j-m);
                                    entfernenxneg[entfernencounterneg] = entfernenxnegzwei[(help-1)]+m;
                                    entfernenyneg[entfernencounterneg] = entfernenynegzwei[(help-1)]+j-m;
                                    entfernencounterneg++;
                                    //printf("entfernt 1221\n");
                                    m++;
                                    if(entfernencounterneg == entfernennegmax){
                                        entfernenxneg = (int*)realloc(entfernenxneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernenyneg = (int*)realloc(entfernenyneg,(entfernennegmax*2+1)*sizeof(int));
                                        entfernennegmax = entfernennegmax*2;
                                    }
                                }
                            }
                        }
                        help--;
                    }
                    help = 0;

                    if(entfernencounterneg > 0 || entfernencounterpos > 0){
                        aenderungen = 1;
                    }
                    //printf("entfernenPOS: %i\n", entfernencounterpos);
                    //printf("entfernenNEG: %i\n", entfernencounterneg);
                    help = entfernencounterpos;
                    while(help > 0){
                        feld[entfernenxpos[help-1]][entfernenypos[help-1]] = 255;
                        //printf("POS X: %i Y: %i\n", entfernenxposzwei[help-1], entfernenyposzwei[help-1]);
                        help--;
                    }
                    help = entfernencounterneg;
                    while(help > 0){
                        neg[entfernenxneg[help-1]][entfernenyneg[help-1]] = 255;
                        //printf("NEG X: %i Y: %i\n", entfernenxnegzwei[help-1], entfernenynegzwei[help-1]);
                        help--;
                    }

                    help = entfernencounterpos;
                    while(help > 0){
                        int k = 0;
                        while((extra[entfernenxpos[help-1]]-k-1) >= 0 && verw[entfernenxpos[help-1]] == 0){
                            //printf("5.Aktueller Block: %i mit (%i,%i), wobei k = %i\n",feld[entfernenxpos[help-1]][extra[entfernenxpos[help-1]]-k-1],entfernenxpos[help-1],extra[entfernenxpos[help-1]]-k-1,k);
                            if(feld[entfernenxpos[help-1]][extra[entfernenxpos[help-1]]-k-1] == 255){
                                memmove(feld[entfernenxpos[help-1]]+(extra[entfernenxpos[help-1]]-k-1),feld[entfernenxpos[help-1]]+(extra[entfernenxpos[help-1]]-k-1)+1,(laenge-(extra[entfernenxpos[help-1]]-k-1)-1)*sizeof(*feld[entfernenxpos[help-1]]));
                                count++;
                            }
                            k++;
                        }
                        if(count > 0){
                            extra[entfernenxpos[help-1]] = extra[entfernenxpos[help-1]] - count;
                            count = 0;
                            verw[entfernenxpos[help-1]] = 1;
                        }
                        help--;
                    }

                    help = entfernencounterneg;
                    while(help > 0){
                        int k = 0;
                        while((extraneg[entfernenxneg[help-1]]-k-1) >= 0 && verwneg[entfernenxneg[help-1]] == 0){
                            //printf("5.Aktueller Block: %i mit (-%i,%i), wobei k = %i\n",neg[entfernenxneg[help-1]][extraneg[entfernenxneg[help-1]]-k-1],entfernenxneg[help-1],extraneg[entfernenxneg[help-1]]-k-1,k);
                            if(neg[entfernenxneg[help-1]][extraneg[entfernenxneg[help-1]]-k-1] == 255){
                                memmove(neg[entfernenxneg[help-1]]+(extraneg[entfernenxneg[help-1]]-k-1),neg[entfernenxneg[help-1]]+(extraneg[entfernenxneg[help-1]]-k-1)+1,(laenge-(extraneg[entfernenxneg[help-1]]-k-1)-1)*sizeof(*neg[entfernenxneg[help-1]]));
                                count++;
                            }
                            k++;
                        }
                        if(count > 0){
                            extraneg[entfernenxneg[help-1]] = extraneg[entfernenxneg[help-1]] - count;
                            count = 0;
                            verwneg[entfernenxneg[help-1]] = 1;
                        }
                        help--;
                    }
                    //printf("\n");
                    
                    help = 0;
                    entfernencounterposzwei = 0;
                    entfernencounternegzwei = 0;

                    memset(verw,0,(size+1)*4);
                    memset(verwneg,0,(size+1)*4);

                    /*
                    if(aenderungen == 1){//hilfe
                        for(int i = 0;i < (size+1);i++){
                            //printf("%i\n",extra[i]);
                            if(feld[i][0] != -1){
                                //printf("%i mit i = %i\n",extra[i],i);
                                int j = 0;
                                while(feld[i][j] != -1){
                                    fprintf(stdout,"%i %i %i\n",feld[i][j], i,j);
                                    j++;
                                }
                            }
                            //printf("%i\n",extraneg[i]);
                            if(neg[i][0] != -1){
                                int j = 0;
                                while(neg[i][j] != -1){
                                    fprintf(stdout,"%i -%i %i\n",neg[i][j], i,j);
                                    j++;
                                }
                            }
                        }
                        printf("\n");
                        for(int i = 0;i < entfernencounterpos;i++){
                            printf("+(%i,%i)\n",entfernenxpos[i],entfernenypos[i]);
                        }
                        printf("\n");
                        for(int i = 0;i < entfernencounterneg;i++){
                            printf("-(%i,%i)\n",entfernenxneg[i],entfernenyneg[i]);
                        }
                        printf("5\n");
                    }
                    */
                }
                if((durchlaeufe % 2) == 1){
                    //printf("Ungerade Anzahl an Durchläufen.\n");
                    help = entfernencounterpos;
                    while(help > 0){
                        int i = 0;
                        int k = 1;
                        for(int j = 0;(j+entfernenypos[(help-1)]) < (laenge+1);j++){
                            if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1){
                                break;
                            }
                            hitcounterWag = 0;
                            hitcounterWagneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Wagerecht in pos Richtung
                                if((entfernenxpos[(help-1)]+i) >= (size+1)){
                                    break;
                                }
                                if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]+i][entfernenypos[(help-1)]+j]){
                                    break;
                                }
                                hitcounterWag++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Wagerecht in neg Richtung
                                if((entfernenxpos[(help-1)]-i) < 0){
                                    break;
                                }
                                if((entfernenxpos[(help-1)]-i) == 0){
                                    if((entfernenxpos[(help-1)]-i+k) < 0 || (entfernenxpos[(help-1)]-i+k) >= (size+1)){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == feld[0][entfernenypos[(help-1)]+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k][entfernenypos[(help-1)]+j]){
                                        hitcounterWagneg++;
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[0][entfernenypos[(help-1)]+j]){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == neg[k-1][entfernenypos[(help-1)]+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                        hitcounterWagneg++;
                                        hitcounterWagneg++;
                                    }
                                    if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k+1][entfernenypos[(help-1)]+j]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]-i][entfernenypos[(help-1)]+j]){
                                        break;
                                    }
                                }
                                hitcounterWagneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            if((hitcounterWag + hitcounterWagneg) >= 5){
                                //printf("Hit: Feld: Wag: Durchlauf: %i\n",durchlaeufe);
                                //printf("Treffer: Loop(%i), Feld Wag X: %i Y: %i => %i\n",durchlaeufe,entfernenxpos[(help-1)],entfernenypos[(help-1)]+j,feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j]);
                                //printf("Gefunden Loop Wag\n");
                                entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                                entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                                entfernencounterposzwei++;
                                if(entfernencounterposzwei == entfernenposmaxzwei){
                                    entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenposmaxzwei = entfernenposmaxzwei*2;
                                }
                                int m = 1;
                                while(m < hitcounterWag){
                                    entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]+m;
                                    entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                                    entfernencounterposzwei++;
                                    m++;
                                    if(entfernencounterposzwei == entfernenposmaxzwei){
                                        entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenposmaxzwei = entfernenposmaxzwei*2;
                                    }
                                }
                                m = 1;
                                int n = 1;//vielleicht = 1?
                                while(m < hitcounterWagneg){
                                    if((entfernenxpos[(help-1)]-m) < 0){
                                        entfernenxnegzwei[entfernencounternegzwei] = n;
                                        n++;
                                        entfernenynegzwei[entfernencounternegzwei] = entfernenypos[(help-1)]+j;
                                        entfernencounternegzwei++;
                                        if(entfernencounternegzwei == entfernennegmaxzwei){
                                            entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernennegmaxzwei = entfernennegmaxzwei*2;
                                        }
                                    }else{
                                        entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]-m;
                                        entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                                        entfernencounterposzwei++;
                                        if(entfernencounterposzwei == entfernenposmaxzwei){
                                            entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenposmaxzwei = entfernenposmaxzwei*2;
                                        }
                                    }
                                    m++;
                                }
                                
                            }
                            hitcounterSen = 0;
                            hitcounterSenneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Senkrecht in pos Richtung
                                if((entfernenypos[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterSen++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Senkrecht in neg Richtung
                                if((entfernenypos[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterSenneg++;
                                i++;
                            }
                            if((hitcounterSen + hitcounterSenneg) >= 5){
                                //printf("Hit: Feld: Sen: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop Sen\n");
                                //printf("Treffer: Loop(%i), Feld Sen X: %i Y: %i => %i\n",durchlaeufe,entfernenxpos[(help-1)],entfernenypos[(help-1)]+j,feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j]);
                                entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                                entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                                entfernencounterposzwei++;
                                if(entfernencounterposzwei == entfernenposmaxzwei){
                                    entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenposmaxzwei = entfernenposmaxzwei*2;
                                }
                                int m = 1;
                                while(m < hitcounterSen){
                                    entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                                    entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j+m;
                                    entfernencounterposzwei++;
                                    m++;
                                    if(entfernencounterposzwei == entfernenposmaxzwei){
                                        entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenposmaxzwei = entfernenposmaxzwei*2;
                                    }
                                }
                                m = 1;
                                while(m < hitcounterSenneg){
                                    entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                                    entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j-m;
                                    entfernencounterposzwei++;
                                    m++;
                                    if(entfernencounterposzwei == entfernenposmaxzwei){
                                        entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenposmaxzwei = entfernenposmaxzwei*2;
                                    }
                                }
                            }
                            hitcounterDiaLR = 0;
                            hitcounterDiaLRneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal LR in pos Richtung
                                if((entfernenxpos[(help-1)]+i) >= (size+1) || (entfernenypos[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]+i][entfernenypos[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterDiaLR++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Diagonal LR in neg Richtung
                                if((entfernenxpos[(help-1)]-i) < 0 || (entfernenypos[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if((entfernenxpos[(help-1)]-i) == 0){
                                    if((entfernenxpos[(help-1)]-i+k) < 0 || (entfernenxpos[(help-1)]-i+k) >= (size+1) || (entfernenypos[(help-1)]-i+j-k) < 0 || (entfernenypos[(help-1)]-i+j-k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == feld[0][entfernenypos[(help-1)]-i+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k][entfernenypos[(help-1)]-i+j-k]){
                                        hitcounterDiaLRneg++;
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[0][entfernenypos[(help-1)]-i+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == neg[k][entfernenypos[(help-1)]-i+j-k] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                        hitcounterDiaLRneg++;
                                        hitcounterDiaLRneg++;
                                    }
                                    if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k+1][entfernenypos[(help-1)]-i+j-k-1]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]-i][entfernenypos[(help-1)]-i+j]){
                                        break;
                                    }
                                }
                                hitcounterDiaLRneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                                //printf("Hit: Feld: DiaLR: Durchlauf: %i\n",durchlaeufe);
                                //printf("Treffer: Loop(%i), Feld DiaLR X: %i Y: %i => %i\n",durchlaeufe,entfernenxpos[(help-1)],entfernenypos[(help-1)]+j,feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j]);
                                //printf("Gefunden Loop DiaLR\n");
                                entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                                entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                                entfernencounterposzwei++;
                                if(entfernencounterposzwei == entfernenposmaxzwei){
                                    entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenposmaxzwei = entfernenposmaxzwei*2;
                                }
                                int m = 1;
                                while(m < hitcounterDiaLR){
                                    entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]+m;
                                    entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j+m;
                                    entfernencounterposzwei++;
                                    m++;
                                    if(entfernencounterposzwei == entfernenposmaxzwei){
                                        entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenposmaxzwei = entfernenposmaxzwei*2;
                                    }
                                }
                                m = 1;
                                int n = 1;//vielleicht = 1?
                                while(m < hitcounterDiaLRneg){
                                    if((entfernenxpos[(help-1)]-m) < 0){
                                        entfernenxnegzwei[entfernencounternegzwei] = n;
                                        n++;
                                        entfernenynegzwei[entfernencounternegzwei] = entfernenypos[(help-1)]+j+m;
                                        entfernencounternegzwei++;
                                        if(entfernencounternegzwei == entfernennegmaxzwei){
                                            entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernennegmaxzwei = entfernennegmaxzwei*2;
                                        }
                                    }else{
                                        entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]-m;
                                        entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j-m;
                                        entfernencounterposzwei++;
                                        if(entfernencounterposzwei == entfernenposmaxzwei){
                                            entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenposmaxzwei = entfernenposmaxzwei*2;
                                        }
                                    }
                                    m++;
                                }
                            }
                            hitcounterDiaRL = 0;
                            hitcounterDiaRLneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal RL in pos Richtung
                                if((entfernenxpos[(help-1)]-i) < 0 || (entfernenypos[(help-1)]-i+j) >= (laenge+1)){
                                    break;
                                }
                                if((entfernenxpos[(help-1)]-i) == 0){
                                    if((entfernenxpos[(help-1)]-i+k) < 0 || (entfernenxpos[(help-1)]-i+k) >= (size+1) || (entfernenypos[(help-1)]+i+j+k) < 0 || (entfernenypos[(help-1)]+i+j+k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == feld[0][entfernenypos[(help-1)]+i+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k][entfernenypos[(help-1)]+i+j+k]){
                                        hitcounterDiaRL++;
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[0][entfernenypos[(help-1)]+i+j] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == neg[k][entfernenypos[(help-1)]+i+j+k] && feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != -1){
                                        hitcounterDiaRL++;
                                        hitcounterDiaRL++;
                                    }
                                    if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != neg[k+1][entfernenypos[(help-1)]+i+j+k+1]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]-i][entfernenypos[(help-1)]+i+j]){
                                        break;
                                    }
                                }
                                hitcounterDiaRL++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            i = 0;
                            while(1){//suche Diagonal RL in neg Richtung
                                if((entfernenxpos[(help-1)]+i) >= (size+1) || (entfernenypos[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] == -1 || feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j] != feld[entfernenxpos[(help-1)]+i][entfernenypos[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterDiaRLneg++;
                                i++;
                            }
                            if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                                //printf("Hit: Feld: DiaRL: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop DiaRL\n");
                                //printf("Treffer: Loop(%i), Feld DiaRL X: %i Y: %i => %i\n",durchlaeufe,entfernenxpos[(help-1)],entfernenypos[(help-1)]+j,feld[entfernenxpos[(help-1)]][entfernenypos[(help-1)]+j]);
                                entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)];
                                entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j;
                                entfernencounterposzwei++;
                                if(entfernencounterposzwei == entfernenposmaxzwei){
                                    entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                    entfernenposmaxzwei = entfernenposmaxzwei*2;
                                }
                                int m = 1;
                                int n = 1;//vielleicht = 1?
                                while(m < hitcounterDiaRL){
                                    if((entfernenxpos[(help-1)]-m) < 0){
                                        entfernenxnegzwei[entfernencounternegzwei] = n;
                                        n++;
                                        entfernenynegzwei[entfernencounternegzwei] = entfernenypos[(help-1)]+j+m;
                                        entfernencounternegzwei++;
                                        if(entfernencounternegzwei == entfernennegmaxzwei){
                                            entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernennegmaxzwei = entfernennegmaxzwei*2;
                                        }
                                    }else{
                                        entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]-m;
                                        entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j+m;
                                        entfernencounterposzwei++;
                                        if(entfernencounterposzwei == entfernenposmaxzwei){
                                            entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenposmaxzwei = entfernenposmaxzwei*2;
                                        }
                                    }
                                    m++;
                                }
                                m = 1;
                                while(m < hitcounterDiaRLneg){
                                    entfernenxposzwei[entfernencounterposzwei] = entfernenxpos[(help-1)]+m;
                                    entfernenyposzwei[entfernencounterposzwei] = entfernenypos[(help-1)]+j-m;
                                    entfernencounterposzwei++;
                                    m++;
                                    if(entfernencounterposzwei == entfernenposmaxzwei){
                                        entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                        entfernenposmaxzwei = entfernenposmaxzwei*2;
                                    }
                                }
                            }
                        }
                        help--;
                    }
                    
                    help = entfernencounterneg;
                    //printf("NegCounter: %i\n", entfernencounterneg);
                    while(help > 0){
                        int i = 0;
                        int k = 1;
                        for(int j = 0;(j+entfernenyneg[(help-1)]) < (laenge+1);j++){
                            if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1){
                                break;
                            }
                            //printf("Aktuelles Neg: X: %i Y: %i Farbe: %i\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j]);
                            hitcounterWag = 0;
                            hitcounterWagneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Wagerecht in pos Richtung
                                if((entfernenxneg[(help-1)]+i) >= (size+1)){
                                    break;
                                }
                                if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]+i][entfernenyneg[(help-1)]+j]){
                                    break;
                                }
                                hitcounterWag++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Wagerecht in neg Richtung
                                if((entfernenxneg[(help-1)]-i) < 1){
                                    //printf("break 1\n");
                                    break;
                                }
                                if((entfernenxneg[(help-1)]-i) == 1){
                                    if((entfernenxneg[(help-1)]-i+k) < 1 || (entfernenxneg[(help-1)]-i+k) >= (size+1)){
                                        //printf("break 2\n");
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == neg[1][entfernenyneg[(help-1)]+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k-1][entfernenyneg[(help-1)]+j]){
                                        hitcounterWagneg++;
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[1][entfernenyneg[(help-1)]+j]){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == feld[k-1][entfernenyneg[(help-1)]+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                        //printf("hi\n");
                                        hitcounterWagneg++;
                                        hitcounterWagneg++;
                                    }
                                    if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k][entfernenyneg[(help-1)]+j]){
                                        //printf("break 3\n");
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+j]){
                                        //printf("break 4\n");
                                        break;
                                    }
                                }
                                hitcounterWagneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            //printf("Hit Wag: %i\n", hitcounterWag);
                            //printf("Hit Wag Neg: %i\n", hitcounterWagneg);
                            if((hitcounterWag + hitcounterWagneg) >= 5){
                                //printf("Hit: Neg: Wag: Durchlauf: %i\n",durchlaeufe);
                                //printf("Treffer: Loop(%i), Neg Wag X: %i Y: %i => %i\n",durchlaeufe,entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j]);
                                //printf("Gefunden Loop Wag\n");
                                //printf("1) speichere: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                                entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                                entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                                entfernencounternegzwei++;
                                if(entfernencounternegzwei == entfernennegmaxzwei){
                                    entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernennegmaxzwei = entfernennegmaxzwei*2;
                                }
                                //printf("neu in neg entfernen: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                                //printf("entfernen NEG aktuelle Position: (%i,%i)\n",entfernenxnegzwei[entfernencounternegzwei-1],entfernenynegzwei[entfernencounternegzwei-1]);
                                int m = 1;
                                while(m < hitcounterWag){
                                    //printf("2) speichere: (%i,%i)\n",entfernenxneg[(help-1)]+m,entfernenyneg[(help-1)]+j);
                                    entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]+m;
                                    entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                                    entfernencounternegzwei++;
                                    m++;
                                    if(entfernencounternegzwei == entfernennegmaxzwei){
                                        entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernennegmaxzwei = entfernennegmaxzwei*2;
                                    }
                                }
                                m = 1;
                                int n = 0;
                                while(m < hitcounterWagneg){
                                    if((entfernenxneg[(help-1)]-m) < 1){
                                        //printf("3) speichere: (%i,%i)\n",n,entfernenyneg[(help-1)]+j);
                                        entfernenxposzwei[entfernencounterposzwei] = n;
                                        n++;
                                        entfernenyposzwei[entfernencounterposzwei] = entfernenyneg[(help-1)]+j;
                                        entfernencounterposzwei++;
                                        if(entfernencounterposzwei == entfernenposmaxzwei){
                                            entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenposmaxzwei = entfernenposmaxzwei*2;
                                        }
                                        //printf("neu in entfernen: (%i,%i)\n",n-1,entfernenyneg[(help-1)]+j);
                                        //printf("entfernen aktuelle Position: (%i,%i)\n",entfernenxposzwei[entfernencounterposzwei-1],entfernenyposzwei[entfernencounterposzwei-1]);
                                    }else{
                                        //printf("4) speichere: (%i,%i)\n",entfernenxneg[(help-1)]-m,entfernenyneg[(help-1)]+j);
                                        entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]-m;
                                        entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                                        entfernencounternegzwei++;
                                        if(entfernencounternegzwei == entfernennegmaxzwei){
                                            entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernennegmaxzwei = entfernennegmaxzwei*2;
                                        }
                                    }
                                    m++;
                                }
                                
                            }
                            hitcounterSen = 0;
                            hitcounterSenneg = 0;
                            i = 0;
                            while(1){//suche Senkrecht in pos Richtung
                                if((entfernenyneg[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterSen++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Senkrecht in neg Richtung
                                if((entfernenyneg[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterSenneg++;
                                i++;
                            }
                            if((hitcounterSen + hitcounterSenneg) >= 5){
                                //printf("Hit: Neg: Sen: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop Sen\n");
                                //printf("Treffer: Loop(%i), Neg Sen X: %i Y: %i => %i\n",durchlaeufe,entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j]);
                                entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                                entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                                entfernencounternegzwei++;
                                if(entfernencounternegzwei == entfernennegmaxzwei){
                                    entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernennegmaxzwei = entfernennegmaxzwei*2;
                                }
                                int m = 1;
                                while(m < hitcounterSen){
                                    entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                                    entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j+m;
                                    entfernencounternegzwei++;
                                    m++;
                                    if(entfernencounternegzwei == entfernennegmaxzwei){
                                        entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernennegmaxzwei = entfernennegmaxzwei*2;
                                    }
                                }
                                m = 1;
                                while(m < hitcounterSenneg){
                                    entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                                    entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j-m;
                                    entfernencounternegzwei++;
                                    m++;
                                    if(entfernencounternegzwei == entfernennegmaxzwei){
                                        entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernennegmaxzwei = entfernennegmaxzwei*2;
                                    }
                                }
                            }
                            hitcounterDiaLR = 0;
                            hitcounterDiaLRneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal LR in pos Richtung
                                if((entfernenxneg[(help-1)]+i) >= (size+1) || (entfernenyneg[(help-1)]+i+j) >= (laenge+1)){
                                    break;
                                }
                                if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]+i][entfernenyneg[(help-1)]+i+j]){
                                    break;
                                }
                                hitcounterDiaLR++;
                                i++;
                            }
                            i = 0;
                            while(1){//suche Diagonal LR in neg Richtung
                                if((entfernenxneg[(help-1)]-i) < 1 || (entfernenyneg[(help-1)]-i+j) < 1){
                                    break;
                                }
                                if((entfernenxneg[(help-1)]-i) == 1){
                                    if((entfernenxneg[(help-1)]-i+k) < 1 || (entfernenxneg[(help-1)]-i+k) >= (size+1) || (entfernenyneg[(help-1)]-i+j-k) < 0 || (entfernenyneg[(help-1)]-i+j-k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == neg[1][entfernenyneg[(help-1)]-i+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k-1][entfernenyneg[(help-1)]-i+j-k]){
                                        hitcounterDiaLRneg++;
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[1][entfernenyneg[(help-1)]-i+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == feld[k-1][entfernenyneg[(help-1)]-i+j-k] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                        hitcounterDiaLRneg++;
                                        hitcounterDiaLRneg++;
                                    }
                                    if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k][entfernenyneg[(help-1)]-i+j-k-1]){
                                        break;
                                    }
                                    k++;
                                }else{
                                    if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]-i+j]){
                                        break;
                                    }
                                }
                                hitcounterDiaLRneg++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            if((hitcounterDiaLR + hitcounterDiaLRneg) >= 5){
                                //printf("Hit: Neg: DiaLR: Durchlauf: %i\n",durchlaeufe);
                                //printf("Gefunden Loop DiaLR\n");
                                //printf("Treffer: Loop(%i), Neg DiaLR X: %i Y: %i => %i\n",durchlaeufe,entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j]);
                                entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                                entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                                entfernencounternegzwei++;
                                if(entfernencounternegzwei == entfernennegmaxzwei){
                                    entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernennegmaxzwei = entfernennegmaxzwei*2;
                                }
                                int m = 1;
                                while(m < hitcounterDiaLR){
                                    entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]+m;
                                    entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j+m;
                                    entfernencounternegzwei++;
                                    m++;
                                    if(entfernencounternegzwei == entfernennegmaxzwei){
                                        entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernennegmaxzwei = entfernennegmaxzwei*2;
                                    }
                                }
                                m = 1;
                                int n = 0;
                                while(m < hitcounterDiaLRneg){
                                    if((entfernenxneg[(help-1)]-m) < 1){
                                        entfernenxposzwei[entfernencounterposzwei] = n;
                                        n++;
                                        entfernenyposzwei[entfernencounterposzwei] = entfernenyneg[(help-1)]+j+m;
                                        entfernencounterposzwei++;
                                        if(entfernencounterposzwei == entfernenposmaxzwei){
                                            entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenposmaxzwei = entfernenposmaxzwei*2;
                                        }
                                    }else{
                                        entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]-m;
                                        entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j-m;
                                        entfernencounternegzwei++;
                                        if(entfernencounternegzwei == entfernennegmaxzwei){
                                            entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernennegmaxzwei = entfernennegmaxzwei*2;
                                        }
                                    }
                                    m++;
                                }
                            }
                            hitcounterDiaRL = 0;
                            hitcounterDiaRLneg = 0;
                            i = 0;
                            k = 1;
                            while(1){//suche Diagonal RL in pos Richtung
                                if((entfernenxneg[(help-1)]-i) < 1 || (entfernenyneg[(help-1)]-i+j) >= (laenge+1)){
                                    break;
                                }
                                if((entfernenxneg[(help-1)]-i) == 1){
                                    //printf("3 wird verglichen mit: %i\n",neg[entfernenxneg[(help-1)]-i+k][entfernenyneg[(help-1)]+i+j+k]);
                                    if((entfernenxneg[(help-1)]-i+k) < 1 || (entfernenxneg[(help-1)]-i+k) >= (size+1) || (entfernenyneg[(help-1)]+i+j+k) < 0 || (entfernenyneg[(help-1)]+i+j+k) >= (laenge+1)){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == neg[1][entfernenyneg[(help-1)]+i+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k-1][entfernenyneg[(help-1)]+i+j+k]){
                                        hitcounterDiaRL++;
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[1][entfernenyneg[(help-1)]+i+j] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                        break;
                                    }
                                    if(k == 1 && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == feld[k-1][entfernenyneg[(help-1)]+i+j+k] && neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != -1){
                                        hitcounterDiaRL++;
                                        hitcounterDiaRL++;
                                        //printf("erhöhe um 2\n");
                                    }
                                    if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != feld[k][entfernenyneg[(help-1)]+i+j+k+1]){
                                        break;
                                    }
                                    //printf("erhöhe um 1 (Übergang)\n");
                                    k++;
                                }else{
                                    //printf("3 wird verglichen mit: %i\n",neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j]);
                                    if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j]){
                                        break;
                                    }
                                    //printf("erhöhe um 1 (kein Übergang)\n");
                                    //printf("%i bei (%i,%i) und %ibei (%i,%i)\n",neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j],entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]-i][entfernenyneg[(help-1)]+i+j],entfernenxneg[(help-1)]-i,entfernenyneg[(help-1)]+i+j);
                                }
                                hitcounterDiaRL++;
                                if(k == 1){
                                    i++;
                                }
                            }
                            i = 0;
                            while(1){//suche Diagonal RL in neg Richtung
                                if((entfernenxneg[(help-1)]+i) >= (size+1) || (entfernenyneg[(help-1)]-i+j) < 0){
                                    break;
                                }
                                if(neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] == -1 || neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j] != neg[entfernenxneg[(help-1)]+i][entfernenyneg[(help-1)]-i+j]){
                                    break;
                                }
                                hitcounterDiaRLneg++;
                                i++;
                            }
                            //printf("hit DiaRL pos: %i\n", hitcounterDiaRL);
                            //printf("hit DiaRL neg: %i\n", hitcounterDiaRLneg);
                            if((hitcounterDiaRL + hitcounterDiaRLneg) >= 5){
                                //printf("Hit: Neg: DiaRL: Durchlauf: %i\n",durchlaeufe);
                                //printf("Treffer: Loop(%i), Neg DiaRL X: %i Y: %i => %i\n",durchlaeufe,entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j,neg[entfernenxneg[(help-1)]][entfernenyneg[(help-1)]+j]);
                                //printf("Gefunden Loop DiaRL\n");
                                //printf("1) speichere: (%i,%i)\n",entfernenxneg[(help-1)],entfernenyneg[(help-1)]+j);
                                entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)];
                                entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j;
                                entfernencounternegzwei++;
                                if(entfernencounternegzwei == entfernennegmaxzwei){
                                    entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                    entfernennegmaxzwei = entfernennegmaxzwei*2;
                                }
                                int m = 1;
                                int n = 0;
                                while(m < hitcounterDiaRL){
                                    if((entfernenxneg[(help-1)]-m) < 1){
                                        //printf("2) speichere: (%i,%i)\n",n,entfernenyneg[(help-1)]+j+m);
                                        entfernenxposzwei[entfernencounterposzwei] = n;
                                        n++;
                                        entfernenyposzwei[entfernencounterposzwei] = entfernenyneg[(help-1)]+j+m;
                                        entfernencounterposzwei++;
                                        if(entfernencounterposzwei == entfernenposmaxzwei){
                                            entfernenxposzwei = (int*)realloc(entfernenxposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenyposzwei = (int*)realloc(entfernenyposzwei,(entfernenposmaxzwei*2+1)*sizeof(int));
                                            entfernenposmaxzwei = entfernenposmaxzwei*2;
                                        }
                                    }else{
                                        //printf("3) speichere: (%i,%i)\n",entfernenxneg[(help-1)]-m,entfernenyneg[(help-1)]+j+m);
                                        entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]-m;
                                        entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j+m;
                                        entfernencounternegzwei++;
                                        if(entfernencounternegzwei == entfernennegmaxzwei){
                                            entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                            entfernennegmaxzwei = entfernennegmaxzwei*2;
                                        }
                                    }
                                    m++;
                                }
                                m = 1;
                                while(m < hitcounterDiaRLneg){
                                    //printf("4) speichere: (%i,%i)\n",entfernenxneg[(help-1)]+m,entfernenyneg[(help-1)]+j-m);
                                    entfernenxnegzwei[entfernencounternegzwei] = entfernenxneg[(help-1)]+m;
                                    entfernenynegzwei[entfernencounternegzwei] = entfernenyneg[(help-1)]+j-m;
                                    entfernencounternegzwei++;
                                    m++;
                                    if(entfernencounternegzwei == entfernennegmaxzwei){
                                        entfernenxnegzwei = (int*)realloc(entfernenxnegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernenynegzwei = (int*)realloc(entfernenynegzwei,(entfernennegmaxzwei*2+1)*sizeof(int));
                                        entfernennegmaxzwei = entfernennegmaxzwei*2;
                                    }
                                }
                            }
                        }
                        help--;
                    }
                    help = 0;

                    if(entfernencounternegzwei > 0 || entfernencounterposzwei > 0){
                        aenderungen = 1;
                    }
                    //printf("entfernenPOS: %i\n", entfernencounterposzwei);
                    //printf("entfernenNEG: %i\n", entfernencounternegzwei);
                    help = entfernencounterposzwei;
                    while(help > 0){
                        feld[entfernenxposzwei[help-1]][entfernenyposzwei[help-1]] = 255;
                        //printf("POS X: %i Y: %i\n", entfernenxposzwei[help-1], entfernenyposzwei[help-1]);
                        help--;
                    }
                    help = entfernencounternegzwei;
                    while(help > 0){
                        neg[entfernenxnegzwei[help-1]][entfernenynegzwei[help-1]] = 255;
                        //printf("NEG X: %i Y: %i\n", entfernenxnegzwei[help-1], entfernenynegzwei[help-1]);
                        help--;
                    }

                    help = entfernencounterposzwei;
                    while(help > 0){
                        int k = 0;
                        while((extra[entfernenxposzwei[help-1]]-k-1) >= 0 && verw[entfernenxposzwei[help-1]] == 0){
                            //printf("6.Aktueller Block: %i mit (%i,%i), wobei k = %i\n",feld[entfernenxposzwei[help-1]][extra[entfernenxposzwei[help-1]]-k-1],entfernenxposzwei[help-1],extra[entfernenxposzwei[help-1]]-k-1,k);
                            if(feld[entfernenxposzwei[help-1]][extra[entfernenxposzwei[help-1]]-k-1] == 255){
                                memmove(feld[entfernenxposzwei[help-1]]+(extra[entfernenxposzwei[help-1]]-k-1),feld[entfernenxposzwei[help-1]]+(extra[entfernenxposzwei[help-1]]-k-1)+1,(laenge-(extra[entfernenxposzwei[help-1]]-k-1)-1)*sizeof(*feld[entfernenxposzwei[help-1]]));
                                count++;
                            }
                            k++;
                        }
                        if(count > 0){
                            extra[entfernenxposzwei[help-1]] = extra[entfernenxposzwei[help-1]] - count;
                            count = 0;
                            verw[entfernenxposzwei[help-1]] = 1;
                        }
                        help--;
                    }

                    help = entfernencounternegzwei;
                    while(help > 0){
                        int k = 0;
                        while((extraneg[entfernenxnegzwei[help-1]]-k-1) >= 0 && verwneg[entfernenxnegzwei[help-1]] == 0){
                            //printf("6.Aktueller Block: %i mit (-%i,%i), wobei k = %i\n",neg[entfernenxnegzwei[help-1]][extraneg[entfernenxnegzwei[help-1]]-k-1],entfernenxnegzwei[help-1],extraneg[entfernenxnegzwei[help-1]]-k-1,k);
                            if(neg[entfernenxnegzwei[help-1]][extraneg[entfernenxnegzwei[help-1]]-k-1] == 255){
                                memmove(neg[entfernenxnegzwei[help-1]]+(extraneg[entfernenxnegzwei[help-1]]-k-1),neg[entfernenxnegzwei[help-1]]+(extraneg[entfernenxnegzwei[help-1]]-k-1)+1,(laenge-(extraneg[entfernenxnegzwei[help-1]]-k-1)-1)*sizeof(*neg[entfernenxnegzwei[help-1]]));
                                count++;
                            }
                            k++;
                        }
                        if(count > 0){
                            //printf("%i von %i abgezogen, an pos extraneg[%i]\n",count,extraneg[entfernenxnegzwei[help-1]],entfernenxnegzwei[help-1]);
                            extraneg[entfernenxnegzwei[help-1]] = extraneg[entfernenxnegzwei[help-1]] - count;
                            count = 0;
                            verwneg[entfernenxnegzwei[help-1]] = 1;
                        }
                        help--;
                    }
                    //printf("\n");
                    help = 0;
                    entfernencounterpos = 0;
                    entfernencounterneg = 0;

                    memset(verw,0,(size+1)*4);
                    memset(verwneg,0,(size+1)*4);

                    /*
                    if(aenderungen == 1){//hilfe
                        for(int i = 0;i < (size+1);i++){
                            //printf("%i\n",extra[i]);
                            if(feld[i][0] != -1){
                                //printf("%i mit i = %i\n",extra[i],i);
                                int j = 0;
                                while(feld[i][j] != -1){
                                    fprintf(stdout,"%i %i %i\n",feld[i][j], i,j);
                                    j++;
                                }
                            }
                            //printf("%i\n",extraneg[i]);
                            if(neg[i][0] != -1){
                                int j = 0;
                                while(neg[i][j] != -1){
                                    fprintf(stdout,"%i -%i %i\n",neg[i][j], i,j);
                                    j++;
                                }
                            }
                        }
                        printf("\n");
                        for(int i = 0;i < entfernencounterposzwei;i++){
                            printf("+(%i,%i)\n",entfernenxposzwei[i],entfernenyposzwei[i]);
                        }
                        printf("\n");
                        for(int i = 0;i < entfernencounternegzwei;i++){
                            printf("-(%i,%i)\n",entfernenxnegzwei[i],entfernenynegzwei[i]);
                        }
                        printf("6\n");
                    }
                    */
                }

                //loop vergleich ende

                durchlaeufe++;
            }
            
            //printf("%i\n",extraneg[negx]);
        }
        //Teil 3 + Teil 4 getrennt durch Ende der Leseloop while(1)
        //printf("farbe: %i\nxko: %i\n",farbe,xko); 
        if(c == EOF){
               exit = 1;
            }
            break;
         }//Ende if c = Endzeichen
         input[pos] = c;
         pos++;
        }//Ende Leseloop
        pos = 0;
        memset(input,0,strlen(input));
        memset(haelfte1,0,strlen(haelfte1));
        memset(haelfte2,0,strlen(haelfte2));
        memset(marker,0,strlen(marker));
        if(exit == 1){
            break;
        }

    }//Ende Hauptloop while(1)
    //einlesen ende   

    //ausgabe start     STDOUT NACHRICHT VERAENDERN!!!!

    //printf("Änd: %i\n",aenderungen);
    //printf("Durch: %i\n",durchlaeufe);

    for(int i = 0;i < (size+1);i++){
        //printf("%i\n",extra[i]);
        if(feld[i][0] != -1){
            //printf("%i mit i = %i\n",extra[i],i);
            int j = 0;
            while(feld[i][j] != -1){
                fprintf(stdout,"%i %i %i\n",feld[i][j], i,j);
                j++;
            }
        }
        //printf("%i\n",extraneg[i]);
        if(neg[i][0] != -1){
            int j = 0;
            while(neg[i][j] != -1){
                fprintf(stdout,"%i -%i %i\n",neg[i][j], i,j);
                j++;
            }
        }
    }

    //ausgabe ende

    free(verwneg);
    free(verw);
    free(entfernenxnegzwei);
    free(entfernenxposzwei);
    free(entfernenynegzwei);
    free(entfernenyposzwei);
    free(entfernenxneg);
    free(entfernenxpos);
    free(entfernenyneg);
    free(entfernenypos);
    free(extra);
    free(extraneg);
    for(int i = 0;i < (size+1);i++){
      free(feld[i]);
      free(neg[i]);
    }
    free(feld);
    free(neg);
    return 0; 
}