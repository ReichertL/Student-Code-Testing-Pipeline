#include <stdio.h>
#include <stdlib.h>
#include <regex.h>
#include <string.h>
#include <assert.h>
#include <math.h>

struct NODE
{
    int xValue;
    int *yValues;
    int countYValues;
    int height;
    struct NODE *left;
    struct NODE *right;
};

struct NODE *board = NULL;

// free all allocated memory for the board
void freeBoard(struct NODE *ptr)
{
    if (ptr != NULL)
    {
        struct NODE *left = ptr->left;
        struct NODE *right = ptr->right;
        free(ptr->yValues);
        free(ptr);
        freeBoard(left);
        freeBoard(right);
    }
}
// if Memory could not be allocated print error message, free all allocated memory and exit program
void mallocFail()
{
    fprintf(stderr, "could not allocate the requested momory, exiting program\n");
    freeBoard(board);
    exit(-1);
}

// sear for location of xValue and return the pointer to it
struct NODE *getNodePointer(int xValue)
{
    struct NODE *ptr = board;

    // while pointer for xValue not found search in child nodes
    while (ptr != NULL)
    {
        if (ptr->xValue < xValue)
        {
            ptr = ptr->right;
        }
        else if (ptr->xValue > xValue)
        {
            ptr = ptr->left;
        }
        else if (ptr->xValue == xValue)
        {
            break;
        }
    }

    return ptr;
}

// quickly calculate the bigger of two values
int max(int a, int b)
{
    return (a > b) ? a : b;
}

// the height of a given NODE will be updated with the help of its children
void updateHeightOfNode(struct NODE *ptr)
{
    if (ptr->left != NULL && ptr->right != NULL)
    {
        ptr->height = max(ptr->left->height, ptr->right->height) + 1;
    }
    else if (ptr->left != NULL)
    {
        ptr->height = ptr->left->height + 1;
    }
    else if (ptr->right != NULL)
    {
        ptr->height = ptr->right->height + 1;
    }
    else
    {
        ptr->height = 1;
    }
}

// do a rotation to the left for three nodes and return new root of these three
struct NODE *leftRotation(struct NODE *ptr)
{
    struct NODE *right = ptr->right;
    struct NODE *rightLeft = right->left;

    // do the rotation
    right->left = ptr;
    ptr->right = rightLeft;

    updateHeightOfNode(ptr);
    updateHeightOfNode(right);

    return right;
}

// do a rotation to the right for three nodes and return new root of these three
struct NODE *rightRotation(struct NODE *ptr)
{
    struct NODE *left = ptr->left;
    struct NODE *leftRight = left->right;

    // do the rotation
    left->right = ptr;
    ptr->left = leftRight;

    updateHeightOfNode(ptr);
    updateHeightOfNode(left);

    return left;
}

// calculate the balance for one NODE with the height of its children
int getBalance(struct NODE *ptr)
{
    int balance = 0;

    if (ptr->left != NULL && ptr->right != NULL)
    {
        balance = ptr->left->height - ptr->right->height;
    }
    else if (ptr->left != NULL)
    {
        balance = -1 * ptr->left->height;
    }
    else if (ptr->right != NULL)
    {
        balance = ptr->right->height;
    }

    return balance;
}

struct NODE *reshapeSubTreeIfNeeded(struct NODE *ptr)
{
    int balance = getBalance(ptr);

    // Case tree is larger on the right side as well as its subtree
    if (balance > 1 && getBalance(ptr->right) == 1)
    {
        return leftRotation(ptr);
    }

    // Case tree is larger on the left side as well as its subtree
    if (balance < -1 && getBalance(ptr->left) == -1)
    {
        return rightRotation(ptr);
    }

    // Case tree is larger on the right side but subtree on its left
    if (balance > 1 && getBalance(ptr->right) == -1)
    {
        ptr->right = rightRotation(ptr->right);
        return leftRotation(ptr);
    }

    // Case tree is larger on the left side but subtree on its right
    if (balance < -1 && getBalance(ptr->left) == 1)
    {
        ptr->left = leftRotation(ptr->left);
        return rightRotation(ptr);
    }

    // do nothing if tree is not unbalanced
    return ptr;
}

// recursively look for the position to insert a new NODE
// if tree gets unbalanced reshape it to a balanced state
struct NODE *insertNewNode(struct NODE *ptr, int xValue, int color)
{
    if (ptr == NULL)
    {
        // create the new node, initialize with start value and set xValue and color
        struct NODE *newNode = (struct NODE *)malloc(sizeof(struct NODE));
        if (newNode == NULL)
        {
            mallocFail();
        }
        newNode->left = NULL;
        newNode->right = NULL;
        newNode->height = 1;
        newNode->xValue = xValue;
        newNode->countYValues = 1;
        int *temp;
        temp = (int *)malloc(sizeof(int));
        if (temp == NULL)
        {
            free(newNode);
            mallocFail();
        }
        temp[0] = color;
        newNode->yValues = temp;

        return newNode;
    }
    if (xValue < ptr->xValue)
    {
        ptr->left = insertNewNode(ptr->left, xValue, color);
    }
    else
    {
        ptr->right = insertNewNode(ptr->right, xValue, color);
    }

    // update Height of current NODE
    updateHeightOfNode(ptr);

    // return the reshaped tree
    return reshapeSubTreeIfNeeded(ptr);
}

int insertNewValue(int xValue, int color)
{
    int yValue = 0;
    struct NODE *ptr = getNodePointer(xValue);

    // if a node already exists expand the array which holds the color and add the new
    if (ptr != NULL)
    {
        int *temp;
        temp = (int *)realloc(ptr->yValues, sizeof(int) * (ptr->countYValues + 1));
        if (temp == NULL)
        {
            free(ptr->yValues);
            mallocFail();
        }
        temp[ptr->countYValues] = color;
        yValue = ptr->countYValues;
        ptr->countYValues = ptr->countYValues + 1;

        ptr->yValues = temp;
    }
    else
    {
        board = insertNewNode(board, xValue, color);
    }

    return yValue;
}

// get the input of program and reshape
void modifyLine(char *line, int regexReturnValue, regex_t regex)
{

    // remove newline character at the end of the line
    if (line[strlen(line) - 1] == '\n')
    {
        line[strlen(line) - 1] = 0;
    }

    // check line agains regular expression
    regexReturnValue = regexec(&regex, line, 0, NULL, 0);

    if (regexReturnValue == 1)
    {
        fprintf(stderr, "The input is not in the correct format, exiting program\n");
        freeBoard(board);
        exit(-1);
    }
}

void printResult(struct NODE *board)
{
    for (int i = 0; i < board->countYValues; i++)
    {
        printf("%d %d %d\n", board->yValues[i], board->xValue, i);
    }
    if (board->left != NULL)
    {
        printResult(board->left);
    }
    if (board->right != NULL)
    {
        printResult(board->right);
    }
}

// recursively check a point on the board for matches and calculate its lenght
int checkHitDirectionForLength(struct NODE *ptr, int xValue, int yValue, int xDirection, int yDirection)
{
    int length = 1;
    struct NODE *tempPtr = getNodePointer(xValue + xDirection);
    int color = ptr->yValues[yValue];

    // check if there is a NODE near the one to check and calculated yValue of is not bigger than its count or below 0
    if (tempPtr != NULL && yValue + yDirection < tempPtr->countYValues && yValue + yDirection >= 0)
    {
        int tempColor = tempPtr->yValues[yValue + yDirection];
        // check if the color of the new Node matches or if there have already been matches these round and other need to be added as well
        if (color == tempColor || color == tempColor - 255 || color - 255 == tempColor)
        {
            length = length + checkHitDirectionForLength(tempPtr, xValue + xDirection, yValue + yDirection, xDirection, yDirection);
        }
    }

    return length;
}

int **checkPositionForHitsAndGetHitLength(struct NODE *ptr, int xValue, int yValue)
{
    int yCheck = 0;
    int **hits;

    struct NODE *tempPtr;

    int color = ptr->yValues[yValue];

    // allocate the memory for hits array
    hits = (int **)malloc(sizeof(int *) * 3);
    if (hits == NULL)
    {
        mallocFail();
    }
    for (int i = 0; i < 3; i++)
    {
        hits[i] = (int *)calloc(3, sizeof(int *));
        if (hits[i] == NULL)
        {
            mallocFail();
        }
    }

    // check sourounding positions on board if there is a match
    for (int i = -1; i < 2; i++)
    {
        tempPtr = getNodePointer(xValue + i);
        if (tempPtr != NULL)
        {
            for (int j = -1; j < 2; j++)
            {
                yCheck = yValue + j;
                if (yCheck >= 0 && yCheck < tempPtr->countYValues)
                {
                    int tempColor = tempPtr->yValues[yCheck];
                    if (tempColor == color || color == tempColor - 255 || color - 255 == tempColor)
                    {
                        if (!(i == 0 && j == 0))
                        {
                            hits[i + 1][j + 1] = checkHitDirectionForLength(ptr, xValue, yValue, i, j) - 1;
                            hits[1][1] = 1;
                        }
                    }
                }
            }
        }
    }

    return hits;
}

void checkHitLengthAndRemoveIfThreshold(struct NODE *ptr, int xValue, int yValue, int **hits)
{
    struct NODE *tempPtr;
    //check for hit lenght from left to right
    for (int i = 2; i >= 0; i--)
    {
        int left = hits[0][2 - i];
        int right = hits[2][i];
        int totalHitLength = left + right + 1;
        if (totalHitLength >= 4)
        {
            int yDirection = i - 1;

            for (int j = -left; j <= right; j++)
            {
                tempPtr = getNodePointer(xValue + j);
                if (tempPtr->yValues[yValue + j * yDirection] >= 0)
                {
                    // indicate an already matched position in board by shifting it below 0 in case there are other matches with it in this round
                    tempPtr->yValues[yValue + j * yDirection] = tempPtr->yValues[yValue + j * yDirection] - 255;
                }
            }
            // Let the program know that lines have been removed
            hits[1][1] = 2;
        }
        else
        {
            hits[0][2 - i] = 0;
            hits[2][i] = 0;
        }
    }

    //check for hit lenght top down
    if (hits[1][2] + hits[1][0] + 1 >= 4)
    {
        for (int j = 1; j <= hits[1][2]; j++)
        {
            if (ptr->yValues[yValue + j] >= 0)
            {
                // indicate an already matched position in board by shifting it below 0 in case there are other matches with it in this round
                ptr->yValues[yValue + j] = ptr->yValues[yValue + j] - 255;
            }
        }
        for (int j = 1; j <= hits[1][0]; j++)
        {
            if (ptr->yValues[yValue - j] >= 0)
            {
                // indicate an already matched position in board by shifting it below 0 in case there are other matches with it in this round
                ptr->yValues[yValue - j] = ptr->yValues[yValue - j] - 255;
            }
        }
        if (ptr->yValues[yValue] >= 0)
        {
            ptr->yValues[yValue] = ptr->yValues[yValue] - 255;
        }

        // Let the program know that lines have been removed
        hits[1][1] = 2;
    }
    else
    {
        hits[1][2] = 0;
        hits[1][0] = 0;
    }
}

// lets all stones fall to the button indicated by negative values and update the NODEs value count
void updateBoard(int xValue, int yValue, int left, int right)
{
    struct NODE *tempPtr;
    for (int i = -left; i <= right; i++)
    {
        tempPtr = getNodePointer(xValue + i);
        if (tempPtr != NULL)
        {
            int topCount = 0;
            for (int j = yValue; j < tempPtr->countYValues; j++)
            {
                for (int k = j; k > yValue; k--)
                {
                    int top = tempPtr->yValues[k];
                    int down = tempPtr->yValues[k - 1];
                    if (top >= 0 && down < 0)
                    {
                        tempPtr->yValues[k] = -1;
                        tempPtr->yValues[k - 1] = top;
                    }
                }
            }
            for (int j = 0; j < tempPtr->countYValues && tempPtr->yValues[j] >= 0; j++)
            {
                topCount = j + 1;
            }
            tempPtr->countYValues = topCount;
            int *temp;
            temp = (int *)realloc(tempPtr->yValues, sizeof(int) * topCount);
            if (temp == NULL)
            {
                free(tempPtr->yValues);
                mallocFail();
            }
            tempPtr->yValues = temp;
        }
    }
}

// check the area where hits have been detected and remove if more hits occure and recursivly check until there are no more changed
void recheckBoard(int xValue, int yValue, int left, int right)
{
    int moreHits = 0;
    int furthestLeft = left;
    int furthestRight = right;
    struct NODE *ptr;
    int down = 0;

    // check the area indicated by left to right in reference to xValue
    for (int i = -left; i <= right; i++)
    {
        ptr = getNodePointer(xValue + i);

        if (ptr != NULL)
        {
            for (int j = 0; j < ptr->countYValues; j++)
            {
                int **newHits = checkPositionForHitsAndGetHitLength(ptr, xValue + i, j);
                if (newHits[1][1] == 1)
                {
                    checkHitLengthAndRemoveIfThreshold(ptr, xValue + i, j, newHits);
                    if (newHits[1][1] == 2)
                    {
                        moreHits = 1;
                        for (int k = 2; k >= 0; k--)
                        {
                            if (-1 * (i - newHits[0][2 - k]) > furthestLeft && -1 * (i - newHits[0][2 - k]) > left)
                            {
                                furthestLeft = -1 * (i - newHits[0][2 - k]);
                            }
                            if (i + newHits[2][k] > furthestRight && newHits[2][k] + i > right)
                            {
                                furthestRight = i + newHits[2][k];
                            }
                        }
                        //check how far down the program should go to check for additional hits
                        down = furthestLeft;
                        if (furthestRight > down)
                        {
                            down = furthestRight;
                        }
                        if (newHits[1][0] > down)
                        {
                            down = newHits[1][0];
                        }
                        if (newHits[1][2] > down)
                        {
                            down = newHits[1][2];
                        }
                        if (yValue - down < 0)
                        {
                            down = yValue;
                        }
                        down = yValue;
                    }
                }
                free(newHits);
            }
        }
    }

    if (moreHits == 1)
    {
        //recursive call if more hits have been found
        updateBoard(xValue, yValue - down, furthestLeft, furthestRight);
        recheckBoard(xValue, yValue - down, furthestLeft, furthestRight);
    }
}

int main()
{
    char line[15];
    int regexReturnValue;
    regex_t regex;
    int firstRun = 1;

    regexReturnValue = regcomp(&regex, "^[0-9]+ +-?[0-9]+$", REG_EXTENDED);
    /* read all input line by line*/
    while (1)
    {

        if (fgets(line, 15, stdin) == NULL)
        {
            break;
        }

        modifyLine(line, regexReturnValue, regex);

        // convert first part of String to Number color
        char delim[] = " ";
        char *ptr = strtok(line, delim);
        int color = atoi(ptr);

        // if color is out of range end program and free memory
        if (color < 0 || color > 254)
        {
            fprintf(stderr, "The Color is out of range, exiting program\n");
            freeBoard(board);
            exit(-1);
        }

        // convert second part of String to Number xValue
        ptr = strtok(NULL, delim);
        int xValue = atoi(ptr);

        // if the first entry is added set the returning NODE as root for the game board
        if (firstRun == 1)
        {
            insertNewValue(xValue, color);
            board = getNodePointer(xValue);
            firstRun = 0;
        }
        else
        {
            // printf("insertNewValue, xValue: %d, color: %d\n", xValue, color);
            int yValue = insertNewValue(xValue, color);
            // printHeights(board);

            struct NODE *ptr = getNodePointer(xValue);

            // check the newly inserted value for matches to its surrounding neighbours
            // an array is returned with the number of matches for each direction
            // if there are matches the center of the array is set to 1
            int **hits = checkPositionForHitsAndGetHitLength(ptr, xValue, yValue);
            if (hits[1][1] == 1)
            {
                // if there are matches and they reach the Threshold of 4 they will be removed from the board
                checkHitLengthAndRemoveIfThreshold(ptr, xValue, yValue, hits);
                if (hits[1][1] == 2)
                {
                    int left = 0;
                    int right = 0;
                    for (int i = 2; i >= 0; i--)
                    {
                        if (hits[0][2 - i] > left)
                        {
                            left = hits[0][2 - i];
                        }
                        if (hits[2][i] >= right)
                        {
                            right = hits[2][i];
                        }
                    }
                    int down = left;
                    if (right > down)
                    {
                        down = right;
                    }
                    if (hits[1][0] > down)
                    {
                        down = hits[1][0];
                    }
                    if (hits[1][2] > down)
                    {
                        down = hits[1][2];
                    }
                    down = 2 * down;
                    if (yValue - down < 0)
                    {
                        down = yValue;
                    }
                    free(hits);

                    updateBoard(xValue, yValue - down, left, right);
                    recheckBoard(xValue, yValue - down, left, right);
                }
            }
        }
    }

    if (firstRun == 0)
    {
        printResult(board);
        freeBoard(board);
    }

    return 0;
}