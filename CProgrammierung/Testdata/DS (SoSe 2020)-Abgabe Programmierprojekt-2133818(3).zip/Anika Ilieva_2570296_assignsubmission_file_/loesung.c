#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

enum Color{RED, BLACK};

typedef struct binaryTreeElement {
	long key;
	void* value;
	char color; // red or black
	
	struct binaryTreeElement* parent;
	struct binaryTreeElement* left;
	struct binaryTreeElement* right;
} binaryTreeElement;

typedef struct binaryTree {
	struct binaryTreeElement *root;
	unsigned long size;
} binaryTree;

binaryTree* createBinaryTree();
binaryTreeElement* createBinaryTreeElement(long key, void* value);
void destroyBinaryTreeElement(binaryTreeElement* element);
void deepDestroySubtree(binaryTree* tree, binaryTreeElement* element);
void destroyBinaryTree(binaryTree* tree);
void insertToBinaryTree(binaryTree* tree, long key, void* value);
void* getValueOfBinaryTree(binaryTree* tree, long key);
binaryTreeElement* minKeyElementInSubTree(binaryTreeElement* element);
void removeFromBinaryTree(binaryTree* tree, long key);
binaryTreeElement** sortedBinaryTreeElements(binaryTree* tree);

void rotateLeft(binaryTree* tree, binaryTreeElement* element) {
	binaryTreeElement* x = element->right;
	element->right = x->left;

	if(element->right != NULL) {
		element->right->parent = element;
	}
	x->parent = element->parent;
	if(element->parent == NULL) {
		tree->root = x;
	}
	else if(element == element->parent->left) {
		element->parent->left = x; 
	}
	else {
		element->parent->right = x;	
	}
	x->left = element;
	element->parent = x; 
}

void rotateRight(binaryTree* tree, binaryTreeElement* element) {
	binaryTreeElement* x = element->left;
	element->left = x->right;

	if(element->left != NULL) {
		element->left->parent = element;
	}
	x->parent = element->parent;
	if(element->parent == NULL) {
		tree->root = x;
	}
	else if(element == element->parent->left) {
		element->parent->left = x; 
	}
	else {
		element->parent->right = x;	
	}
	x->right = element;
	element->parent = x; 
}

void rebalance(binaryTree* tree, binaryTreeElement* element) {
	binaryTreeElement* parent = NULL;
	binaryTreeElement* pparent = NULL;
	
	while(element->parent != NULL && element->color != BLACK && element->parent == RED) {
		parent = element->parent;
		pparent = element->parent->parent;
		
		// 1. Case parent is left child of grandparent
		if(parent == pparent->left) {
			binaryTreeElement* tmp = pparent->right;
			
			// 1.1 Case the uncle is also red
			if(tmp != NULL && tmp->color == RED) {
				pparent->color = RED;
				parent->color = BLACK;
				tmp->color = BLACK;
				element = pparent;
			}
			else {
				// 1.2 is right child of parent
				if(element == parent->right) {
					rotateLeft(tree, parent);
					element = parent;
					parent = element->parent;
				}
				// 1.3 is left child of parent
				rotateRight(tree, pparent);
				char tmpColor = parent->color;
				parent->color = pparent->color;
				pparent->color = tmpColor;
				element = parent;
			}
		} else {
			// 2. Case parent is right child of grandparent
			binaryTreeElement* tmp = pparent->left;
			
			// 2.1 Case the uncle is also red
			if(tmp != NULL && tmp->color == RED) {
				pparent->color = RED;
				parent->color = BLACK;
				tmp->color = BLACK;
				element = pparent;
			}
			else {
				// 2.2 is left child of parent
				if(element == parent->right) {
					rotateRight(tree, parent);
					element = parent;
					parent = element->parent;
				}
				// 2.3 is right child of parent
				rotateRight(tree, pparent);
				char tmpColor = parent->color;
				parent->color = pparent->color;
				pparent->color = tmpColor;
				element = parent;
			}
		}
	}
	tree->root->color = BLACK;
}

binaryTree* createBinaryTree() {
	// init binary tree
	binaryTree* tree = (binaryTree*)malloc(sizeof(binaryTree));
	tree->root = NULL;
	tree->size = 0;
	return tree;
}

binaryTreeElement* createBinaryTreeElement(long key, void* value) {
	// init binary tree node
	binaryTreeElement* treeElement = (binaryTreeElement*)malloc(sizeof(binaryTreeElement));
	treeElement->key = key;
	treeElement->value = value;
	treeElement->left = NULL;
	treeElement->right = NULL;
	treeElement->parent = NULL;
	treeElement->color = RED;
	return treeElement;
}

void destroyBinaryTreeElement(binaryTreeElement* element) {
	// frees the memory
	free(element);
}

void deepDestroySubtree(binaryTree* tree, binaryTreeElement* element) {
	if(element->right != NULL) {
		// destroys the right subtree
		deepDestroySubtree(tree, element->right);
		element->right = NULL;
	}
	if(element->left != NULL) {
		// destroys the left subtree
		deepDestroySubtree(tree, element->left);
		element->left = NULL;
	}
	destroyBinaryTreeElement(element);
	tree->size -= 1;
}

void destroyBinaryTree(binaryTree* tree) {
	if(tree->root != NULL) {
		// destroys every node in it before it destroys itself
		deepDestroySubtree(tree, tree->root);
		tree->root = NULL;
	}
	free(tree);
}


binaryTreeElement* insert(binaryTree* tree, long key, void* value) {
	// create node with key and value
	binaryTreeElement* element = createBinaryTreeElement(key, value);
	
	if(tree->root == NULL) {
		// insert first node
		tree->root = element;
		tree->size += 1;
	} else {
		binaryTreeElement* tmp = tree->root;
		while (1) {
			if(tmp->key == key) {
				// replace value of already existing node (with the correct key)
				tmp->value = value;
				break;
			} else {
				if(key > tmp->key) {
					if(tmp->right == NULL) {
						// attach to the right of the node (its currently empty)
						element->parent = tmp;
						tmp->right = element;
						tree->size += 1;
						break;
					} else {
						// move forward to the right node
						tmp = tmp->right;
					}
				} else {
					if(tmp->left == NULL) {
						// attach to the left of the node (its currently empty)
						element->parent = tmp;
						tmp->left = element;
						tree->size += 1;
						break;
					} else {
						// move forward to the left node
						tmp = tmp->left;
					}
				}
			}
		}
	}
	return element;
}

void insertToBinaryTree(binaryTree* tree, long key, void* value) {
	binaryTreeElement* element = insert(tree, key, value);
	rebalance(tree, element);
}

void* getValueOfBinaryTree(binaryTree* tree, long key) {
	if(tree->root == NULL)
		// tree is empty
		return NULL;
	binaryTreeElement* tmp = tree->root;	
	while (1) {
		if(tmp->key == key) {
			// node was found with the requested key and return its value
			return tmp->value;
		} else {
			if(key > tmp->key) {
				if(tmp->right == NULL) {
					// no way to go
					return NULL;
				} else {
					// move forward to the right node
					tmp = tmp->right;
				}
			} else {
				if(tmp->left == NULL) {
					// no way to go
					return NULL;
				} else {
					// move forward to the left node
					tmp = tmp->left;
				}
			}
		}
	}
	return NULL;
}

binaryTreeElement* minKeyElementInSubTree(binaryTreeElement* element) {
	// gets the node with the smallest key of the right subtree
	binaryTreeElement* currentElement = element->right;
	while (currentElement && currentElement->left != NULL) {
		currentElement = currentElement->left;	
	}
	return currentElement;
}

void removeFromBinaryTree(binaryTree* tree, long key) {
	if(tree->root == NULL)
		// tree is empty
		return;
	binaryTreeElement* tmp = tree->root;
	while (1) {
		if(tmp->key == key) {
			// 1. Case (node has no children)
			if(tmp->left == NULL && tmp->right == NULL) {
				if(tmp->parent == NULL) {
					tree->root = NULL;
				} else {
					if(tmp->parent->right == tmp) {
						tmp->parent->right = NULL;
					} else {
						tmp->parent->left = NULL;
					}
				}
				destroyBinaryTreeElement(tmp);
				tree->size -= 1;
				return;
			}
			// 2. Case (node has one children)
			if((tmp->left != NULL) ^ (tmp->right != NULL)) {
				binaryTreeElement *keep = (tmp->left == NULL) ? tmp->right : tmp->left;
				
				if(tmp->parent == NULL) {
					tree->root = keep;
					keep->parent = NULL;
				} else if(tmp->parent->right == tmp) {
					tmp->parent->right = keep;
					keep->parent = tmp->parent;
				} else {
					tmp->parent->left = keep;
					keep->parent = tmp->parent;
				}
				destroyBinaryTreeElement(tmp);
				tree->size -= 1;
				return;
			}
			// 3. Case (node has two children)
			if(tmp->left != NULL && tmp->right != NULL) {
				binaryTreeElement *minKey = minKeyElementInSubTree(tmp);
				tmp->key = minKey->key;
				tmp->value = minKey->value;
				if(minKey->parent->left == minKey) {
					minKey->parent->left = minKey->right;
					if(minKey->right != NULL) {
						minKey->right->parent = minKey->parent;
					}
				} else {
					if(minKey->right != NULL) {
						minKey->right->parent = tmp;
						tmp->right = minKey->right;
					} else {
						tmp->right = NULL;
					}
				}
				destroyBinaryTreeElement(minKey);
				tree->size -= 1;
				return;
			}
		} else {
			if(key > tmp->key) {
				if(tmp->right == NULL) {
					return;
				} else {
					tmp = tmp->right;
				}
			} else {
				if(tmp->left == NULL) {
					return;
				} else {
					tmp = tmp->left;
				}
			}
		}
	}
}

binaryTreeElement** sortedBinaryTreeElements(binaryTree* tree) {
	binaryTreeElement** result = (binaryTreeElement**)malloc(tree->size*sizeof(binaryTreeElement *));
	if(tree->size == 0) {
		return result;
	}
	long i = 0;
	binaryTreeElement* tmp = tree->root;
	char mode = 0;
	
	while(mode != 4) {
		switch (mode) {
			case 0:
				// move left as long as you can else switch to case 1
				if(tmp->left != NULL) {
					tmp = tmp->left;	
				} else {
					mode = 1;
					result[i++] = tmp;
				}
				break;
			case 1:
				// (move 1 step to the right and switch to case 1) or switch to case 2
				if(tmp->right != NULL) {
					tmp = tmp->right;
					mode = 0;
				} else {
					mode = 2;
				}
				break;
			case 2:
				// move to the parent, if you came from the left side switch to case 1 else repeat case 2 another time
				// stop if you visit the root node
				if(tmp->parent == NULL) {
					mode = 4;
					break;
				}
				if(tmp->parent->left == tmp) {
					mode = 1;
					result[i++] = tmp->parent;
				} 
				tmp = tmp->parent;
				break;
		}
	}
	return result;
}

typedef struct colorStapleElement {
	unsigned char color;
	unsigned long height;
	struct colorStapleElement *nextBelow;
	struct colorStapleElement *nextAbove;
	struct colorStaple *staple;
} colorStapleElement;

typedef struct colorStaple {
	colorStapleElement *topElement;
	unsigned long currentHeight;
	long x;
} colorStaple;

colorStapleElement* createColorStapleElement(colorStaple* cs, unsigned char color);
void destroyColorStapleElement(colorStapleElement* element);
colorStaple* createColorStaple(long x);
void destroyColorStaple(colorStaple* cs);
void insertColor(colorStaple* cs, unsigned char color);
colorStapleElement* getColorStapleElementByHeight(colorStaple* cs, long height);
void dropColor(colorStapleElement* element);
void printColorStaple(colorStaple* cs);
void outputColorStaple(colorStaple* cs);


colorStapleElement* createColorStapleElement(colorStaple* cs, unsigned char color) {
	colorStapleElement* element = (colorStapleElement*)malloc(sizeof(colorStapleElement));
	if(element == NULL) {
		return NULL;
	}
	element->color = color;
	element->height = 0;
	element->nextBelow = NULL;
	element->nextAbove = NULL;
	element->staple = cs;
	return element;
}

void destroyColorStapleElement(colorStapleElement* element) {
	free(element);
}

colorStaple* createColorStaple(long x) {
	colorStaple *staple = (colorStaple*)malloc(sizeof(colorStaple));
	if(staple == NULL) {
		return NULL;
	}
	staple->topElement = NULL;
	staple->currentHeight = 0;
	staple->x = x;
	return staple;
}

void destroyColorStaple(colorStaple* cs) {
	colorStapleElement* tmp = cs->topElement;
	colorStapleElement* keep = NULL;

	while(tmp != NULL) {
		keep = tmp->nextBelow;
		destroyColorStapleElement(tmp);
		tmp = keep;
	}
	free(cs);
}

void insertColor(colorStaple* cs, unsigned char color) {
	cs->currentHeight += 1;
	colorStapleElement* cse = createColorStapleElement(cs, color);
	cse->height = cs->currentHeight;
	
	cse->nextAbove = NULL;
	cse->nextBelow = cs->topElement;
	if(cse->nextBelow != NULL)
		cse->nextBelow->nextAbove = cse;
	cs->topElement = cse;
}

colorStapleElement* getColorStapleElementByHeight(colorStaple* cs, long height) {
	if(cs->currentHeight < height)
		return NULL;
	colorStapleElement* tmp = cs->topElement;
	
	while (tmp->height != height) {
		tmp = tmp->nextBelow;
	}
	return tmp;
}

void dropColor(colorStapleElement* element) {
	if(element->nextAbove == NULL) {
		element->staple->topElement = element->nextBelow;
		if(element->nextBelow != NULL) {
			element->nextBelow->nextAbove = NULL;
		}
	} else {
		element->nextAbove->nextBelow = element->nextBelow;
		if(element->nextBelow != NULL) {
			element->nextBelow->nextAbove = element->nextAbove;
		}
		colorStapleElement *tmp = element->nextAbove;
		
		while(tmp != NULL) {
			tmp->height -= 1;
			tmp = tmp->nextAbove;
		}
	}
	element->staple->currentHeight -= 1;
	destroyColorStapleElement(element);
}

void printColorStaple(colorStaple* cs) {
	colorStapleElement* cse = cs->topElement;
	printf("%3ld:", cs->x);
	while(1) {
		if(cse->nextBelow == NULL) {
			break;
		}
		cse = cse->nextBelow;
	}
	while(1) {
		printf("%3i|", cse->color);
		if(cse->nextAbove == NULL) {
			break;
		}
		cse = cse->nextAbove;
	}
	printf("\n");
}

void outputColorStaple(colorStaple* cs) {
	colorStapleElement* cse = cs->topElement;
	while(cse != NULL) {
		printf("%i %ld %lu\n", cse->color, cs->x, cse->height-1);
		cse = cse->nextBelow;
	}
}

void outputBoard(binaryTree* tree) {
	binaryTreeElement** sorted = sortedBinaryTreeElements(tree);
	for(long i = 0; i < tree->size; i++) {
		outputColorStaple((colorStaple*)sorted[i]->value);
	}
}

void printBinaryTree(binaryTree* tree) {
	if(tree->size == 0) {
		return;
	}
	binaryTreeElement** sorted = sortedBinaryTreeElements(tree);
	long lastX = ((colorStaple*)sorted[0]->value)->x;
	printColorStaple((colorStaple*)sorted[0]->value);
	for(long i = 1; i < tree->size; i++) {
		for(long j = 0; j < ((colorStaple*)sorted[i]->value)->x - lastX - 1; j++) {
			printf("%3ld:\n", lastX+j+1);
		}
		lastX = ((colorStaple*)sorted[i]->value)->x;
		printColorStaple((colorStaple*)sorted[i]->value);
	}
}

void cleanVerticalLines(binaryTree* elementsToDrop, colorStaple *cs) {
	colorStapleElement* cse = cs->topElement;
	colorStapleElement** col = (colorStapleElement**)malloc(cs->currentHeight*sizeof(colorStapleElement *));
	long currentIndex = 0;
	unsigned char currentColor = cse->color;
	col[currentIndex++] = cse;
	cse = cse->nextBelow;
	
	while(cse != NULL) {
		if(cse->color == currentColor) {
			col[currentIndex++] = cse;
		} else {
			if(currentIndex >= 4) {
				for(long j = 0; j < currentIndex; j++) {
					insertToBinaryTree(elementsToDrop, (long)col[j], col[j]);
				}
			}
			for(long j = 0; j < currentIndex; j++) {
				col[j] = NULL;
			}
			currentIndex = 0;
			currentColor = cse->color;
			col[currentIndex++] = cse;
		}
		cse = cse->nextBelow;
	}
	if(currentIndex >= 4) {
		for(long j = 0; j < currentIndex; j++) {
			cse = col[j];
			insertToBinaryTree(elementsToDrop, (long)cse, cse);
		}
	}
	free(col);
}

void checkForSameColor(binaryTree* elementsToDrop, colorStapleElement** elements, unsigned long minHeight) {
	for(long y = minHeight-1; y >= 0; y--) {
		unsigned char color = elements[0]->color;
		char allTheSameColor = 1;
		for(int x = 1; x < 4; x++) {
			if(elements[x]->color != color) {
				allTheSameColor = 0;
				break;
			}
		}
		if(allTheSameColor) {
			for(int x = 0; x < 4; x++) {
				insertToBinaryTree(elementsToDrop, (long)elements[x], elements[x]);
			}
		}
		for(int x = 0; x < 4; x++) {
			elements[x] = elements[x]->nextBelow;
		}
	}
}

void cleanHorizontalLines(binaryTree* elementsToDrop, colorStaple** chunk, unsigned long minHeight) {
	colorStapleElement** elements = (colorStapleElement**)malloc(4*sizeof(colorStapleElement*));
	
	for(int i = 0; i < 4; i++) {
		elements[i] = getColorStapleElementByHeight(chunk[i], minHeight);
	}
	checkForSameColor(elementsToDrop, elements, minHeight);
	free(elements);
}

void cleanDiagonalLines(binaryTree* elementsToDrop, colorStaple** chunk) {
	colorStapleElement** ascElements = (colorStapleElement**)malloc(4*sizeof(colorStapleElement*));
	colorStapleElement** descElements = (colorStapleElement**)malloc(4*sizeof(colorStapleElement*));
	char ascElementsCompleted = 1;
	char descElementsCompleted = 1;
	
	unsigned long minDiagonalHeightAsc = ULONG_MAX;
	unsigned long minHeightAsc = ULONG_MAX;
	int minIndexAsc = 0;
	
	unsigned long minDiagonalHeightDesc = ULONG_MAX;
	unsigned long minHeightDesc = ULONG_MAX;
	int minIndexDesc = 0;

	for(int i = 0; i < 4; i++) {
		if(3-i+chunk[i]->currentHeight < minDiagonalHeightAsc) {
			minDiagonalHeightAsc = 3-i+chunk[i]->currentHeight;
			minHeightAsc = chunk[i]->currentHeight;
			minIndexAsc = i;
		}
		if(i+chunk[i]->currentHeight < minDiagonalHeightDesc) {
			minDiagonalHeightDesc = i+chunk[i]->currentHeight;
			minHeightDesc = chunk[i]->currentHeight;
			minIndexDesc = i;
		}
	}
	
	for(int i = 0; i < 4; i++) {
		if(ascElementsCompleted) {
			if(minHeightAsc+i <= minIndexAsc || minHeightAsc-minIndexAsc+i > chunk[i]->currentHeight) {
				ascElementsCompleted = 0;
			} else {
				ascElements[i] = getColorStapleElementByHeight(chunk[i], minHeightAsc-minIndexAsc+i);
			}
		}
		if(descElementsCompleted) {
			if(minHeightDesc+minIndexDesc <= i || minHeightDesc+minIndexDesc-i > chunk[i]->currentHeight) {
				descElementsCompleted = 0;
			} else {
				descElements[i] = getColorStapleElementByHeight(chunk[i], minHeightDesc+minIndexDesc-i);
			}
		}
	}
	if(ascElementsCompleted) {
		checkForSameColor(elementsToDrop, ascElements, minHeightAsc-minIndexAsc);
	}
	if(descElementsCompleted) {
		checkForSameColor(elementsToDrop, descElements, minHeightDesc-(3-minIndexDesc));
	}
	free(ascElements);
	free(descElements);
}

void cleanByChunks(binaryTree* elementsToDrop, colorStaple** neighbours, long amount) {
	if(amount < 4) {
		return;
	}
	
	colorStaple** chunk = (colorStaple**)malloc(4*sizeof(colorStaple*));
	unsigned long minHeight = neighbours[0]->currentHeight;
	long currentX = neighbours[0]->x;
	unsigned long chunkAmount = 0;
	chunk[chunkAmount++] = neighbours[0];
	
	for(long i = 1; i < amount+1; i++) {
		if(chunkAmount == 4) {
			cleanHorizontalLines(elementsToDrop, chunk, minHeight);
			cleanDiagonalLines(elementsToDrop, chunk);
			minHeight = ULONG_MAX;
			for(int j = 0; j < 3; j++) {
				chunk[j] = chunk[j+1];
				if(minHeight > chunk[j]->currentHeight) {
					minHeight = chunk[j]->currentHeight;
				}
			}
			chunkAmount = 3;
			chunk[3] = NULL;
		}
		if(i == amount) {
			break;
		}
		if(neighbours[i]->x != currentX+1) {
			minHeight = neighbours[i]->currentHeight;
			chunkAmount = 0;
			for(int j = 0; j < 4; j++) {
				chunk[j] = NULL;
			}
			chunk[chunkAmount++] = neighbours[i];
		} else {
			if(neighbours[i]->currentHeight < minHeight) {
				minHeight = neighbours[i]->currentHeight;
			}
			chunk[chunkAmount++] = neighbours[i];
		}
		currentX = neighbours[i]->x;
	}
	free(chunk);
}

void playRound(char debug, binaryTree* tree, long minX, long maxX) {
	if(debug) {
		printBinaryTree(tree);
		printf("\t||\n\t||\n\t\\/\n");
	}
	long stapleRangeSize = (maxX-minX+1)+6;
	colorStaple **neighbours = (colorStaple**)malloc(stapleRangeSize*sizeof(colorStaple*));
	long amount = 0;
	binaryTree* elementsToDrop = createBinaryTree();
	
	colorStaple* cs = NULL;
	for(long i = 0; i < stapleRangeSize; i++) {
		cs = getValueOfBinaryTree(tree, minX-3+i);
		if(cs != NULL) {
			neighbours[amount++] = cs;
			
			if(cs->currentHeight < 4) {
				continue;
			}
			cleanVerticalLines(elementsToDrop, cs);
		}
	}
	
	cleanByChunks(elementsToDrop, neighbours, amount);
	
	if(elementsToDrop->size != 0) {
		binaryTreeElement** elements = sortedBinaryTreeElements(elementsToDrop);
		for(long i = 0; i < elementsToDrop->size; i++) {
			dropColor((colorStapleElement*)(elements[i]->value));
			if(((colorStapleElement*)(elements[i]->value))->staple->currentHeight == 0) {
				removeFromBinaryTree(tree, ((colorStapleElement*)(elements[i]->value))->staple->x);
			}
		}
		if(debug) {
			printf("\tCHANGE\n");
		}
		playRound(debug, tree, minX-3, maxX+3);
	}
	free(neighbours);
}

typedef struct lineObject {
	unsigned char color;
	long x;
} lineObject;

lineObject* emptyLineObject(){
	lineObject *emptyLineObject = malloc(sizeof(lineObject));
	emptyLineObject->color = 0;
	emptyLineObject->x = 0;
	return emptyLineObject; 
}

lineObject* lineToCoordinate(char *line, unsigned long lineLength) {
	long a = 0;
	long b = 0;
	char mode = 0;
	
	char* seperation = (char*)malloc(sizeof(char)*lineLength);
	unsigned long x = 0;
	for(unsigned long i = 0; i < lineLength; i++) {
		if(mode == 2) {
			mode++;
			break;
		}
		if(line[i] == ' ' || line[i] == '\n' || line[i] == 0) {
			seperation[x] = 0;
			if(mode == 0) {
				a = atol(seperation);
				free(seperation);
				seperation = (char*)malloc(sizeof(char)*lineLength);
				x = 0;
				mode++;
			} else if(mode == 1) {
				b = atol(seperation);
				free(seperation);
				seperation = (char*)malloc(sizeof(char)*lineLength);
				x = 0;
				mode++;
			} else {
				break;
			}
		} else {
			if(line[i] != '-' && (line[i] < 48 || line[i] > 57)) {
				fprintf(stderr, "Invalid Format");
				exit(1);
			}
			seperation[x++] = line[i];
		}
	}
	
	if(mode == 1) {
		b = atol(seperation);
		free(seperation);
	}
	
	if(mode > 2 || a > 254 || a < 0) {
		fprintf(stderr, "Invalid Format");
		exit(1);
	}

	lineObject* l = emptyLineObject();
	l->color = a;
	l->x = b;
	
	return l;
}

binaryTree* readLines(char debug) {
	binaryTree* tree = createBinaryTree();
	char ch;
	char* line = (char*)malloc(sizeof(char)*25);
	unsigned char lineLength = 0;
	unsigned long currentLine = 0;
	
	while(1) {
		ch = getc( stdin );
		line[lineLength++] = ch;
		if(ch == '\n' || ch == EOF) {
			currentLine += 1;

			if ((line)[lineLength - 1] == '\n' || (line)[lineLength - 1] == EOF)
			{
				if((line)[lineLength - 1] == EOF && lineLength == 1) {
					break;
				}
				(line)[lineLength - 1] = '\0';
			}
			lineObject* lineObj = lineToCoordinate(line, lineLength);
			colorStaple* cs = getValueOfBinaryTree(tree, lineObj->x);
			if(cs == NULL) {
				cs = createColorStaple(lineObj->x);
				insertToBinaryTree(tree, lineObj->x, cs);
			}
			insertColor(cs, lineObj->color);
			playRound(debug, tree, lineObj->x, lineObj->x);
			
			lineLength = 0;
			free(line);
			if(ch == EOF){
				break;
			}
			
			line = (char*)malloc(sizeof(char)*20);
		}
	}
	
	return tree;
}

int main(int argc, const char * argv[]) {
	char debug = 0;
	binaryTree* tree = readLines(debug);
	outputBoard(tree);
	
	destroyBinaryTree(tree);
	
	return 0;
}


