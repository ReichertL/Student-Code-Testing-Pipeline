#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>

int i;
int j;
int k;
bool verrutschen = false;

int** loeschen(int** spielfeld, int zeilen,  int spalten){
	//Felder, die geloescht werden, auf -1 setzen
	for (i = 0; i < zeilen; i++){
		for (j = 0; j < spalten; j++){
			if (spielfeld[i][j] < -1){
				spielfeld[i][j] = -1;
			}
		}
	}
	return spielfeld;
}

int** nachrutschen(int** spielfeld, int zeilen, int spalten){
	//Spalten nachrutschen, setzt verrutschen auf true, falls sich Steine in ihrer Position veraendert haben
	verrutschen = false;
	for (j = 0; j < spalten; j++){
		k = 0;
		for (i = 0; i < zeilen; i++){
			if (spielfeld[i][j] == -1){
				k++;
			}
			else if(k != 0){
				spielfeld[i - k][j] = spielfeld[i][j];
				spielfeld[i][j] = -1;
				verrutschen = true;
			}
		}
	}
	return spielfeld;
}

int** diagonale(int** spielfeld, int zeilen, int spalten){
	//gibt es diagonale Viererlinien?
	bool steinloeschen = false;
	for (j = 0; j < spalten; j++){
		for (i = 0; i < zeilen - 3; i++){
			//sind am Ende der Spalte angekommen
			if (spielfeld[i][j] == -1){
				break;
			}
			//Fall 1: Derzeitiger Stein ist noch nicht in Viererlinie, die geloescht wird
			if (spielfeld[i][j] > -1){
				//Diagonalen Richtung rechts unten, die geloescht werden sollen, markieren mit -256
				if ( j < spalten -3 && (spielfeld[i][j] == spielfeld[i + 1][j + 1] || spielfeld[i][j] - 256 == spielfeld[i + 1][j + 1]) 
									&& (spielfeld[i][j] == spielfeld[i + 2][j + 2] || spielfeld[i][j] - 256 == spielfeld[i + 2][j + 2]) 
									&& (spielfeld[i][j] == spielfeld[i + 3][j + 3] || spielfeld[i][j] - 256 == spielfeld[i + 3][j + 3])){
					k = 1;
					while (i + k < zeilen && j + k < spalten && (spielfeld[i + k][j + k] == spielfeld[i][j] || spielfeld[i + k][j + k] == spielfeld[i][j] - 256)){
						//Nur Felder markeren, die nich sowieso schon geloescht werden
						if (spielfeld[i + k][j + k] > -1){
							spielfeld[i + k][j + k] -= 256;
						}
						k++;
					}
					steinloeschen = true;
					verrutschen = true;
				}
				//Diagonalen Richtung links unten, die geloescht werden sollen, markieren mit -256
				if ( j > 2 	&& (spielfeld[i][j] == spielfeld[i + 1][j - 1] || spielfeld[i][j] - 256 == spielfeld[i + 1][j - 1]) 
							&& (spielfeld[i][j] == spielfeld[i + 2][j - 2] || spielfeld[i][j] - 256 == spielfeld[i + 2][j - 2]) 
							&& (spielfeld[i][j] == spielfeld[i + 3][j - 3] || spielfeld[i][j] - 256 == spielfeld[i + 3][j - 3])){
					k = 1;
					while (i + k < zeilen && j - k > -1 && (spielfeld[i + k][j - k] == spielfeld[i][j] || spielfeld[i + k][j - k] == spielfeld[i][j] - 256)){
						if (spielfeld[i + k][j - k] > -1){
							spielfeld[i + k][j - k] -= 256;
						}
						k++;
					}
					steinloeschen = true;
					verrutschen = true;
				}
			}
			//Fall 2: Derzeitiger Stein ist schon in einer Viererlinie enthalten, d.h. markiert mit -256
			else{
				//Diagonalen Richtung rechts unten, die geloescht werden sollen, markieren mit -256
				if ( j < spalten -3 && (spielfeld[i][j] == spielfeld[i + 1][j + 1] || spielfeld[i][j] + 256 == spielfeld[i + 1][j + 1]) 
									&& (spielfeld[i][j] == spielfeld[i + 2][j + 2] || spielfeld[i][j] + 256 == spielfeld[i + 2][j + 2]) 
									&& (spielfeld[i][j] == spielfeld[i + 3][j + 3] || spielfeld[i][j] + 256 == spielfeld[i + 3][j + 3])){
					k = 1;
					while (i + k < zeilen && j + k < spalten && (spielfeld[i + k][j + k] == spielfeld[i][j] || spielfeld[i + k][j + k] == spielfeld[i][j] + 256)){
						if (spielfeld[i + k][j + k] > -1){
							spielfeld[i + k][j + k] -= 256;
						}
						k++;
					}
					verrutschen = true;
				}
				//Diagonalen RIchtung links unten, die geloescht werden sollen, markieren mit -256
				if ( j > 2  && (spielfeld[i][j] == spielfeld[i + 1][j - 1] || spielfeld[i][j] + 256 == spielfeld[i + 1][j - 1]) 
							&& (spielfeld[i][j] == spielfeld[i + 2][j - 2] || spielfeld[i][j] + 256 == spielfeld[i + 2][j - 2]) 
							&& (spielfeld[i][j] == spielfeld[i + 3][j - 3] || spielfeld[i][j] + 256 == spielfeld[i + 3][j - 3])){
					k = 1;
					while (i + k < zeilen && j - k > -1 && (spielfeld[i + k][j - k] == spielfeld[i][j] || spielfeld[i + k][j - k] == spielfeld[i][j] + 256)){
						if (spielfeld[i + k][j - k] > -1){
							spielfeld[i + k][j - k] -= 256;
						}
						k++;
					}
					verrutschen = true;
				}
			}
			//stein ist in Viererlinie, aber noch nicht markiert
			if (steinloeschen){
				spielfeld[i][j] -= 256;
				steinloeschen = false;
			}
		}
	}
	return spielfeld;
}

int main(void){
	int farbe;
	int koord;
	char w;
	int spalten = 4;
	int zeilen = 4;
	int **spielfeld = NULL;
	int offset = 0;
	int spaltneu;
	int ykoord;
	//int **temparray = NULL;
	bool spalteweg = false;
	int zeileweg = -1;
	int zeilenlaenge = 0;
	bool steinloeschen = false;
	
	/*alloziere Speicher fuer Spielfeld (default: 4x4)*/
	spielfeld = malloc(zeilen * sizeof(int*));
	if(spielfeld==NULL){
		fprintf(stderr, "Keinen Speicher für das Spielfeld bekommen!\n");
		exit(0);
	}
	for (i = 0; i < zeilen; i++){
		spielfeld[i]= malloc(spalten * sizeof(int));
		if(spielfeld[i]==NULL){
			fprintf(stderr, "Keinen Speicher für das Spielfeld bekommen!\n");
			exit(0);
		}
		/*Setze alle Werte im Spielfeld auf -1, entspricht leerem Spielfeld ohne Steine*/
		for (j = 0; j < spalten; j++){
			spielfeld[i][j] = -1;
		}
	}
	
	while (scanf("%d %d", &farbe, &koord) != EOF){
		
		//Ueberpruefung der Eingabe
		w = getchar();
		//Eingabe besteht nicht aus exakt 2 Integern
		if (w != '\n' && w != EOF){
			fprintf(stderr,"%s","Falsche Eingabe!\n");
			return -1;
		}
		//Farbe hat ungueltigen Wert
		if (farbe < 0 || farbe > 254){
			fprintf(stderr,"%s", "Farbe nicht gueltig!\n");
			return -1;
		}
		
		//Array ist zu klein und muss vergroessert werden, Spalte rechts hinzufuegen
		if (koord + offset > spalten -1){
			spaltneu = koord + offset + 1;
			//vergroessere Spielfeld
			for ( i = 0; i < zeilen; i++){
				spielfeld[i] = realloc(spielfeld[i], spaltneu * sizeof(int));
				if(spielfeld[i]==NULL){
					fprintf(stderr, "Nicht ausreichend Speicher für das Spielfeld bekommen!\n");
					exit(0);
				}
				//zusaetzliche Spalten mit -1 initiieren
				for (j = spalten; j < spaltneu ; j++){
					spielfeld[i][j] = -1;
				}
			}
			spalten = spaltneu;
		}
		
		//Array ist zu klein und muss vergroessert werden, offset erhoehen da ins Negative vergroessert wird, Spalte links hinzufuegen
		else if (koord < -offset){
			spalten = spalten - koord - offset;
			//Spielfeld vergroessern
			for ( i = 0; i < zeilen; i++){
				spielfeld[i] = realloc(spielfeld[i], spalten * sizeof(int));
				if(spielfeld[i]==NULL){
					fprintf(stderr, "Kein Speicher für das Spielfeld bekommen!\n");
					exit(0);
				}
				//Spielfeld muss verschoben werden, den Rest mit -1 allozieren
				for (j = spalten - 1; j > -koord -offset - 1; j--){
					spielfeld[i][j] = spielfeld[i][j + koord + offset];
				}
				for (j = -koord -offset - 1; j > -1; j--){
					spielfeld[i][j] = -1;
				}
			}
			offset = -koord;
		}
		
		//falls Spalte voll ist, muss das Spielfeld vergroessert werden, Zeile hinzufuegen
		else if (spielfeld[zeilen-1][koord + offset] != -1){
			//neues groesseres Spielfeld
			zeilen += 1;
			spielfeld = realloc(spielfeld, zeilen * sizeof(int*));
			if(spielfeld == NULL){
				fprintf(stderr, "Nicht ausreichend Speicher für das Spielfeld bekommen!\n");
				exit(0);
			}
		
			spielfeld[zeilen -1]=malloc(spalten * sizeof(int));
			if(spielfeld[zeilen -1]==NULL){
				fprintf(stderr, "Nicht ausreichend Speicher für das Spielfeld bekommen!\n");
				exit(0);
			}
			for (j = 0; j < spalten; j++){
				spielfeld[zeilen - 1][j] = -1;
			}
		}

		//Stein wird in Spielfeld hinzugefuegt
		ykoord = 0;
		for (i = zeilen - 2; i > -1; i--){
			if (spielfeld[i][koord+offset] != -1){
				spielfeld[i+1][koord+offset] = farbe;
				ykoord = i+1;
				break;
			}
			else if (i == 0){
				spielfeld[i][koord+offset] = farbe;
				break;
			}
		}
		
		//Ist in der Spalte eine Viererlinie?
		if (ykoord > 2 && spielfeld[ykoord - 1][koord + offset] == farbe && spielfeld[ykoord - 2][koord + offset] == farbe && spielfeld[ykoord - 3][koord + offset] == farbe){
			spalteweg = true;
		}
		
		//Ist in der Zeile eine Viererlinie?
		for (j = 0; j < spalten - 3; j++){
			if (spielfeld[ykoord][j] == farbe && spielfeld[ykoord][j + 1] == farbe && spielfeld[ykoord][j + 2] == farbe && spielfeld[ykoord][j + 3] == farbe){
				zeileweg = j;
				zeilenlaenge = 4;
				while (zeileweg + zeilenlaenge != spalten && spielfeld[ykoord][zeileweg + zeilenlaenge] == farbe){
					zeilenlaenge++;
				}
				break;
			}
		}
		
		//gibt es diagonale Viererlinien?
		spielfeld = diagonale(spielfeld, zeilen, spalten);
		
		//Diagonalen loeschen
		if (verrutschen){
			spielfeld = loeschen(spielfeld, zeilen, spalten);
		}
		
		//Spalte loeschen
		if (spalteweg){
			for (i = 0; i < 4; i++){
				spielfeld[ykoord - i][koord + offset] = -1;
			}
			spalteweg = false;
		}
		
		//Zeile loeschen
		if (zeileweg != -1){
			for (i = zeileweg; i < zeileweg + zeilenlaenge; i++){
				spielfeld[ykoord][i] = -1;
			}
			verrutschen = true;
			zeileweg = -1;
		}
		//Spalten nachrutschen
		if (verrutschen){
			spielfeld = nachrutschen(spielfeld, zeilen, spalten);
		}
		
		//Spielfeld nach Viererlinien durchsuchen, die durch Nachrutschen entstanden sind, bis nichts mehr nachrutscht
		while (verrutschen){
			verrutschen = false;
			
			//Nach Spalten, Zeilen und Diagonalen zum Loeschen suchen
			for (j = 0; j < spalten; j++){
				for (i = 0; i < zeilen; i++){
					//Am Ende der Spalte angekommen?
					if (spielfeld[i][j] == -1){
						break;
					}
					//Fall 1: Derzeitiger Stein ist noch nicht markiert
					else if (spielfeld[i][j] > -1){
						//Zeilen, die geloescht werden sollen, markieren mit -256
						if (j < spalten - 3 && (spielfeld[i][j] == spielfeld[i][j + 1] || spielfeld[i][j] - 256 == spielfeld[i][j + 1]) 
											&& (spielfeld[i][j] == spielfeld[i][j + 2] || spielfeld[i][j] - 256 == spielfeld[i][j + 2]) 
											&& (spielfeld[i][j] == spielfeld[i][j + 3] || spielfeld[i][j] - 256 == spielfeld[i][j + 3])){
							k = 1;
							while (j + k < spalten && (spielfeld[i][j] == spielfeld[i][j + k] || spielfeld[i][j] - 256 == spielfeld[i][j + k])){
								if (spielfeld[i][j + k] > -1){
									spielfeld[i][j + k] -= 256;
								}
								k++;
							}
							steinloeschen = true;
							verrutschen = true;
						}
						//Spalten, die geloescht werden sollen, markieren mit -256
						if (i < zeilen - 3  && (spielfeld[i][j] == spielfeld[i + 1][j] || spielfeld[i][j] - 256 == spielfeld[i + 1][j]) 
											&& (spielfeld[i][j] == spielfeld[i + 2][j] || spielfeld[i][j] - 256 == spielfeld[i + 2][j]) 
											&& (spielfeld[i][j] == spielfeld[i + 3][j] || spielfeld[i][j] - 256 == spielfeld[i + 3][j])){
							k = 1;
							while (i + k < zeilen && (spielfeld[i][j] == spielfeld[i + k][j] || spielfeld[i][j] - 256 == spielfeld[i + k][j])){
								if (spielfeld[i + k][j] > -1){
									spielfeld[i + k][j] -= 256;
								}
								k++;
							}
							steinloeschen = true;
							verrutschen = true;
						}
						//Diagonalen Richtung rechts unten, die geloescht werden sollen, markieren mit -256
						if ( j < spalten - 3 && i < zeilen - 3  && (spielfeld[i][j] == spielfeld[i + 1][j + 1] || spielfeld[i][j] - 256 == spielfeld[i + 1][j + 1]) 
																&& (spielfeld[i][j] == spielfeld[i + 2][j + 2] || spielfeld[i][j] - 256 == spielfeld[i + 2][j + 2]) 
																&& (spielfeld[i][j] == spielfeld[i + 3][j + 3] || spielfeld[i][j] - 256 == spielfeld[i + 3][j + 3])){
							k = 1;
							while (i + k < zeilen && j + k < spalten && (spielfeld[i + k][j + k] == spielfeld[i][j] || spielfeld[i + k][j + k] == spielfeld[i][j] - 256)){
								if (spielfeld[i + k][j + k] > -1){
									spielfeld[i + k][j + k] -= 256;
								}
								k++;
							}
							steinloeschen = true;
							verrutschen = true;
						}
						//Diagonalen Richtung links unten, die geloescht werden sollen, markieren mit -256
						if (j > 2 && i < zeilen - 3 && (spielfeld[i][j] == spielfeld[i + 1][j - 1] || spielfeld[i][j] - 256 == spielfeld[i + 1][j - 1]) 
													&& (spielfeld[i][j] == spielfeld[i + 2][j - 2] || spielfeld[i][j] - 256 == spielfeld[i + 2][j - 2]) 
													&& (spielfeld[i][j] == spielfeld[i + 3][j - 3] || spielfeld[i][j] - 256 == spielfeld[i + 3][j - 3])){
							k = 1;
							while (i + k < zeilen && j - k > -1 && (spielfeld[i + k][j - k] == spielfeld[i][j] || spielfeld[i + k][j - k] == spielfeld[i][j] - 256)){
								if (spielfeld[i + k][j - k] > -1){
									spielfeld[i + k][j - k] -= 256;
								}
								k++;
							}
							steinloeschen = true;
							verrutschen = true;
						}
						if (steinloeschen){
							spielfeld[i][j] -= 256;
							steinloeschen = false;
						}
					}
					//Fall 2: Derzeitiger Stein ist bereits Teil einer Viererlinie, wurde also schon mit -256 markiert
					else{
						//Zeilen, die geloescht werden sollen, markieren mit -256
						if (j < spalten - 3 && (spielfeld[i][j] == spielfeld[i][j + 1] || spielfeld[i][j] + 256 == spielfeld[i][j + 1]) 
											&& (spielfeld[i][j] == spielfeld[i][j + 2] || spielfeld[i][j] + 256 == spielfeld[i][j + 2]) 
											&& (spielfeld[i][j] == spielfeld[i][j + 3] || spielfeld[i][j] + 256 == spielfeld[i][j + 3])){
							k = 1;
							while (j + k < spalten && (spielfeld[i][j] == spielfeld[i][j + k] || spielfeld[i][j] + 256 == spielfeld[i][j + k])){
								if (spielfeld[i][j + k] > -1){
									spielfeld[i][j + k] -= 256;
								}
								k++;
							}
							verrutschen = true;
						}
						//Spalten, die geloescht werden sollen, markieren mit -256
						if ( i < zeilen - 3 && (spielfeld[i][j] == spielfeld[i + 1][j] || spielfeld[i][j] + 256 == spielfeld[i + 1][j]) 
											&& (spielfeld[i][j] == spielfeld[i + 2][j] || spielfeld[i][j] + 256 == spielfeld[i + 2][j]) 
											&& (spielfeld[i][j] == spielfeld[i + 3][j] || spielfeld[i][j] + 256 == spielfeld[i + 3][j])){
							k = 1;
							while (i + k < zeilen && (spielfeld[i][j] == spielfeld[i + k][j] || spielfeld[i][j] + 256 == spielfeld[i + k][j])){
								if (spielfeld[i + k][j] > -1){
									spielfeld[i + k][j] -= 256;
								}
								k++;
							}
							verrutschen = true;
						}
						//Diagonalen, die geloescht werden sollen, markieren mit -256
						if ( j < spalten - 3 && i < zeilen - 3  && (spielfeld[i][j] == spielfeld[i + 1][j + 1] || spielfeld[i][j] + 256 == spielfeld[i + 1][j + 1]) 
																&& (spielfeld[i][j] == spielfeld[i + 2][j + 2] || spielfeld[i][j] + 256 == spielfeld[i + 2][j + 2]) 
																&& (spielfeld[i][j] == spielfeld[i + 3][j + 3] || spielfeld[i][j] + 256 == spielfeld[i + 3][j + 3])){
							k = 1;
							while (i + k < zeilen && j + k < spalten && (spielfeld[i + k][j + k] == spielfeld[i][j] || spielfeld[i + k][j + k] == spielfeld[i][j] + 256)){
								if (spielfeld[i + k][j + k] > -1){
									spielfeld[i + k][j + k] -= 256;
								}
								k++;
							}
							verrutschen = true;
						}
						//Diagonalen, die geloescht werden sollen, markieren mit -256
						if (j > 2 && i < zeilen - 3 && (spielfeld[i][j] == spielfeld[i + 1][j - 1] || spielfeld[i][j] + 256 == spielfeld[i + 1][j - 1]) 
													&& (spielfeld[i][j] == spielfeld[i + 2][j - 2] || spielfeld[i][j] + 256 == spielfeld[i + 2][j - 2]) 
													&& (spielfeld[i][j] == spielfeld[i + 3][j - 3] || spielfeld[i][j] + 256 == spielfeld[i + 3][j - 3])){
							k = 1;
							while (i + k < zeilen && j - k > -1 && (spielfeld[i + k][j - k] == spielfeld[i][j] || spielfeld[i + k][j - k] == spielfeld[i][j] + 256)){
								if (spielfeld[i + k][j - k] > -1){
									spielfeld[i + k][j - k] -= 256;
								}
								k++;
							}
							verrutschen = true;
						}
					}
				}
			}
			if (verrutschen){
				//markierte Spielfelder auf -1 setzen
				spielfeld = loeschen(spielfeld, zeilen, spalten);
				//Spalten nachrutschen
				spielfeld = nachrutschen(spielfeld, zeilen, spalten);
			}
		}
	}
	//Ausgabe aller Felder != -1
	for (i=0;i<zeilen;i++){
		for (j=0;j<spalten;j++){
			if (spielfeld[i][j] != -1){
				printf("%d %d %d\n", spielfeld[i][j], j - offset, i);
			}
		}
	}
	//Spielfeld am Ende wieder freigeben
	for (i = 0; i < zeilen; i++){
		free(spielfeld[i]);
	}
	free(spielfeld);
	return 0;
} 
