#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <string.h>
#include <stdbool.h> 

#define COLOR_MIN 0
#define COLOR_MAX 254
#define MIN_CRUSH 4
#define DEBUG false
#define PRINT_FIELD false

void printField(long** field, long width, long height);
char *readLine(void);
struct InputLine *parseLine(void);
long min(long a, long b);
long max(long a, long b);
bool slidePieces(long** field, long minX, long maxX, long height);

struct InputLine {
	long color;
	long x;
};

struct Line {
	long x1;
	long y1;
	long x2;
	long y2;
};
bool isInAnyLine(long x, long y, struct Line *lines, int n);

int main() {
	// struct InputLine *inputArr = malloc(inputArrSize * sizeof(*inputArr));
	// struct InputLine *inputArrPointer = inputArr;

	size_t inputArrSize = 4;
	long *colors = malloc(inputArrSize * sizeof(*colors)),
		*colorsPointer = colors;
	long *xCoords = malloc(inputArrSize * sizeof(*xCoords)),
		*xCoordsPointer = xCoords;

	struct InputLine *input = parseLine();
	if(input == NULL) {
		// printf("%s\n", "Invalid input!");
		free(colorsPointer);
		free(xCoordsPointer);
		exit(1);
	}

	long maxX = 0,
		minX = 0,
		i = -1;
	// read input
	while(input != NULL) {
		// check if x in min-max range, otherwise change
		if(input->x < minX) {
			minX = input->x;
		} else if(input->x > maxX) {
			maxX = input->x;
		}

		// validate color
		if(input->color < COLOR_MIN || input->color > COLOR_MAX) {
			printf("%s\n", "Invalid Color!");
			free(colorsPointer);
			free(xCoordsPointer);
			free(input);
			exit(1);
		}

		// array full -> double size
		if(++i == (long)inputArrSize -1) {
			inputArrSize *= 2;
			if(DEBUG) printf("Doubling array size to %d\n", (int)inputArrSize);
			// inputArrPointer = realloc(inputArrPointer, inputArrSize * sizeof(*inputArr));
			long *tmpColorsPointer = (long*) realloc(colorsPointer, inputArrSize * sizeof(*colors));
			long *tmpXCoordsPointer = (long*) realloc(xCoordsPointer, inputArrSize * sizeof(*xCoords));

			if(tmpColorsPointer == NULL || tmpXCoordsPointer == NULL) {
				free(colorsPointer);
				free(xCoordsPointer);
				free(input);
				printf("%s\n", "Error allocating memory for input");
				exit(1);
			}
			// Fix pointers
			colors = tmpColorsPointer + (colors - colorsPointer);
			colorsPointer = tmpColorsPointer;
			xCoords = tmpXCoordsPointer + (xCoords - xCoordsPointer);
			xCoordsPointer = tmpXCoordsPointer;
		}

		// write input to array and move pointer
		colors[i] = input->color;
		xCoords[i] = input->x;

		free(input);
		// recieve new input
		input = parseLine();
	}

	// initialize play-field
	long x, y;
	long width = abs(minX) + maxX + 1;
	long height = 2;
	int offset = abs(minX);
	long **field;

	if(DEBUG) printf("Width: %ld, Height: %ld, Offset: %d\n", width, height, offset);

	// allocate playing field
	field = malloc(width * sizeof(*field));
	for (x = 0; x < width; ++x)
	{
		field[x] = malloc(height * sizeof(*field[x]));
	}

	// set empty fields to -1
	for (x = 0; x < width; ++x)
	{
		for (y = 0; y < height; ++y)
		{
			field[x][y] = -1;
		}
	}


	if(PRINT_FIELD) printField(field, width, height);

	int elements = i + 1;
	// printf("elements: %d\n", elements);
	// printf("inputArrPointer[0].x: %ld\n", inputArrPointer[0].x);

	long translatedX;
	bool checkVertical, checkHorizontal, checkDiagonal;
	for(i = 0; i < elements; ++i) {

		// printf("Input #%ld: x:%ld,color:%ld\n", i, colorsPointer[i], xCoordsPointer[i]);

		y = 0;
		while(field[offset + xCoordsPointer[i]][y] != -1 && y < height) {
			y++;
		}

		// // check if field big enough for y realloc if neccessary
		if(y >= height) {
			if(DEBUG) printf("%s\n", "Doubling field height...");
			size_t newHeight = height * 2;
			for (x = 0; x < width; ++x)
			{
				field[x] = (long *) realloc(field[x], newHeight * sizeof(*field[x]));
				if(field[x] == NULL) {
					printf("%s\n", "Error reallocating field (height)");
					// deallocate field
					for (x = 0; x < width; ++x)
					{
						free(field[x]);
					}
					free(field);
					exit(1);
				}
				// set newly allocated fields to -1
				for(int h = height; h < (int)newHeight; ++h) {
					field[x][h] = -1;
				}
			}
			height = newHeight;
		}

		if(DEBUG) printf("#%ld - Inserting color %ld into x:%ld, y:%ld\n", i, colorsPointer[i], xCoordsPointer[i], y);
		translatedX = offset + xCoordsPointer[i];
		field[translatedX][y] = colorsPointer[i];

		checkVertical = y > 0 && field[translatedX][y] == field[translatedX][y - 1];
		checkHorizontal = (translatedX > 0 && field[translatedX][y] == field[translatedX - 1][y])  || (translatedX < width - 1 && field[translatedX][y] == field[translatedX + 1][y]);
		// above left
		checkDiagonal = translatedX > 0 && y + 1 < height && field[translatedX][y] == field[translatedX - 1][y + 1];
		// above right
		checkDiagonal = checkDiagonal || (translatedX < width - 1 && y + 1 < height && field[translatedX][y] == field[translatedX + 1][y + 1]);
		// below left
		checkDiagonal = checkDiagonal || (translatedX > 0 && y > 0 && field[translatedX][y] == field[translatedX - 1][y - 1]);
		// below right
		checkDiagonal = checkDiagonal || (translatedX < width - 1 && y > 0 && field[translatedX][y] == field[translatedX + 1][y - 1]);

		// printf("checkVertical:%d, checkHorizontal:%d, checkHorizontal:%d\n", (int)checkVertical, (int)checkHorizontal, (int)checkDiagonal);
		if(i + 1 >= MIN_CRUSH && (checkVertical || checkHorizontal || checkDiagonal)) {
			// check for matches
			// printf("%s\n", "check stuff!");

			bool hLineFound = false;
			long hMinX = translatedX,
				hMaxX = translatedX,
				hY = y;
			if(checkHorizontal) {
				long xtmp = translatedX;
				// check left
				while(--xtmp >= 0 && field[translatedX][y] == field[xtmp][y]) {
					hMinX = xtmp;
				}
				xtmp = translatedX;
				// check right
				while(++xtmp < width && field[translatedX][y] == field[xtmp][y]) {
					hMaxX = xtmp;
				}
				hLineFound = hMaxX - hMinX >= MIN_CRUSH - 1;
				// printf("hMinX:%ld, hMaxX:%ld\n", hMinX, hMaxX);
				if(hLineFound) {
					if(DEBUG) printf("Horizontal Line found (%ld, %ld) -> (%ld, %ld)\n", hMinX, hY, hMaxX, hY);
				}
			}

			bool vLineFound = false;
			long vMinY = y,
				vMaxY = y,
				vX = translatedX;
			if(checkVertical) {
				long ytmp = y;
				// check below
				while(--ytmp >= 0 && field[translatedX][y] == field[translatedX][ytmp]) {
					vMinY = ytmp;
				}

				vLineFound = vMaxY - vMinY >= MIN_CRUSH - 1;
				if(vLineFound) {
					if(DEBUG) printf("Vertical Line found (%ld, %ld) -> (%ld, %ld)\n", vX, vMinY, vX, vMaxY);
				}
			}

			bool topLeftToBottomRightLineFound = false,
				bottomLeftToTopRightLineFound = false;
			long topLeftToBottomRightx1 = translatedX,
				topLeftToBottomRightx2 = translatedX,
				topLeftToBottomRighty1 = y,
				topLeftToBottomRighty2 = y;
			long bottomLeftToTopRightx1 = translatedX,
				bottomLeftToTopRightx2 = translatedX,
				bottomLeftToTopRighty1 = y,
				bottomLeftToTopRighty2 = y;
			if(checkDiagonal) {
				long xtmp = translatedX,
					yTopTmp = y,
					yBottomTmp = y;
				bool oneLineFound = true;
				// check left
				while(--xtmp >= 0 && oneLineFound) {
					oneLineFound = false;
					// check top left
					if(++yTopTmp < height && field[translatedX][y] == field[xtmp][yTopTmp]) {
						oneLineFound = true;
						topLeftToBottomRighty1 = yTopTmp;
						topLeftToBottomRightx1 = xtmp;
					}
					// check bottom left
					if(--yBottomTmp >= 0 && field[translatedX][y] == field[xtmp][yBottomTmp]) {
						oneLineFound = true;
						bottomLeftToTopRighty1 = yBottomTmp;
						bottomLeftToTopRightx1 = xtmp;
					}
					if(!oneLineFound) {
						break;
					}
				}
				xtmp = translatedX;
				yTopTmp = y;
				yBottomTmp = y;
				oneLineFound = true;
				// check right
				while(++xtmp < width && oneLineFound) {
					oneLineFound = false;
					// check top right
					if(++yTopTmp < height && field[translatedX][y] == field[xtmp][yTopTmp]) {
						oneLineFound = true;
						bottomLeftToTopRighty2 = yTopTmp;
						bottomLeftToTopRightx2 = xtmp;
					}
					// check bottom right
					if(--yBottomTmp >= 0 && field[translatedX][y] == field[xtmp][yBottomTmp]) {
						oneLineFound = true;
						topLeftToBottomRighty2 = yBottomTmp;
						topLeftToBottomRightx2 = xtmp;
					}
					if(!oneLineFound) {
						break;
					}
				}

				topLeftToBottomRightLineFound = topLeftToBottomRightx2 - topLeftToBottomRightx1 >= MIN_CRUSH - 1;
				bottomLeftToTopRightLineFound = bottomLeftToTopRightx2 - bottomLeftToTopRightx1 >= MIN_CRUSH - 1;
				if(topLeftToBottomRightLineFound) {
					if(DEBUG) printf("topLeftToBottomRightLineFound (%ld, %ld) -> (%ld, %ld)\n", topLeftToBottomRightx1, topLeftToBottomRighty1, topLeftToBottomRightx2, topLeftToBottomRighty2);
				}
				if(bottomLeftToTopRightLineFound) {
					if(DEBUG) printf("bottomLeftToTopRightLineFound (%ld, %ld) -> (%ld, %ld)\n", bottomLeftToTopRightx1, bottomLeftToTopRighty1, bottomLeftToTopRightx2, bottomLeftToTopRighty2);
				}
			}

			bool anylineFound = hLineFound || vLineFound || topLeftToBottomRightLineFound || bottomLeftToTopRightLineFound;
			
			if(PRINT_FIELD) printField(field, width, height);

			long slideX1 = translatedX,
				slideX2 = translatedX;

			bool haveToSlide = false;

			// remove horizontal line if found
			if(hLineFound) {
				if(DEBUG) printf("%s\n", "Removing Horizontal Line...");
				long xtmp;
				for(xtmp = hMinX; xtmp <= hMaxX; xtmp++) {
					haveToSlide = haveToSlide || (hY + 1 < height && field[xtmp][hY + 1] != -1);
					field[xtmp][hY] = -1;
				}
				slideX1 = min(slideX1, hMinX);
				slideX2 = max(slideX2, hMaxX);
			}

			// remove vertical line if found
			if(vLineFound) {
				if(DEBUG) printf("%s\n", "Removing Vertical Line...");
				long ytmp;
				for(ytmp = vMinY; ytmp <= vMaxY; ytmp++) {
					field[vX][ytmp] = -1;
				}
				slideX1 = min(slideX1, vX);
				slideX2 = max(slideX2, vX);
				haveToSlide = haveToSlide || (vMaxY + 1 < height && field[vX][vMaxY + 1] != -1);
			}

			// remove top-left to bottom-right diagonal line if found
			if(topLeftToBottomRightLineFound) {
				if(DEBUG) printf("%s\n", "Removing Top-Left to Bottom-right Diagional Line...");
				long xtmp = topLeftToBottomRightx1,
					ytmp = topLeftToBottomRighty1;

				while(xtmp <= topLeftToBottomRightx2 && ytmp >= topLeftToBottomRighty2) {
					haveToSlide = haveToSlide || (ytmp + 1 < height && field[xtmp][ytmp + 1] != -1);
					field[xtmp++][ytmp--] = -1;
				}
				slideX1 = min(slideX1, topLeftToBottomRightx1);
				slideX2 = max(slideX2, topLeftToBottomRightx2);
			}

			// remove bottom-left to top-right diagonal line if found
			if(bottomLeftToTopRightLineFound) {
				if(DEBUG) printf("%s\n", "Removing Bottom-Left to Top-right Diagional Line...");
				long xtmp = bottomLeftToTopRightx1,
					ytmp = bottomLeftToTopRighty1;

				while(xtmp <= bottomLeftToTopRightx2 && ytmp <= bottomLeftToTopRightx2) {
					haveToSlide = haveToSlide || (ytmp + 1 < height && field[xtmp][ytmp + 1] != -1);
					field[xtmp++][ytmp++] = -1;
				}
				slideX1 = min(slideX1, bottomLeftToTopRightx1);
				slideX2 = max(slideX2, bottomLeftToTopRightx2);
			}

			// slide down
			if(anylineFound && haveToSlide) {
				bool anyMoved = slidePieces(field, slideX1, slideX2, height);

				// if any slid down we need to check for new rows...
				while(anyMoved) {
					if(DEBUG) printf("%s\n", "Some shit moved");

					if(PRINT_FIELD) printField(field, width, height);

					int linesIndex = -1;
					size_t linesSize = 1;
					struct Line *lines = malloc(linesSize * sizeof(struct Line)),
						*linesPointer = lines;

					if(lines == NULL) {
						printf("%s\n", "Error allocating Line array!");
						// deallocate field
						for (x = 0; x < width; ++x)
						{
							free(field[x]);
						}
						free(field);
						exit(1);
					}

					long tmpx, tmpy, tmpx2, tmpy2;

					// search horizontal and diagonal WHOLE FIELD BECAUSE FUCK DO I KNOW
					for(tmpx = 0; tmpx < max(width - (MIN_CRUSH - 1), 0); tmpx++) {
						for(tmpy = 0; tmpy < height; tmpy++) {
							if(field[tmpx][tmpy] != -1 && !isInAnyLine(tmpx, tmpy, lines, linesIndex + 1)) {
								// horizonal
								tmpx2 = tmpx + 1;
								while(tmpx2 < width && field[tmpx][tmpy] == field[tmpx2][tmpy]) {
									tmpx2++;
								}
								if(tmpx2 - tmpx > MIN_CRUSH - 1) {
									if(DEBUG) printf("%s\n", "Line found!");
									struct Line *line = malloc(sizeof (struct Line));

									if(line == NULL) {
										printf("%s\n", "Error allocating Line!");
										free(linesPointer);
										free(lines);
										// deallocate field
										for (x = 0; x < width; ++x)
										{
											free(field[x]);
										}
										free(field);
										exit(1);
									}

									line->x1 = tmpx;
									line->x2 = tmpx2 - 1;
									line->y1 = tmpy;
									line->y2 = tmpy;

									if(linesSize - ++linesIndex == 0) {
										linesSize = linesSize * 2;
										struct Line *linestmp = realloc(linesPointer, linesSize * sizeof(struct Line));

										if(linestmp == NULL) {
											printf("%s\n", "Error reallocating lines array!");
											free(linesPointer);
											free(lines);
											// deallocate field
											for (x = 0; x < width; ++x)
											{
												free(field[x]);
											}
											free(field);
											exit(1);
										}
										// Fix pointers
										lines = linestmp + (lines - linesPointer);
										linesPointer = linestmp;
									}

									lines[linesIndex] = *line;
									free(line);
								}
								// diagonal upwards
								tmpx2 = tmpx + 1;
								tmpy2 = tmpy + 1;
								while(tmpx2 < width && tmpy2 < height && field[tmpx][tmpy] == field[tmpx2][tmpy2]) {
									tmpx2++;
									tmpy2++;
								}
								if(tmpx2 - tmpx > MIN_CRUSH - 1) {
									if(DEBUG) printf("%s\n", "Line found!");
									struct Line *line = malloc(sizeof (struct Line));

									if(line == NULL) {
										printf("%s\n", "Error allocating Line!");
										free(linesPointer);
										free(lines);
										// deallocate field
										for (x = 0; x < width; ++x)
										{
											free(field[x]);
										}
										free(field);
										exit(1);
									}

									line->x1 = tmpx;
									line->x2 = tmpx2 - 1;
									line->y1 = tmpy;
									line->y2 = tmpy2 - 1;

									if(linesSize - ++linesIndex == 0) {
										linesSize = linesSize * 2;
										struct Line *linestmp = realloc(linesPointer, linesSize * sizeof(struct Line));

										if(linestmp == NULL) {
											printf("%s\n", "Error reallocating lines array!");
											free(linesPointer);
											free(lines);
											// deallocate field
											for (x = 0; x < width; ++x)
											{
												free(field[x]);
											}
											free(field);
											exit(1);
										}
										// Fix pointers
										lines = linestmp + (lines - linesPointer);
										linesPointer = linestmp;
									}

									lines[linesIndex] = *line;
								}
								// diagonal downwards
								tmpx2 = tmpx + 1;
								tmpy2 = tmpy - 1;
								while(tmpx2 < width && tmpy2 > 0 && field[tmpx][tmpy] == field[tmpx2][tmpy2]) {
									tmpx2++;
									tmpy2--;
								}
								if(tmpx2 - tmpx > MIN_CRUSH - 1) {
									if(DEBUG) printf("%s\n", "Line found!");
									struct Line *line = malloc(sizeof (struct Line));

									if(line == NULL) {
										printf("%s\n", "Error allocating Line!");
										exit(1);
									}

									line->x1 = tmpx;
									line->x2 = tmpx2 - 1;
									line->y1 = tmpy;
									line->y2 = tmpy2 + 1;

									if(linesSize - ++linesIndex == 0) {
										linesSize = linesSize * 2;
										struct Line *linestmp = realloc(linesPointer, linesSize * sizeof(struct Line));

										if(linestmp == NULL) {
											printf("%s\n", "Error reallocating lines array!");
											free(linesPointer);
											free(lines);
											// deallocate field
											for (x = 0; x < width; ++x)
											{
												free(field[x]);
											}
											free(field);
											exit(1);
										}
										// Fix pointers
										lines = linestmp + (lines - linesPointer);
										linesPointer = linestmp;
									}

									lines[linesIndex] = *line;
								}
							} else if(field[tmpx][tmpy] == -1) {
								break;
							}
						}
					}

					// vertical search only in slide range, the rest didn't chance vertically
					for(tmpx = slideX1; tmpx <= slideX2; tmpx++) {
						for(tmpy = 0; tmpy < max(height - (MIN_CRUSH - 1), 0); tmpy++) {
							if(field[tmpx][tmpy] != -1 && !isInAnyLine(tmpx, tmpy, lines, linesIndex + 1)) {
								tmpy2 = tmpy + 1;
								while(tmpy2 < width && field[tmpx][tmpy] == field[tmpx][tmpy2]) {
									tmpy2++;
								}
								if(tmpy2 - tmpy > MIN_CRUSH - 1) {
									if(DEBUG) printf("%s\n", "Line found!");
									struct Line *line = malloc(sizeof (struct Line));

									if(line == NULL) {
										printf("%s\n", "Error allocating Line!");
										free(linesPointer);
										free(lines);
										// deallocate field
										for (x = 0; x < width; ++x)
										{
											free(field[x]);
										}
										free(field);
										exit(1);
									}

									line->x1 = tmpx;
									line->x2 = tmpx;
									line->y1 = tmpy;
									line->y2 = tmpy2 - 1;

									if(linesSize - ++linesIndex == 0) {
										linesSize = linesSize * 2;
										struct Line *linestmp = realloc(linesPointer, linesSize * sizeof(struct Line));

										if(linestmp == NULL) {
											printf("%s\n", "Error reallocating lines array!");
											free(linesPointer);
											free(lines);
											exit(1);
										}
										// Fix pointers
										lines = linestmp + (lines - linesPointer);
										linesPointer = linestmp;
									}

									lines[linesIndex] = *line;
								}
							} else if(field[tmpx][tmpy] != -1) {
								break;
							}
						}
					}

					int j;
					slideX1 = width - 1;
					slideX2 = 0;
					for(j = 0; j <= linesIndex; j++) {
						if(DEBUG) printf("Removing Line #%d: (%ld, %ld) -> (%ld, %ld)\n", j, lines[j].x1, lines[j].y1, lines[j].x2, lines[j].y2);
						for(tmpx = lines[j].x1; tmpx <= lines[j].x2; tmpx++) {
							for(tmpy = lines[j].y1; tmpy <= lines[j].y2; tmpy++) {
								field[tmpx][tmpy] = -1;
							}
						}
						slideX1 = min(slideX1, lines[j].x1);
						slideX2 = max(slideX2, lines[j].x2);
					}

					anyMoved = slidePieces(field, slideX1, slideX2, height);
					free(linesPointer);
				}
			}
		}
	}

	if(PRINT_FIELD) printField(field, width, height);

	// print result
	for (x = 0; x < width; ++x) {
		for (y = 0; y < height; ++y){
			if(field[x][y] != -1) {
				printf("%ld %ld %ld\n", field[x][y], x - offset, y);
			}
		}
	}

	free(colorsPointer);
	free(xCoordsPointer);

	// deallocate field
	for (x = 0; x < width; ++x)
	{
		free(field[x]);
	}
	free(field);
	return 0;
}

bool isInAnyLine(long x, long y, struct Line *lines, int n) {
	if(n <= 0) {
		return false;
	}
	int i;
	for(i = 0; i <= n; i++) {
		// printf("Checking if (%ld, %ld) is in line #%d: (%ld, %ld) -> (%ld, %ld)\n", x, y, i, lines[i].x1, lines[i].y1, lines[i].x2, lines[i].y2);
		if(x <= lines[i].x2 && x >= lines[i].x1 && y <= lines[i].y2 && y >= lines[i].y1) {
			if(DEBUG) printf("(%ld, %ld) is in line #%d: (%ld, %ld) -> (%ld, %ld)\n", x, y, i, lines[i].x1, lines[i].y1, lines[i].x2, lines[i].y2);
			return true;
		}
	}
	return false;
}

// iterate over the part of the field, where pieces were removed
// check if there are gaps (-1) in the field and move pieces down as long as that's the case
bool slidePieces(long** field, long minX, long maxX, long height) {
	long xtmp, ytmp, ytmp2, colorTmp;
	bool gapFound,
		anyMoved = false;
	for(xtmp = minX; xtmp <= maxX; xtmp++) {
		do {
			for(ytmp = 0; ytmp < height; ytmp++) {
				gapFound = false;
				if(field[xtmp][ytmp] == -1) {
					for(ytmp2 = ytmp + 1; ytmp2 < height; ytmp2++) {
						if(field[xtmp][ytmp2] != -1) {
							gapFound = true;
							anyMoved = true;
							colorTmp = field[xtmp][ytmp2];
							field[xtmp][ytmp2] = -1;
							field[xtmp][ytmp] = colorTmp;
							break;
						}
					}
				}
			}
		} while (gapFound);
	}
	return anyMoved;
}

void printField(long** field, long width, long height) {
	long x, y;


	printf("\n");
	for (y = height - 1; y >= 0; --y)
	{
		for (x = 0; x < width; ++x)
		{
			printf("%s%s%ld ", field[x][y] > 10 ? "" : " ", field[x][y] < 0 ? "" : " ", field[x][y]);
		}
		printf("\n");
	}
	printf("\n");

	return;
}

long min(long a, long b) {
	if(a <= b) {
		return a;
	}
	return b;
}

long max(long a, long b) {
	if(a >= b) {
		return a;
	}
	return b;
}

struct InputLine *parseLine(void) {
    char *line = malloc(32),
    	*linePointer = line;
    size_t maxLen = 32,
    	len = maxLen;
    int c;
    char *end;
    struct InputLine *input = malloc(sizeof (struct InputLine));

    if(line == NULL || input == NULL){
    	free(input);
    	free(linePointer);
    	return NULL;
    }

    // read color
    while(1) {
        c = fgetc(stdin);
        if(c == ' ') {
        	break;
        } else if(c == EOF || c == '\n') {
            free(input);
            free(linePointer);
            return NULL;
        } else if (!isdigit(c)) {
        	printf("%s\n", "Invalid input! (color)");
        	printf("c:'%c'\n", c);
	    	free(input);
	    	free(linePointer);
        	exit(1);
        }

        // line full -> reallocate and double size
        if(--len == 0) {
            len = maxLen;
            linePointer = realloc(linePointer, maxLen *= 2);

            if(linePointer == NULL) {
            	// realloc failed
                free(linePointer);
                free(input);
                return NULL;
            }
        }

        // write c to line and move pointer
        (*line++ = c);
    }
    *line = '\0';

    if(linePointer[0] == '\0') {
    	printf("%s\n", "Invalid input!");
    	free(linePointer);
    	free(input);
    	return NULL;
    }

    errno = 0;
    long col = strtol(linePointer, &end, 10);
    // printf("Color: %ld\n", col);
    input->color = col;
    if (errno == ERANGE || *end != '\0'){
        printf("Error when parsing color!");
        free(linePointer);
        free(input);
        exit(1);
    }

    // reset
    char *line2 = malloc(32),
    	*linePointer2 = line2;
    maxLen = 32;
    len = maxLen;

    bool minusFound = false;

    // read x-coordinate
    while(1) {
        c = fgetc(stdin);
        if(c == EOF || c == '\n') {
            break;
        } else if ((!isdigit(c) && c != '-') || (c == '-' && minusFound)) {
        	free(linePointer);
        	free(linePointer2);
        	free(input);
        	printf("%s\n", "Invalid input! (x)");
        	printf("c='%c'\n", c);
        	exit(1);
        } else if(c == '-') {
        	minusFound = true;
        }

        // line2 full -> reallocate and double size
        if(--len == 0) {
            len = maxLen;
            linePointer2 = realloc(linePointer2, maxLen *= 2);

            if(linePointer2 == NULL) {
            	// realloc failed
                free(linePointer);
                free(linePointer2);
                free(input);
                return NULL;
            }
        }

        // write c to line2 and move pointer
        *line2++ = c;
    }
    *line2 = '\0';

    if(linePointer2[0] == '\0') {
    	printf("%s\n", "Invalid input!");
        free(linePointer);
        free(linePointer2);
        free(input);
    	exit(1);
    }

    errno = 0;
    long xPos = strtol(linePointer2, &end, 10);
    // printf("xPos: %ld\n", xPos);
    input->x = xPos;
    if (errno == ERANGE || *end != '\0'){
        printf("Error when parsing x-coordinate!");
        exit(1);
    }

    free(linePointer);
    free(linePointer2);

    return input;
}
