#define  _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include <string.h>

#define STARTSIZE 100
#define SMALL 25000
#define SMALLISH 50000
#define MIDISH 100000
#define MIDSIZE 200000
#define ENDSIZE 500000
#define MAXSIZE 1048576
#define INITHEIGHT 3

typedef struct InsertNode
{
    int xCoord; //Contains x-position of block
    int color; //Contains color of block
} InsertNode;

typedef struct Position {
    int xPos;
    int yPos;
} Position;

typedef struct DeleteNode
{
    int xPos;
    int yPos;
    struct DeleteNode *next;
} DeleteNode;

typedef struct ColumnNode
{
    int xPos;
    int yPos;
    struct ColumnNode *next;
} ColumnNode;

u_int16_t** gameBoard;
int** sizeGameBoard;

DeleteNode* listOfDeletions;
ColumnNode** columnHashTable;
int deletionLength;

int lengthOfGameBoard = STARTSIZE;
int offset;

int globalErrorFlag = 0;

//The individual columns are initialized on demand later
int initializeGameBoard() {
    if ((gameBoard = calloc((STARTSIZE + 1), sizeof( u_int16_t* ))) == NULL) {
        //Couldn't allocate enough memmory
        globalErrorFlag = 1;
        return 1;
    }
    if ((sizeGameBoard = calloc((STARTSIZE + 1), sizeof( int* ))) == NULL) {
        //Couldn't allocate enough memmory
        globalErrorFlag = 1;
        return 2;
    }
    return 0;
}

//Reads current line and scans for a block
InsertNode* getCurrent(char* line, int lineLength, int bounds[]) {
    int position;
    if(line[lineLength - 1] == '\n') {
        position = lineLength - 2; //adjust for line break and indexing
    } else {
        position = lineLength - 1; //adjust for indexing
    }
    int xCoord = 0;
    int color = 0;

    //Error flags for problems happening at the start, middle or end of the line
    bool errorFlagEnd = true;
    bool errorFlagMiddle = true;
    bool errorFlagStart = true;

    //Read xPosition from lowest to highest digit, breaks if stream of digits stop or number is getting too large
    for(int exp = 1; position >= 0 && isdigit(line[position]) && exp < 10000000; exp *= 10) {
        errorFlagEnd = false;
        xCoord += (line[position] - '0') * exp;

        position -= 1;
    }

    //Skip leading zeros
    for (;position >= 0 && line[position] == '0'; position -= 1) {}
    
    //Apply minus sign
    if(position >= 0 && line[position] == '-') {
        xCoord *= -1;
        position -= 1;
    }

    //Skip over the space between the two arguments
    while(position >= 0 && line[position] == 32) {
        errorFlagMiddle = false;
        position -= 1;
    }
    //Read color from lowest to highest digit, stops if it encounters a non digit or the line ends
    for(int exp = 1; position >= 0 && isdigit(line[position]) && exp < 1000; exp *= 10) {
        errorFlagStart = false;
        color += (line[position] - '0') * exp;

        position -= 1;
    }

    //Skip leading zeros
    for (;position >= 0 && line[position] == '0'; position -= 1) {}

    //Error handling
    //Most common error, some format problems occured
    if (errorFlagEnd || errorFlagMiddle || errorFlagStart) {
        globalErrorFlag =  2;
        return NULL;
    //The start of the line isn't a digit
    }
    if(position != -1) {
        globalErrorFlag =  2;
        return NULL;
    //At least one number is out of bound
    }
    if (color < 0 || color > 254 || xCoord < -1048576 || xCoord > 1048576) {
        globalErrorFlag =  2;
        return NULL;
    }

    //Update min and max x coordinates
    if(bounds[0] == 10000000) {
        int lowerBound = xCoord - (lengthOfGameBoard / 2);
        int upperBound = xCoord + (lengthOfGameBoard / 2);

        //Adjust for bounds out of range
        if(lowerBound < -MAXSIZE) {
            upperBound += -MAXSIZE - lowerBound;
            lowerBound = -MAXSIZE;
        } else if (upperBound > MAXSIZE) {
            lowerBound -= upperBound - MAXSIZE;
            upperBound = MAXSIZE;
        }

        bounds[0] = lowerBound;
        bounds[1] = upperBound;
        offset = lowerBound;
    } else if(bounds[0] > xCoord) {
        bounds[0] = xCoord;
    } else if(bounds[1] < xCoord) {
        bounds[1] = xCoord;
    }

    InsertNode *new_block = malloc (sizeof(InsertNode));

    if(new_block == NULL) {
        globalErrorFlag = 1;
        return NULL;
    }

    new_block->color = color;
    new_block->xCoord = xCoord;

    return new_block;
}

//Checks if the gameBoard is wide enough
int adjustGameBoardWidth(int bounds[]) {
    //Check if current gameBoard is too small
    if(bounds[1] > offset + lengthOfGameBoard || (offset + lengthOfGameBoard)-bounds[0] > lengthOfGameBoard) {
        int newLength;
        int mapAt;
        //Decides new size based on current size and required size
        if(bounds[1] <= (offset + (lengthOfGameBoard / 2)) + (SMALL / 2) && bounds[0] >= (offset + (lengthOfGameBoard / 2)) - (SMALL / 2)) {
            newLength = SMALL;
            mapAt = (newLength - lengthOfGameBoard) / 2;
            offset -= mapAt;
            //Adjust offset and mapAt if the new board would be smaller/bigger than the max limit
            if(offset < -MAXSIZE) {
                mapAt += offset + MAXSIZE; //reduce mapAt because offset close to negative edge
                offset = -MAXSIZE;
            } else if (offset + newLength > MAXSIZE) {
                mapAt += (offset + newLength) - MAXSIZE;
                offset -= (offset + newLength) - MAXSIZE;
            }
        } else if(bounds[1] <= (offset + (lengthOfGameBoard / 2)) + (SMALLISH / 2) && bounds[0] >= (offset + (lengthOfGameBoard / 2)) - (SMALLISH / 2)) {
            newLength = SMALLISH;
            mapAt = (newLength - lengthOfGameBoard) / 2;
            offset -= mapAt;
            if(offset < -MAXSIZE) {
                mapAt += offset + MAXSIZE; //reduce mapAt because offset close to negative edge
                offset = -MAXSIZE;
            } else if (offset + newLength > MAXSIZE) {
                mapAt += (offset + newLength) - MAXSIZE;
                offset -= (offset + newLength) - MAXSIZE;
            }
        } else if(bounds[1] <= (offset + (lengthOfGameBoard / 2)) + (MIDISH / 2) && bounds[0] >= (offset + (lengthOfGameBoard / 2)) - (MIDISH / 2)) {
            newLength = MIDISH;
            mapAt = (newLength - lengthOfGameBoard) / 2;
            offset -= mapAt;
            if(offset < -MAXSIZE) {
                mapAt += offset + MAXSIZE; //reduce mapAt because offset close to negative edge
                offset = -MAXSIZE;
            } else if (offset + newLength > MAXSIZE) {
                mapAt += (offset + newLength) - MAXSIZE;
                offset -= (offset + newLength) - MAXSIZE;
            }
        } else if(bounds[1] <= (offset + (lengthOfGameBoard / 2)) + (MIDSIZE / 2) && bounds[0] >= (offset + (lengthOfGameBoard / 2)) - (MIDSIZE / 2)) {
            newLength = MIDSIZE;
            mapAt = (newLength - lengthOfGameBoard) / 2;
            offset -= mapAt;
            if(offset < -MAXSIZE) {
                mapAt += offset + MAXSIZE; //reduce mapAt because offset close to negative edge
                offset = -MAXSIZE;
            } else if (offset + newLength > MAXSIZE) {
                mapAt += (offset + newLength) - MAXSIZE;
                offset -= (offset + newLength) - MAXSIZE;
            }
        } else if(bounds[1] <= (offset + (lengthOfGameBoard / 2)) + (ENDSIZE / 2) && bounds[0] >= (offset + (lengthOfGameBoard / 2)) - (ENDSIZE / 2)) {
            newLength = ENDSIZE;
            mapAt = (newLength - lengthOfGameBoard) / 2;
            offset -= mapAt;
            if(offset < -MAXSIZE) {
                mapAt += offset + MAXSIZE; //reduce mapAt because offset close to negative edge
                offset = -MAXSIZE;
            } else if (offset + newLength > MAXSIZE) {
                mapAt += (offset + newLength) - MAXSIZE;
                offset -= (offset + newLength) - MAXSIZE;
            }
        } else {
            newLength = 2*MAXSIZE;
            mapAt = (newLength / 2) + offset; //Maps the small gameBoard with absolute values;
            offset = -MAXSIZE;
        }
        //Create new Board
        u_int16_t** newBoard;
        int** newSizeBoard;
        if ((newBoard = calloc((newLength + 1), sizeof(u_int16_t*))) == NULL) {
            //Couldn't allocate enough memmory
            globalErrorFlag = 1;
            return 1;
        }
        if ((newSizeBoard = calloc((newLength + 1), sizeof(int*))) == NULL) {
            //Couldn't allocate enough memmory
            globalErrorFlag = 1;
            return 1;
        }
        //Copy old board into new memory location
        memcpy(newBoard+mapAt, gameBoard, sizeof(u_int16_t*) * (lengthOfGameBoard + 1));
        memcpy(newSizeBoard+mapAt, sizeGameBoard, sizeof(int*) * (lengthOfGameBoard + 1));

        //Free Memory
        u_int16_t** temp = gameBoard;
        gameBoard = newBoard;
        free(temp);

        int** tempSize = sizeGameBoard;
        sizeGameBoard = newSizeBoard;
        free(tempSize);

        lengthOfGameBoard = newLength;
    }
    return 0;
}

//Checks if the current column even exists, before a block is dropped into it
int checkColumnForExistence(int xPos) {
    if(gameBoard[xPos] == NULL) {
        gameBoard[xPos] = calloc(INITHEIGHT, sizeof(u_int16_t));
        sizeGameBoard[xPos] = calloc(2, sizeof(int));
        if (gameBoard[xPos] == NULL || sizeGameBoard[xPos] == NULL) { 
            //Couldn't allocate enough memory
            globalErrorFlag = 1;
            return 1;
        }
        gameBoard[xPos][1] = INITHEIGHT;
    }
    return 0;
}

int adjustColumnHeight(int xPos) {
    //[0] contains actual size and [1] max size of current column array
    if(sizeGameBoard[xPos][0] == sizeGameBoard[xPos][1]) {
        int newLength = 2 * sizeGameBoard[xPos][0] + 10;

        //Adjust memory size, realloc first tries to allocate more memory right after the array if that fails it tries to allocate a new memory block AND copies all the data. Awesome
        u_int16_t* newColumn = realloc(gameBoard[xPos], newLength * sizeof(u_int16_t));
        if(newColumn == NULL) {
            globalErrorFlag = 1;
            return 1;
        }

        gameBoard[xPos] = newColumn;
        sizeGameBoard[xPos][1] = newLength;
    }
    return 0;
}

//Checks if gameBoardn needs to be extended
int adjustGameBoard(int bounds[], int xCoord) {

    if(adjustGameBoardWidth(bounds) == 1)
        return 1;

    int xPos = xCoord - offset;

    if(checkColumnForExistence(xPos) == 1)
        return 1;
    if(adjustColumnHeight(xPos) == 1)
        return 1;
    
    return 0;
}

int dropBlock(InsertNode* newBlock) {
    int xPos = newBlock->xCoord - offset;
    sizeGameBoard[xPos][0] += 1;
    int yPos = sizeGameBoard[xPos][0] - 1;
    gameBoard[xPos][yPos] = newBlock->color;
    return yPos;    
}

//Add all the blocks which need to be deleted to listOfDeletions
//extraPosInfo gives the xPos of the "centre" block for column and diags and contains yPos for rows
void prepareDeletion(int type, int connectedBlockPos[7], int extraPosInfo) {
    switch(type) { //type: 0 - Column, 1 - Row, 2 - Diag
        case 0:
            for(int i = 6; i >= 0; i--) {
                int xPos = extraPosInfo;
                int yPos = connectedBlockPos[i];
                if(connectedBlockPos[i] != -1 && gameBoard[xPos][yPos] < 256) { //By checking if the color is in the normal range, I can make sure that there are no duplicates
                    deletionLength += 1;

                    //Create Node containing position of block which needs to be deleted
                    DeleteNode* currentBlock = malloc(sizeof(DeleteNode));
                    if(currentBlock == NULL) {
                        globalErrorFlag = 1;
                        return;
                    }
                    currentBlock->xPos = xPos;
                    currentBlock->yPos = yPos;
                    currentBlock->next = listOfDeletions;
                    listOfDeletions = currentBlock;

                    gameBoard[xPos][yPos] += 256; //Mark block for deletion, so even if a block is multiple times in the deletion list, it will only be deleted ones, color is preserved
                }
            }
            break;
        case 1:
            for(int i = 0; i < 7; i++) {
                int xPos = connectedBlockPos[i];
                int yPos = extraPosInfo;
                if(connectedBlockPos[i] != 2097152 && gameBoard[xPos][yPos] < 256) {
                    deletionLength += 1;
                    DeleteNode* currentBlock = malloc(sizeof(DeleteNode));
                    if(currentBlock == NULL) {
                        globalErrorFlag = 1;
                        return;
                    }
                    currentBlock->xPos = xPos;
                    currentBlock->yPos = yPos;
                    currentBlock->next = listOfDeletions;
                    listOfDeletions = currentBlock;

                    gameBoard[xPos][yPos] += 256;
                }
            }
            break;
        case 2:
            for(int i = 0; i < 7; i++) {
                int xPos = (extraPosInfo - 3) + i;
                int yPos = connectedBlockPos[i];
                if(connectedBlockPos[i] != -1 && gameBoard[xPos][yPos] < 256) {
                    deletionLength += 1;
                    DeleteNode* currentBlock = malloc(sizeof(DeleteNode));
                    if(currentBlock == NULL) {
                        globalErrorFlag = 1;
                        return;
                    }
                    currentBlock->xPos = xPos;
                    currentBlock->yPos = yPos;
                    currentBlock->next = listOfDeletions;
                    listOfDeletions = currentBlock;

                    gameBoard[xPos][yPos] += 256;
                }
            }
            break;
    }
}

void checkColumn(Position* blockPosition) {
    if(sizeGameBoard[blockPosition->xPos][0] < 4) {
        //Column not high enough
        return;
    }

    u_int16_t color = gameBoard[blockPosition->xPos][blockPosition->yPos] % 256;
    int connectedBlockPos[7] = {-1, -1, -1, blockPosition->yPos, -1, -1, -1};
    int connectedCount = 1;
    
    for(int t = 0; t < 2; t++) { //Loop switches between above and below main block
        int sign = (2*t)-1; //Sign is used for 'going' up or down
        for(int i = 1; i < 4; i++) { //Iterate through neighbouring blocks
            int currentYPos = blockPosition->yPos + (i*sign);
            if(currentYPos >= 0 && currentYPos < sizeGameBoard[blockPosition->xPos][0] && //Check if yPos is in bounds
                (gameBoard[blockPosition->xPos][currentYPos] % 256) == color) { //Check color
                connectedBlockPos[3 + (i*sign)] = currentYPos;
                connectedCount += 1;
            } else {
                break;
            }
        }
    }

    //Evaluate results
    if(connectedCount > 3) {
        prepareDeletion(0, connectedBlockPos, blockPosition->xPos);
    }
}

void checkRow(Position* blockPosition) {
    u_int16_t color = gameBoard[blockPosition->xPos][blockPosition->yPos] % 256;
    int connectedBlockPos[7] = {2097152, 2097152, 2097152, blockPosition->xPos, 2097152, 2097152, 2097152};
    int connectedCount = 1;

    for(int t = 0; t < 2; t++) {
        int sign = (2*t)-1; //left - right
        for(int i = 1; i < 4; i++) {
            int currentXPos = blockPosition->xPos + (i*sign);
            if((currentXPos >= 0 && currentXPos <= lengthOfGameBoard && gameBoard[currentXPos] != NULL) && //Out of bounds check
                sizeGameBoard[currentXPos][0] > blockPosition->yPos && //Column high enough
                (gameBoard[currentXPos][blockPosition->yPos] % 256) == color) //Color check
                {
                connectedBlockPos[3 + (i*sign)] = currentXPos;
                connectedCount += 1;
            } else {
                break;
            }
        }
    }

    if(connectedCount > 3) {
        prepareDeletion(1, connectedBlockPos, blockPosition->yPos);
    }
}

void checkDiag(Position* blockPosition) {
    u_int16_t color = gameBoard[blockPosition->xPos][blockPosition->yPos] % 256;
    int connectedBlockPos[2][7] = {{-1, -1, -1, blockPosition->yPos, -1, -1, -1}, {-1, -1, -1, blockPosition->yPos, -1, -1, -1}};
    int connectedCount[2] = {1,1};

    for(int ud = 0; ud < 2; ud++) { //This loop switches between up or down diagonal
        int diagType = (2*ud)-1;
        for(int lr = 0; lr < 2; lr++) { //This loop switches between left or right
            int sign = (2*lr)-1;
            for(int i = 1; i < 4; i++) {
                int currentXPos = blockPosition->xPos + (i*sign);
                int currentYPos = blockPosition->yPos + (i*sign*diagType);
                if((currentXPos >= 0 && currentXPos <= lengthOfGameBoard && gameBoard[currentXPos] != NULL && currentYPos >= 0) && //Out of bounds check
                    sizeGameBoard[currentXPos][0] > currentYPos && //Column high enough
                    (gameBoard[currentXPos][currentYPos] % 256) == color) //Color check
                    {
                    connectedBlockPos[ud][3 + (i*sign)] = currentYPos;
                    connectedCount[ud] += 1;
                } else {
                    break;
                }
            }
        }
    }
    if(connectedCount[0] > 3) {
        prepareDeletion(2, connectedBlockPos[0], blockPosition->xPos);
    }
    if(connectedCount[1] > 3) {
        prepareDeletion(2, connectedBlockPos[1], blockPosition->xPos);
    }
}

//Check if at this position there are any connections
void applyRules(Position* blockPosition) {
    if(sizeGameBoard[blockPosition->xPos][0] == 0)
        return;
    
    checkColumn(blockPosition);
    checkRow(blockPosition);
    checkDiag(blockPosition);
}

//In case of exception, this function is used to free the deleteArray
void freeDeleteArray(DeleteNode** deleteArray, int fillLevel) {
    //Two cases: start of array needs to be freed or end of array needs to be deleted
    if(fillLevel >= 0) {
        for(int i = 0; i < fillLevel; i++) {
            free(deleteArray[i]);
        }
        free(deleteArray);
    } else {
        for (int i = -1 * (fillLevel + 1); i < deletionLength; i++)
        {
            free(deleteArray[i]);
        }
        //free(deleteArray) happens right after deleteBlock
    }
}
//Also in case of exception, frees hashTable
void freeHashTable(int startIndex) {
    for(int i = startIndex; i < 10; i++) {
        free(columnHashTable[i]);
    }
    free(columnHashTable);
}

//Organize listOfDeletions into an array for sorting and also Find lowest yPos of 
//each column containing elements to be deleted. Yeah one function doing two things is not very clean, but now I only have to iterate through the list once
DeleteNode** processListOfDeletions() {
    DeleteNode** deleteArray = malloc(deletionLength * sizeof(DeleteNode*));
    if(deleteArray == NULL) {
        globalErrorFlag = 1;
        return NULL;
    }
    columnHashTable = calloc(10, sizeof(ColumnNode*));
    if(columnHashTable == NULL) {
        globalErrorFlag = 1;
        free(deleteArray);
        return NULL;
    }

    for(int i = 0; i < deletionLength; i++) {
        //Only copy pointer and not data into the array
        deleteArray[i] = listOfDeletions;

        //Find lowest yPos of each column containing elements to be deleted
        //I use a hash table to quickly look up and create new entries
        ColumnNode* current = columnHashTable[listOfDeletions->xPos % 10];
        if(current == NULL) {
            ColumnNode* newColumnNode = malloc(sizeof(ColumnNode));
            if(newColumnNode == NULL) {
                globalErrorFlag = 1;
                freeDeleteArray(deleteArray, i);
                freeHashTable(0);
                return NULL;
            }
            newColumnNode->xPos = listOfDeletions->xPos;
            newColumnNode->yPos = listOfDeletions->yPos;
            newColumnNode->next = NULL;
            columnHashTable[listOfDeletions->xPos % 10] = newColumnNode;
        } else {
            while(current->xPos != listOfDeletions->xPos) {
                if(current->next == NULL) {
                    ColumnNode* newColumnNode = malloc(sizeof(ColumnNode));
                    if(newColumnNode == NULL) {
                        globalErrorFlag = 1;
                        freeDeleteArray(deleteArray, i);
                        freeHashTable(0);
                        return NULL;
                    }
                    newColumnNode->xPos = listOfDeletions->xPos;
                    newColumnNode->yPos = listOfDeletions->yPos;
                    newColumnNode->next = NULL;
                    current->next = newColumnNode;
                }
                current = current->next;
            }
            if(current->yPos > listOfDeletions->yPos) {
                current->yPos = listOfDeletions->yPos;
            }
        }

        listOfDeletions = listOfDeletions->next;
    }

    return deleteArray;
}

//Super standard parition for quick sort
int partition(int left, int right, DeleteNode** deleteArray) {
    int lCounter = left;
    int rCounter = right - 1;
    int pivot = deleteArray[right]->yPos;

    while(lCounter < rCounter) {
        for(;deleteArray[lCounter]->yPos > pivot && lCounter < right; lCounter++) {}

        for(;deleteArray[rCounter]->yPos <= pivot && left < rCounter; rCounter--) {}

        if(lCounter < rCounter) {
            DeleteNode* tmp = deleteArray[lCounter];
            deleteArray[lCounter] = deleteArray[rCounter];
            deleteArray[rCounter] = tmp;
        }
    }

    if(deleteArray[lCounter]->yPos < pivot) {
            DeleteNode* tmp = deleteArray[lCounter];
            deleteArray[lCounter] = deleteArray[right];
            deleteArray[right] = tmp;
    }

    return lCounter;
}

//Standard quicksort
//It's important to delete upper blocks first so lowerToBeDeletedBlocks don't get their position changed before deletion
void quicksort(int left, int right, DeleteNode** deleteArray) {
    if(left < right) {
        int pivot = partition(left, right, deleteArray);
        quicksort(left, pivot - 1, deleteArray);
        quicksort(pivot+1, right, deleteArray);
    }
}

//Finally deletes the blocks
void deleteBlocks(DeleteNode** deleteArray) {
    for(int i = 0; i < deletionLength; i++) {
        u_int16_t* currentColumn = gameBoard[deleteArray[i]->xPos];
        int heightOfUpperColumn = sizeGameBoard[deleteArray[i]->xPos][0] - deleteArray[i]->yPos - 1;
        sizeGameBoard[deleteArray[i]->xPos][0] -= 1;

        //Copy and resize gameBoard column
        void* dest = currentColumn + deleteArray[i]->yPos;
        void* src = currentColumn + deleteArray[i]->yPos + 1;
        int nmbr = heightOfUpperColumn * sizeof(u_int16_t);
        if(nmbr > 0) {
            memcpy(dest, src, nmbr);
        }
        //Reduces size of column if it's larger than the initial height
        if(sizeGameBoard[deleteArray[i]->xPos][0] >= INITHEIGHT) {
            u_int16_t* tmp = realloc(currentColumn, sizeof(u_int16_t) * (--sizeGameBoard[deleteArray[i]->xPos][1]));
            if(tmp == NULL) {
                //This is kinda weird, it doesn't make sense for realloc to fail when SHRINKING memory but it can fail, so I have to handle the exception
                globalErrorFlag = 1;
                freeDeleteArray(deleteArray, -(i+1));
                freeHashTable(0);
                return;
            }
            gameBoard[deleteArray[i]->xPos] = tmp;
        }

        //Finally free the deletion node
        free(deleteArray[i]);
    }
    //Reset length of listOfDeletions
    deletionLength = 0;
}

//If I had time left, I'd remove the array and do all the sorting in the list to save on space, because man a big pointer array is fricking big
void doDeletion() {
    DeleteNode** deleteArray = processListOfDeletions();
    if(deleteArray == NULL) {
        return;
    }
    quicksort(0, deletionLength - 1, deleteArray);
    deleteBlocks(deleteArray);

    free(deleteArray);
}

//Check if after a deletion new connection have formed
void checkForNewConnections() {
    //Iterate through hash table
    for(int i = 0; i < 10; i++) {
        //Iterate through every entry, may contain multiple columns if there is an overflow
        for(ColumnNode* currentColumnInfo = columnHashTable[i]; currentColumnInfo != NULL;) {
            Position* insertPos = malloc(sizeof(Position));
            if(insertPos == NULL) {
                globalErrorFlag = 1;
                freeHashTable(i);
                return;
            }
            insertPos->xPos = currentColumnInfo->xPos;
            //Check every element in the column which had a position change (all nodes above including the deleted block)
            for(int yPos = currentColumnInfo->yPos; yPos < sizeGameBoard[currentColumnInfo->xPos][0]; yPos++) {
                insertPos->yPos = yPos;
                applyRules(insertPos);
                if(globalErrorFlag != 0) {
                    free(insertPos);
                    freeHashTable(i);
                    return;
                }
            }
            free(insertPos);

            //Clean up HashTable List Nodes
            ColumnNode* tmp = currentColumnInfo->next;
            free(currentColumnInfo);
            currentColumnInfo = tmp;
        }
    }
    free(columnHashTable);
}

void renderGameBoard() {
    for(int xPos = 0; xPos <= lengthOfGameBoard; xPos++) {
        u_int16_t* column = gameBoard[xPos];
        if(column != NULL) {
            int columnHeight = sizeGameBoard[xPos][0];
            for(int yPos = 0; yPos < columnHeight; yPos++) {
                printf("%u %i %i\n", column[yPos], xPos + offset, yPos);
            }

            //Clean up
            free(column);
            free(sizeGameBoard[xPos]);
        }
    }
}

void abortGame() {
    for(int i = lengthOfGameBoard; i >= 0; i--) {
        free(gameBoard[i]);
        free(sizeGameBoard[i]);
    }
    free(gameBoard);
    free(sizeGameBoard);

    while(listOfDeletions != NULL) {
        DeleteNode* tmp = listOfDeletions->next;
        free(listOfDeletions);
        listOfDeletions = tmp;
    }
}

void manageException() {
    switch(globalErrorFlag) {
        case 2:
            fprintf(stderr, "Error: wrong input format!");
            abortGame();
            break;
        case 1:
            fprintf(stderr, "Error: couldn't reserve enough memory!");
            abortGame();
            break;
        default: //This shouldnt happen
            fprintf(stderr, "An error has occurred. Aborting game...");
            abortGame();
            break;
    }
}

int main() {
    //Boundaries of GameBoard, min and max xCoord
    int bounds[2] = {10000000, 0};

    if(initializeGameBoard() == 1) {
        if(globalErrorFlag == 22) {
            free(gameBoard) ;
        }
        fprintf(stderr, "Error: couldn't reserve enough memory!");
        exit(EXIT_FAILURE);
    }
    
    listOfDeletions = NULL;

    //Filemanagement
    char *line = NULL;
    size_t sizeOfBuffer = 32;
    size_t lineLength;

    //Main game part
    while((lineLength = getline(&line, &sizeOfBuffer, stdin)) < 1000000) {
        //Get next block
        InsertNode* current = getCurrent(line, lineLength, bounds);
        if(current == NULL) {
            free(line);
            manageException();
            exit(EXIT_FAILURE);
        }

        //Manage gameBoard
        if(adjustGameBoard(bounds, current->xCoord) == 1) {
            //Memory exception
            free(line);
            free(current);
            manageException();
            exit(EXIT_FAILURE);
        }

        Position* insertPos = malloc(sizeof(Position));

        if(insertPos == NULL) {
            globalErrorFlag = 1;
            free(current);
            free(line);
            manageException();
            exit(EXIT_FAILURE);
        }

        insertPos->xPos = current->xCoord - offset;
        insertPos->yPos = dropBlock(current);

        applyRules(insertPos);

        free(insertPos);

        //The memory exception is too deep in applyRules so I'm just using the globalErrorFlag to check if there has been an error
        if(globalErrorFlag != 0) {
            free(current);
            free(line);
            manageException();
            exit(EXIT_FAILURE);
        }
        //delete and iteratively check if there are new connection
        while(listOfDeletions != NULL) {
            doDeletion();
            if(globalErrorFlag != 0) {
                free(current);
                free(line);
                manageException();
                exit(EXIT_FAILURE);
            }
            checkForNewConnections();
            if(globalErrorFlag != 0) {
                free(current);
                free(line);
                manageException();
                exit(EXIT_FAILURE);
            }
        }
        free(current);
    }

    //Print final state of game
    renderGameBoard();

    free(gameBoard);
    free(sizeGameBoard);
    free(listOfDeletions);
    free(line);
    exit(EXIT_SUCCESS);
}