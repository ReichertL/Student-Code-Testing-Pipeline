#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#define SIZE 50

struct erase{
    long xPos;
    long yPos;
    int type;
    long length;
    struct erase *previous;
};

struct erase *head;

/*Start*/

int main(){
    int n=4, m=4, defoult=-1;
    int **zustand=calloc(n, sizeof(int*));
    for(int i=0;i<n;i++)zustand[i]=calloc(m, sizeof(int));
    void stack();
    stack();
    void get();
    void put();


    //Zustand mit default fuellen


    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++)zustand[i][j]=defoult;
    }
    char *brick = (char*) alloca(SIZE);
    char *temp = alloca(SIZE);
    char delimiter[] = " ";
    long f,x,counter,offset=0;                                                  //offset: um wieviele stellen die originale 0 nach rechts verschoben wurde


    /*Zeilenweises einlesen & verarbeiten der .stdin*/


    while((fgets(brick, SIZE, stdin))!=NULL){
        counter = 1;                                                           //oberstes Zeile bei n-1
        temp = strtok(brick,delimiter);                                         //Teilstring f�r Farbe bestimmen
        f=atol(temp);                                                           //Farbwert auslesen
        temp = strtok(NULL,delimiter);                                          //Teilstring f�r Position bestimmen
        x=atol(temp);                                                           //Position ablesen
        long xOrigin=x;


       /*Spielfelderweiterung bei negativen x-Werten*/


        if(x<0){                                                                //negatives x
            if(x+offset<0){                                                     //neues x waere ausserhalb von zustand[n][m]
                int **kill=zustand;
                int diff=abs(x)-offset;                                         //um wieviel muss das Feld verschoben werden
                long mneu=(m+diff);                                             //neue spaltenanzahl=altes m+ neues minimum-altes minimum
                int **copy=calloc(n, sizeof(int*));
                for(int i=0;i<n;i++)copy[i]=calloc(mneu, sizeof(int));
                for (int i=0;i<n;i++){
                    for(int j=0;j<mneu;j++) copy[i][j]=defoult;
                }
                for (int i=0;i<n;i++){
                   for(int j=0;j<m;j++) copy[i][j+diff]=zustand[i][j];
                }
                zustand=copy;
                offset=abs(x);                                                      //offset vergroessern
                m=mneu;
                free(kill);
            }
        }


        /*Spielfelderweiterung bei neuem maximalem x-Wert*/


        else if(x>=(m-offset)){
            int **kill=zustand;
            long mneu=(x-offset+1);
            int **copy=calloc(n, sizeof(int*));
            for(int i=0;i<n;i++)copy[i]=calloc(mneu, sizeof(int));
            for (int i=0;i<n;i++){
                for(int j=0;j<mneu;j++)copy[i][j]=defoult;
            }
            for (int i=0;i<n;i++){
                for(int j=0;j<m;j++) copy[i][j]=zustand[i][j];
            }
            m=mneu;
            zustand=copy;
            free(kill);
        }
        x+=offset;                                                              //x anpassen


        /*Weitere Zeilen hinzufuegen*/


        if(zustand[n-counter-1][x]!=defoult){                                   //zusaetzliche Zeilen einfuegen
            int **kill=zustand;
            int nneu=n+2;
            int **copy=calloc(nneu, sizeof(int*));
            for(int i=0;i<nneu;i++)copy[i]=calloc(m, sizeof(int));
            for (int i=n-1;i<nneu;i++){
                for(int j=0;j<m;j++)copy[i][j]=defoult;
            }
            for (int i=0;i<n;i++){
                for(int j=0;j<m;j++) copy[i][j]=zustand[i][j];
            }
            n=nneu;
            zustand=copy;
            free(kill);
        }


        /*Platzierung des Spielsteins*/


        while(zustand[n-counter-1][x]==defoult){                                //schauen, ob uebernaechster stein
             if(n-1==counter){
                counter=n;
                break;
             }
             counter++;
        }
        int y=n-counter;
        zustand[y][x]=f;


        /*Analyse des aktuellen Spielfeldes*/


        bool finish=false;
        bool diag=false;
        bool waag=false;
        bool vert=false;
        int key=-2,folge=0, iteration=1;
        struct erase *neu;
        void put(struct erase *neu);
        while(finish==false){

            /*verkleinerten Ausschnitt zur betrachtung erstellen*/

            int left=x-(iteration*3);
            if(left<0)left=0;
            int right=x+(iteration*3);
            if(right>=m)right=m-1;
            int up= y+(iteration*3);
            if(up>=n)up=n-1;
            int bottom=y-(iteration*3);
            if(bottom<0)bottom=0;
            int range=right-left;
            int height=up-bottom+1;
            int row=0,collum=0;int **spielzug=calloc(height, sizeof(int*));
            for(int i=0;i<=height;i++)spielzug[i]= calloc(range,sizeof(int));
            for(int i=bottom;i<=up;i++){
                collum=0;
                for(int j=left;j<=right;j++){
                    spielzug[row][collum]=zustand[i][j];
                    collum++;
                }
                row++;
            };


            /*Analyse horizontal*/


            for(int i=0;i<=up;i++){
                if(folge>=4){
                    waag=true;
                    neu = (struct erase*)malloc(sizeof(struct erase));
                    neu->xPos=left+range-3;
                    neu->yPos=bottom+i-1;
                    neu->type=1;
                    neu->length=folge;
                    neu->previous=NULL;
                    put(neu);
                    folge=0;
                    key=-2;
                }
                else folge=0;
                for(int j=0;j<=range;j++){
                    if(spielzug[i][j]==key)folge++;
                    else{
                        if(folge>=4){
                            waag=true;
                            neu = (struct erase*)malloc(sizeof(struct erase));
                            neu->xPos=left+j-3;
                            neu->yPos=bottom+i;
                            neu->type=1;
                            neu->length=folge;
                            neu->previous=NULL;
                            put(neu);
                            folge=0;
                            key=-2;
                        }
                        else if(spielzug[i][j]>=0){
                            key=spielzug[i][j];
                            folge=1;
                        }
                        else folge=0;
                    }
                }
            }


            /*Analyse vertikal*/


            for(int j=0;j<=range;j++){
                if(folge>=4){
                    vert=true;
                    neu= (struct erase*)malloc(sizeof(struct erase));
                    neu->xPos=left+j-1;
                    neu->yPos=bottom+height;
                    neu->type=2;
                    neu->length=folge;
                    neu->previous=NULL;
                    put(neu);
                    folge=0;
                    key=-2;
                }
                else folge=0;
                for(int i=0;i<=up;i++){
                    if(spielzug[i][j]==key)folge++;
                    else{
                        if(folge>=4){
                            vert=true;
                            neu= (struct erase*)malloc(sizeof(struct erase));
                            neu->xPos=left+j;
                            neu->yPos=bottom+i;
                            neu->type=2;
                            neu->length=folge;
                            neu->previous=NULL;
                            put(neu);
                            folge=0;
                            key=-2;
                        }
                        else if(spielzug[i][j]>=0){
                            key=spielzug[i][j];
                            folge=1;
                        }
                        else folge=0;
                    }
                }
            }


            /*Analyse diagonal links oben->rechts unten*/


            for(int i=0;i<=height;i++){
                if(folge>=4){
                    diag=true;
                    neu= (struct erase*)malloc(sizeof(struct erase));
                    neu->xPos=left+range-3;
                    neu->yPos=bottom+i-1;
                    neu->type=3;
                    neu->length=folge;
                    neu->previous=NULL;
                    put(neu);
                    folge=0;
                    key=-2;
                }
                else folge=0;
                for(int j=0;j<=range;j++){
                    if(i-j>=0){
                        if(spielzug[i-j][j]==key)folge++;
                        else{
                            if(folge>=4){
                                diag=true;
                                neu= (struct erase*)malloc(sizeof(struct erase));
                                neu->xPos=left+j-3;
                                neu->yPos=bottom+i;
                                neu->type=3;
                                neu->length=folge;
                                neu->previous=NULL;
                                put(neu);
                                folge=0;
                                key=-2;
                            }
                            else if(spielzug[i-j][j]>=0){
                                key=spielzug[i-j][j];
                                folge=1;
                            }
                            else folge=0;
                        }
                    }
                }
            }


            /*Analyse diagonal links unten->rechts oben*/


            for(int i=0;i<=range;i++){
                if(folge>=4){
                    diag=true;
                    neu= (struct erase*)malloc(sizeof(struct erase));
                    neu->xPos=left+i+range-3;
                    neu->yPos=bottom+height-3;
                    neu->type=4;
                    neu->length=folge;
                    neu->previous=NULL;
                    put(neu);
                    folge=0;
                    key=-2;
                }
                else folge=0;
                for(int j=0;j<=height;j++){
                    if(i+j<=right){
                        if(spielzug[j][i+j]==key)folge++;
                        else{
                            if(folge>=4){
                                diag=true;
                                neu= (struct erase*)malloc(sizeof(struct erase));
                                neu->xPos=left+i+j-3;
                                neu->yPos=bottom+j-3;
                                neu->type=4;
                                neu->length=folge;
                                neu->previous=NULL;
                                put(neu);
                                folge=0;
                                key=-2;
                            }
                            else if(spielzug[j][i+j]>=0){
                                key=spielzug[j][i+j];
                                folge=1;
                            }
                            else folge=0;
                        }
                    }
                }
            }
            if(diag==false&&waag==false&&vert==false)finish=true;
            else{


                /*zu loeschende Feldermarkieren*/


                while(head->previous!=NULL){
                    int xPos= head->previous->xPos;
                    int yPos= head->previous->yPos;
                    int type=head->previous->type;
                    int length=head->previous->length;
                    switch(type){
                        case 1: for(int i=0;i<length;i++) zustand[yPos][xPos+i] = -2;break;
                        case 2: for(int i=0;i<length;i++) zustand[yPos+i][xPos] = -2;break;
                        case 3: for(int i=0;i<length;i++) zustand[yPos-i][xPos+i]=-2;break;
                        case 4: for(int i=0;i<length;i++) zustand[yPos+i][xPos+i]=-2;break;
                        default:;
                    }
                    get();
                }


                /*Felder loeschen und nachrutschen*/


                for(int i=bottom;i<=up;i++){
                    for(int j=left;j<=right;j++){
                        while(zustand[i][j]==-2){
                            int down= 0;
                            while(i+down<n){
                                if(i+down==n-1);
                                else zustand[i+down][j]=zustand[i+down+1][j];
                                down++;
                            }
                        }
                    }
                }
                diag=false;
                waag=false;
                vert=false;
            }
            iteration++;
        }
    }


    /*Ausgabe des finalen Zustands*/

    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++) if(zustand[i][j]!=-1)printf("%d %ld %ld\n",zustand[i][j],j-offset,i);
    }
    return 0;
}
 /*   printf("\n");
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++) if(zustand[i][j]!=-1)printf("%d %ld %ld\n",zustand[i][j],j-offset,i);
    }

/*Funktionen fuer die queues*/


void stack(){
    if((head=malloc(sizeof(struct erase)))!= NULL){
        head->xPos =-1;
        head->yPos =-1;
        head->type = 0;
        head->length=0;
        head->previous=NULL;
    }
    else fprintf(stderr,"Konnte keinen Speicher reservieren!!\n");
}

void get(){
    struct erase *zeiger;
    if(head->previous != NULL){
        zeiger=head->previous;
        head->previous=zeiger->previous;
        free(zeiger);
    }
    else fprintf(stderr,"Es muessen keine weiteren Steine geloescht werden\n");
}

void put(struct erase *neu){
    struct erase *zeiger;
    if(head->previous==NULL){
        head->previous=neu;
        neu->previous=NULL;
    }
    else{
        zeiger=head;
        while(zeiger->previous!=NULL)zeiger=zeiger->previous;
        zeiger->previous=neu;
        neu->previous=NULL;
    }
}

/*

Funktioniert fuer ketten der laenge 4

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#define SIZE 50

struct erase{
    long xPos;
    long yPos;
    int type;
    struct erase *previous;
};

struct erase *head;

/*Start*/
/*
int main(){
    int n=4, m=4, defoult=-1;
    int **zustand=calloc(n, sizeof(int*));
    for(int i=0;i<n;i++)zustand[i]=calloc(m, sizeof(int));
    void stack();
    stack();
    void get();
    void put();


    //Zustand mit default fuellen


    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++)zustand[i][j]=defoult;
    }
    char *brick = (char*) alloca(SIZE);
    char *temp = alloca(SIZE);
    char delimiter[] = " ";
    long f,x,counter,offset=0;                                                  //offset: um wieviele stellen die originale 0 nach rechts verschoben wurde


    /*Zeilenweises einlesen & verarbeiten der .stdin*/

/*
    while((fgets(brick, SIZE, stdin))!=NULL){
        counter = 1;                                                           //oberstes Zeile bei n-1
        temp = strtok(brick,delimiter);                                         //Teilstring f�r Farbe bestimmen
        f=atol(temp);                                                           //Farbwert auslesen
        temp = strtok(NULL,delimiter);                                          //Teilstring f�r Position bestimmen
        x=atol(temp);                                                           //Position ablesen
        long xOrigin=x;


       /*Spielfelderweiterung bei negativen x-Werten*/

/*
        if(x<0){                                                                //negatives x
            if(x+offset<0){                                                     //neues x waere ausserhalb von zustand[n][m]
                int **kill=zustand;
                int diff=abs(x)-offset;                                         //um wieviel muss das Feld verschoben werden
                long mneu=(m+diff);                                             //neue spaltenanzahl=altes m+ neues minimum-altes minimum
                int **copy=calloc(n, sizeof(int*));
                for(int i=0;i<n;i++)copy[i]=calloc(mneu, sizeof(int));
                for (int i=0;i<n;i++){
                    for(int j=0;j<mneu;j++) copy[i][j]=defoult;
                }
                for (int i=0;i<n;i++){
                   for(int j=0;j<m;j++) copy[i][j+diff]=zustand[i][j];
                }
                zustand=copy;
                offset=abs(x);                                                      //offset vergroessern
                m=mneu;
                free(kill);
            }
        }


        /*Spielfelderweiterung bei neuem maximalem x-Wert*/
/*

        else if(x>=(m-offset)){
            int **kill=zustand;
            long mneu=(x-offset+1);
            int **copy=calloc(n, sizeof(int*));
            for(int i=0;i<n;i++)copy[i]=calloc(mneu, sizeof(int));
            for (int i=0;i<n;i++){
                for(int j=0;j<mneu;j++)copy[i][j]=defoult;
            }
            for (int i=0;i<n;i++){
                for(int j=0;j<m;j++) copy[i][j]=zustand[i][j];
            }
            m=mneu;
            zustand=copy;
            free(kill);
        }
        x+=offset;                                                              //x anpassen


        /*Weitere Zeilen hinzufuegen*/

/*
        if(zustand[n-counter-1][x]!=defoult){                                   //zusaetzliche Zeilen einfuegen
            int **kill=zustand;
            int nneu=n+2;
            int **copy=calloc(nneu, sizeof(int*));
            for(int i=0;i<nneu;i++)copy[i]=calloc(m, sizeof(int));
            for (int i=n-1;i<nneu;i++){
                for(int j=0;j<m;j++)copy[i][j]=defoult;
            }
            for (int i=0;i<n;i++){
                for(int j=0;j<m;j++) copy[i][j]=zustand[i][j];
            }
            n=nneu;
            zustand=copy;
            free(kill);
        }


        /*Platzierung des Spielsteins*/

/*
        while(zustand[n-counter-1][x]==defoult){                                //schauen, ob uebernaechster stein
             if(n-1==counter){
                counter=n;
                break;
             }
             counter++;
        }
        int y=n-counter;
        zustand[y][x]=f;


        /*Analyse des aktuellen Spielfeldes*/

/*
        bool finish=false;
        bool diag=false;
        bool waag=false;
        bool vert=false;
        int key=-2,folge=0, iteration=1;
        struct erase *neu;
        void put(struct erase *neu);
        while(finish==false){


            /*verkleinerten Ausschnitt zur betrachtung erstellen*/

/*
            int left=x-(iteration*3);
            if(left<0)left=0;
            int right=x+(iteration*3);
            if(right>=m)right=m-1;
            int up= y+(iteration*3);
            if(up>=n)up=n-1;
            int bottom=y-(iteration*3);
            if(bottom<0)bottom=0;
            int range=right-left;
            int height=up-bottom+1;
            int row=0,collum=0;int **spielzug=calloc(height, sizeof(int*));
            for(int i=0;i<=height;i++)spielzug[i]= calloc(range,sizeof(int));
            for(int i=bottom;i<=up;i++){
                collum=0;
                for(int j=left;j<=right;j++){
                    spielzug[row][collum]=zustand[i][j];
                    collum++;
                }
                row++;
            };


            /*Analyse horizontal*/

/*
            for(int i=0;i<=up;i++){
                folge=0;
                for(int j=0;j<=right;j++){
                    if(spielzug[i][j]==key)folge++;
                    else if(spielzug[i][j]>=0){
                        key=spielzug[i][j];
                        folge=1;
                    }
                    else folge=0;
                    if(folge==4){
                        waag=true;
                        neu= (struct erase*)malloc(sizeof(struct erase));
                        neu->xPos=left+j-3;
                        neu->yPos=bottom+i;
                        neu->type=1;
                        neu->previous=NULL;
                        put(neu);
                        folge=0;
                        key=-2;
                    }
                    else;
                };
            }


            /*Analyse vertikal*/

/*
            for(int j=0;j<=range;j++){
                folge=0;
                for(int i=0;i<=up;i++){
                    if(spielzug[i][j]==key)folge++;
                    else if(spielzug[i][j]>=0){
                        key=spielzug[i][j];
                        folge=1;
                    }
                    else folge=0;
                    if(folge==4){
                        vert=true;
                        neu= (struct erase*)malloc(sizeof(struct erase));
                        neu->xPos=left+j;
                        neu->yPos=bottom+i-3;
                        neu->type=2;
                        neu->previous=NULL;
                        put(neu);
                        folge=0;
                        key=-2;
                    }
                }
            }


            /*Analyse diagonal links oben->rechts unten*/

/*
            for(int i=0;i<=up;i++){
                folge=0;
                for(int j=0;j<=right;j++){
                    if(i-j>=0){
                        if(spielzug[i-j][j]==key)folge++;
                        else if(spielzug[i-j][j]>=0){
                            key=spielzug[i-j][j];
                            folge=1;
                        }
                        else folge=0;
                        if(folge==4){
                            diag=true;
                            neu= (struct erase*)malloc(sizeof(struct erase));
                            neu->xPos=left+j-3;
                            neu->yPos=bottom+i;
                            neu->type=3;
                            neu->previous=NULL;
                            put(neu);
                            folge=0;
                            key=-2;
                        }
                    else;
                    }
                }
            }


            /*Analyse diagonal links unten->rechts oben*/

/*
            for(int i=0;i<=right;i++){
                folge=0;
                for(int j=0;j<=up;j++){
                    if(i+j<=right){
                        if(spielzug[j][i+j]==key)folge++;
                        else if(spielzug[j][i+j]>=0){
                            key=spielzug[j][i+j];
                            folge=1;
                        }
                        else folge=0;
                        if(folge==4){
                            diag=true;
                            neu= (struct erase*)malloc(sizeof(struct erase));
                            neu->xPos=left+i+j-3;
                            neu->yPos=bottom+j-3;
                            neu->type=4;
                            neu->previous=NULL;
                            put(neu);
                            folge=0;
                            key=-2;
                        }
                    else;
                    }
                }
            }
            if(diag==false&&waag==false&&vert==false)finish=true;
            else{


                /*zu loeschende Feldermarkieren*/

/*
                while(head->previous!=NULL){
                    int xPos= head->previous->xPos;
                    int yPos= head->previous->yPos;
                    int type=head->previous->type;
                    switch(type){
                        case 1: for(int i=0;i<4;i++) zustand[yPos][xPos+i] = -2;break;
                        case 2: for(int i=0;i<4;i++) zustand[yPos+i][xPos] = -2;break;
                        case 3: for(int i=0;i<4;i++) zustand[yPos-i][xPos+i]=-2;break;
                        case 4: for(int i=0;i<4;i++) zustand[yPos+i][xPos+i]=-2;break;
                        default:;
                    }
                    get();
                }


                /*Felder loeschen und nachrutschen*/

/*
                for(int i=bottom;i<=up;i++){
                    for(int j=left;j<=right;j++){
                        while(zustand[i][j]==-2){
                            int down= 0;
                            while(i+down<n){
                                if(i+down==n-1);
                                else zustand[i+down][j]=zustand[i+down+1][j];
                                down++;
                            }
                        }
                    }
                }
                diag=false;
                waag=false;
                vert=false;
            }
            iteration++;
        }
    }


    /*Ausgabe des finalen Zustands*/
/*

    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++) if(zustand[i][j]!=-1)printf("%d %ld %ld\n",zustand[i][j],j-offset,i);
    }
    return 0;
}


/*Funktionen fuer die queues*/

/*
void stack(){
    if((head=malloc(sizeof(struct erase)))!= NULL){
        head->xPos =-1;
        head->yPos =-1;
        head->type = 0;
        head->previous=NULL;
    }
    else fprintf(stderr,"Konnte keinen Speicher reservieren!!\n");
}

void get(){
    struct erase *zeiger;
    if(head->previous != NULL){
        zeiger=head->previous;
        head->previous=zeiger->previous;
        free(zeiger);
    }
    else fprintf(stderr,"Es muessen keine weiteren Steine geloescht werden\n");
}

void put(struct erase *neu){
    struct erase *zeiger;
    if(head->previous==NULL){
        head->previous=neu;
        neu->previous=NULL;
    }
    else{
        zeiger=head;
        while(zeiger->previous!=NULL)zeiger=zeiger->previous;
        zeiger->previous=neu;
        neu->previous=NULL;
    }
}
*/
