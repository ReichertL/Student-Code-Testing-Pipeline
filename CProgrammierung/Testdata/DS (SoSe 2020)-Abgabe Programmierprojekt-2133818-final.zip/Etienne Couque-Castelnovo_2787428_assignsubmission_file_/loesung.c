#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <regex.h>

/*POSIX Regex*/
regex_t regex;
int reti;
char msgbuf[20];

/*STDIN*/
char *line;
int matches = 0;
int nLine = 0;
int myEOF = 0;

/*DECOMPOSE*/
int firstDecimal, secondDecimal;
char cpFirstDecimal[128], cpSecondDecimal[128];
int stringLength;
int fisrtAssignedidx = -1;
int secondAssignedIndex = -1;

/*Game Table*/
int ResizeNR = 8;
int ResizeNL = 8;
int ResizeNA = 8;
short **gt_arr;
short **helper_arr;
int *row_arr;
int *helper_row_arr;
int nRows = 2;
int nCols = 1;
int oldnRows;
int lowerBound;
int oldLowerBound;
int higherBound;
int oldHigherBound;
char **hitMask;
int smallestIndex;
int highestIndex;
int lrDelim[3];

/***
 *        ______     _ __ 
 *       / ____/  __(_) /_
 *      / __/ | |/_/ / __/
 *     / /____>  </ / /_  
 *    /_____/_/|_/_/\__/  
 *                        
 */

/*Custom Exit function to call whenever i want to quit the program and still want to free my memory*/
void myExit()
{
    for (size_t i = 0; i < nCols; i++)
    {
        free(gt_arr[i]);
    }
    free(gt_arr);
    regfree(&regex);
    /*Manual free hitmask*/
    for (size_t i = 0; i < nCols; i++)
    {
        free(hitMask[i]);
    }
    free(hitMask);
    free(helper_arr);
    free(row_arr);
    free(line);
    exit(1);
}

/***
 *       ______                        ______      __    __   
 *      / ____/___ _____ ___  ___     /_  __/___ _/ /_  / /__ 
 *     / / __/ __ `/ __ `__ \/ _ \     / / / __ `/ __ \/ / _ \
 *    / /_/ / /_/ / / / / / /  __/    / / / /_/ / /_/ / /  __/
 *    \____/\__,_/_/ /_/ /_/\___/    /_/  \__,_/_.___/_/\___/ 
 *                                                            
 */

/*Shifting down after having identified groups*/
void shiftDown(int llim, int rlim, int dlim)
{
    //printf("Shifting down L: %d, R: %d, D: %d\n", llim+ smallestIndex - lowerBound, rlim+ smallestIndex - lowerBound, dlim );
    if (llim == -1 || rlim == -1 || dlim == -1)
    {
        //printf("Nothing to shift in shift.\n");
        return;
    }

    int nShifts;
    int shiftIdx;
    /*Going through each column that was affected by changes and performing shifts*/
    for (size_t i = llim; i < rlim + 1; i++)
    {
        nShifts = 0;
        shiftIdx = dlim;
        while (shiftIdx < row_arr[i])
        {
            /*Finding first entry to erase*/
            while (shiftIdx < (row_arr[i]) && (hitMask[i][shiftIdx] != '1'))
            {
                shiftIdx++;
            }
            /*Looking how many entrys to erase*/
            while (((shiftIdx + nShifts) < row_arr[i]) && (hitMask[i][shiftIdx + nShifts] == '1'))
            {
                hitMask[i][shiftIdx + nShifts] = '0';
                nShifts++;
            }
            //printf("ShiftIdx = %d, nShifts = %d\n", shiftIdx, nShifts);
            /*shifting down our values*/
            if (nShifts > 0)
            {
                //printf("Row: %ld ShiftIdx: %d nShifts: %d\n", i+smallestIndex-lowerBound, shiftIdx, nShifts);
                for (size_t j = 0; j < row_arr[i] - shiftIdx - nShifts; j++)
                {
                    gt_arr[i][shiftIdx + j] = gt_arr[i][shiftIdx + j + nShifts];
                    hitMask[i][shiftIdx + j] = hitMask[i][shiftIdx + j + nShifts];
                }
                /*Now fill up with idle values*/
                // for (size_t j = 0; j < nShifts; j++)
                // {
                //     gt_arr[i + smallestIndex - lowerBound][nRows - 1 - j] = -2;
                //     hitMask[i][nRows - 1 - j] = 0;
                // }
                for (size_t j = 0; j < nShifts; j++)
                {
                    gt_arr[i][row_arr[i] - 1 - j] = -2;
                    hitMask[i][row_arr[i] - 1 - j] = '0';
                }
                row_arr[i] -= nShifts;
                nShifts = 0;
            }
        }
    }
}

/*Checking stone at position x, y and finding matches in all directions*/
void checkStone(int x, int y)
{
    /*Passed arguments x, y are absolute coordinates in gt_arr*/
    //printf("Looking at [%d][%d]\n", x, y);
    int horizL = 0;
    int horizR = 0;
    int vertA = 0;
    int vertB = 0;
    int diagLL = 0;
    int diagUR = 0;
    int diagUL = 0;
    int diagLR = 0;

    /*In case there aint no hit the values will stay -1, so its also like a isHit() indicator
    These values represent hitmask index values*/
    lrDelim[0] = -1;
    lrDelim[1] = -1;
    lrDelim[2] = -1;

    /*Just to make sure*/
    if (gt_arr[x][y] == -2)
    {
        return;
    }

    /*Left horizontal*/
    //printf("LHOR Looking x index raw: ");
    size_t iterator = 1;
    /*We look above SI - LB so that we dont check useless neighbours*/
    while ((x - iterator) + 1 > (smallestIndex - lowerBound))
    {
        //printf("%ld ", x - iterator);
        if (gt_arr[x][y] == gt_arr[x - iterator][y])
        {
            //printf("[hit], ");
            horizL++;
            iterator++;
        }
        else
        {
            //printf("[miss]");
            break;
        }
    }
    //printf("\n");

    /*Right horizontal*/
    //printf("RHOR Looking x index raw: ");
    iterator = 1;
    while ((x + iterator) - 1 < (highestIndex - lowerBound))
    {
        //printf("%ld, ", x + iterator);
        if (gt_arr[x][y] == gt_arr[x + iterator][y])
        {
            //printf("[hit], ");
            horizR++;
            iterator++;
        }
        else
        {
            //printf("[miss]");
            break;
        }
    }
    //printf("\n");

    /*Horizontal hit*/
    if ((horizL + horizR + 1) > 3)
    {
        //printf("Horizontal hit from [%d][%d] to [%d][%d]\n", x - horizL, y, x + horizR, y);
        lrDelim[0] = x - horizL;
        lrDelim[1] = x + horizR;
        lrDelim[2] = y;
        /*Create entrys in Hittable*/
        for (size_t i = x - horizL; i < x + horizR + 1; i++)
        {
            hitMask[i][y] = '1';
        }
    }

    /*Upper vertical -> unnecessary for single coin*/
    //printf("AVER Looking y index raw: ");
    iterator = 1;
    while ((y + iterator) < nRows)
    {
        //printf("%ld ", y + iterator);
        if (gt_arr[x][y] == gt_arr[x][y + iterator])
        {
            //printf("[hit], ");
            vertA++;
            iterator++;
        }
        else
        {
            //printf("[miss]");
            break;
        }
    }
    //printf("\n");

    /*Lower vertical*/
    //printf("BVER Looking y index raw: ");
    iterator = 1;
    while ((y - iterator) + 1 > 0)
    {
        //printf("%ld ", y - iterator);
        if (gt_arr[x][y] == gt_arr[x][y - iterator])
        {
            //printf("[hit], ");
            vertB++;
            iterator++;
        }
        else
        {
            //printf("[miss]");
            break;
        }
    }
    //printf("\n");

    /*Vertical hit*/
    if ((vertA + vertB + 1) > 3)
    {
        //printf("Vertical hit from [%d][%d] to [%d][%d]\n", x, y - vertB, x, y + vertA);
        /*Create entrys in Hittable*/
        if ((lrDelim[0] == -1) || x < lrDelim[0])
        {
            lrDelim[0] = x;
        }
        if ((lrDelim[1] == -1) || (x) > lrDelim[1])
        {
            lrDelim[1] = x;
        }
        if (lrDelim[2] == -1 || (lrDelim[2] > y - vertB))
        {
            lrDelim[2] = y - vertB;
        }

        for (size_t i = y - vertB; i < y + vertA + 1; i++)
        {
            hitMask[x][i] = '1';
        }
    }

    /*LLUR Diagonal*/
    /*LL*/
    //printf("LL Looking x, y index raw: ");
    iterator = 1;
    while (((x - iterator) + 1 > (smallestIndex - lowerBound)) && ((y - iterator) + 1 > 0))
    {
        //printf("(%ld, %ld) ", x - iterator, y - iterator);
        if (gt_arr[x][y] == gt_arr[x - iterator][y - iterator])
        {
            //printf("[hit], ");
            diagLL++;
            iterator++;
        }
        else
        {
            //printf("[miss]");
            break;
        }
    }
    //printf("\n");
    /*UR*/
    //printf("UR Looking x, y index raw: ");
    iterator = 1;
    while (((x + iterator) - 1 < (highestIndex - lowerBound)) && ((y + iterator) < nRows))
    {
        //printf("(%ld, %ld) ", x + iterator, y + iterator);
        if (gt_arr[x][y] == gt_arr[x + iterator][y + iterator])
        {
            //printf("[hit], ");
            diagUR++;
            iterator++;
        }
        else
        {
            //printf("[miss]");
            break;
        }
    }
    //printf("\n");

    /*LLUR Diagonal hit*/
    if ((diagLL + diagUR + 1) > 3)
    {
        //printf("LLUR Diagonal hit from [%d][%d] to [%d][%d]\n", x - diagLL, y - diagLL, x + diagUR, y + diagUR);
        if ((lrDelim[0] == -1) || ((x - diagLL) < lrDelim[0]))
        {
            lrDelim[0] = x - diagLL;
        }
        if ((lrDelim[1] == -1) || ((x + diagUR) > lrDelim[1]))
        {
            lrDelim[1] = x + diagUR;
        }
        if (lrDelim[2] == -1 || (lrDelim[2] > y - diagLL))
        {
            lrDelim[2] = y - diagLL;
        }

        for (size_t i = 0; i < diagLL + diagUR + 1; i++)
        {
            hitMask[x - diagLL + i][y - diagLL + i] = '1';
        }
    }

    /*ULLR Diagonal*/

    /*UL*/
    //printf("UL Looking x, y index raw: ");
    iterator = 1;
    while (((x - iterator) + 1 > (smallestIndex - lowerBound)) && ((y + iterator) < nRows))
    {
        //printf("(%ld, %ld) ", x - iterator, y + iterator);
        if (gt_arr[x][y] == gt_arr[x - iterator][y + iterator])
        {
            //printf("[hit], ");
            diagUL++;
            iterator++;
        }
        else
        {
            //printf("[miss]");
            break;
        }
    }
    //printf("\n");
    /*LR*/
    //printf("LR Looking x, y index raw: ");
    iterator = 1;
    while (((x + iterator) - 1 < (highestIndex - lowerBound)) && ((y - iterator) + 1 > 0))
    {
        //printf("(%ld, %ld) ", x + iterator, y - iterator);
        if (gt_arr[x][y] == gt_arr[x + iterator][y - iterator])
        {
            //printf("[hit], ");
            diagLR++;
            iterator++;
        }
        else
        {
            //printf("[miss]");
            break;
        }
    }
    //printf("\n");

    /*ULLR Diagonal hit*/
    if ((diagUL + diagLR + 1) > 3)
    {
        //printf("ULLR Diagonal hit from [%d][%d] to [%d][%d]\n", x - diagUL, y + diagUL, x + diagLR, y - diagLR);

        if ((lrDelim[0] == -1) || ((x - diagUL) < lrDelim[0]))
        {
            lrDelim[0] = x - diagUL;
        }
        if ((lrDelim[1] == -1) || ((x + diagLR) > lrDelim[1]))
        {
            lrDelim[1] = x + diagLR;
        }
        if (lrDelim[2] == -1 || lrDelim[2] > y - diagLR)
        {
            lrDelim[2] = y - diagLR;
        }

        for (size_t i = 0; i < diagUL + diagLR + 1; i++)
        {
            hitMask[x - diagUL + i][y + diagUL - i] = '1';
        }
    }

    // /*Debug printing hitmask*/
    // printf("####\tHITMASK\t####\n");
    // for (size_t i = nRows; i > 0; i--)
    // {
    //     printf("| ");
    //     for (size_t j = 0; j < highestIndex - smallestIndex + 1; j++)
    //     {
    //         printf("%c |", hitMask[j][i - 1]);
    //     }
    //     printf("\n");
    // }
}

/*Allocating space for the first time for our main game table array and the corresponding hitmask array*/
void initGameTable()
{
    gt_arr = (short **)malloc(nCols * sizeof(short *));
    if (!gt_arr)
    {
        fprintf(stderr, "Failed memory allocation");
        myExit();
    }

    for (int col = 0; col < nCols; col++)
    {
        gt_arr[col] = (short *)malloc(nRows * sizeof(short));
        if (!gt_arr[col])
        {
            fprintf(stderr, "Failed memory allocation");
            myExit();
        }
    }
    for (size_t i = 0; i < nCols; i++)
    {
        for (size_t j = 0; j < nRows; j++)
        {
            gt_arr[i][j] = -2;
        }
    }

    hitMask = (char **)malloc(nCols * sizeof(char *));
    if (!hitMask)
    {
        fprintf(stderr, "Failed memory allocation");
        myExit();
    }
    for (int col = 0; col < nCols; col++)
    {
        hitMask[col] = (char *)malloc(nRows * sizeof(char));
        if (!hitMask[col])
        {
            fprintf(stderr, "Failed memory allocation");
            myExit();
        }
        for (size_t j = 0; j < nRows; j++)
        {
            hitMask[col][j] = '0';
        }
    }

    row_arr = (int *)malloc(nCols * sizeof(int));
    if (!row_arr)
    {
        fprintf(stderr, "Failed memory allocation");
        myExit();
    }

    for (size_t i = 0; i < nCols; i++)
    {
        row_arr[i] = 0;
    }
}

/*Funtion used to resize the game table. It allocates an new array, copys the data and frees old array */
void resizeGameTableLeft()
{
    /*Allocate new memory for a larger gametable*/
    helper_arr = (short **)malloc(nCols * sizeof(short *));
    if (!helper_arr)
    {
        fprintf(stderr, "Failed memory allocation");
        myExit();
    }

    for (int col = 0; col < nCols; col++)
    {
        helper_arr[col] = (short *)malloc(nRows * sizeof(short));
        if (!helper_arr[col])
        {
            fprintf(stderr, "Failed memory allocation");
            myExit();
        }

        for (size_t j = 0; j < nRows; j++)
        {
            helper_arr[col][j] = -2;
        }
    }

    /*New Hitmask Array*/
    /*Free it first*/
    for (size_t i = 0; i < (higherBound - oldLowerBound) + 1; i++)
    {
        free(hitMask[i]);
    }
    free(hitMask);

    hitMask = (char **)malloc(nCols * sizeof(char *));
    if (!hitMask)
    {
        fprintf(stderr, "Failed memory allocation");
        myExit();
    }

    for (int col = 0; col < nCols; col++)
    {
        hitMask[col] = (char *)malloc(nRows * sizeof(char));
        if (!hitMask[col])
        {
            fprintf(stderr, "Failed memory allocation");
            myExit();
        }

        for (size_t j = 0; j < nRows; j++)
        {
            hitMask[col][j] = '0';
        }
    }

    /*helper_row_arr*/
    helper_row_arr = (int *)malloc(nCols * sizeof(int));
    if (!helper_row_arr)
    {
        fprintf(stderr, "Failed memory allocation");
        myExit();
    }

    for (size_t i = 0; i < nCols; i++)
    {
        helper_row_arr[i] = 0;
    }

    /*Copy data from old array into new array*/
    for (int col = oldLowerBound; (col - oldLowerBound) < (higherBound - oldLowerBound + 1); col++)
    {
        memcpy(helper_arr[col - lowerBound], gt_arr[col - oldLowerBound], nRows * sizeof(short));
    }
    /*helper_row_arr*/
    memcpy(&helper_row_arr[oldLowerBound - lowerBound], &row_arr[0], (higherBound - oldLowerBound + 1) * sizeof(int));
    /*free memory from old array*/
    //printf("Freeing old array of size %d\n", (higherBound - oldLowerBound) + 1);
    for (size_t i = 0; i < (higherBound - oldLowerBound) + 1; i++)
    {
        free(gt_arr[i]);
    }
    /*Reassigning and freein dem pointaz*/
    free(gt_arr);
    gt_arr = helper_arr;
    helper_arr = NULL;
    free(row_arr);
    row_arr = helper_row_arr;
    helper_row_arr = NULL;
}

void resizeGameTableRight()
{
    /*Analog zu ResizeGameTableLeft*/
    helper_arr = (short **)malloc(nCols * sizeof(short *));
    if (!helper_arr)
    {
        fprintf(stderr, "Failed memory allocation");
        myExit();
    }

    for (int col = 0; col < nCols; col++)
    {
        helper_arr[col] = (short *)malloc(nRows * sizeof(short));
        if (!helper_arr[col])
        {
            fprintf(stderr, "Failed memory allocation");
            myExit();
        }

        for (size_t j = 0; j < nRows; j++)
        {
            helper_arr[col][j] = -2;
        }
    }

    for (size_t i = 0; i < (oldHigherBound - lowerBound) + 1; i++)
    {
        free(hitMask[i]);
    }
    free(hitMask);

    hitMask = (char **)malloc(nCols * sizeof(char *));
    if (!hitMask)
    {
        fprintf(stderr, "Failed memory allocation");
        myExit();
    }

    for (int col = 0; col < nCols; col++)
    {
        hitMask[col] = (char *)malloc(nRows * sizeof(char));
        if (!hitMask[col])
        {
            fprintf(stderr, "Failed memory allocation");
            myExit();
        }

        for (size_t j = 0; j < nRows; j++)
        {
            hitMask[col][j] = '0';
        }
    }

    helper_row_arr = (int *)malloc(nCols * sizeof(int));
    if (!helper_row_arr)
    {
        fprintf(stderr, "Failed memory allocation");
        myExit();
    }

    for (size_t i = 0; i < nCols; i++)
    {
        helper_row_arr[i] = 0;
    }

    for (int col = 0; col < oldHigherBound - lowerBound + 1; col++)
    {
        memcpy(helper_arr[col], gt_arr[col], nRows * sizeof(short));
    }
    /*helper_row_arr*/
    memcpy(&helper_row_arr[0], &row_arr[0], (oldHigherBound - lowerBound + 1) * sizeof(int));

    for (size_t i = 0; i < (oldHigherBound - lowerBound) + 1; i++)
    {
        free(gt_arr[i]);
    }
    free(gt_arr);
    gt_arr = helper_arr;
    helper_arr = NULL;
    free(row_arr);
    row_arr = helper_row_arr;
    helper_row_arr = NULL;
}

void resizeGameTableAbove()
{
    helper_arr = (short **)malloc(nCols * sizeof(short *));
    if (!helper_arr)
    {
        fprintf(stderr, "Failed memory allocation");
        myExit();
    }

    for (int col = 0; col < nCols; col++)
    {
        helper_arr[col] = (short *)malloc(nRows * sizeof(short));
        if (!helper_arr[col])
        {
            fprintf(stderr, "Failed memory allocation");
            myExit();
        }

        for (size_t j = 0; j < nRows; j++)
        {
            helper_arr[col][j] = -2;
        }
    }

    for (size_t i = 0; i < nCols; i++)
    {
        free(hitMask[i]);
    }
    free(hitMask);

    hitMask = (char **)malloc(nCols * sizeof(char *));
    if (!hitMask)
    {
        fprintf(stderr, "Failed memory allocation");
        myExit();
    }

    for (int col = 0; col < nCols; col++)
    {
        hitMask[col] = (char *)malloc(nRows * sizeof(char));
        if (!hitMask[col])
        {
            fprintf(stderr, "Failed memory allocation");
            myExit();
        }

        for (size_t j = 0; j < nRows; j++)
        {
            hitMask[col][j] = '0';
        }
    }

    for (int col = 0; col < nCols; col++)
    {
        //memcpy(helper_arr[col], gt_arr[col], nRows/2 * sizeof(int));
        for (size_t i = 0; i < oldnRows; i++)
        {
            helper_arr[col][i] = gt_arr[col][i];
        }
    }
    //printf("Freeing old array of size %d\n", (oldHigherBound - lowerBound) + 1);
    for (size_t i = 0; i < nCols; i++)
    {
        free(gt_arr[i]);
    }
    free(gt_arr);
    gt_arr = helper_arr;
    helper_arr = NULL;
}

/*Inserting Pair of color/position, managing GameTable size and creating new hitmask
since a new one is needed for every insert*/
int insertPair(int color, int xpos)
{
    int returnV = -1;
    //printf("Inserting %d, %d\n", color, xpos);
    /*Checking if Boundary adjustment is needed*/
    if (xpos < lowerBound)
    {
        oldLowerBound = lowerBound;
        lowerBound = xpos - ResizeNL;
        ResizeNL = ResizeNL * 4;
        smallestIndex = xpos;
        nCols = (higherBound - lowerBound) + 1;
        resizeGameTableLeft();
    }
    else if (xpos > higherBound)
    {
        oldHigherBound = higherBound;
        higherBound = xpos + ResizeNR;
        ResizeNR = ResizeNR * 4;
        highestIndex = xpos;
        nCols = (higherBound - lowerBound) + 1;
        resizeGameTableRight();
    }
    else if (xpos < smallestIndex)
    {
        smallestIndex = xpos;
    }
    else if (xpos > highestIndex)
    {
        highestIndex = xpos;
    }

    /*Insertion process starts here*/
    if (row_arr[xpos - lowerBound] == nRows)
    {
        oldnRows = nRows;
        nRows = ResizeNA;
        resizeGameTableAbove();
        gt_arr[xpos - lowerBound][row_arr[xpos - lowerBound]] = color;
        row_arr[xpos - lowerBound]++;
        ResizeNA = ResizeNA * 4;
        returnV = oldnRows;
    }
    else
    {
        gt_arr[xpos - lowerBound][row_arr[xpos - lowerBound]] = color;
        row_arr[xpos - lowerBound]++;
        returnV = row_arr[xpos - lowerBound] - 1;
    }
    return returnV;
}

void reshift()
{
    int changes = 0;
    int lmax = -1;
    int rmax = -1;
    int dmax = -1;
    int coll = lrDelim[0];
    int collr = (lrDelim[1] + 1);
    int colld = lrDelim[2];
    for (size_t i = coll; i < collr; i++)
    {
        for (size_t j = colld; j < row_arr[i] + 1; j++)
        {
            checkStone(i, j);
            if ((lrDelim[0] != -1) && (lrDelim[1] != -1))
            {
                changes = 1;
                if (lmax == -1)
                {
                    lmax = lrDelim[0];
                }
                else if (lmax > lrDelim[0])
                {
                    lmax = lrDelim[0];
                }
                if (rmax == -1)
                {
                    rmax = lrDelim[1];
                }
                else if (rmax < lrDelim[1])
                {
                    rmax = lrDelim[1];
                }
                if (dmax == -1)
                {
                    dmax = lrDelim[2];
                }
                else if (dmax > lrDelim[2])
                {
                    dmax = lrDelim[2];
                }
            }
        }
    }
    //printf("\nFound Bounds; %d %d\n", lmax, rmax);
    if (changes == 1)
    {
        shiftDown(lmax, rmax, dmax);
        lrDelim[0] = lmax;
        lrDelim[1] = rmax;
        lrDelim[2] = dmax;
        reshift();
    }
    else
    {
        return;
    }
    return;
}

/***
 *             __      ___          ____                  _            
 *       _____/ /_____/ (_)___     / __ \____ ___________(_)___  ____ _
 *      / ___/ __/ __  / / __ \   / /_/ / __ `/ ___/ ___/ / __ \/ __ `/
 *     (__  ) /_/ /_/ / / / / /  / ____/ /_/ / /  (__  ) / / / / /_/ / 
 *    /____/\__/\__,_/_/_/ /_/  /_/    \__,_/_/  /____/_/_/ /_/\__, /  
 *                                                            /____/   
 */

int mGetLine()
{
    size_t rdIdx = 0;
    int tmp;

    while (true)
    {
        tmp = fgetc(stdin);
        if (tmp == EOF)
        {
            myEOF = 1;
            line[rdIdx] = '\0';
            break;
        }
        if (tmp == 0)
        {
            fprintf(stderr, "Read NULL\n");
            myExit();
        }
        if (tmp == 10)
        {
            line[rdIdx] = '\0';
            break;
        }
        
        line[rdIdx] = (char)tmp;
        rdIdx++;
    }
    
    stringLength = rdIdx;
    if (rdIdx > 2)
    {
        return 1;
    }
    
    return 0;
}

void initRegex()
{
    /* Compile regular expression */
    reti = regcomp(&regex, "^[0-9]+[[:space:]]+-?[0-9]+[[:space:]]*[\n]?$", REG_EXTENDED | REG_NOSUB);
    if (reti)
    {
        fprintf(stderr, "Could not compile regex\n");
        myExit();
    }
}

bool checkLine(char *pline)
{
    reti = regexec(&regex, pline, 0, NULL, 0);
    if (!reti)
    {
        return 1;
    }
    else if (reti == REG_NOMATCH)
    {
        fprintf(stderr, "Regex match failed at line %d: \"%s\" Your entry is not correct!\n", nLine, pline);
        myExit();
    }
    else
    {
        regerror(reti, &regex, msgbuf, sizeof(msgbuf));
        fprintf(stderr, "Regex match failed: \"%s\". Your entry is not correct!\n", msgbuf);
        myExit();
    }
    return 0;
}

/*This function decomposes a valid string and stores the 2 digits found in it.
Furthermore it also takes care of verifying the numbers validity (in range or not)*/
void parseLine()
{
    int nPrefixZeros = 0;
    int firstDigitHit = 0;
    /*First Decimal: we know it starts at line beginning*/
    for (int i = 0; i < stringLength; i++)
    {
        if (line[i] == '\\' && i < stringLength - 1 && line[i + 1] == '0')
        {
            fprintf(stderr, "Read NULL byte!\n");
            myExit();
        }

        /*Finding first whitespace delimiting the first and the second decimal*/
        if (line[i] == ' ')
        {
            fisrtAssignedidx = i;
            while (nPrefixZeros < fisrtAssignedidx && line[nPrefixZeros] == 48)
            {
                nPrefixZeros++;
            }
            if (fisrtAssignedidx - nPrefixZeros > 3)
            {
                fprintf(stderr, "Color decimal is too big!\n");
                myExit();
            }

            sprintf(cpFirstDecimal, "%.*s", (i), line);
            firstDecimal = atoi(cpFirstDecimal);
            /*Checking if firstDecimal is in range*/
            if (firstDecimal > 254 || firstDecimal < 0)
            {
                fprintf(stderr, "At entry line %d: Color decimal number is out of range. Expected range: [0, 254]. Read decimal: %d\n", nLine + 1, firstDecimal);
                myExit();
            }
            break;
        }
    }
    /*Second Decimal: we must first skip all whitespaces and find the first digit or '-'*/
    for (int i = fisrtAssignedidx + 1; i < stringLength; i++)
    {
        /*Skipping whitespaces*/
        if (line[i] == ' ')
        {
            continue;
        }
        else
        {
            secondAssignedIndex = i;
            break;
        }
    }
    /*Second decimal: digest all digits until we encounter whitespace or escape sequence*/
    /*Special case: single digit at end of file w/o newline / CR*/
    if (secondAssignedIndex == (stringLength - 1))
    {
        sprintf(cpSecondDecimal, "%.*s", 1, &line[secondAssignedIndex]);
        secondDecimal = atoi(cpSecondDecimal);
        return;
    }
    /*Rest of the file case*/
    nPrefixZeros = 0;
    firstDigitHit = 0;
    for (int i = secondAssignedIndex; i < stringLength; i++)
    {
        if (line[i] == 48 && firstDigitHit != 1)
        {
            nPrefixZeros++;
            continue;
        }

        if ((line[i] == '-'))
        {
            continue;
        }

        if (((47 < line[i] && line[i] < 58)) && (i < stringLength - 1))
        {
            firstDigitHit = 1;
            continue;
        }
        else
        {
            //EOF W/out \n
            if ((47 < line[i] && line[i] < 58) && i == stringLength - 1)
            {
                if ((i - secondAssignedIndex + 1 - nPrefixZeros) > 9)
                {
                    fprintf(stderr, "X Position is either too large or too small!\n");
                    myExit();
                }

                sprintf(cpSecondDecimal, "%.*s", (i - secondAssignedIndex + 1), &line[secondAssignedIndex]);
                secondDecimal = atoi(cpSecondDecimal);
                break;
            }
            if ((i - secondAssignedIndex + 1 - nPrefixZeros) > 9)
            {
                fprintf(stderr, "X Position is either too large or too small!\n");
                myExit();
            }
            sprintf(cpSecondDecimal, "%.*s", (i - secondAssignedIndex), &line[secondAssignedIndex]);
            secondDecimal = atoi(cpSecondDecimal);
            if (secondDecimal < (int)-1048576 || secondDecimal > (int)1048576)
            {
                fprintf(stderr, "X Position out of range [-2^20, 2^20]\n");
                myExit();
            }

            break;
        }
    }
    fisrtAssignedidx = -1;
    secondAssignedIndex = -1;
    return;
}

/***
 *                        _     
 *       ____ ___  ____ _(_)___ 
 *      / __ `__ \/ __ `/ / __ \
 *     / / / / / / /_/ / / / / /
 *    /_/ /_/ /_/\__,_/_/_/ /_/ 
 *                              
 */

int main()
{
    /*Initializing Game table*/
    initGameTable();
    /*Initialize Regex Object*/
    initRegex();
    /*Getting first line seperately to setup GameTable*/
    line = malloc(256 * sizeof(char));

    //if (fgets(line, 256, stdin) != NULL)
    if (mGetLine() == 1)
    {
        if ((stringLength = strlen(line)) > 2 && checkLine(line))
        {
            //printf("----------------NEWLINE----------------\n");
            parseLine();
            matches++;
            nLine++;
            lowerBound = secondDecimal;
            higherBound = secondDecimal;
            oldLowerBound = secondDecimal;
            oldHigherBound = secondDecimal;
            smallestIndex = secondDecimal;
            highestIndex = secondDecimal;
            insertPair(firstDecimal, secondDecimal);
        }
        // else if (line[0] == '\n' && stringLength == 1)
        // {
        //     return 0;
        // }
        else
        {
            fprintf(stderr, "Line too short! Length %d\n", stringLength);
            myExit();
        }
    }

    /*Looping through stdin*/
    //while (fgets(line, 256, stdin) != NULL)
    while (mGetLine() == 1)
    {
        /*Looking for strlen greater than 3 because we expect at least 3 chars: 1 dec 1 space 1 dec*/
        if ((stringLength) > 2 && checkLine(line)) /* Check line for regex match */
        {
            //printf("\n----------------NEWLINE----------------\n\n");
            /*Line matched the regular expression. We can safely decompose our string*/
            parseLine();

            //Doing stuff
            int putY = insertPair(firstDecimal, secondDecimal);

            // printf("####\tGameTable\t####\n");
            // for (size_t i = nRows; i > 0; i--)
            // {
            //     printf("|");
            //     for (size_t j = 0; j < nCols; j++)
            //     {
            //         printf("% d |", gt_arr[j][i - 1]);
            //     }
            //     printf("\n");
            // }
            // printf("|");
            // for (size_t i = 0; i < nCols; i++)
            // {
            //     printf(" %d |", row_arr[i]);
            // }
            // printf("\n");

            //printf("####\tCheckResults\t####\n");
            checkStone(secondDecimal - lowerBound, putY);

            //printf("####\tShiftingDown\t####\n");
            if (lrDelim[0] == -1 || lrDelim[1] == -1)
            {
                //printf("Nothing to shift\n");
            }
            else
            {
                shiftDown(lrDelim[0], lrDelim[1], lrDelim[2]);
                // printf("####\tAfterSD\t####\n");
                // for (size_t i = nRows; i > 0; i--)
                // {
                //     printf("| ");
                //     for (size_t j = 0; j < nCols; j++)
                //     {
                //         printf("%d |", gt_arr[j][i - 1]);
                //     }
                //     printf("\n");
                // }
                // printf("|");
                // for (size_t i = 0; i < nCols; i++)
                // {
                //     printf(" %d |", row_arr[i]);
                // }
                // printf("\n");
                //begin reshift loops
                reshift();
                // printf("####\tAfterReshift\t####\n");
                // for (size_t i = nRows; i > 0; i--)
                // {
                //     printf("| ");
                //     for (size_t j = 0; j < nCols; j++)
                //     {
                //         printf("%d |", gt_arr[j][i - 1]);
                //     }
                //     printf("\n");
                // }
                // printf("|");
                // for (size_t i = 0; i < nCols; i++)
                // {
                //     printf(" %d |", row_arr[i]);
                // }
                // printf("\n");
            }
            matches++;
            if (myEOF == 1)
            {
                break;
            }
            
        }
        else
        {
            fprintf(stderr, "Line too short! Length %d\n", stringLength);
            myExit();
        }
        nLine++;
    }
    // printf("|");
    // for (size_t i = 0; i < nCols; i++)
    // {
    //     printf(" %d |", row_arr[i]);
    // }
    // printf("\n");

    //printf("####\tFinalResult\t####\n");
    for (size_t i = 0; i < nCols; i++)
    {
        for (size_t j = 0; j < nRows; j++)
        {
            if (gt_arr[i][j] != -2)
            {
                printf("%d %ld %ld\n", gt_arr[i][j], i + lowerBound, j);
            }
        }
    }

    /* Free memory allocated to the pattern buffer by regcomp() */
    regfree(&regex);
    /* Free game Table memory */
    //printf("freeing memory of array at end of main of size %d * %d\n", nCols, nRows);
    for (size_t i = 0; i < nCols; i++)
    {
        free(gt_arr[i]);
    }
    free(gt_arr);
    for (size_t i = 0; i < nCols; i++)
    {
        free(hitMask[i]);
    }
    free(hitMask);
    free(row_arr);
    free(line);
    return 0;
}