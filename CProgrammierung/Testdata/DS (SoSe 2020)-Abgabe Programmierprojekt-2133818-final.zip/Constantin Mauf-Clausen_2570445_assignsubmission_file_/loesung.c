#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_X 1048576 //maximum value for x

//global values

typedef struct inputVector { //input vector extracted from stdin
    int valid;
    int xvalue;
    unsigned char color;
} inputVector;

typedef struct clearVector { // structure for removal queue
    int x;
    int y;
    struct clearVector* next;
    struct clearVector* prev;
} clearVector;

typedef struct fieldColumn { //structure representing a column
    unsigned int cap; // column capacity
    unsigned int len; // # of indexes in column
    unsigned char* arr; // the array holding the actual values
} fieldColumn;

void **field; //global playing field
size_t fieldSize; //current size of playing field
int offset = 0; //offset for neg x values
clearVector* clearHead; // pointer to first vector in clear queue
clearVector* clearTail; //pointer to last vector in clear queue

//END GLOBAL VALUES

//START INPUT FUNCTIONS

/** Checks if the given characters are valid input
 *  is given single tokens
 *  @param str the string to check
 *  @return 0 if characters are valid, 1 if not
 * */
int checkChars (const char* str) {
    int len = strlen(str);
    for (int i=0; i<len-1; i++) {
        if (i == 0) {
            if (str[i] != 45) { //first character is allowed to be '-'
                if (str[i] < 48 || str[i] > 57) {
                    fprintf(stderr, "Kein gueltiges Zeichen!\n");
                    return 1;
                }
            }
        }
        else {   
            if (str[i] < 48 || str[i]> 57) {
                fprintf(stderr, "Falsche Eingabe!\n");
                return 1;
            }
        }
    }
    return 0;
}

/** Checks if input is valid 
 * @param input string from stdin
 * @return InputVector specifying validity and inpute values
 * */
inputVector checkInput(char* input) {
    char *loc = strchr(input, '\0');
    char delim [2] = " "; //used for strtok
    static inputVector values;
    int valid = -1;
    values.valid = 0;
    if (loc == NULL) {
        fprintf(stderr, "Fehler beim Einlesen - keine Newline?!\n");
        values.valid = -1;
    }
    else {
        char *token;
        token = strtok(input, delim);
        int tmpvar = atoi(token);
        if ((valid=checkChars(token)) == 0 && (tmpvar>=0 && tmpvar <=255)) {
            values.color = tmpvar;
        }
        else {
            values.valid = -1;
            fprintf(stderr,"Farbwert ausserhalb des Erlaubten!\n");
            return values;

        } ; // argument has valid characters?
        
        token = strtok(NULL, delim);
        (valid = checkChars(token)) == 0 ? (values.xvalue = atoi(token)) : (values.valid = -1); //argument correct? write in array, put -1 for otherwise
        if (abs(values.xvalue)>MAX_X) { // X value bigger than 2^20
            fprintf(stderr, "X-Wert zu gross!\n");
            values.valid = -1;
            return values;
        }
        if ((token=strtok(NULL, delim))!=NULL) { //more than 2 values
            fprintf(stderr, "Zu viele Werte auf der Zeile!\n");
            values.valid = -1;
            return values;
        }
    }
    return values;
}

// END INPUT FUNCTIONS


// START FUNCTIONS FOR PLAYING FIELD

/** Initializes column to have height 8 
 *  @param column pointer to column
 *  @return initialized column of height 8
 * */
fieldColumn* initColumn(fieldColumn* column) {
    unsigned char* colors = calloc(8, sizeof(unsigned char));
    column = malloc(sizeof(fieldColumn));
    if(colors == NULL || column == NULL) {
            return NULL;
        }
    column->arr = colors;
    column->cap = 8;
    column->len = 0;
    return column;
}

/** Prints the whole field
 * */
void showField() {
    for(int i=0; (size_t) i<fieldSize; i++) { //for each column
        fieldColumn* t = (fieldColumn*) field[i];
        for(int j = t->len-1; j>=0;j--) { //show pieces from top to bottom
            fprintf(stdout,"%d %d %d\n", t->arr[j], i-offset, j);
        }
    }
}

/** @brief gets index of playing field
 *  @param x the desired column
 * */
int getFieldIndex(int x) {
    return x+offset;
}

/** @brief checks if column is corrupted
 *  @param x the index of the column
 *  @return 0 if all is fine, -1 else
 * */
int checkColumn(int x){
    fieldColumn* t = (fieldColumn*) field[x];
    if ( (t->len > t->cap) || t->arr == NULL || t == NULL) return -1;
    return 0;
}

/**Initializes playing field
 *  @return NULL if initialization failed
 * **/
void* init() {
    void** startingField = calloc(8, sizeof(fieldColumn*)); //initial playing field of 8 
    for (int i=0; i<8; i++) {
        fieldColumn* t = initColumn(t);
        if(t == NULL || t->arr == NULL) {
            return NULL;
        }
        startingField[i] = t;
    }
    field = startingField;
    fieldSize = 8;
    return field;
}

/** Frees the whole playing field
 *  @param oldField pointer to field needing cleanup
 *  @param size size of field to clean
 * */
void cleanUp(void** oldField, size_t size) {
    for(size_t i=0; i<size; i++) {
        fieldColumn* t = (fieldColumn*) oldField[i];
        free(t->arr);
        free(t);
    }
    free(oldField);
}

/** @brief return a deep copy of a column
 *  @param old the pointer to the old column
 *  @return a new column
 * */
fieldColumn* copyColumn (fieldColumn* old) {
    fieldColumn* t = malloc(sizeof(fieldColumn));
    unsigned char* newArr = calloc((size_t) old->cap, sizeof(char));
    t->len = old->len;
    t->cap = old->cap;
    for(unsigned int i=0; i<old->len; i++) {
        newArr[i] = old->arr[i];
    }
    t->arr = newArr;
    return t;
}

/** Broaden the playing field
 * @param x the value that exceeds the bounds of the playing field
 * */
void* broaden(int x) {
    if ((x-offset)==(int) fieldSize-offset-1) { //do nothing if function got called falsely
    
    }
    else if (x>0) { //
        size_t newFieldSize = fieldSize+(size_t) x -(fieldSize - (size_t) offset) +1;
        field = realloc(field, newFieldSize*(sizeof(fieldColumn*)));
        if(field==NULL) return field;
        for(size_t i = fieldSize; i<newFieldSize; i++) {

            fieldColumn* t = initColumn(t);
            field[i] = t;
        }
        fieldSize = newFieldSize;

    }
    else {
        int oo = offset;
        offset = abs(x);
        size_t newFieldSize = fieldSize + (size_t) (offset-oo);
        void** newField = calloc(newFieldSize, (sizeof(fieldColumn)));
        for (unsigned int i = 0; i< newFieldSize-fieldSize; i++) {
            fieldColumn* t = initColumn(t);
            newField[i] = t;
        }
        for (unsigned int i = 0; i< fieldSize; i++) { //copy old field offset in new field
            fieldColumn *t = field[i];
            newField[i+(offset-oo)] = copyColumn(t);
        }
        cleanUp(field, fieldSize); // free all blocks from old field
        field = newField;
        fieldSize = newFieldSize;
    }
    return field;
}

/** Heightens the column when too small
 *  @param x the colum to be heightened 
 *  @return NULL if realloc failed
 *  */
void* heighten(int x) {
    int i = getFieldIndex(x);
    fieldColumn* curr = (fieldColumn*) field[i];
    curr->arr = realloc(curr->arr, curr->cap*2);
    curr->cap*=2;
    return curr->arr;
}

/** @brief Adds the "piece" to a column
 *  @param x the colum
 *  @param color the color;
 *  @return NULL if heightening failed
 * */
void* addColor(int x, unsigned char color) {
    int i = getFieldIndex(x);
    if((size_t) i >= fieldSize) {
        void* k = broaden(x);
        if (k == NULL) {
            return k;
        }
        i = getFieldIndex(x);
    }
    fieldColumn* curr = (fieldColumn*) field[i];
    if (curr == NULL) {
        curr = initColumn(curr);
    }
    if (curr->len==curr->cap) {
        void* k = heighten(x);
        if (k==NULL) return k;
    }
    if(curr->len > curr->cap) {
        curr->len = 8;
        }
    curr->arr[curr->len] = color;
    curr->len++;
    return curr;
}

/** @brief removes piece at given index
 *  @param x the colum
 *  @param y the index to be removed (actual value)
 *  @return 0 if everything worked
 * */
int removePiece(int x, int y) { 
    
    fieldColumn* t = (fieldColumn*) field[x];

    if(t->len == 1 && y== 0) { //only one piece in column
        t->arr[0] = 0;
        t->len--;

        if (checkColumn(x) == 0){
            return 0;
        }
        else {
            return -1;
        } 
    }

    for (unsigned int j=y; j+1<t->len;j++) { //more than one piece
        t->arr[j] = t->arr[j+1];
    }
    t->arr[t->len] = 0;
    t->len--;

    if (checkColumn(x) == 0){
        return 0;
    }
    else {
        return -1;
    } 
}

/** Add a color to column X
 * @param color the char value representing the color added
 * @param xvalue the column at which the piece is added
 * @return 0 if success, -1 if broaden() fails, -2 if addColor() fails
 * */
int addPiece(char color, int xvalue) { 
    if (((xvalue < 0) && (abs(xvalue)> offset)) || //Negative X Value that exceeds the offset
        ((size_t) (xvalue+ offset) >= fieldSize)) { //Positive X Value that exceeds the size of the field
        void* k = broaden(xvalue);
        if(k == NULL) return -1;
        }
    void* u = addColor(xvalue, color);
    if(u == NULL) return -2;
    else return 0;
}

//END FUNCTIONS FOR PLAYING FIELD


// linked list for clearing pieces aka clear queue

/** @brief free clear queue
 * */
void clearCV() {

    clearVector* curr = clearHead;
    while(curr->next != NULL) {
        clearVector* tmp = curr->next;
        free(curr);
        curr = tmp;
    }
    free(curr);
    clearHead = NULL;
    clearTail = NULL; 

}

/** returns no. of vectors in removal queue
 *  @return no of vectors in removal queue 
 * */
int rQLen() {
    int cnt = 0;
    clearVector* curr = clearHead;
    while(curr->next != NULL) {
        curr = curr->next;
        cnt++;
    }
    return ++cnt;
}


/** @brief checks rm queue for double entries to avoid removing the wrong pieces
 *  @return 0 if no duplicates and more than 4 elements, !=0 else 
 * */
int checkRemovalQueue() {

    clearVector* tmp = clearHead;
    int cnt = 0;
    int dup = 0;
    while(tmp->next != NULL) {
        clearVector* t2 = tmp->next;
        while (t2->next != NULL) {
            if (tmp->x == t2->x && tmp->y == t2->y) {
                clearVector* t3 = t2->next;
                t2->prev->next = t2->next;
                t2->next->prev = t2->prev;
                free(t2);
                dup++;
                t2 = t3;
            }
            else {
                t2 = t2->next;
            }
        };
        tmp = tmp->next;
        cnt++;
    };
    if(tmp->x == tmp->prev->x && tmp->y == tmp->prev->y) {
        tmp->prev->next = NULL;
        tmp->prev = clearTail;
        free(tmp);
    }
    cnt++;
   if(cnt>=4) return 0;
   else {
       clearCV();
       return cnt;
   }
}

/** remove pieces in clear queue
 *  @return 0 if success, -1 else
 * */
int removePieces() {
    if (checkRemovalQueue()!=0) return -1;
    clearVector* curr = clearHead;
    int ret = 0;
    if (curr != NULL) {
        while (curr->next != NULL) {
            clearVector* tmp = curr->next;
            removePiece(curr->x, curr->y);
            curr = tmp;
        }
        ret = removePiece(curr->x, curr->y);
    }
    clearCV();
    return (ret == 0? 0: -1);
}

/** @brief adds a clear vector to clear queue
 *  @param cv the clear vector
 * */

void addCV (clearVector* cv) { //if queue is empty, add at head
    if(clearHead == NULL) {
        clearHead = cv;
        clearTail = cv;
        } 
    else { //go to last entry and append cv
        clearVector* curr = clearTail;
        curr->next = cv;
        cv->prev = curr;
        clearTail = cv;
    }
}

/** @brief initiates a clear vector, adds it to clear queue
 *  @param x x value
 *  @param y y value
 *  */
void initCV(int x, int y) {
    clearVector* tmp = malloc(sizeof(clearVector));
    tmp->x = x;
    tmp->y = y;
    tmp->next = NULL;
    tmp->prev = NULL;
    addCV(tmp);
}
// end clear queue

//solution algorithm

/** @brief checking for matches horizontally
 *  @param color the color that has to be matched
 *  @param x column of starting point
 *  @param y row of starting point
 *  @return 0 if no match, number of matching pieces else
 * */
int checkHorizontal(unsigned char color, size_t x, unsigned int y) { 
    int cnt = 1;
    size_t begin=x;
    for(int i = 1; i<4 && x+i < fieldSize; i++) { //searching for matches to the right
        fieldColumn* t = field[x+i];
        if (t->len <= y) break; //no value at height y
        else if (t->arr[y] != color) break; //not the same color
        else {
            cnt++;
        }
    }
    for (int j=1; j<4 && (int)(x)-j >=0; j++) {
        fieldColumn* t = field[x-j];
        if (t->len <= y) break; //no value at height y
        else if (t->arr[y] != color) break; //not the same color
        else {
            begin--;
            cnt++;
        }
    }
    
    for (int i = 1; cnt>=4 && i<=cnt; i++ ) {
        initCV(begin+i-1, y);
        if(i==cnt) {
            return i;
        }
    }

    return 0;
}

/** @brief checking for matches vertically
 *  @param color the color that has to be matched
 *  @param x column of starting point
 *  @param y row of starting point
 *  @return 0 if no match, number of matching pieces else
 * */
int checkVertical(unsigned char color, size_t x, unsigned int y) {
    int cnt = 0;
    fieldColumn* t = (fieldColumn*) field[x];
    for(int i= (int) y; i>=0; i--) {
        if(t->arr[i] != color) { //next is not the same color
            break;
        }
        cnt++;
    }

    for (int i = 0; cnt>=4 && i<cnt; i++ ) {
        initCV(x, y-i);
        if(i==cnt) return i;
    }
    return 0;
}

/** @brief checking for matches diagonally upwards
 *  @param color the color that has to be matched
 *  @param x column of starting point
 *  @param y row of starting point
 *  @return 0 if no match, number of matching pieces else
 * */
int checkUpwardDiagonal(unsigned char color, size_t x, int y) {
    int cnt = 0;
    size_t begin = x;
    for(int i=1; i<4 && x+i < fieldSize; i++) { //checking upwards right
        fieldColumn* t = (fieldColumn*) field[x+i];
        if((unsigned int)y+i >= t->len) break;
        if(t->arr[y+i] != color) { //next is not the same color
            break;
        }
        cnt++;
    }

    for(int j=1; j<4 && (int)x-j >= 0; j++) { //checking downwards left
        fieldColumn* t = (fieldColumn*) field[x-j];
        if((unsigned int)y-j >= t->len) break;
        if(t->arr[y-j] != color) { //next is not the same color
            break;
        }
        begin--;
        cnt++;
    }
    
    for (int i = 0; cnt>=4 && i<cnt; i++ ) {
        initCV(begin+i, y-(x-begin)+i);
        if(i==cnt) return i;
    }
    return 0;
}

/** @brief checking for matches diagonally downwards
 *  @param color the color that has to be matched
 *  @param x column of starting point
 *  @param y row of starting point
 *  @return 0 if no match, number of matching pieces else
 * */
int checkDownwardDiagonal(unsigned char color, size_t x, unsigned int y) {

    int cnt = 0;
    size_t begin = x;
    for(int i=1; i<4 && (size_t) i+x < fieldSize && (int) y-i >= 0; i++) {

        fieldColumn* t = (fieldColumn*) field[x+i];
        if (t->len <= (unsigned int) y-i) break; // there is no piece at y-i
        if(t->arr[y-i] != color) { //next is not the same color
            break;
        }
        cnt++;
    }

    for(int i=1; i<4 && (int)x-i >=0; i++) {
        fieldColumn* t = (fieldColumn*) field[x-i];
        if (t->len <= (unsigned int) y+i) break; // there is no piece at y-i
        if(t->arr[y+i] != color) { //next is not the same color
            break;
        }
        begin--;
        cnt++;
    }

    for (int i = 0; cnt>=4 && i<cnt; i++ ) {
        initCV(begin+i, y+(begin-x)-i);
        if(i==cnt) return i;
    }
    return 0;
}


/** resolve the pieces horizontally, vertically and diagonally
 *  @param x the column at which to start
 *  @param round the round of recursion we are doing
 *  @return 0 if resolving worked, 10 if recursion, -1 if it failed
 **/
int resolve(int x, int round) {
    size_t k = (size_t) getFieldIndex(x);

    int h = 0, v = 0, u = 0, d = 0; //ret values for resolving
    long li;
    size_t lb; // loop variables
    li = k - round*4;
    lb = k + round*4;
    if(li < 0 ) li = 0;
    if(lb >= fieldSize) lb=fieldSize; 

    while ((size_t) li <= lb)  {
        if((size_t)li==fieldSize) {
            break;
        }
        fieldColumn* t = (fieldColumn*) field[li];
        if (t->len==0) {
            li++;
        }
        else if ((size_t)li!=lb){
            for (unsigned int j = t->len-1; (int) j >= 0; j--) {
                unsigned char color = t->arr[j];
                h = checkHorizontal(color, li, j);
                v = checkVertical(color, li, j);
                u = checkUpwardDiagonal(color, li, j);
                d = checkDownwardDiagonal(color, li, j); 
            }
            li++;
        }
        else {
            unsigned int j = (t->len)-1; 
            unsigned char color = t->arr[j];

            h = checkHorizontal(color, li, j);
            v = checkVertical(color, li, j);
            u = checkUpwardDiagonal(color, li, j);
            d = checkDownwardDiagonal(color, li, j); 

            li++;
        }
    } 
    int tst = 0;
    int tst2= 0;
    if (clearHead != NULL) {

        tst = removePieces();
        if (tst == 0) {

            tst2 = resolve(x, round+1);
            if (round != 0){

                return 10;
            }
            else if (tst2 == 10 && tst == 0) {

                return 0;
            }
        }
        else return -1;
    }
    else {

        return 0;
    }
    tst = h+v+u+d; //only here to use the return values

    return 0;
}

//end of solution algorithm

/** Main function
 * @return 10 bei fehlerhaftem Aufruf, \\
 * 11 bei Scheitern der Initialisierung \\
 * 12 bei Fehlerhafter Eingabe, \\
 * 13 bei Fehler beim Verbreitern des Spielfelds,\\
 * 14 bei Fehler im Hinzufügen der Steine,
 * 15 bei Fehler im Auflösen
 * */ 
int main (int argc, char **argv) {
    
    if (argc != 1) { //only run with piped input
        fprintf(stderr, "Too many arguments: %s\n", argv[1]);
        return 10;
    }
    
    char buf [4096]; //make sure input of maximum length can be handled
    void* ini = init();
    if(ini == NULL) return 11;
    while (fgets(buf, sizeof(buf), stdin) != NULL) { //reading input 
        inputVector values; 
        values = checkInput(buf); //extracting values from input
        if (values.valid == -1) {
            fprintf(stderr, "Fehlerhafte Eingabe!\n");
            return 12;
        }
        else {
            int v = addPiece(values.color, values.xvalue);
            // showField();
            if(v==-1) {
                cleanUp(field, fieldSize);
                return 13;
            }
            else if(v==-2) {
                cleanUp(field, fieldSize);
                return 14;
            }
            else {
                int ret = resolve(values.xvalue, 0);
                if (ret == -1) {
                    cleanUp(field, fieldSize);
                    return 15;
                }
            }
        }
    }

    showField();
    cleanUp(field, fieldSize);

    return 0;
}