#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TRUE 1
#define FALSE 0

typedef struct {
    long long start;
    long long end;
} PopResult;

typedef struct {
    long long start_x;
    long long start_y;
    int length;
} DiagonalResult;

//------------------------- Array --------------------------------------

#define MAX 1048577


typedef struct Array_t {
    long long** content;
    long long* size;
    long long* alloced_size;
    long long max_used;
    struct Array_t* neg;
} Array;

Array* create_array() {
    Array* a = malloc(sizeof(Array));
    if(a == NULL)
        goto DIE;

    a->content = malloc(MAX * sizeof(long long*));
    if(a->content == NULL)
        goto CONTENT_DIE;
    a->alloced_size = malloc(MAX * sizeof(long long));
    if(a->alloced_size == NULL)
        goto ALLOCED_DIE;
    a->size = malloc(MAX * sizeof(long long));
    if(a->size == NULL)
        goto SIZE_DIE;

    for(long long i=0; i<MAX; i++) {
        a->content[i] = NULL;
        a->size[i] = 0;
        a->alloced_size[i] = 0;
    }
    a->max_used = -1;
    a->neg = NULL;
    return a;

 SIZE_DIE:
    free(a->alloced_size);
 ALLOCED_DIE:
    free(a->content);
 CONTENT_DIE:
    free(a);
 DIE:
    fprintf(stderr, "create_array: Allocation error\n");
    return NULL;
}

void destroy_array(Array* a) {
    if(a->neg)
        destroy_array(a->neg);
    for(long long i=0; i<MAX; i++) {
        free(a->content[i]);
    }
    free(a->alloced_size);
    free(a->size);
    free(a->content);
    free(a);
}

long long push(Array* a, long long i, long long color) {
    if(i < 0) {
        a = a->neg;
        i = i * -1;
    }

    if(i > a->max_used)
        a->max_used = i;
    a->size[i] += 1;
    if(a->alloced_size[i] == 0) {
        a->content[i] = malloc(sizeof(long long));
        a->alloced_size[i] = 1;
    } else if (a->size[i] > a->alloced_size[i]) {
        a->content[i] = realloc(a->content[i], sizeof(long long) * a->size[i]);
        a->alloced_size[i] = a->size[i];
    }
    if(a->content[i] == NULL)
        goto DIE;
    a->content[i][a->size[i] - 1] = color;
    /* printf("(push) x: %lld  y: %lld color: %lld\n", */
    /*        i, a->size[i] - 1, color); */
    return a->size[i] - 1;

 DIE:
    fprintf(stderr, "push: Allocation error\n");
    return -1;
}

long long get(Array* a, long long x, long long y) {
    if(x < 0)
        return a->neg->content[x * -1][y];
    return a->content[x][y];
}

void pop(Array* a, long long x, long long y) {
    // printf("(pop) x: %lld y: %lld", x, y);
    if(x < 0) {
        x *= -1;
        a = a->neg;
    }
    a->size[x]--;
    for(long long i=y; i<a->size[x]; i++)
        a->content[x][i] = a->content[x][i+1];
}

//------------------------- Game Logic --------------------------------------

// Pop three in a line
//   Note that if we pop upwards, we don't need to change the coordinate
//   We leave out the center, to avoid multiple deletions of the same
//   coordinate.
// Decrease is a special case, where we want to finish earlier,
//   because we want to delete the rest of the line later on.
//   The default is 0;
#define HORIZONTAL 0
#define VERTICAL 1
#define DIAGONAL1 2
#define DIAGONAL2 3
void pop_line(Array* a, long long x, long long y, int mode, int skip,
              int count) {
    /* printf("(pop_line) mode: %d  x: %lld y: %lld skip: %d count: %d\n", */
    /*        mode, x, y, skip, count); */
    for(int i=0; i<count; i++) {
        if(i == skip)
            continue;

        switch(mode) {
        case VERTICAL: pop(a, x, y); break;
        case HORIZONTAL: pop(a, x+i, y); break;
        case DIAGONAL1: pop(a, x+i, y-i); break;
        case DIAGONAL2: pop(a, x+i, y+i); break;
        }
    }
}

// Helper for counting, make sure the coordinate access is within bounds
int check_bounds(Array* a, int i, long long x, long long y, int X, int Y) {
    x += (X*i);
    if(x < 0) {
        a = a->neg;
        x *= -1;
    }

    if(x <= a->max_used) {
        if((y+(Y*i) < a->size[x]) && (y+(Y*i) >= 0)) {
            return 1;
        }
    }
    return 0;
}

// Counting method: search at most 3 positions from the center for the same color
// A flexible function for counting in a certain direction
//   by setting X, Y with 0, 1 or -1;
// Use 0 for now change in this direction
//     1 for increasing (down to up, left to right)
//    -1 for decreasing
int count_line(Array* a, long long x, long long y, int X, int Y) {
    long long count = 0;
    for(int i=1; i<4; i++) {
        if(check_bounds(a, i, x, y, X, Y)) {
            if(get(a, x+(X*i), y+(Y*i)) == get(a, x, y)) {
                count++;
            } else {
                return count;
            }
        } else {
            return count;
        }
    }
    return count;
}

void evaluate_and_pop(Array* a, long long x, long long y);

void horizontal_pop(Array* a, long long x, long long y, int left,
                    int right, PopResult* r) {
    r->start = 0;
    r->end = 0;

    if(left + right >= 3) {
        pop_line(a, x-left, y, HORIZONTAL, left, left + right + 1);
        r->start = x - left;
        r->end = x + right;
    }
}

void vertical_pop(Array* a, long long x, long long y, int up, int down, PopResult* r) {
    r->start = 0;
    r->end = 0;

    if(down + up >= 3) {
        pop_line(a, x, y-down, VERTICAL, down, down + up + 1);
        r->start = y - down;
        r->end = y + up;
    }
}


void diagonal1_pop(Array* a, long long x, long long y, int top_left,
                   int bottom_right, DiagonalResult* d1, int top_half) {
    if(top_left + bottom_right >= 3) {
        d1->start_x = x - top_left;
        d1->start_y = y + top_left;
        d1->length = top_left + bottom_right + 1;

        if(top_half) {
            pop_line(a, x - top_left, y + top_left, DIAGONAL1, top_left, top_left);
        } else {
            pop_line(a, x, y, DIAGONAL1, 0, bottom_right + 1);
        }
    }
}

void diagonal2_pop(Array* a, long long x, long long y, int bottom_left,
                   int top_right, DiagonalResult* d2, int top_half) {
    if(bottom_left + top_right >= 3) {
        d2->start_x = x - bottom_left;
        d2->start_y = y - bottom_left;
        d2->length = bottom_left + top_right + 1;

        if(top_half) {
            pop_line(a, x, y, DIAGONAL2, 0, top_right + 1);
        } else {
            pop_line(a, x - bottom_left, y - bottom_left, DIAGONAL2, bottom_left, bottom_left);
        }
    }
}

void horizontal_check(Array* a, long long x, long long y, long long left, long long right) {
    for(long long i=left; i<=right; i++) {
        if(i == x)
            continue;
        evaluate_and_pop(a, i, y);
    }
}

void vertical_check(Array* a, long long x, long long up, long long down) {
    // Careful, the original (x,y) got overriden and we have 3 or 6 in a line
    for(long long i=down; i<up; i++)
        evaluate_and_pop(a, x, i);
}

void diagonal1_check(Array* a, long long x, long long top_left_x, long long top_left_y,
                     int length) {
    for(long long i=0; i<length; i++) {
        if(top_left_x + i == x)
            continue;
        evaluate_and_pop(a, top_left_x + i, top_left_y - i);
    }
}

void diagonal2_check(Array* a, long long x, long long bottom_left_x, long long bottom_left_y,
                     int length) {
    for(long long i=0; i<length; i++) {
        if(bottom_left_x + i == x)
            continue;
        evaluate_and_pop(a, bottom_left_x + i, bottom_left_y + i);
    }
}


// Evaluate whether given coordinate forms one or multiple single color lines
//     If so, call the pop function and run this function recursively
//     for each popped coordinate
void evaluate_and_pop(Array* a, long long x, long long y) {
    // printf("(evaluate_and_pop) x: %lld y: %lld\n", x, y);
    if(x < 0) {
        if(y >= a->neg->size[-1 * x])
            return;
    } else if(y >= a->size[x]) {
        return;
    }

    int left = count_line(a, x, y, -1, 0);
    int right = count_line(a, x, y, 1, 0);
    int up = count_line(a, x, y, 0, 1);
    int down = count_line(a, x, y, 0, -1);
    int top_left = count_line(a, x, y, -1, 1);
    int top_right = count_line(a, x, y, 1, 1);
    int bottom_left = count_line(a, x, y, -1, -1);
    int bottom_right = count_line(a, x, y, 1, -1);

    if((left + right < 3) && (up + down < 3)
       && (top_left + bottom_right < 3)
       && (bottom_left + top_right < 3))
        return;

    pop(a, x, y);
    PopResult h, v;
    DiagonalResult d1, d2;
    d1.length = 0; // We increase these up to two times
    d2.length = 0;

    // Since coordinates change during the pop process
    //   we must work from top to bottom
    // The x column has no effect to the other lines
    diagonal1_pop(a, x, y, top_left, bottom_right, &d1, 1);
    diagonal2_pop(a, x, y, bottom_left, top_right, &d2, 1);
    horizontal_pop(a, x, y, left, right, &h);
    vertical_pop(a, x, y, up, down, &v);
    diagonal1_pop(a, x, y, top_left, bottom_right, &d1, 0);
    diagonal2_pop(a, x, y, bottom_left, top_right, &d2, 0);

    evaluate_and_pop(a, x, y);
    if(h.start)
        horizontal_check(a, x, y, h.start, h.end);
    if(v.start)
        vertical_check(a, x, v.start, v.end);
    if(d1.length)
        diagonal1_check(a, x, d1.start_x, d1.start_y, d1.length);
    if(d2.length)
        diagonal2_check(a, x, d2.start_x, d2.start_y, d2.length);
}

//------------------------- I/O --------------------------------------

/* read_line allocates memory as needed,
   so the pointer has to be free'd by the caller ***/
#define RL_BUFFER_SIZE 80
char* read_line() {
  int buffer_size = RL_BUFFER_SIZE;
  int position = 0, c;

  char* buffer = malloc(sizeof(char) * buffer_size);
  if(!buffer) return NULL;

  while(1) {
    c = getchar();

    if(c == EOF || c == '\n') {
      buffer[position] = '\0';
      return buffer;
    } else {
      buffer[position] = c;
    }
    position++;

    if(position >= buffer_size) {
      buffer_size += RL_BUFFER_SIZE;
      buffer = realloc(buffer, buffer_size * sizeof(char));
      if(!buffer) return NULL;
    }
  }
}


/*** Helper function for get_ul and get_array
     Get the next token from given line and parse it to long long
     With the first call a pointer to the line must be given, with all subsequent
     calls for the same line, NULL must be passed.

     Returns FALSE if any input errors occured
 ***/
int get_token(char* line, long long* input) {
  char* token = strtok(line, " \t");
  if(token == NULL) {
    fprintf(stderr, "get_token: Invalid format\n");
    return FALSE;
  }

  errno = 0;
  char* endptr;
  *input = strtoll(token, &endptr, 10);
  if(errno != 0 ||
     endptr == line ||
     *endptr != '\0') {
    fprintf(stderr, "get_token: Invalid value\n");
    return FALSE;
  }
  return TRUE;
}


/*** Gets n values from a line from stdin.
     The space for array needs to be allocated by the user.

     RETURNS TRUE for success and FALSE for failure
 ***/
int get_array(int n, long long* array, int* error_status) {
  char* line = read_line();
  if(line[0] == '\0') {
      free(line);
      *error_status = 0;
      return FALSE;
  }
  if(line == NULL) {
    fprintf(stderr, "get_array: Allocation error\n");
    goto DIE;
  }

  for(int i=0; i<n; i++) {
    if(!get_token((i == 0) ? line : NULL, &array[i]))
        goto CLEAN_DIE;
  }

  if(strtok(NULL, " \t") != NULL) {
    fprintf(stderr, "get_array: Invalid format\n");
    goto CLEAN_DIE;
  }

  free(line);
  *error_status = 0;
  return TRUE;

 CLEAN_DIE:
  free(line);
 DIE:
  *error_status = 1;
  return FALSE;
}

void print_board(Array* a) {
    long long start = a->neg->max_used < 0 ? 0 : a->neg->max_used * -1;
    for(long long i=start; i<=a->max_used; i++) {
        if(i < 0) {
            for(long long j=0; j<a->neg->size[i * -1]; j++)
                printf("%lld %lld %lld\n", a->neg->content[i * -1][j], i, j);
        } else {
            for(long long j=0; j<a->size[i]; j++)
                printf("%lld %lld %lld\n", a->content[i][j], i, j);
        }
    }
}

//------------------------- Main --------------------------------------

int main() {
    Array* a;
    long long input[2];
    int error;
    long long pos;

    a = create_array();
    if(a == NULL)
        return 1;
    a->neg = create_array();
    if(a->neg == NULL)
        goto DIE;

    while(get_array(2, input, &error)) {
        if(input[1] < MAX * -1 || input[1] > MAX) {
            fprintf(stderr, "Coordinate out of bounds\n");
            goto DIE;
        }
        if(input[0] < 0 || input[0] > 254) {
            fprintf(stderr, "Color out of bounds\n");
            goto DIE;
        }
        pos = push(a, input[1], input[0]);
        if(pos == -1)
            goto DIE;
        evaluate_and_pop(a, input[1], pos);
    }
    if(error)
        goto DIE;

    print_board(a);
    destroy_array(a);
    return 0;

 DIE:
    destroy_array(a);
    return 1;
}
