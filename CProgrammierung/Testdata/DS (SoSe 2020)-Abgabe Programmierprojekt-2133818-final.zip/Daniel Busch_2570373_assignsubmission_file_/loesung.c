#include <assert.h>
#include <errno.h>
#include <inttypes.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define safe_malloc(size) ( safe_malloc_( (size) , __LINE__) )
#define safe_calloc(nmemb, size) ( safe_calloc_( (nmemb), (size) ,  __LINE__) )
#define safe_realloc(ptr, size) ( safe_realloc_( (ptr), (size), __LINE__) )

#if !defined(OUTPUT_ONLY) && !defined(NDEBUG)
#define log(...)  (log_ (__LINE__, __VA_ARGS__))
#else
#define log(...)
#endif
#define warn(...) (warn_(__LINE__, __VA_ARGS__))
#define die(...)  (die_ (__LINE__, __VA_ARGS__))

#define bitsizeof(x) (sizeof( ( x ) ) * CHAR_BIT)

void log_(int line, char* fmt, ...) {

    va_list varargs;
    va_start(varargs, fmt);
    
    char msg[500];
    vsnprintf(msg, sizeof(msg), fmt, varargs);
    printf("[Info in Z. %4d]: %s\n", line, msg);

    va_end(varargs);

}

void warn_(int line, char *fmt, ...) {

#ifndef NDEBUG
    va_list varargs;
    va_start(varargs, fmt);
    
    char msg[500];
    vsnprintf(msg, sizeof(msg), fmt, varargs);
#ifndef OUTPUT_ONLY
    printf("[Warnung in Z. %4d]: %s\n", line, msg);
#endif
    fprintf(stderr, "[Warnung in Z. %4d]: %s\n", line, msg);

    va_end(varargs);
#endif

}

void die_(int line, char *fmt, ...) {

    va_list varargs;
    va_start(varargs, fmt);
    
    char msg[500];
    vsnprintf(msg, sizeof(msg), fmt, varargs);
    fprintf(stderr, "[Fehler in Z. %4d]: %s\n", line, msg);

    va_end(varargs);

    exit(1);

}

void* safe_malloc_(size_t size, int line) {

    void* ptr = malloc(size);
    if (ptr == NULL) {

        char str[200];
        snprintf(str, 200, "malloc (%ld byte) fehlgeschlagen in Zeile %d, breche ab.", size, line);
        die(str);
        return NULL;

    }
    return ptr;

}

void* safe_calloc_(size_t nmemb, size_t size, int line) {

    void* ptr = calloc(nmemb, size);
    if (ptr == NULL) {

        char str[200];
        snprintf(str, 200, "calloc (%ld member zu je %ld byte) fehlgeschlagen in Zeile %d, breche ab.", nmemb, size, line);
        die(str);
        return NULL;

    }
    return ptr;

}

void* safe_realloc_(void *ptr, size_t size, int line) {

    void* new_ptr = realloc(ptr, size);
    if (new_ptr == NULL) {

        char str[200];
        snprintf(str, 200, "realloc (%ld byte) fehlgeschlagen in Zeile %d, breche ab.", size, line);
        die(str);

    }
    return new_ptr;

}

// make sure not to use these
#pragma GCC poison malloc calloc realloc

unsigned int msb_index(uint32_t x) {

    for (int i = bitsizeof(x) - 1; i >= 0; i--) {

        if (x & (((uint32_t) 1) << i)) return i;

    }

    assert(x == 0);
    return -1;

}


#define MIN_X (-1024 * 1024)
#define MAX_X ( 1024 * 1024)

typedef struct queue_node_ {

    struct queue_node_* prev;
    struct queue_node_* next;

    uint8_t data[];

} queue_node;

typedef struct queue_ {

    queue_node* head;
    queue_node* last;

    size_t elem_size;
    uint64_t size;
    
} queue;

queue* queue_init(size_t elem_size) {

    queue* the_queue = safe_malloc(sizeof(queue));
    the_queue->head = NULL;
    the_queue->last = NULL;
    the_queue->elem_size = elem_size;
    the_queue->size = 0;

    return the_queue;

}

void queue_putl(queue* the_queue, void* data) {

    queue_node* node = safe_malloc(sizeof(queue_node) + the_queue->elem_size);
    node->prev = NULL;
    node->next = the_queue->head;
    memcpy(&(node->data), data, the_queue->elem_size);

    if (the_queue->head == NULL) {

        assert(the_queue->size == 0);

        the_queue->head = node;
        the_queue->last = node;
        the_queue->size = 1;

    } else {

        assert(the_queue->size != 0);

        the_queue->head->prev = node;
        the_queue->head = node;
        the_queue->size += 1;

    }

}

void queue_putr(queue* the_queue, void* data) {

    queue_node* node = safe_malloc(sizeof(queue_node) + the_queue->elem_size);
    node->prev = the_queue->last;
    node->next = NULL;
    memcpy(&(node->data), data, the_queue->elem_size);

    if (the_queue->last == NULL) {

        assert(the_queue->size == 0);

        the_queue->head = node;
        the_queue->last = node;
        the_queue->size = 1;

    } else {

        assert(the_queue->size != 0);

        the_queue->last->next = node;
        the_queue->last = node;
        the_queue->size += 1;

    }

}

void queue_reml(queue* the_queue, void* data) {

    assert(the_queue->size > 0);
    queue_node* to_remove = the_queue->head;
    queue_node* new_head = to_remove->next;
    if (data != NULL) memcpy(data, &(to_remove->data), the_queue->elem_size);

    if (new_head == NULL) {

        the_queue->last = NULL;

    } else {

        new_head->prev = NULL;

    }

    free(to_remove);
    the_queue->size -= 1;

}

void queue_remr(queue* the_queue, void* data) {

    assert(the_queue->size > 0);
    queue_node* to_remove = the_queue->last;
    queue_node* new_last = to_remove->prev;
    if (data != NULL) memcpy(data, &(to_remove->data), the_queue->elem_size);

    if (new_last == NULL) {

        the_queue->head = NULL;

    } else {

        new_last->next = NULL;

    }

    free(to_remove);
    the_queue->size -= 1;

}

void queue_rem_node(queue* the_queue, queue_node* the_node) {

    assert(the_node != NULL);
    assert(the_queue->size > 0);

    assert(the_node->next == NULL || the_node->next->prev == the_node);
    assert(the_node->prev == NULL || the_node->prev->next == the_node);

    if (the_node->prev != NULL) {
        
        the_node->prev->next = the_node->next;

    } else {
        
        assert(the_queue->head == the_node);
        the_queue->head = the_node->next;

    }

    if (the_node->next != NULL) {
        
        the_node->next->prev = the_node->prev;

    } else {

        assert(the_queue->last == the_node);
        the_queue->last = the_node->prev;

    }

    free(the_node);
    the_queue->size -= 1;

}

void queue_uninit(queue* the_queue) {

    queue_node* current_node = the_queue->head;

    while (current_node != NULL) {

        queue_node* next_node = current_node->next;
        free(current_node);
        current_node = next_node;

    }

    free(the_queue);

}

// malloc max small bin payload size = 504 - word = 496 byte

#define HBLOCK_SIZE ((int32_t) 16)
#define VBLOCK_SIZE ((int32_t) 32)
#define EMPTY ((uint8_t) 255)

typedef struct vblock_ {

    uint8_t data[HBLOCK_SIZE][VBLOCK_SIZE];

} vblock;

typedef struct hblock_ {

    vblock* vblock_tower;
    uint32_t tower_size;
    int64_t heights[HBLOCK_SIZE];

} hblock;

typedef struct grid_ {

    hblock* positive;
    uint32_t positive_size;

    hblock* negative;
    uint32_t negative_size;

    uint32_t offset_x;

} grid;

grid* grid_global;
queue* removal_queue_global;
queue* gravity_queue_global;

void vblock_init(vblock* the_vblock) {

    memset(&(the_vblock->data), EMPTY, VBLOCK_SIZE * HBLOCK_SIZE);

}

void hblock_init(hblock* the_hblock) {

    the_hblock->vblock_tower = NULL;
    the_hblock->tower_size = 0;
    for (int i = 0; i < HBLOCK_SIZE; i++) the_hblock->heights[i] = -1;

}

grid* grid_init(void) {

    grid *the_grid = safe_malloc(sizeof(grid));

    the_grid->offset_x = 0;

    the_grid->positive = NULL;
    the_grid->positive_size = 0;

    the_grid->negative = NULL;
    the_grid->negative_size = 0;

    return the_grid;

}

void hblock_uninit(hblock* the_hblock) {

    free(the_hblock->vblock_tower);

}

void grid_uninit(grid* the_grid) {

    for (int i = 0; i < the_grid->positive_size; i++) hblock_uninit(&the_grid->positive[i]);
    for (int i = 0; i < the_grid->negative_size; i++) hblock_uninit(&the_grid->negative[i]);
    free(the_grid->positive);
    free(the_grid->negative);
    free(the_grid);

}

void x_to_subindexed_coords(int32_t x, uint32_t* x_index, uint32_t* x_offset) {

    // http://graphics.stanford.edu/~seander/bithacks.html#IntegerAbs

    int32_t mask = x >> (bitsizeof(x) - 1);
    int32_t x_xor_mask = (x ^ mask);
    *x_index = (x_xor_mask - mask) / HBLOCK_SIZE;

#ifndef NDEBUG
    int32_t x_offset0 = (x >= 0 ? x : (-x - 1)) % HBLOCK_SIZE;
    int32_t x_offset1 = (x >= 0 ? x : ~x) % HBLOCK_SIZE;
#endif

    *x_offset = x_xor_mask % HBLOCK_SIZE;
#ifndef NDEBUG
    assert(x_offset0 == *x_offset);
    assert(x_offset1 == *x_offset);
#endif

}

void grid_get_hblock(grid* the_grid, int64_t x, hblock** the_hblock) {

    uint32_t hblock_index = abs(x / HBLOCK_SIZE);

    /*char* arr_base = (char*) &(the_grid->positive);
    ptrdiff_t arr_diff = offsetof(grid, negative) - offsetof(grid, positive);
    hblock* arr = *((hblock**) (arr_base + (-(x < 0) & arr_diff)));


#ifndef NDEBUG
    uint32_t arr_size0;
    if (x < 0) arr_size0 = the_grid->negative_size;
    else       arr_size0 = the_grid->positive_size;
#endif
    
    char* size_base = (char*) &(the_grid->positive_size);
    ptrdiff_t size_diff = offsetof(grid, negative_size) - offsetof(grid, positive_size);
    uint32_t arr_size = *((uint32_t*) (size_base + (-(x < 0) & size_diff)));

    assert(arr_size == arr_size0);*/

    hblock* arr = (x >= 0 ? the_grid->positive : the_grid->negative);
    uint32_t arr_size = (x >= 0 ? the_grid->positive_size : the_grid->negative_size);

    if (hblock_index >= arr_size) *the_hblock = NULL;
    else *the_hblock = &(arr[hblock_index]);

}

uint8_t grid_read_at(grid* the_grid, int64_t x, int64_t y) {

    if (y < 0) return EMPTY;

    uint32_t hblock_offset;
    x_to_subindexed_coords(x, &hblock_offset, &hblock_offset);
    hblock* the_hblock;
    grid_get_hblock(the_grid, x, &the_hblock);

    if (the_hblock == NULL) return EMPTY;
    
    if (y > the_hblock->heights[hblock_offset]) return EMPTY;
    return the_hblock->vblock_tower[y / VBLOCK_SIZE].data[hblock_offset][y % VBLOCK_SIZE];

}

/*uint8_t grid_read_at(grid* the_grid, int64_t x, int64_t y) {

    if (y < 0) return EMPTY;

    uint32_t hblock_index, hblock_offset;
    x_to_subindexed_coords(x, &hblock_index, &hblock_offset);

    char* arr_base = (char*) &(the_grid->positive);
    ptrdiff_t arr_diff = offsetof(grid, negative) - offsetof(grid, positive);
    hblock* arr = *((hblock**) (arr_base + (-(x < 0) & arr_diff)));

#ifndef NDEBUG
    uint32_t arr_size0;
    if (x < 0) arr_size0 = the_grid->negative_size;
    else       arr_size0 = the_grid->positive_size;
#endif
    
    char* size_base = (char*) &(the_grid->positive_size);
    ptrdiff_t size_diff = offsetof(grid, negative_size) - offsetof(grid, positive_size);
    uint32_t arr_size = *((uint32_t*) (size_base + (-(x < 0) & size_diff)));

#ifndef NDEBUG
    if (arr_size != arr_size0) warn("arr_size != arr_size0: x = %d", x);
    assert(arr_size == arr_size0);
#endif

    if (hblock_index >= arr_size) return EMPTY;
    hblock* the_hblock = &arr[hblock_index];
    if (y > the_hblock->heights[hblock_offset]) return EMPTY;
    
    if (y / VBLOCK_SIZE >= the_hblock->tower_size) return EMPTY;
    return the_hblock->vblock_tower[y / VBLOCK_SIZE].data[hblock_offset][y % VBLOCK_SIZE];

}*/

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"
void grid_pprint(grid* the_grid) {

#if !defined(OUTPUT_ONLY) && !defined(NDEBUG)
    printf("\n\n\n");

    for (int x = 0; x < the_grid->negative_size; x++) {

        hblock the_hblock = the_grid->negative[x];

        if (the_hblock.tower_size == 0) {

            printf("SPARSE\n");

        } else {

            for (int x_offset = HBLOCK_SIZE - 1; x_offset >= 0; x_offset--) {

                int64_t height = the_hblock.heights[x_offset];

                for (int y = 0; y < the_hblock.tower_size; y++) {

                    vblock the_vblock = the_hblock.vblock_tower[y];

                    for (int y_offset = 0; y_offset < VBLOCK_SIZE; y_offset++) {

                        if (y * VBLOCK_SIZE + y_offset == height + 1) {

                            if (the_vblock.data[x_offset][y_offset] == EMPTY) printf("<   ");
                            else printf("<%3u", the_vblock.data[x_offset][y_offset]);

                        } else {

                            if (the_vblock.data[x_offset][y_offset] == EMPTY) printf("    ");
                            else printf("%4u", the_vblock.data[x_offset][y_offset]);

                        }

                    }

                    printf(" |||");

                }

                printf("\n");

            }

        }

        for (int y = 0; y < the_hblock.tower_size * VBLOCK_SIZE + 1; y++) {

            printf("====");

        }

        printf("\n");

    }

    for (int x = 0; x < the_grid->positive_size; x++) {

        hblock the_hblock = the_grid->positive[x];

        if (the_hblock.tower_size == 0) {

            printf("SPARSE\n");

        } else {

            for (int x_offset = 0; x_offset < HBLOCK_SIZE; x_offset++) {

                int64_t height = the_hblock.heights[x_offset];

                for (int y = 0; y < the_hblock.tower_size; y++) {

                    vblock the_vblock = the_hblock.vblock_tower[y];

                    for (int y_offset = 0; y_offset < VBLOCK_SIZE; y_offset++) {

                        if (y * VBLOCK_SIZE + y_offset == height + 1) {

                            if (the_vblock.data[x_offset][y_offset] == EMPTY) printf("<   ");
                            else printf("<%3u", the_vblock.data[x_offset][y_offset]);

                        } else {

                            if (the_vblock.data[x_offset][y_offset] == EMPTY) printf("    ");
                            else printf("%4u", the_vblock.data[x_offset][y_offset]);

                        }

                    }

                    printf(" |||");

                }

                printf("\n");

            }

        }

        for (int y = 0; y < the_hblock.tower_size * VBLOCK_SIZE + 1; y++) {

            printf("====");

        }

        printf("\n");

    }

    printf("\n\n\n");
#endif

}

void grid_output(grid* the_grid) {

#if (defined(OUTPUT_ONLY) && !defined(PYFORMAT)) || defined(NDEBUG)
    for (int64_t x = -((int64_t) (the_grid->negative_size + 1)) * HBLOCK_SIZE; x < ((int64_t) (the_grid->positive_size + 1)) * HBLOCK_SIZE; x++) {

        hblock* the_hblock = NULL;
        grid_get_hblock(the_grid, x, &the_hblock);
        if (the_hblock == NULL) continue;

        for (int64_t y = 0; y < the_hblock->tower_size * VBLOCK_SIZE; y++) {

            uint8_t color = grid_read_at(the_grid, x, y);
            if (color != EMPTY) printf("%d %ld %ld\n", color, x, y);

        }

    }
#endif

}

void grid_pyformat(grid* the_grid) {

#if defined(PYFORMAT) && !defined(NDEBUG)
    for (int64_t x = -((int64_t) (the_grid->negative_size + 1)) * HBLOCK_SIZE; x < ((int64_t) (the_grid->positive_size + 1)) * HBLOCK_SIZE; x++) {

        hblock* the_hblock = NULL;
        grid_get_hblock(the_grid, x, &the_hblock);
        if (the_hblock == NULL) continue;

        for (int64_t y = 0; y < the_hblock->tower_size * VBLOCK_SIZE; y++) {

            uint8_t color = grid_read_at(the_grid, x, y);
            if (color != EMPTY) printf("%d %ld %ld,", color, x, y);

        }

    }
    printf("\n");
#endif

}
#pragma GCC diagnostic pop

void hblock_insert(uint8_t color, uint32_t x_offset, hblock* the_hblock, int64_t* y_index_out, int64_t* y_offset_out) {

    uint64_t y_index;
    uint64_t y_offset;
    assert(the_hblock != NULL);
    assert(0 <= x_offset && x_offset < HBLOCK_SIZE);
    assert(color < EMPTY);

    if (the_hblock->vblock_tower == NULL) {

        the_hblock->vblock_tower = safe_malloc(sizeof(vblock));
        the_hblock->tower_size = 1;
        vblock_init(&(the_hblock->vblock_tower[0]));

        y_index = 0;
        y_offset = 0;
        goto insert;

    }

    if ((the_hblock->vblock_tower[the_hblock->tower_size - 1]).data[x_offset][VBLOCK_SIZE - 1] != EMPTY) {

        the_hblock->vblock_tower = safe_realloc(the_hblock->vblock_tower, 2 * the_hblock->tower_size * sizeof(vblock));
        the_hblock->tower_size = 2 * the_hblock->tower_size;
        for (int i = the_hblock->tower_size / 2; i < the_hblock->tower_size; i++) vblock_init(&(the_hblock->vblock_tower[i]));

        y_index = the_hblock->tower_size / 2;
        y_offset = 0;
        goto insert;

    }

    int64_t height = the_hblock->heights[x_offset] + 1;
    y_index = height / VBLOCK_SIZE;
    y_offset = height % VBLOCK_SIZE;

insert:
    the_hblock->vblock_tower[y_index].data[x_offset][y_offset] = color;
    the_hblock->heights[x_offset] += 1;
    *y_index_out = y_index;
    *y_offset_out = y_offset;
    grid_pyformat(grid_global);

}

void grid_insert(grid* the_grid, uint8_t color, int32_t x, int64_t* y_index, int64_t* y_offset) {

    uint32_t hblock_index, hblock_offset;
    x_to_subindexed_coords(x, &hblock_index, &hblock_offset);

    if (0 <= x) {

        if (hblock_index >= the_grid->positive_size) {

            // positive erweitern
            uint32_t new_size = 1 << (msb_index(hblock_index) + 1);
            the_grid->positive = safe_realloc(the_grid->positive, new_size * sizeof(hblock));

            for (int i = the_grid->positive_size; i < new_size; i++) hblock_init(&(the_grid->positive[i])); 

            the_grid->positive_size = new_size;

        }

        hblock_insert(color, hblock_offset, &the_grid->positive[hblock_index], y_index, y_offset);

    } else {

        if (hblock_index >= the_grid->negative_size) {

            // negative erweitern
            uint32_t new_size = 1 << (msb_index(hblock_index) + 1);
            the_grid->negative = safe_realloc(the_grid->negative, new_size * sizeof(hblock));

            for (int i = the_grid->negative_size; i < new_size; i++) hblock_init(&the_grid->negative[i]);

            the_grid->negative_size = new_size;

        }

        hblock_insert(color, hblock_offset, &the_grid->negative[hblock_index], y_index, y_offset);

    }

    assert(grid_read_at(the_grid, x, (*y_index) * VBLOCK_SIZE + (*y_offset)) == color);

}

/*typedef struct removal_info_ {

    int32_t x;
    uint64_t y_index, y_offset;

    uint8_t prev_color;

} removal_info;

void removal_info_pprint(removal_info* info) {

    log("Removal info struct:\n  x = %d,\n  y_index = %d,\n  y_offset = %d,\n  prev_color = %d", info->x, info->y_index, info->y_offset, info->prev_color);

}*/

typedef struct gravity_info_ {

    int32_t x;
    int64_t y;

} gravity_info;

void grid_reduce_directional_horizontal(grid* the_grid, queue* removal_queue, int32_t x_min, int32_t x_max, int64_t y_min, int64_t y_max) {

    for (int32_t current_x = x_min; current_x <= x_max + 3; current_x += 3) {

        //uint32_t hblock_index, hblock_offset;
        //x_to_subindexed_coords(current_x, &hblock_index, &hblock_offset);
        //hblock* current_hblock;
        //grid_get_hblock(the_grid, current_x, &current_hblock);
        //if (current_hblock == NULL) return;
        //int64_t height = current_hblock->heights[hblock_offset];
        //log("height in d1: %d (x = %d)", height, current_x);

        //for (int64_t current_y = y_min; current_y <= (y_max > height ? y_max : height); current_y++) {
        for (int64_t current_y = y_min; current_y <= y_max; current_y++) {

            uint8_t color = grid_read_at(the_grid, current_x, current_y);

            if (color == EMPTY) break;

            uint8_t hfirst, hlast;
            hfirst = hlast = 0;

            // horizontal

            if (grid_read_at(the_grid, current_x + 1, current_y) == color) {
                hfirst += 1;
                if (grid_read_at(the_grid, current_x + 2, current_y) == color) {
                    hfirst += 1;
                    if (grid_read_at(the_grid, current_x + 3, current_y) == color) hfirst += 1;
                }
            }

            if (grid_read_at(the_grid, current_x - 1, current_y) == color) {
                hlast += 1;
                if (grid_read_at(the_grid, current_x - 2, current_y) == color) {
                    hlast += 1;
                    if (grid_read_at(the_grid, current_x - 3, current_y) == color) hlast += 1;
                }
            }

            if (hlast + hfirst >= 3) {

                for (int32_t i = current_x - hlast; i <= current_x + hfirst; i++) {

                    gravity_info info;
                    info.x = i;
                    info.y = current_y;

                    queue_putl(removal_queue, &info);

                }

            }

        }

    }

}

void grid_reduce_directional_diagonal_1(grid* the_grid, queue* removal_queue, int32_t x_min, int32_t x_max, int64_t y_min, int64_t y_max) {

    for (int32_t current_x = x_min; current_x <= x_max; current_x++) {

        //uint32_t hblock_index, hblock_offset;
        //x_to_subindexed_coords(current_x, &hblock_index, &hblock_offset);
        //hblock* current_hblock;
        //grid_get_hblock(the_grid, current_x, &current_hblock);
        //if (current_hblock == NULL) return;
        //int64_t height = current_hblock->heights[hblock_offset];
        //log("height in d1: %d (x = %d)", height, current_x);

        //for (int64_t current_y = y_min; current_y <= (y_max > height ? y_max : height); current_y++) {
        for (int64_t current_y = y_min; current_y <= y_max; current_y++) {

            uint8_t color = grid_read_at(the_grid, current_x, current_y);

            // if (color == EMPTY) continue;
            if (color == EMPTY) break;

            uint8_t d1first, d1last;
            d1first = d1last = 0;

            if (grid_read_at(the_grid, current_x + 1, current_y + 1) == color) {
                d1first += 1;
                if (grid_read_at(the_grid, current_x + 2, current_y + 2) == color) {
                    d1first += 1;
                    if (grid_read_at(the_grid, current_x + 3, current_y + 3) == color) d1first += 1;
                }
            }

            if (grid_read_at(the_grid, current_x - 1, current_y - 1) == color) {
                d1last += 1;
                if (grid_read_at(the_grid, current_x - 2, current_y - 2) == color) {
                    d1last += 1;
                    if (grid_read_at(the_grid, current_x - 3, current_y - 3) == color) d1last += 1;
                }
            }

            if (d1last + d1first >= 3) {

                for (int32_t i = -d1last; i <= d1first; i++) {

                    gravity_info info;
                    info.x = current_x + i;
                    info.y = current_y + i;

                    queue_putl(removal_queue, &info);

                }

            }

        }

    }

}

void grid_reduce_directional_vertical(grid* the_grid, queue* removal_queue, int32_t x_min, int32_t x_max, int64_t y_min, int64_t y_max) {

    for (int32_t current_x = x_min; current_x <= x_max; current_x++) {

        for (int64_t current_y = y_min; current_y <= y_max + 3; current_y += 3) {

            uint8_t color = grid_read_at(the_grid, current_x, current_y);

            // if (color == EMPTY) continue;
            if (color == EMPTY) break;

            uint8_t vfirst, vlast;
            vfirst = vlast = 0;

            // vertical

            if (grid_read_at(the_grid, current_x, current_y + 1) == color) {
                vfirst += 1;
                if (grid_read_at(the_grid, current_x, current_y + 2) == color) {
                    vfirst += 1;
                    if (grid_read_at(the_grid, current_x, current_y + 3) == color) vfirst += 1;
                }
            }

            if (grid_read_at(the_grid, current_x, current_y - 1) == color) {
                vlast += 1;
                if (grid_read_at(the_grid, current_x, current_y - 2) == color) {
                    vlast += 1;
                    if (grid_read_at(the_grid, current_x, current_y - 3) == color) vlast += 1;
                }
            }

            if (vlast + vfirst >= 3) {
                
                for (int32_t i = -vlast; i <= vfirst; i++) {

                    gravity_info info;
                    info.x = current_x;
                    info.y = current_y + i;

                    queue_putl(removal_queue, &info);

                }

            }

        }

    }
    
}

void grid_reduce_directional_diagonal_2(grid* the_grid, queue* removal_queue, int32_t x_min, int32_t x_max, int64_t y_min, int64_t y_max) {

    for (int32_t current_x = x_min; current_x <= x_max; current_x++) {

        for (int64_t current_y = y_min; current_y <= y_max; current_y++) {

            uint8_t color = grid_read_at(the_grid, current_x, current_y);

            // if (color == EMPTY) continue;
            if (color == EMPTY) break;

            uint8_t d2first, d2last;
            d2first = d2last = 0;

            if (grid_read_at(the_grid, current_x - 1, current_y + 1) == color) {
                d2first += 1;
                if (grid_read_at(the_grid, current_x - 2, current_y + 2) == color) {
                    d2first += 1;
                    if (grid_read_at(the_grid, current_x - 3, current_y + 3) == color) d2first += 1;
                }
            }

            if (grid_read_at(the_grid, current_x + 1, current_y - 1) == color) {
                d2last += 1;
                if (grid_read_at(the_grid, current_x + 2, current_y - 2) == color) {
                    d2last += 1;
                    if (grid_read_at(the_grid, current_x + 3, current_y - 3) == color) d2last += 1;
                }
            }

            if (d2last + d2first >= 3) {

                for (int32_t i = -d2last; i <= d2first; i++) {

                    gravity_info info;
                    info.x = current_x - i;
                    info.y = current_y + i;

                    queue_putl(removal_queue, &info);

                }

            }

        }

    }
    
}

void grid_reduce_unified(grid* the_grid, queue* removal_queue, queue* gravity_queue, int32_t x_min, int32_t x_max, int64_t y_min, int64_t y_max) {

    while (true) {

        assert(x_min <= x_max);
        assert(y_min <= y_max);

        grid_reduce_directional_horizontal(the_grid, removal_queue, x_min, x_max, y_min, y_max);
        grid_reduce_directional_diagonal_1(the_grid, removal_queue, x_min, x_max, y_min, y_max);
        grid_reduce_directional_vertical  (the_grid, removal_queue, x_min, x_max, y_min, y_max);
        grid_reduce_directional_diagonal_2(the_grid, removal_queue, x_min, x_max, y_min, y_max);

        /*
        for (int32_t x = x_min; x <= x_max + HBLOCK_SIZE; x += HBLOCK_SIZE) {

            hblock* the_hblock = NULL;
            grid_get_hblock(the_grid, x, &the_hblock);
            if (the_hblock == NULL) continue;
            hblock_resize(the_hblock);

        }
        */
        
        if (removal_queue->size == 0) return;

        x_min = MAX_X;
        x_max = MIN_X;
        y_min = INT64_MAX;
        y_max = 0;

        queue_node* current_node = removal_queue->head;

        while (current_node != NULL) {

            gravity_info* info = (gravity_info*) &(current_node->data);
            int32_t x = info->x;
            x_min = (x < x_min ? x : x_min);
            x_max = (x > x_max ? x : x_max);

            gravity_info grav_info;
            grav_info.x = x;
            grav_info.y = info->y;
            queue_putl(gravity_queue, &grav_info);

            queue_node* to_compare = current_node->next;

            while (to_compare != NULL) {

                gravity_info* other_info = (gravity_info*) &(to_compare->data);
                queue_node* next = to_compare->next;
                if (other_info->x == x) {

                    grav_info.y = other_info->y;
                    queue_putl(gravity_queue, &grav_info);
                    queue_rem_node(removal_queue, to_compare);

                }

                to_compare = next;

            }

            uint64_t y_arr[gravity_queue->size];
            uint64_t y_arr_size = 0;
            assert(gravity_queue->size > 0);

            while (gravity_queue->size > 0) {

                queue_node* sort_current = gravity_queue->head;
                uint64_t sort_min = UINT64_MAX;
                queue_node* sort_node_min = NULL;

                while (sort_current != NULL) {

                    queue_node* sort_next = sort_current->next;
                    uint64_t sort_current_y = ((gravity_info*) (sort_current->data))->y;
                    if (sort_current_y < sort_min) {

                        sort_min = sort_current_y;
                        sort_node_min = sort_current;

                    }
                    sort_current = sort_next;

                }

                assert(sort_min != INT64_MAX);
                queue_rem_node(gravity_queue, sort_node_min);
                if (y_arr_size == 0 || y_arr[y_arr_size - 1] != sort_min) {

                    y_arr[y_arr_size++] = sort_min;

                }

            }

            hblock* current_hblock = NULL;
            uint32_t hblock_index, hblock_offset;
            x_to_subindexed_coords(x, &hblock_index, &hblock_offset);
            grid_get_hblock(the_grid, x, &current_hblock);
            int64_t height = (current_hblock->heights)[hblock_offset];

            uint64_t y_min_column = y_arr[0];
            uint64_t y_max_column = height > y_arr[y_arr_size - 1] ? height : y_arr[y_arr_size - 1];

            log("grav: x = %d, y_min_column = %d, y_max_column = %d, y_arr_size = %d, y_arr[-1] = %d, height = %d", x, y_min_column, y_max_column, y_arr_size, y_arr[y_arr_size - 1], height);

            if (y_min > y_min_column) y_min = y_min_column;
            if (y_max < y_max_column) y_max = y_max_column;

            for (uint64_t i = 0; i < y_arr_size; i++) {

                uint64_t start_y = y_arr[i] + 1;
                uint64_t end_y = (i == y_arr_size - 1 ? height + y_arr_size : y_arr[i + 1] - 1);

                for (uint64_t j = start_y; j <= end_y; j++) {

                    uint64_t new_y_index = (j - i - 1) / VBLOCK_SIZE;
                    uint64_t new_y_offset = (j - i - 1) % VBLOCK_SIZE;
                    uint64_t old_y_index = j / VBLOCK_SIZE;
                    uint64_t old_y_offset = j % VBLOCK_SIZE;
                    uint8_t color = 255;

                    if (old_y_index < current_hblock->tower_size) {

                        color = current_hblock->vblock_tower[old_y_index].data[hblock_offset][old_y_offset];

                    }

                    //log("at %d %d (%d), moving %d to %d %d (%d), i = %d", x, j, old_y_index * VBLOCK_SIZE + old_y_offset, color, x, j - i - 1, new_y_index * VBLOCK_SIZE + new_y_offset, i);
                    current_hblock->vblock_tower[new_y_index].data[hblock_offset][new_y_offset] = color;

                }

                /*memmove(start_y - i - 1, start_y, VBLOCK_SIZE - start_y);

                  while (...) {

                  memmove(...);

                  }

                  memmove(0, i + 1, end_y % VBLOCK_SIZE);*/

            }

            current_hblock->heights[hblock_offset] -= y_arr_size;

            queue_node* next = current_node->next;
            if (current_node != NULL) queue_rem_node(removal_queue, current_node);
            current_node = next;
            grid_pprint(the_grid);

        }

        grid_pyformat(the_grid);

    }

}

void init_globals(void) {

    grid_global = grid_init();
    removal_queue_global = queue_init(sizeof(gravity_info));
    gravity_queue_global = queue_init(sizeof(gravity_info));

}

void uninit_globals(void) {

    grid_uninit(grid_global);
    queue_uninit(removal_queue_global);
    queue_uninit(gravity_queue_global);

}

bool read_input_line(uint8_t* color, int32_t* x) {

    // 12 chars are sufficient since log10(2^32) rounds up to 10, 2 more chars for sign and zero terminator
    char color_buffer[12], x_buffer[12];
    int color_buffer_index = 0, x_buffer_index = -1;
    bool space_found = false;

    int read_raw;

    memset(color_buffer, 0, sizeof(color_buffer));
    memset(x_buffer, 0, sizeof(color_buffer));

    while ((read_raw = getc(stdin)) != EOF && read_raw != '\n') {

        char c = (char) read_raw;
        if (!(32 <= c && c <= 57)) die("Ungültige Eingabe (Ungültiges Zeichen)");
        if (c == ' ') {

            if (color_buffer_index <= 0) die("Ungültige Eingabe (Parsing fehlgeschlagen)");
            if (x_buffer_index >= 0) die("Ungültige Eingabe (Parsing fehlgeschlagen)");
            
            x_buffer_index = 0;
            space_found = true;
            continue;

        }

        if (!space_found) {

            if (color_buffer_index >= 11) die("Ungültige Eingabe (Farbe zu groß falls valide Zahl)");

            color_buffer[color_buffer_index++] = c;

        } else {

            if (x_buffer_index >= 11) die("Ungültige Eingabe (x-Koordinate zu groß falls valide Zahl)");

            x_buffer[x_buffer_index++] = c;

        }

    }

    if (color_buffer_index == 0 && !space_found && read_raw == EOF) {

        grid_output(grid_global);
        exit(0);

    }

    char* endptr;
    long int read_color = strtol(color_buffer, &endptr, 10);
    if (read_color == 0 && (errno != 0 || endptr == color_buffer)) die("Ungültige Eingabe (Farbe konnte nicht korrekt gelesen werden)");
    long int read_x = strtol(x_buffer, &endptr, 10);
    if (read_x == 0 && (errno != 0 || endptr == x_buffer)) die("Ungültige Eingabe (x-Koordinate konnte nicht korrekt gelesen werden)");

    if (!(0 <= read_color && read_color < 256)) die("Ungültige Eingabe (Farbe nicht im gültigen Bereich)");
    if (!(MIN_X <= read_x && read_x <= MAX_X)) die("Ungültige Eingabe (x-Koordinate nicht im gültigen Bereich)");

    *color = read_color;
    *x = read_x;

    return read_raw == EOF;

}

int main() {

    atexit(uninit_globals);
    init_globals();

#ifndef NDEBUG
    uint64_t counter = 0;
#endif

    bool eof = false;
    while (!eof) {

        uint8_t color;
        int32_t x;
        int64_t y_index, y_offset;
        eof = read_input_line(&color, &x);

        log("begin insert #%d with color = %d, x = %d", counter, color, x);
        grid_insert(grid_global, color, x, &y_index, &y_offset);
        log("end insert #%d", counter++);

        grid_reduce_unified(grid_global, removal_queue_global, gravity_queue_global, x, x, y_index * VBLOCK_SIZE + y_offset, y_index * VBLOCK_SIZE + y_offset);

        grid_pprint(grid_global);

    }

    grid_output(grid_global);

    return 0;

}
