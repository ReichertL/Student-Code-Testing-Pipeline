#include <assert.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define safe_malloc(size) ( safe_malloc_( (size) , __LINE__) )
#define safe_calloc(nmemb, size) ( safe_calloc_( (nmemb), (size) ,  __LINE__) )
#define safe_realloc(ptr, size) ( safe_realloc_( (ptr), (size), __LINE__) )

#define log(...)  (log_ (__LINE__, __VA_ARGS__))
#define warn(...) (warn_(__LINE__, __VA_ARGS__))
#define die(...)  (die_ (__LINE__, __VA_ARGS__))

#define bitsizeof(x) (sizeof( ( x ) ) * 8)

void log_(int line, char* fmt, ...) {

#ifndef OUTPUT_ONLY
#ifndef NDEBUG
    va_list varargs;
    va_start(varargs, fmt);
    
    char msg[500];
    vsnprintf(msg, sizeof(msg), fmt, varargs);
    printf("[Info in Z. %4d]: %s\n", line, msg);

    va_end(varargs);
#endif
#endif

}

void warn_(int line, char *fmt, ...) {

#ifndef NDEBUG
    va_list varargs;
    va_start(varargs, fmt);
    
    char msg[500];
    vsnprintf(msg, sizeof(msg), fmt, varargs);
#ifndef OUTPUT_ONLY
    printf("[Warnung in Z. %4d]: %s\n", line, msg);
#endif
    fprintf(stderr, "[Warnung in Z. %4d]: %s\n", line, msg);

    va_end(varargs);
#endif

}

void die_(int line, char *fmt, ...) {

    va_list varargs;
    va_start(varargs, fmt);
    
    char msg[500];
    vsnprintf(msg, sizeof(msg), fmt, varargs);
    fprintf(stderr, "[Fehler in Z. %4d]: %s\n", line, msg);

    va_end(varargs);

    exit(1);

}

void* safe_malloc_(size_t size, int line) {

    void* ptr = malloc(size);
    if (ptr == NULL) {

        char str[200];
        snprintf(str, 200, "malloc (%ld byte) fehlgeschlagen in Zeile %d, breche ab.", size, line);
        die(str);
        return NULL;

    }
    return ptr;

}

void* safe_calloc_(size_t nmemb, size_t size, int line) {

    void* ptr = calloc(nmemb, size);
    if (ptr == NULL) {

        char str[200];
        snprintf(str, 200, "calloc (%ld member zu je %ld byte) fehlgeschlagen in Zeile %d, breche ab.", nmemb, size, line);
        die(str);
        return NULL;

    }
    return ptr;

}

void* safe_realloc_(void *ptr, size_t size, int line) {

    void* new_ptr = realloc(ptr, size);
    if (new_ptr == NULL) {

        char str[200];
        snprintf(str, 200, "realloc (%ld byte) fehlgeschlagen in Zeile %d, breche ab.", size, line);
        die(str);

    }
    return new_ptr;

}

// make sure not to use these
#pragma GCC poison malloc calloc realloc

void bits_to_str(uint16_t x, char* out) {

    for (int i = 0; i < bitsizeof(x); i++) {

        out[bitsizeof(x) - 1 - i] = !!(x & (1 << i)) + '0';

    }
    out[bitsizeof(x)] = '\0';

}

int msb_index(uint32_t x) {

    for (int i = bitsizeof(x) - 1; i >= 0; i--) {

        if (x & (((uint32_t) 1) << i)) return i;

    }

    assert(x == 0);
    return -1;

}


#define MIN_X ((int32_t) -1024 * 1024)
#define MAX_X ((int32_t)  1024 * 1024)

typedef struct queue_node_ {

    struct queue_node_* prev;
    struct queue_node_* next;

    uint8_t data[];

} queue_node;

typedef struct queue_ {

    queue_node* head;
    queue_node* last;

    size_t elem_size;
    uint64_t size;
    
} queue;

queue* queue_init(size_t elem_size) {

    queue* the_queue = safe_malloc(sizeof(queue));
    the_queue->head = NULL;
    the_queue->last = NULL;
    the_queue->elem_size = elem_size;
    the_queue->size = 0;

    return the_queue;

}

void queue_putl(queue* the_queue, void* data) {

    queue_node* node = safe_malloc(sizeof(queue_node) + the_queue->elem_size);
    node->prev = NULL;
    node->next = the_queue->head;
    memcpy(&(node->data), data, the_queue->elem_size);

    if (the_queue->head == NULL) {

        assert(the_queue->size == 0);

        the_queue->head = node;
        the_queue->last = node;
        the_queue->size = 1;

    } else {

        assert(the_queue->size != 0);

        the_queue->head->prev = node;
        the_queue->head = node;
        the_queue->size += 1;

    }

}

void queue_putr(queue* the_queue, void* data) {

    queue_node* node = safe_malloc(sizeof(queue_node) + the_queue->elem_size);
    node->prev = the_queue->last;
    node->next = NULL;
    memcpy(&(node->data), data, the_queue->elem_size);

    if (the_queue->last == NULL) {

        assert(the_queue->size == 0);

        the_queue->head = node;
        the_queue->last = node;
        the_queue->size = 1;

    } else {

        assert(the_queue->size != 0);

        the_queue->last->next = node;
        the_queue->last = node;
        the_queue->size += 1;

    }

}

void queue_reml(queue* the_queue, void* data) {

    assert(the_queue->size > 0);
    queue_node* to_remove = the_queue->head;
    queue_node* new_head = to_remove->next;
    if (data != NULL) memcpy(data, &(to_remove->data), the_queue->elem_size);

    if (new_head == NULL) {

        the_queue->last = NULL;

    } else {

        new_head->prev = NULL;

    }

    free(to_remove);
    the_queue->size -= 1;

}

void queue_remr(queue* the_queue, void* data) {

    assert(the_queue->size > 0);
    queue_node* to_remove = the_queue->last;
    queue_node* new_last = to_remove->prev;
    if (data != NULL) memcpy(data, &(to_remove->data), the_queue->elem_size);

    if (new_last == NULL) {

        the_queue->head = NULL;

    } else {

        new_last->next = NULL;

    }

    free(to_remove);
    the_queue->size -= 1;

}

void queue_rem_node(queue* the_queue, queue_node* the_node, void* data) {

    assert(the_node != NULL);
    assert(the_queue->size > 0);

    assert(the_node->next == NULL || the_node->next->prev == the_node);
    assert(the_node->prev == NULL || the_node->prev->next == the_node);

    if (the_node->prev != NULL) {
        
        the_node->prev->next = the_node->next;

    } else {
        
        assert(the_queue->head == the_node);
        the_queue->head = the_node->next;

    }

    if (the_node->next != NULL) {
        
        the_node->next->prev = the_node->prev;

    } else {

        assert(the_queue->last == the_node);
        the_queue->last = the_node->prev;

    }

    if (data != NULL) memcpy(data, &(the_node->data), the_queue->elem_size);
    free(the_node);
    the_queue->size -= 1;

}

void queue_uninit(queue* the_queue) {

    queue_node* current_node = the_queue->head;

    while (current_node != NULL) {

        queue_node* next_node = current_node->next;
        free(current_node);
        current_node = next_node;

    }

    free(the_queue);

}

void queue_dedup(queue* the_queue) {

    queue_node* current = the_queue->head;

    while (current != NULL) {
        
        queue_node* to_compare = current->next;

        while (to_compare != NULL) {

            if (memcmp(&(current->data), &(to_compare->data), the_queue->elem_size) == 0) {

                queue_node* next = to_compare->next;
                queue_rem_node(the_queue, to_compare, NULL);
                to_compare = next;

            } else {

                to_compare = to_compare->next;

            }

        }

        current = current->next;

    }

}

// malloc max small bin payload size = 504 - word = 496 byte

#define HBLOCK_SIZE ((int32_t) 16)
#define VBLOCK_SIZE ((int32_t) 32)
#define EMPTY ((uint8_t) 255)

typedef struct vblock_ {

    uint8_t data[HBLOCK_SIZE][VBLOCK_SIZE];
    //uint16_t clear_map; // 0 bit == column clear, 1 bit == column contains elements

} vblock;

typedef struct hblock_ {

    vblock* vblock_tower;
    uint32_t tower_size;
    int64_t heights[HBLOCK_SIZE];

} hblock;

typedef struct grid_ {

    hblock* positive;
    uint32_t positive_size;

    hblock* negative;
    uint32_t negative_size;

    uint32_t offset_x;

} grid;

void x_to_subindexed_coords(int32_t x, uint32_t* x_index, uint32_t* x_offset) {

    *x_index = abs(x / HBLOCK_SIZE);

#ifndef NDEBUG
    int32_t x_offset0 = (x >= 0 ? x : (-x - 1)) % HBLOCK_SIZE;
    int32_t x_offset1 = (x >= 0 ? x : ~x) % HBLOCK_SIZE;
#endif

    *x_offset = (x ^ (x >> (bitsizeof(x) - 1))) % HBLOCK_SIZE;
#ifndef NDEBUG
    assert(x_offset0 == *x_offset);
    assert(x_offset1 == *x_offset);
#endif

}

void vblock_init(vblock* the_vblock) {

    memset(&(the_vblock->data), EMPTY, VBLOCK_SIZE * HBLOCK_SIZE);
    //the_vblock->clear_map = 0;

}

void hblock_init(hblock* the_hblock) {

    the_hblock->vblock_tower = NULL;
    the_hblock->tower_size = 0;
    for (int i = 0; i < HBLOCK_SIZE; i++) the_hblock->heights[i] = -1;

}

grid* grid_init(void) {

    grid *the_grid = safe_malloc(sizeof(grid));

    the_grid->offset_x = 0;

    the_grid->positive = NULL;
    the_grid->positive_size = 0;

    the_grid->negative = NULL;
    the_grid->negative_size = 0;

    return the_grid;

}

void hblock_uninit(hblock* the_hblock) {

    free(the_hblock->vblock_tower);

}

void grid_uninit(grid* the_grid) {

    for (int i = 0; i < the_grid->positive_size; i++) hblock_uninit(&the_grid->positive[i]);
    for (int i = 0; i < the_grid->negative_size; i++) hblock_uninit(&the_grid->negative[i]);
    free(the_grid->positive);
    free(the_grid->negative);
    free(the_grid);

}

//__attribute__((noinline))
//extern uint8_t grid_read_at_safe(grid* the_grid, int64_t x, int64_t y) {
//
//    if (y < 0) return EMPTY;
//
//    uint32_t hblock_index, hblock_offset;
//    x_to_subindexed_coords(x, &hblock_index, &hblock_offset);
//
//    hblock* arr;
//    uint32_t arr_size;
//
//    if (x >= 0) {
//
//        arr = the_grid->positive;
//        arr_size = the_grid->positive_size;
//
//    } else {
//
//        arr = the_grid->negative;
//        arr_size = the_grid->negative_size;
//
//    }
//
//    if (hblock_index >= arr_size) return EMPTY;
//    hblock the_hblock = arr[hblock_index];
//    
//    if (y / VBLOCK_SIZE >= the_hblock.tower_size) return EMPTY;
//    return the_hblock.vblock_tower[y / VBLOCK_SIZE].data[hblock_offset][y % VBLOCK_SIZE];
//
//}

void grid_get_hblock(grid* the_grid, int64_t x, hblock** the_hblock) {

    uint32_t hblock_index, hblock_offset;
    x_to_subindexed_coords(x, &hblock_index, &hblock_offset);

    char* arr_base = (char*) &(the_grid->positive);
    ptrdiff_t arr_diff = offsetof(grid, negative) - offsetof(grid, positive);
    hblock* arr = *((hblock**) (arr_base + (-(x < 0) & arr_diff)));

#ifndef NDEBUG
    uint32_t arr_size0;
    if (x < 0) arr_size0 = the_grid->negative_size;
    else       arr_size0 = the_grid->positive_size;
#endif
    
    char* size_base = (char*) &(the_grid->positive_size);
    ptrdiff_t size_diff = offsetof(grid, negative_size) - offsetof(grid, positive_size);
    uint32_t arr_size = *((uint32_t*) (size_base + (-(x < 0) & size_diff)));

    assert(arr_size == arr_size0);

    if (hblock_index >= arr_size) *the_hblock = NULL;
    else *the_hblock = &(arr[hblock_index]);

}

/*__attribute__((noinline))
extern */ uint8_t grid_read_at(grid* the_grid, int64_t x, int64_t y) {

    if (y < 0) return EMPTY;

    uint32_t hblock_index, hblock_offset;
    x_to_subindexed_coords(x, &hblock_index, &hblock_offset);

    char* arr_base = (char*) &(the_grid->positive);
    ptrdiff_t arr_diff = offsetof(grid, negative) - offsetof(grid, positive);
    hblock* arr = *((hblock**) (arr_base + (-(x < 0) & arr_diff)));

#ifndef NDEBUG
    uint32_t arr_size0;
    if (x < 0) arr_size0 = the_grid->negative_size;
    else       arr_size0 = the_grid->positive_size;
#endif
    
    char* size_base = (char*) &(the_grid->positive_size);
    ptrdiff_t size_diff = offsetof(grid, negative_size) - offsetof(grid, positive_size);
    uint32_t arr_size = *((uint32_t*) (size_base + (-(x < 0) & size_diff)));

#ifndef NDEBUG
    if (arr_size != arr_size0) warn("arr_size != arr_size0: x = %d", x);
    assert(arr_size == arr_size0);
#endif

    if (hblock_index >= arr_size) return EMPTY;
    hblock the_hblock = arr[hblock_index];
    if (y > the_hblock.heights[hblock_offset]) return EMPTY;
    
    if (y / VBLOCK_SIZE >= the_hblock.tower_size) return EMPTY;
    return the_hblock.vblock_tower[y / VBLOCK_SIZE].data[hblock_offset][y % VBLOCK_SIZE];

}

void grid_set_at(grid* the_grid, int64_t x, int64_t y, uint8_t color) {

    if (y < 0) return;

    uint32_t hblock_index, hblock_offset;
    x_to_subindexed_coords(x, &hblock_index, &hblock_offset);

    char* arr_base = (char*) &(the_grid->positive);
    ptrdiff_t arr_diff = offsetof(grid, negative) - offsetof(grid, positive);
    hblock* arr = *((hblock**) (arr_base + (-(x < 0) & arr_diff)));

#ifndef NDEBUG
    uint32_t arr_size0;
    if (x < 0) arr_size0 = the_grid->negative_size;
    else       arr_size0 = the_grid->positive_size;
#endif
    
    char* size_base = (char*) &(the_grid->positive_size);
    ptrdiff_t size_diff = offsetof(grid, negative_size) - offsetof(grid, positive_size);
    uint32_t arr_size = *((uint32_t*) (size_base + (-(x < 0) & size_diff)));

    assert(arr_size == arr_size0);

    if (hblock_index >= arr_size) return;
    hblock the_hblock = arr[hblock_index];
    
    if (y / VBLOCK_SIZE >= the_hblock.tower_size) return;
    vblock* the_vblock = &(the_hblock.vblock_tower[y / VBLOCK_SIZE]);
    the_vblock->data[hblock_offset][y % VBLOCK_SIZE] = color;
    //the_vblock->clear_map |= (1 << hblock_offset);

    if (color == EMPTY) {

        if (the_hblock.heights[hblock_offset] == y) the_hblock.heights[hblock_offset] = y - 1;

    } else {
        
        if (the_hblock.heights[hblock_offset] < y) the_hblock.heights[hblock_offset] = y;
        
    }

}

void grid_pprint(grid* the_grid) {

#ifdef OUTPUT_ONLY
    return;
#endif

    printf("\n\n\n");

    for (int x = 0; x < the_grid->negative_size; x++) {

        hblock the_hblock = the_grid->negative[x];

        if (the_hblock.tower_size == 0) {

            printf("SPARSE\n");

        } else {

            for (int x_offset = HBLOCK_SIZE - 1; x_offset >= 0; x_offset--) {

                for (int y = 0; y < the_hblock.tower_size; y++) {

                    vblock the_vblock = the_hblock.vblock_tower[y];

                    for (int y_offset = 0; y_offset < VBLOCK_SIZE; y_offset++) {

                        if (the_vblock.data[x_offset][y_offset] == EMPTY) printf("    ");
                        else printf("%4u", the_vblock.data[x_offset][y_offset]);

                    }

                    printf(" |||");

                }

                printf("\n");

            }

        }

        for (int y = 0; y < the_hblock.tower_size * VBLOCK_SIZE + 1; y++) {

            printf("====");

        }

        printf("\n");

    }

    for (int x = 0; x < the_grid->positive_size; x++) {

        hblock the_hblock = the_grid->positive[x];

        if (the_hblock.tower_size == 0) {

            printf("SPARSE\n");

        } else {

            for (int x_offset = 0; x_offset < HBLOCK_SIZE; x_offset++) {

                for (int y = 0; y < the_hblock.tower_size; y++) {

                    vblock the_vblock = the_hblock.vblock_tower[y];

                    for (int y_offset = 0; y_offset < VBLOCK_SIZE; y_offset++) {

                        if (the_vblock.data[x_offset][y_offset] == EMPTY) printf("    ");
                        else printf("%4u", the_vblock.data[x_offset][y_offset]);

                    }

                    printf(" |||");

                }

                printf("\n");

            }

        }

        for (int y = 0; y < the_hblock.tower_size * VBLOCK_SIZE + 1; y++) {

            printf("====");

        }

        printf("\n");

    }

    printf("\n\n\n");

}

void hblock_insert(uint8_t color, uint32_t x_offset, hblock* the_hblock, int64_t* y_index_out, int64_t* y_offset_out) {

    uint64_t y_index;
    uint64_t y_offset;
    assert(0 <= x_offset && x_offset < HBLOCK_SIZE);
    assert(color < EMPTY);

    if (the_hblock->vblock_tower == NULL) {

        the_hblock->vblock_tower = safe_malloc(sizeof(vblock));
        the_hblock->tower_size = 1;
        vblock_init(&(the_hblock->vblock_tower[0]));

        y_index = 0;
        y_offset = 0;
        goto insert;

    }

    if ((the_hblock->vblock_tower[the_hblock->tower_size - 1]).data[x_offset][VBLOCK_SIZE - 1] != EMPTY) {

        the_hblock->vblock_tower = safe_realloc(the_hblock->vblock_tower, 2 * the_hblock->tower_size * sizeof(vblock));
        the_hblock->tower_size = 2 * the_hblock->tower_size;
        for (int i = the_hblock->tower_size / 2; i < the_hblock->tower_size; i++) vblock_init(&(the_hblock->vblock_tower[i]));

        y_index = the_hblock->tower_size / 2;
        y_offset = 0;
        goto insert;

    }

    for (int i = the_hblock->tower_size - 1; i >= 0; i--) {

        vblock the_vblock = the_hblock->vblock_tower[i];

        //char mask_str[17], map_str[17];
        //bits_to_str((the_vblock.clear_map), map_str);
        //bits_to_str((1 << x_offset), mask_str);
        //log("clear_map = %s, mask = %s", map_str, mask_str);
        // if in lowest vblock (i == 0 <=> !i), clear_map must be ignored
        //if (!(((the_vblock.clear_map) & (1 << x_offset)) || (!i))) {
        if ((the_vblock.data[x_offset][0] == EMPTY) && (i != 0)) {

            //log("Skipping in vblock %d", i);
            continue;

        }

        // Should go into this block or the one above

        if (the_vblock.data[x_offset][VBLOCK_SIZE - 1] != EMPTY) {

            // above

            y_index = i + 1;
            y_offset = 0;
            goto insert;

        }

        // definitely this block
        // 64-bit-vars?

        for (int j = VBLOCK_SIZE - 1; j >= 1; j--) {

            if ((the_vblock.data[x_offset][j - 1] != EMPTY) && (the_vblock.data[x_offset][j] == EMPTY)) {

                y_index = i;
                y_offset = j;
                goto insert;

            }

        }

        y_index = i;
        y_offset = 0;
        goto insert;

    }

    return;

insert:
    the_hblock->vblock_tower[y_index].data[x_offset][y_offset] = color;
    //the_hblock->vblock_tower[y_index].clear_map |= 1 << x_offset;
    the_hblock->heights[x_offset] += 1;
    *y_index_out = y_index;
    *y_offset_out = y_offset;

}

typedef struct removal_info_ {

    int32_t x;
    uint64_t y_index, y_offset;

    uint8_t prev_color;

} removal_info;

void removal_info_pprint(removal_info* info) {

    log("Removal info struct:\n  x = %d,\n  y_index = %d,\n  y_offset = %d,\n  prev_color = %d", info->x, info->y_index, info->y_offset, info->prev_color);

}

void grid_reduce_directional_horizontal(grid* the_grid, queue* removal_queue, int32_t x_min, int32_t x_max, int64_t y, int64_t y_range) {

    for (int64_t current_y = y; current_y <= y + y_range; current_y++) {

        for (int32_t current_x = x_min; current_x <= x_max; current_x++) {

            uint8_t color = grid_read_at(the_grid, current_x, current_y);

            if (color == EMPTY) continue;

            uint8_t hfirst, hlast;
            hfirst = hlast = 0;

            // horizontal

            if (grid_read_at(the_grid, current_x + 1, current_y) == color) {
                hfirst += 1;
                if (grid_read_at(the_grid, current_x + 2, current_y) == color) {
                    hfirst += 1;
                    if (grid_read_at(the_grid, current_x + 3, current_y) == color) hfirst += 1;
                }
            }

            if (grid_read_at(the_grid, current_x - 1, current_y) == color) {
                hlast += 1;
                if (grid_read_at(the_grid, current_x - 2, current_y) == color) {
                    hlast += 1;
                    if (grid_read_at(the_grid, current_x - 3, current_y) == color) hlast += 1;
                }
            }

            if (hlast + hfirst >= 3) {

                for (int32_t i = current_x - hlast; i <= current_x + hfirst; i++) {

                    removal_info info;
                    info.x = i;
                    info.y_index = current_y / VBLOCK_SIZE;
                    info.y_offset = current_y % VBLOCK_SIZE;
                    info.prev_color = color;

                    queue_putl(removal_queue, &info);

                }

            }

        }

    }

}

void grid_reduce_directional_diagonal_1(grid* the_grid, queue* removal_queue, int32_t x_min, int32_t x_max, int64_t y, int64_t y_range) {

    for (int32_t current_x = x_min; current_x <= x_max; current_x++) {

        for (int64_t current_y = y; current_y <= y + y_range; current_y++) {

            uint8_t color = grid_read_at(the_grid, current_x, current_y);

            if (color == EMPTY) continue;

            uint8_t d1first, d1last;
            d1first = d1last = 0;

            if (grid_read_at(the_grid, current_x + 1, current_y + 1) == color) {
                d1first += 1;
                if (grid_read_at(the_grid, current_x + 2, current_y + 2) == color) {
                    d1first += 1;
                    if (grid_read_at(the_grid, current_x + 3, current_y + 3) == color) d1first += 1;
                }
            }

            if (grid_read_at(the_grid, current_x - 1, current_y - 1) == color) {
                d1last += 1;
                if (grid_read_at(the_grid, current_x - 2, current_y - 2) == color) {
                    d1last += 1;
                    if (grid_read_at(the_grid, current_x - 3, current_y - 3) == color) d1last += 1;
                }
            }

            if (d1last + d1first >= 3) {

                for (int32_t i = -d1last; i <= d1first; i++) {

                    int64_t new_y = current_y + i;

                    removal_info info;
                    info.x = current_x + i;
                    info.y_index = new_y / VBLOCK_SIZE;
                    info.y_offset = new_y % VBLOCK_SIZE;
                    info.prev_color = color;

                    queue_putl(removal_queue, &info);

                }

            }

        }

    }

}

void grid_reduce_directional_vertical(grid* the_grid, queue* removal_queue, int32_t x_min, int32_t x_max, int64_t y, int64_t y_range) {

    for (int32_t current_x = x_min; current_x <= x_max; current_x++) {

        for (int64_t current_y = y; current_y <= y + y_range; current_y++) {

            uint8_t color = grid_read_at(the_grid, current_x, current_y);

            if (color == EMPTY) continue;

            uint8_t vfirst, vlast;
            vfirst = vlast = 0;

            // vertical

            if (grid_read_at(the_grid, current_x, current_y + 1) == color) {
                vfirst += 1;
                if (grid_read_at(the_grid, current_x, current_y + 2) == color) {
                    vfirst += 1;
                    if (grid_read_at(the_grid, current_x, current_y + 3) == color) vfirst += 1;
                }
            }

            if (grid_read_at(the_grid, current_x, current_y - 1) == color) {
                vlast += 1;
                if (grid_read_at(the_grid, current_x, current_y - 2) == color) {
                    vlast += 1;
                    if (grid_read_at(the_grid, current_x, current_y - 3) == color) vlast += 1;
                }
            }

            if (vlast + vfirst >= 3) {
                
                for (int32_t i = -vlast; i <= vfirst; i++) {

                    int64_t new_y = current_y + i;

                    removal_info info;
                    info.x = current_x;
                    info.y_index = new_y / VBLOCK_SIZE;
                    info.y_offset = new_y % VBLOCK_SIZE;
                    info.prev_color = color;

                    queue_putl(removal_queue, &info);

                }

            }

        }

    }
    
}

void grid_reduce_directional_diagonal_2(grid* the_grid, queue* removal_queue, int32_t x_min, int32_t x_max, int64_t y, int64_t y_range) {

    for (int32_t current_x = x_min; current_x <= x_max; current_x++) {

        for (int64_t current_y = y; current_y <= y + y_range; current_y++) {

            uint8_t color = grid_read_at(the_grid, current_x, current_y);

            if (color == EMPTY) continue;

            uint8_t d2first, d2last;
            d2first = d2last = 0;

            if (grid_read_at(the_grid, current_x - 1, current_y + 1) == color) {
                d2first += 1;
                if (grid_read_at(the_grid, current_x - 2, current_y + 2) == color) {
                    d2first += 1;
                    if (grid_read_at(the_grid, current_x - 3, current_y + 3) == color) d2first += 1;
                }
            }

            if (grid_read_at(the_grid, current_x + 1, current_y - 1) == color) {
                d2last += 1;
                if (grid_read_at(the_grid, current_x + 2, current_y - 2) == color) {
                    d2last += 1;
                    if (grid_read_at(the_grid, current_x + 3, current_y - 3) == color) d2last += 1;
                }
            }

            if (d2last + d2first >= 3) {

                for (int32_t i = -d2last; i <= d2first; i++) {

                    int64_t new_y = current_y + i;

                    removal_info info;
                    info.x = current_x - i;
                    info.y_index = new_y / VBLOCK_SIZE;
                    info.y_offset = new_y % VBLOCK_SIZE;
                    info.prev_color = color;

                    queue_putl(removal_queue, &info);

                }

            }

        }

    }
    
}

void grid_reduce(grid* the_grid, queue* removal_queue, queue* gravity_queue, int32_t x_min, int32_t x_max, int64_t y, int64_t y_range);

typedef struct gravity_info_ {

    int32_t x;
    int64_t y_start;
    int64_t y_end;

} gravity_info;

void grid_gravity(grid* the_grid, queue* removal_queue, queue* gravity_queue) {

    int32_t x_min = MAX_X;
    int32_t x_max = MIN_X;
    int64_t y_min = INT64_MAX;
    int64_t y_max = 0;

    if (removal_queue->size == 0) return;
    queue_node* current_node = removal_queue->head;

    while (current_node != NULL) {

        removal_info* info = (removal_info*) &(current_node->data);
        int32_t x = info->x;
        x_min = (x < x_min ? x : x_min);
        x_max = (x > x_max ? x : x_max);
        int64_t y_min_column = info->y_index * VBLOCK_SIZE + info->y_offset;

        queue_node* to_compare = current_node->next;

        while (to_compare != NULL) {

            removal_info* other_info = (removal_info*) &(to_compare->data);
            queue_node* next = to_compare->next;
            if (other_info->x == x) {

                int64_t other_y = other_info->y_index * VBLOCK_SIZE + other_info->y_offset;
                if (other_y < y_min_column) y_min_column = other_y;
                queue_rem_node(removal_queue, to_compare, NULL);

            }

            to_compare = next;

        }

        if (y_min > y_min_column) y_min = y_min_column;

        int64_t y = y_min_column + 1;
        int64_t skipped = 1;

        log("grav: starting at %d", y);

        while (true) {

            hblock* current_hblock = NULL;
            uint32_t hblock_index, hblock_offset;
            x_to_subindexed_coords(x, &hblock_index, &hblock_offset);
            grid_get_hblock(the_grid, x, &current_hblock);
            int64_t height = current_hblock->heights[hblock_offset];
            if (y > height) {

                log("grav: stopping at %d", y);
                if (y_max < y) y_max = y;
                
                for (int i = height; i > height - skipped; i--) {

                    grid_set_at(the_grid, x, i, EMPTY);

                }
                break;

            }

            uint8_t current = grid_read_at(the_grid, x, y);

            if (current == EMPTY) {

                skipped += 1;

            } else {

                grid_set_at(the_grid, x, y - skipped, current);

            }

            y += 1;

        }

        queue_node* next = current_node->next;
        if (current_node != NULL) queue_rem_node(removal_queue, current_node, NULL);
        current_node = next;

    }

    grid_reduce(the_grid, removal_queue, gravity_queue, x_min, x_max, y_min, y_max - y_min);

}

void hblock_resize(hblock* the_hblock) {

    int64_t max_height = the_hblock->heights[0];

    for (int i = 1; i < HBLOCK_SIZE; i++) {

        if (the_hblock->heights[i] > max_height) max_height = the_hblock->heights[i];

    }

    int64_t target_height = max_height / VBLOCK_SIZE + 1;

    if (max_height <= 0) {

        free(the_hblock->vblock_tower);
        the_hblock->vblock_tower = NULL;
        the_hblock->tower_size = 0;

    } else if (target_height <= the_hblock->tower_size / 4) {

        while (target_height <= the_hblock->tower_size / 4) the_hblock->tower_size = the_hblock->tower_size / 4;
        the_hblock->tower_size *= 4;
        the_hblock->vblock_tower = safe_realloc(the_hblock->vblock_tower, the_hblock->tower_size * sizeof(vblock));

    }

}

void grid_reduce(grid* the_grid, queue* removal_queue, queue* gravity_queue, int32_t x_min, int32_t x_max, int64_t y, int64_t y_range) {

    //log("%d, %d, %d, %d", x_min, x_max, y, y_range);

    grid_reduce_directional_horizontal(the_grid, removal_queue, x_min, x_max, y, y_range);
    grid_reduce_directional_diagonal_1(the_grid, removal_queue, x_min, x_max, y, y_range);
    grid_reduce_directional_vertical  (the_grid, removal_queue, x_min, x_max, y, y_range);
    grid_reduce_directional_diagonal_2(the_grid, removal_queue, x_min, x_max, y, y_range);

    /*
    for (int32_t x = x_min; x <= x_max + HBLOCK_SIZE; x += HBLOCK_SIZE) {

        hblock* the_hblock = NULL;
        grid_get_hblock(the_grid, x, &the_hblock);
        if (the_hblock == NULL) continue;
        hblock_resize(the_hblock);

    }
    */

    queue_dedup(removal_queue);
    
    queue_node* current = removal_queue->head;
    while (current != NULL) {

        removal_info* info = (removal_info*) &(current->data);
        current = current->next;
        // removal_info_pprint(info);

        // store and overwrite directly during gravity?
        grid_set_at(the_grid, info->x, info->y_index * VBLOCK_SIZE + info->y_offset, EMPTY);

    }

    grid_gravity(the_grid, removal_queue, gravity_queue);

}

void grid_insert(grid* the_grid, uint8_t color, int32_t x, int64_t* y_index, int64_t* y_offset) {

    uint32_t hblock_index, hblock_offset;
    x_to_subindexed_coords(x, &hblock_index, &hblock_offset);

    if (0 <= x) {

        if (hblock_index >= the_grid->positive_size) {

            // positive erweitern
            uint32_t new_size = (1 << (msb_index(hblock_index) + 1));
            the_grid->positive = safe_realloc(the_grid->positive, new_size * sizeof(hblock));

            for (int i = the_grid->positive_size; i < new_size; i++) hblock_init(&(the_grid->positive[i])); 

            the_grid->positive_size = new_size;

        }

        hblock_insert(color, hblock_offset, &the_grid->positive[hblock_index], y_index, y_offset);

    } else {

        if (hblock_index >= the_grid->negative_size) {

            // negative erweitern
            uint32_t new_size = (1 << (msb_index(hblock_index) + 1));
            the_grid->negative = safe_realloc(the_grid->negative, new_size * sizeof(hblock));

            for (int i = the_grid->negative_size; i < new_size; i++) hblock_init(&the_grid->negative[i]);

            the_grid->negative_size = new_size;

        }

        hblock_insert(color, hblock_offset, &the_grid->negative[hblock_index], y_index, y_offset);

    }

    assert(grid_read_at(the_grid, x, (*y_index) * VBLOCK_SIZE + (*y_offset)) == color);

}

void grid_output(grid* the_grid) {

    log("helo");

    for (int64_t x = -((int64_t) (the_grid->negative_size + 1)) * HBLOCK_SIZE; x < ((int64_t) (the_grid->positive_size + 1)) * HBLOCK_SIZE; x++) {

        hblock* the_hblock = NULL;
        grid_get_hblock(the_grid, x, &the_hblock);
        if (the_hblock == NULL) continue;

        for (int64_t y = 0; y < the_hblock->tower_size * VBLOCK_SIZE; y++) {

            uint8_t color = grid_read_at(the_grid, x, y);
            if (color != EMPTY) printf("%d %ld %ld\n", color, x, y);

        }

    }

}

grid* grid_global;
queue* removal_queue_global;
queue* gravity_queue_global;

void init_globals(void) {

    grid_global = grid_init();
    removal_queue_global = queue_init(sizeof(removal_info));
    gravity_queue_global = queue_init(sizeof(int32_t));

}

void uninit_globals(void) {

    grid_uninit(grid_global);
    queue_uninit(removal_queue_global);
    queue_uninit(gravity_queue_global);

}

void grid_pyformat(grid* the_grid) {

    for (int64_t x = -((int64_t) (the_grid->negative_size + 1)) * HBLOCK_SIZE; x < ((int64_t) (the_grid->positive_size + 1)) * HBLOCK_SIZE; x++) {

        hblock* the_hblock = NULL;
        grid_get_hblock(the_grid, x, &the_hblock);
        if (the_hblock == NULL) continue;

        for (int64_t y = 0; y < the_hblock->tower_size * VBLOCK_SIZE; y++) {

            uint8_t color = grid_read_at(the_grid, x, y);
            if (color != EMPTY) printf("%d %ld %ld,", color, x, y);

        }

    }
    printf("\n");

}

int main() {

    atexit(uninit_globals);
    init_globals();

#ifndef NDEBUG
    uint64_t counter = 0;
#endif

    while (true) {

        int32_t color, x;
        int64_t y_index, y_offset;
        int result = scanf("%d%*[ ]%d", &color, &x);

        if (result == EOF) {

            break;

        }

        if ((result < 2)) die("Ungültige Eingabe (Parsing unvollständig)\n");
        if (!((0 <= color) && (color < EMPTY))) die("Ungültige Eingabe (Farbe nicht im zulässigen Bereich)\n");
        if (!((MIN_X <= x) && (x <= MAX_X))) die("Ungültige Eingabe (x-Koordinate nicht im zulässigen Bereich)\n");

#ifndef NDEBUG
        log("begin insert #%d with color = %d, x = %d", counter, color, x);
#endif
        //printf("begin insert with color = %d, x = %d\n", color, x);
        grid_insert(grid_global, color, x, &y_index, &y_offset);
#ifndef NDEBUG
        log("end insert #%d", counter++);
#endif

        grid_reduce(grid_global, removal_queue_global, gravity_queue_global, x, x, y_index * VBLOCK_SIZE + y_offset, 0);

#if !defined(OUTPUT_ONLY) && !defined(NDEBUG)
        grid_pprint(grid_global);
#endif
        //grid_pyformat(grid_global);

    }

#if defined(OUTPUT_ONLY) || defined(NDEBUG)
    grid_output(grid_global);
#endif

    return 0;

}
