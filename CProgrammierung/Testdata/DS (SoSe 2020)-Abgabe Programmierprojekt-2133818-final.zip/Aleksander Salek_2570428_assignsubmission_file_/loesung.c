    #define _GNU_SOURCE
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <time.h>
    #include <math.h>
    #include <errno.h>
    #include <regex.h>
    
    struct resolve_list
    {
        int x;
        int y;
        struct resolve_list *right;
    };
    
    struct array_struct{
        
    };
    
    void circle_check(int directions[3][8], int *sf, int size_y, int *lookup_Y, int x, int y);
    struct resolve_list *fill_rl_list(struct resolve_list *rl_last, int directions[3][8], int x, int y, int *check, short *fail_flag);
    short check_color (int *sf, int size_y, int *lookup_Y ,int x, int y);
    void print_List(struct resolve_list *rl_head);
    void freeList(struct resolve_list* head);
    
    int* resize_1d_array(int* lookup_Y, int new_size_x, int old_offset){
        lookup_Y = lookup_Y + old_offset;
        int *temp = calloc(new_size_x + 2, sizeof(int));
        if (temp == NULL){ //malloc failed
            free(lookup_Y - old_offset);
            return NULL;
        }
        temp = temp + new_size_x/2;
        
        //copy old array to resized array
        for (int x = -old_offset; x < old_offset; x++){
                temp[x] = lookup_Y[x];
        }
        free(lookup_Y - old_offset);
        
        return temp;
    }
    
    // resize 2d-array in x-direction
    int* resize_x(int *arr, int new_Size_x, int y, int old_offset, int *lookup_Y){
    
        int *free_arr = arr;
        int *temp_arr = NULL;
        temp_arr = malloc(new_Size_x * y * sizeof(int));
        if(temp_arr == NULL){
            free(free_arr - old_offset * y);
            fprintf(stderr, "Malloc in x-direction failed..(2d-Array) \nReturn\n");
            return NULL;
        }
        
        int offset = new_Size_x/2;
        temp_arr += offset * y;
        
        // Initialisert neue Array mit "-1"
        for (int x = -offset; x < offset; x++){
            for (int y_val = 0; y_val < y; y_val++){
                temp_arr[x * y + y_val]  = -1;
            }
        }
        
        //copy old array to resized array
        for (int x = -old_offset; x < old_offset; x++){
            if (lookup_Y[x] != 0){
                for (int y_val = 1; y_val <= lookup_Y[x]; y_val++){
                    temp_arr[x * y + y_val]  = arr[x * y + y_val];
                }
            }
        } 
        arr = temp_arr;
        free(free_arr - old_offset * y);
        return arr;
    }

    // resize 2d-array in y-direction
    int* resize_y(int *arr, int x, int new_Size_y, int offset, int old_y, int *lookup_Y, int *to_free){
        
        int *temp_arr = NULL;
        temp_arr = malloc(x * new_Size_y * sizeof(int));
        if(temp_arr == NULL){ // malloc failed
            free(to_free);
            fprintf(stderr, "Malloc in y-direction failed..(2d-Array) \nReturn\n");
            return NULL;
        }
        
        temp_arr += offset * new_Size_y;
        
        // Initialisert neue Array mit "-1" 
        for (int x = -offset; x < offset; x++){
            for (int y_val = 0; y_val < new_Size_y; y_val++){
                temp_arr[x * new_Size_y + y_val]  = -1;
            }
        }
        
        // copy old array to resized array
        for (int x = -offset; x < offset; x++){
            if (lookup_Y[x] != 0){
                for (int y_val = 1; y_val <= lookup_Y[x]; y_val++){
                    temp_arr[x * new_Size_y + y_val]  = arr[x * old_y + y_val];
                }
            }
        }
        
        arr = temp_arr;
        free(to_free);
        return arr;
    }
    
    
    struct resolve_list *new_ListObj(int x,int y){
        struct resolve_list *rl = malloc(sizeof(struct resolve_list));
        if (rl == NULL){ // malloc failed
            return NULL;
        }
        else{
            rl->x = x;
            rl->y = y;
            rl->right = NULL;
            return rl;
        }
    }
    
    // add to resolve list (sorted, for resolve function)
    struct resolve_list *addSortedresolve_list(struct resolve_list *rl, int x, int  y) {
        struct resolve_list* temp = NULL; // speichert vorheriges Element
        struct resolve_list* head = rl;

        if (rl == NULL)
            return new_ListObj(x, y);
        else {
            while (rl->x < x) { // alle x in der Liste ueberspringen, die kleiner sind.
                temp = rl;      // vorletzte Element merken
                if (rl->right != NULL)
                    rl = rl->right;
                else {
                    rl->right = new_ListObj(x, y);
                    if (rl->right == NULL){
                        freeList(head);
                        return NULL;
                    }
                    else
                        return head;
                }
            }
            if (rl->x == x && rl->y == y) // falls x + y schon in Liste vorhanden, Liste zurueckgeben
                return head;
            else if(rl->x == x){ // richtige x-stelle gefunden, jetzt wird y-stelle gesucht
                if(rl->y > y && temp == NULL){ // muss an erster Stelle eingefuegt werden (x == x und rl.y > y und temp == NULL (also kein vorheriges Element vorhanden))
                    temp = new_ListObj(x, y);
                    if (temp == NULL){ // Malloc failed
                        freeList(head);
                        return NULL;
                    }
                    temp->right = head;
                    return temp;
                }
                else if(rl->y > y){ // x-Stelle und richtige y-Stelle gefunden, da rl.y > y!)
                    temp->right = new_ListObj(x, y);
                    if (temp->right == NULL){ // Malloc failed
                        freeList(head);
                        return NULL;
                    }
                    temp->right->right = rl;
                }
                else{
                    while (rl->y < y){ // Ab jetzt wird jedes Listenelemt solange durchgegangen, wie rl.x == x ist und die richtige y-Stelle gefunden wird)
                        temp = rl;
                        if (rl->right != NULL && rl->right->x == x)
                            rl = rl->right;
                        else if (rl->right == NULL){
                            rl->right = new_ListObj(x, y);
                            if (rl->right == NULL){
                                freeList(head);
                                return NULL;
                            }
                            return head;
                        }
                        else{
                            rl = rl->right;
                            temp->right = new_ListObj(x, y);
                            if (temp->right == NULL){
                                freeList(head);
                                return NULL;
                            }
                            else{
                                temp->right->right = rl;
                                return head;
                            }
                        }
                    }
                    if(rl->y == y) // Element schon vorhanden
                        return head;
                    else{   // alle Elemente in Liste mit selben x-Wert haben einen kleineren y-Wert
                        temp->right = new_ListObj(x, y);
                        if (temp->right == NULL){
                            freeList(head);
                            return NULL;
                        }
                        temp->right->right = rl;
                        return head;
                    }
                }
            }
            else if (temp == NULL) { // first element und x gibt es noch nicht
                temp = new_ListObj(x, y);
                if (temp == NULL)
                    return NULL;
                temp->right = head;
                return temp;
            }
            else { // x gibt es noch nicht und liegt in mitten der Liste
                temp->right = new_ListObj(x, y);
                if (temp->right == NULL){
                    freeList(head);
                    return NULL;
                }
                temp->right->right = rl;
            }
        }
        return head;
    }
    
    
    // add multiple (consecutive) stones in resolve list
    struct resolve_list *add_multiple(struct resolve_list *rl, int x, int y, short x_dir, short y_dir, short amount, short *mal_fail){
        for (int i = 1; i <= amount; i++){
                rl = addSortedresolve_list(rl,x + (i*x_dir),y + (i*y_dir));
                if (rl == NULL){
                    *mal_fail = 1;
                    return rl;
                }
        }
        return rl;
    }
    
    // Free function for resolve list
    void freeList(struct resolve_list* head)
    {
    struct resolve_list *tmp = NULL;

    while (head != NULL){
        tmp = head;
        head = head->right;
        free(tmp);
        }
    }
    
    // Visualizing resolve List
    void print_List(struct resolve_list *rl_head){
        struct resolve_list *temp = NULL;
        temp = rl_head;
        printf("\n----------\nList with Values to be deleted: \n");
            while (temp != NULL){
                printf("x: %d | y: %d\n",temp->x, temp->y);
                temp = temp->right;
            }
        printf("---------- end\n\n");
    }
   
    // ob[0] = x-min || ob[1] = x-max || y-min
    void get_Outer_bounds(struct resolve_list *rl, int ob[3]){
       
        ob[0] = rl->x;
        ob[1] = rl->x;
        ob[2] = rl->y;
        while(rl != NULL){
            if(rl->x < ob[0])
                ob[0] = rl->x;
            if(rl->x > ob[1])
                ob[1] = rl->x;
            if(rl->y < ob[2])
                ob[2] = rl->y;
            rl = rl->right;
        }
    }
    
    // das ist die nachrueckfunktion
    void resolve_small(struct resolve_list* rl_head, int size_y, int *sf, int *lookup_Y){
        int count = 0;
        
        while (rl_head != NULL){
            for(int y = rl_head->y; y <= lookup_Y[rl_head->x]; y++){
                sf[rl_head->x * size_y + y] = sf[rl_head->x * size_y + (y + 1)];
            }
            lookup_Y[rl_head->x]--;
            count++;
            
            // Hier ziehe bei allen x in der Liste, die gleich dem x sind welches ich anschaue, beim y-wert "1" ab. (da die ja schon einen runtergefallen sind)
            if(rl_head->right != NULL && rl_head->x == rl_head->right->x){
                struct resolve_list *temp = rl_head;
                while(temp->right != NULL && temp->x == temp->right->x){
                    temp->right->y -= 1;
                    temp = temp->right;
                }
            }
            rl_head = rl_head->right;
        }
    }
    
    // grosse Aufloesung
    short resolve_big(int ob[3], int size_y, int *sf, int *lookup_Y){
        int directions[3][8];
        for(int i = 0; i<3; i++){
            for(int j = 0; j<8; j++){
                directions[i][j] = 0;
            }
        }
        short fail_flag = 0;
        int check = 0;
        int res_again = 0;
        struct resolve_list *rl_head = NULL;
        
        // hier wird jedes Element in der Outer Bound überprüft
        for(int x = ob[0]; x <= ob[1]; x++){
            if(lookup_Y[x] >= ob[2]){
                for(int y = ob[2]; y <= lookup_Y[x]; y++){
                    circle_check(directions, sf, size_y, lookup_Y, x, y);
                    rl_head = fill_rl_list(rl_head, directions, x, y, &check, &fail_flag);
                    if (fail_flag){
                        freeList(rl_head);
                        return fail_flag;
                    }
                        
                    // Falls 4 oder mehr gleiche gefunden wurden is check == true, dann muss noch das gerade betrachtende x-y-paar hinzugefügt werden
                    if(check){
                        rl_head = addSortedresolve_list(rl_head, x, y);
                        check = 0;
                        res_again = 1;
                    }
                    // directions wieder auf "0" setzen
                    for (int j = 0; j < 3; j++){
                        for(int i = 0; i < 8; i++){
                            directions[j][i] = 0;
                        }
                    }
                }
            }
        }
        
        // Falls bisher eine Kette von 4 oder mehr gleichen gefunden wurde, muss resolve big neu aufgerufen werden (mit neuen ob's)
        if(res_again){
            resolve_small(rl_head, size_y, sf, lookup_Y);
            int ob[3];
            get_Outer_bounds(rl_head, ob);
            freeList(rl_head);
            fail_flag = resolve_big(ob, size_y, sf, lookup_Y);
        }
        return fail_flag;
    }
    
    void circle_check(int directions[3][8], int *sf, int size_y, int *lookup_Y, int x, int y){
        
        // directions[i][j] -> 
        // i == der zu betrachtende Ring um den zu betrachtenden Wert (1-3)
        // j == Richtung (0-7)
        /*
         * 0 = Norden
         * 1 = Nord-Osten
         * 2 = Osten
         * 3 = Sued-Osten
         * 4 = Sueden
         * 5 = Sued-Westen
         * 6 = Westen
         * 7 = Nord-Westen
         */
        
        for (int i = 1; i < 4; i++){
            if (y <= (lookup_Y[x]-3) && sf[x * size_y + y] == sf[x * size_y + y+i]){                                            // N
                directions[i-1][0]++;
            }
            if (lookup_Y[x+i] >= y+i && sf[x * size_y + y] == sf[(x+i) * size_y + y+i]){                                        // NO
                directions[i-1][1]++;
            }
            if (lookup_Y[x+i] > 0 && lookup_Y[x+i] >= y && sf[x * size_y + y] == sf[(x+i) * size_y + y]){                       // O
                directions[i-1][2]++;
            }
            if (lookup_Y[x+i] > 0 && lookup_Y[x+i] >= y-i && sf[x * size_y + y] == sf[(x+i) * size_y + y-i]){                   // SO
                directions[i-1][3]++;
            }
            if (lookup_Y[x] > 3 && sf[x * size_y + y] == sf[x * size_y + y-i]) {                                                // S
                directions[i-1][4]++;
            }
            if (lookup_Y[x-i] > 0 && lookup_Y[x-i] >= y-i && sf[x * size_y + y] == sf[(x-i) * size_y + y-i]){                   // SW
                directions[i-1][5]++;
            }
            if (lookup_Y[x-i] > 0 && lookup_Y[x-i] >= y && sf[x * size_y + y] == sf[(x-i) * size_y + y]){                       // W
                directions[i-1][6]++;
            }
            if (lookup_Y[x-i] >= y+i && sf[x * size_y + y] == sf[(x-i) * size_y + y+i]){                                        // NW
                directions[i-1][7]++;
            }
        }
    }
    
    // Fill List with Values to be deleted
    struct resolve_list* fill_rl_list(struct resolve_list *rl_last, int directions[3][8], int x, int y, int *check, short *fail_flag){
        
        int dir[8] = {0};
        int i = 0;
        
        // check how many consecutive colors are there (from W->O, N->S ... etc.)
        while(i < 3 && directions[i][0] == 1){
            dir[0]++;
            i++;
        }
        i = 0;
        while(i < 3 && directions[i][1] == 1){
            dir[1]++;
            i++;
        }
        i = 0;
        while(i < 3 && directions[i][2] == 1){
            dir[2]++;
            i++;
        }
        i = 0;
        while(i < 3 && directions[i][3] == 1){
            dir[3]++;
            i++;
        }
        i = 0;
        while(i < 3 && directions[i][4] == 1){
            dir[4]++;
            i++;
        }
        i = 0;
        while(i < 3 && directions[i][5] == 1){
            dir[5]++;
            i++;
        }
        i = 0;
        while(i < 3 && directions[i][6] == 1){
            dir[6]++;
            i++;
        }
        i = 0;
        while(i < 3 && directions[i][7] == 1){
            dir[7]++;
            i++;
        }
        
        //if there are 4 or more consecutive, store them in resolve_list
        for (int i = 0; i <= 3; i++){
            if (dir[i] + dir[i+4] >= 3){
                if(i==0){       // S -> N
                    rl_last = add_multiple(rl_last, x, y, 0, 1, dir[i], fail_flag);
                    rl_last = add_multiple(rl_last, x, y, 0, -1, dir[i+4], fail_flag);
                }
                else if(i==1){  // SW -> NO
                    rl_last = add_multiple(rl_last, x, y, 1, 1, dir[i], fail_flag);
                    rl_last = add_multiple(rl_last, x, y, -1, -1, dir[i+4], fail_flag);
                }
                else if(i==2){  // W -> O
                    rl_last = add_multiple(rl_last, x, y, 1, 0, dir[i], fail_flag);
                    rl_last = add_multiple(rl_last, x, y, -1, 0, dir[i+4], fail_flag);
                }
                else{           // NW -> SO (i == 3)
                    rl_last = add_multiple(rl_last, x, y, 1, -1, dir[i], fail_flag);
                    rl_last = add_multiple(rl_last, x, y, -1, 1, dir[i+4], fail_flag);
                }
                *check = 1;
            }
        }
        return rl_last;
    }
     
    
    short check_color (int *sf, int size_y, int *lookup_Y ,int x, int y){
        int check = 0;
        //int check_if4 = 0;
        int need_free = 1;
        short fail_flag = 0;
        struct resolve_list *rl_head = new_ListObj(x,y);
        if (rl_head == NULL) // new_ListObj() failed, return
            return 1;
        struct resolve_list *rl_last = rl_head;
        /*
         * 0 = Norden
         * 1 = Nord-Osten
         * 2 = Osten
         * 3 = Sued-Osten
         * 4 = Sueden
         * 5 = Sued-Westen
         * 6 = Westen
         * 7 = Nord-Westen
         */
        
        int directions[3][8] = {0};
        for(int i = 0; i<3; i++){
            for(int j = 0; j<8; j++){
                directions[i][j] = 0;
            }
        }
            
        circle_check(directions, sf, size_y, lookup_Y, x, y);
        rl_last = fill_rl_list(rl_last, directions, x, y, &check, &fail_flag);
        if (fail_flag){
            freeList(rl_last);
            return fail_flag;
        };
        
        // Wenn 4 oder mehr gleiche gefunden wurden ist check == true
        // als erstes werden die ersten gefunden nachgerückt und dann wird resolve big mit den ob's aufgerufen
        if (check){
            int outer_bounds[3]; // ob[0] = x-min, ob[1] = x-max, ob[2] = y-min
            resolve_small(rl_last, size_y, sf, lookup_Y);
            get_Outer_bounds(rl_last, outer_bounds);
            fail_flag = resolve_big(outer_bounds, size_y, sf, lookup_Y);
            if (fail_flag){
                freeList(rl_last);
                return fail_flag;
            }
            need_free = 0;
        }
        
        // Schaut, ob eine Liste vorhanden ist oder nicht
        if (need_free) {
            free(rl_head);
        }
        else
            freeList(rl_last);
        return 0;
    }
    
    // strtol with errorchecking
    int err_check_strtol (char *p, char **ep, int base)
    {
        errno = 0;

        int temp = strtol (p, ep, base);

        /* Check for errors */
        if ((errno == ERANGE  || (errno != 0 && temp == 0))) {
            fprintf(stderr,"strtol failed\n");
            exit (-1);
        }

        if (*ep == p) {
            fprintf (stderr, "No digits were found\n");
            exit (-1);
        }

        return temp;
    }
    
    
    
    int main(void) {
        
    //clock_t t = clock();
    
    // initilize regex
    regex_t regex;
    int reg_check;
    char* regexStr = "^0*[0-9]{1,3} +-?0*[0-9]{1,7}(\n|\r|\r\n)?$"; // regular expression

    if(regcomp(&regex, regexStr, REG_EXTENDED)){
        printf("Couldn't compile regular expression.\n");
        return -1;
    }

    //int while_counter = 0;
    int x_coord;
    int farbe = -1;
    int size_x = 514;
    int size_y = 514;
    int offset_x = size_x / 2;
    int old_offset = offset_x;
    short failed = 0; 
    //int scan_fail = 0;
    errno = 0;
    
    char *line = NULL;
    char *curr = NULL;
    char *line_begin = NULL;
    size_t len = 0;
    ssize_t read_size;
    
    // simulated 2d-array
    int *s_feld = malloc(sizeof(int) * size_x * size_y); //s_feld[x][y] = s_feld[x * size_y + y];
    if (s_feld == NULL){
        printf("Malloc not successfull!!!\n");            //prüfen, ob malloc erfolgreich war.
        regfree(&regex);
	return -1;
    }
        
    //... lookup-table for y-values
    int *lookup_y = calloc(size_x + 2, sizeof(int));
    if (lookup_y == NULL){
        printf("Malloc not successfull! (lookup Table)\n");            //prüfen, ob malloc erfolgreich war.
        regfree(&regex);        
        free(s_feld);
        return -1;
    }
    
    // Set pointer from s_feld and lookup_y to to the middle of the array to access array with negative x-values
    s_feld = (s_feld + offset_x * size_y);
    lookup_y = (lookup_y + offset_x);
    
    // Initialisert neue Array mit "-1"
    for (int x = -offset_x; x < offset_x; x++){
        for (int y_val = 0; y_val < size_y; y_val++){
            s_feld[x * size_y + y_val]  = -1;
        }
    }
    
    while (1) {
        
        errno = 0;
        read_size = getline(&line_begin, &len, stdin);
        curr = line_begin;
        line = line_begin;
        
        if (read_size < 0){
            if (errno == ENOMEM){
                fprintf(stderr, "getline couldn't allocate memory!\nProgramm will be closed..\n");
                regfree(&regex);
                free(s_feld - offset_x * size_y);
                free(lookup_y - offset_x);
                free(line_begin);
                return -1;        
            }
            break; // all getlines were successfull
        }
        if (strlen(line_begin) != (size_t)read_size) {
            regfree(&regex);
            free(s_feld - offset_x * size_y);
            free(lookup_y - offset_x);
            free(line_begin);
            fprintf(stderr, "Invalid input: contains a null byte\n");
            return -1;
        }
        reg_check = regexec(&regex, line_begin, 0, NULL, 0);
        if(reg_check == REG_NOMATCH){
            fprintf(stderr, "Input not correct!\ne.g Something other than a digit were read or too many arguments per line or an argument too small/big (e.g x </> -/+2^20)!\nProgramm will be closed..\n");
            regfree(&regex);
            free(s_feld - offset_x * size_y);
            free(lookup_y - offset_x);
            free(line_begin);
            return -1;
        }
        
        // store color and x_coord from read string in int farbe and x_coord
        farbe = (int)err_check_strtol(line, &curr, 10);
        line = curr;
        x_coord = err_check_strtol(line, &curr, 10);
        

        if (farbe < 0 || farbe > 254 || x_coord > pow(2,20) || x_coord < -pow(2,20)){
            fprintf(stderr, "color < 0 or color > 254 or x </> -/+2^20... \nProgramm will be closed!\n");
            regfree(&regex);
            free(s_feld - offset_x * size_y);
            free(lookup_y - offset_x);
            free(line_begin);
            return -1;
        }
        
        /*
        * Resizing 2d-Array in y-direction 
        */
        if (x_coord <= (-offset_x + 1) || x_coord >= (offset_x - 2)){
            while (x_coord <= (-offset_x + 1) || x_coord >= (offset_x - 2)){
                offset_x *= 2;
            }
            size_x = 2 * offset_x;
            lookup_y = resize_1d_array(lookup_y - old_offset, size_x, old_offset);
            if (lookup_y == NULL){
                fprintf(stderr, "Malloc in y-direction failed (1d-Array)...\n");
                regfree(&regex);
                free(s_feld - old_offset * size_y); 
                free(line_begin);
                return -1;
            }
            
            s_feld = resize_x(s_feld, size_x, size_y, old_offset, lookup_y);
            if(s_feld == NULL){
                regfree(&regex);
                free(lookup_y - offset_x);
                free(line_begin);
                return -1;
            }
        }

        /*
        * Resizing 2d-Array in y-direction 
        */
        if (lookup_y[x_coord] >= (size_y) - 2){
            int *ptr = s_feld - offset_x*size_y; // ptr to be free'd!
            size_y *= 2;
            s_feld = resize_y(s_feld, size_x, size_y, offset_x, size_y/2, lookup_y, ptr);
            if(s_feld == NULL){
                regfree(&regex);
                free(lookup_y - offset_x);
                free(line_begin);
                return -1;
            }
        }
        lookup_y[x_coord]++;
        s_feld[x_coord * size_y + lookup_y[x_coord]] = farbe + 1;
        
        failed = check_color(s_feld, size_y, lookup_y, x_coord, lookup_y[x_coord]);
        if (failed){
            printf("Some Malloc failed... Programm will be closed!\n");
            regfree(&regex);
            free(s_feld - offset_x * size_y);
            free(lookup_y - offset_x);
            free(line_begin);
            return -1;
        }
            
        
        //while_counter++;
        old_offset = offset_x;
        
    }
    //print result
    int counter = 0;
    for (int x = -offset_x; x < (size_x - offset_x); x++){
        if (lookup_y[x] != 0){
            for (int y = 1; y <= lookup_y[x]; y++){
                counter++;
                printf("%d %d %d\n", s_feld[x * size_y + y] - 1 , x, y - 1); // Die "-1" bei s_feld[][] und y sind notwendig, wegen der 0-init's bei nicht belegten Werten
            }
        }
    }     
    
//  printf("\nCounter = %ld\n", counter);
    free(s_feld - offset_x * size_y);
    free(lookup_y - offset_x);
    free(line_begin);
    regfree(&regex);
    
    // check Time
//  t = clock() - t;
// 	double time_taken = ((double)t) / CLOCKS_PER_SEC; // in seconds 
// 
// 	printf("\n|| It took %f seconds to execute || -- %ld elements were read! -- ||\n", time_taken, while_counter);
    
    return 0;
}

