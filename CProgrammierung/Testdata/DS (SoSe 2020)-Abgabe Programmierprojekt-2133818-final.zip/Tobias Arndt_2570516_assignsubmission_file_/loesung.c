#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <ctype.h>
#include <string.h>

#define DEFAULT_VALUE (int)(pow(2, 20)+1)
#define DEFAULT_SIZE 8

/*
Struct der den Array von Steinen auf einer Vertikalen enthält
*/
struct column{
	int* ypos;
	int size;
	int capacity;
	int pos;
};

/*
Struct der die verschiedenen x-Koordinaten managed, aufgebaut als AVL Tree
*/
struct treeNode {
	int val;
	int height;
	struct column* list;
	struct treeNode* left;
	struct treeNode* right;
};

/*
Struct der die zu löschenden Steine in einer Iteration des Spielfeldes enthält
*/
struct deleteArray{
	int size;
	int capacity;
	int** values;
};

/*
Bestimmt das Maximum zweier Integer Werte
*/
int max(int a, int b){
	return (a>b)?a:b;
}

/*
Debug Funktion zum Anzeigen des Arrays mit den zu löschenden Steinen
*/
void showDelArray(struct deleteArray* delA){
	for (int i = 0; i < delA->size; i++){
		printf("[ %d, %d ]\n", delA->values[i][0], delA->values[i][1]);
	}
}

/*
Erstellt einen neuen deleteArray und allocated Speicher für diesen
*/
struct deleteArray* newDelArray(int* flag){
	struct deleteArray* delArray = malloc(sizeof(struct deleteArray));
	if (delArray == NULL){
		*flag = 0;
		return delArray;
	}
	delArray->values = malloc(sizeof(int*)*DEFAULT_SIZE);
	if (delArray->values == NULL){
		*flag = 0;
		return delArray;
	}
	for (int i = 0; i < DEFAULT_SIZE; i++){
		delArray->values[i] = malloc(sizeof(int)*2);
		if (delArray->values[i] == NULL){
			*flag = 0;
			return delArray;
		}
	}
	delArray->size = 0;
	delArray->capacity = DEFAULT_SIZE;
	return delArray;
}

/*
Benutzt den free Befehl auf jedes Element des deleteArray und dann auf den deleteArray
*/
void freeDelArray(struct deleteArray* delA){
	for (int i=0; i < delA->capacity; i++){
		free(delA->values[i]);
	}
	free(delA->values);
	free(delA);
}

/*
Fügt die Koordinaten eines Steins in den deleteArray sortiert nach y Koordinate ein, Speicher wird dabei potenziell neu alloziert
*/
struct deleteArray* insertDelArray(int x, int y, struct deleteArray* delA, int* flag){
	if (delA->size >= delA->capacity){
		int** tmp;
		delA->capacity = delA->capacity*2;
		tmp = realloc(delA->values, delA->capacity*sizeof(int*));
		if (tmp != NULL){
			delA->values = tmp;
		}
		else{
			*flag = 0;
			return delA;
		}
		for (int i = delA->size; i < delA->capacity; i++){
			delA->values[i] = malloc(sizeof(int)*2);
			if (delA->values[i] == NULL){
				*flag = 0;
				return delA;
			}
		}
	}
	if (delA->size == 0){
		delA->values[0][0] = x;
		delA->values[0][1] = y;
		delA->size += 1;
		return delA;
	}
	int i = 0;
	for (; i < delA->size; i++){
		if (x == delA->values[i][0] && y == delA->values[i][1]){
			return delA;
		}
		if (y > delA->values[i][1]){
			break;
		}
	}
	for (int j = delA->size; j > i; j--){
		delA->values[j][0] = delA->values[j-1][0];
		delA->values[j][1] = delA->values[j-1][1];
	}
	delA->values[i][0] = x;
	delA->values[i][1] = y;
	delA->size += 1;
	return delA;
}

/*
Debug Funktion zum Anzeigen der Steine einer Vertikalen
*/
void printList(int* liste, int size){
	int i;
	for(i = 0; i < size; i++){
		printf("%d ", liste[i]);
	}
	printf("\n");
}	

/*
Funktion zum Erzeugen des Outputs
*/
void printListOut(int* liste, int size, int x){
	for (int i = 0; i < size; i++){
		printf("%d %d %d", liste[i], x, i);
		printf("\n");
	}
}

/*
Einfügen eines neuen Steins zu einer Vertikalen, potenziell wird Speicher realloziert
*/
struct column* insertColor(struct column* liste, int val, int* flag){
	if (liste->size+1 >= liste->capacity){
		int* tmp;
		liste->capacity = liste->capacity*2;
		tmp = realloc(liste->ypos, liste->capacity*sizeof(int));
		if (tmp != NULL){
			liste->ypos = tmp;
		}
		else{
			*flag = 0;
			return liste;
		}
	}
	liste->ypos[liste->pos] = val;
	liste->pos += 1;
	liste->size+=1;
	return liste;
}

/*
Benutzt den free Befehl auf einen Array der die Vertikale darstellt.
*/
void freeList(struct column* liste){
	if (liste == NULL){
		return;
	}
	free(liste->ypos);
	free(liste);
}

/*
Funktion die die Hoehe einer Node im AVL Baum zurückgibt
*/
int height(struct treeNode *tree){
	if (tree == NULL){
		return 0;
	}
	return tree->height;
}

/*
Funktion die einen neuen TreeNode erstellt, den Speicher dafür alloziert und auch die zugehörige Vertikale initialisiert
*/
struct treeNode* newTree(int val1, int val2, int* flag){
	 struct treeNode* tree = malloc(sizeof(struct treeNode));
	if (tree == NULL){
		*flag = 0;
		return tree;
	}
	tree->val = val1;
	tree->left = NULL;
	tree->right = NULL;
	tree->height = 1;
		tree->list = malloc(sizeof(struct column));
		if (tree->list == NULL){
			*flag = 0;
			return tree;
		}
		tree->list->size = 0;
		tree->list->capacity = DEFAULT_SIZE;
		tree->list->pos = 0;
			tree->list->ypos = malloc(sizeof(int)*DEFAULT_SIZE);
			if (tree->list->ypos == NULL){
				*flag = 0;
				return tree;
			}
		tree->list = insertColor(tree->list, val2, flag);
	return tree;
}

/*
Typische AVL Funktion, rotiert den Baum ab einem Node nach rechts
*/
struct treeNode* rechtsRot(struct treeNode* tree){
	struct treeNode *sub = tree->left;
	struct treeNode *sub2 = sub->right;
	sub->right = tree;
	tree->left = sub2;
	tree->height = max(height(tree->left), height(tree->right))+1;
	sub->height = max(height(sub->left), height(sub->right))+1;
	return sub;
}

/*
Typische AVL Funktion, rotiert den Baum ab einem Node nach links
*/
struct treeNode* linksRot(struct treeNode* tree){
	struct treeNode *sub = tree->right;
	struct treeNode *sub2 = sub->left;
	sub->left = tree;
	tree->right = sub2;
	tree->height = max(height(tree->left), height(tree->right))+1;
	sub->height = max(height(sub->left), height(sub->right))+1;
	return sub;
}

/*
Typische AVL Funktion zum Bestimmten der Höhenunterschiede im Baum
*/
int Balance(struct treeNode *tree){
	if (tree == NULL){
		return 0;
	}
	return height(tree->left)-height(tree->right);
}

/*
Funktion zum Einfügen eines Elements in den Baum, entweder als neuen Node oder als weiteres Element in der Vertikalen eines vorhandenen Nodes
Prüft auch die AVL Eigenschaft und rotiert falls notwendig
*/
struct treeNode* insert(struct treeNode* tree, int val1, int val2, int* flag){
	if (tree == NULL){
		struct treeNode* new = newTree(val1, val2, flag);
		return new;
	}
	if (val1 < tree->val){
		tree->left = insert(tree->left, val1, val2, flag);
	}
	else if(val1 > tree->val){
		tree->right = insert(tree->right, val1, val2, flag);
	}
	else {
		tree->list = insertColor(tree->list, val2, flag);
		return tree;
	}
	tree->height = max(height(tree->left), height(tree->right))+1;
	int balance = Balance(tree);
	if(balance>1 && val1 < tree->left->val){
		return rechtsRot(tree);
	}
	if(balance<-1 && val1 > tree->right->val){
		return linksRot(tree);
	}
	if(balance>1 && val1 > tree->left->val){
		tree->left = linksRot(tree->left);
		return rechtsRot(tree);
	}
	if(balance<-1 && val1 < tree->right->val){
		tree->right = rechtsRot(tree->right);
		return linksRot(tree);
	}
	return tree;
}

/*
Debug Funktion zum Anzeigen eines AVL Trees durch InOrder Traversierung
*/
void inOrder(struct treeNode *tree){
	if (tree != NULL){
		inOrder(tree->left);
		if (tree->val >= 0){
			printf(" %d->", tree->val);
		}
		else{
			printf("%d->", tree->val);
		}
		printList(tree->list->ypos, tree->list->size);
		inOrder(tree->right);
	}
}

/*
Funktion zum Erzeugen des Outputs durch InOrder Traversierung
*/
void inOrderOut(struct treeNode* tree){
	if (tree != NULL){
		inOrderOut(tree->left);
		printListOut(tree->list->ypos, tree->list->size, tree->val);
		inOrderOut(tree->right);
	}
}

/*
Funktion zum Finden des Knotens mit Label x im AVL Baum
*/
struct treeNode* find(int x, struct treeNode* tree){
	if (tree == NULL){
		return tree;
	}
	else if (x == tree->val){
		return tree;
	}
	else if (x < tree->val){
		return find(x, tree->left);
	}
	else{
		return find(x, tree->right);
	}
}

/*
Funktion zum Löschen eines einzelnen Elements aus der Vertikalen
*/
void deleteSingle(struct column* list, int k){
	for (int i = k; i<list->size; i++){
		list->ypos[i] = list->ypos[i+1];
	}
	list->size -= 1;
	list->pos -= 1;
}

/*
Funktion zum Löschen aller Elemente die zum Löschen markiert sind 
*/
void delete(struct deleteArray* delA, int count, struct treeNode* tree){
	for(int i = 0; i < count; i++){
		struct treeNode* found = find(delA->values[i][0], tree);
		deleteSingle(found->list, delA->values[i][1]);
	}
}

/*
Funktion die den free Befehl auf alle Elemente des AVL Baums anwendet
*/
void freeTree(struct treeNode* tree){
	if (tree == NULL){
		return;
	}
	freeTree(tree->left);
	freeTree(tree->right);
	freeList(tree->list);
	free(tree);
	
}

/*
Funktion die für einen bestimmten Stein überprüft ob der Stein Teil einer mind. Viererkette ist
*/
struct deleteArray* check(struct treeNode *tree, int xpos, int ypos, struct deleteArray* delA, struct treeNode* found, int* flag){
	//vertical
	struct treeNode* xArr[7];
	int leftcounter = 0;
	int rightcounter = 0;
	for(int i = 0; i < 4; i++){
		if (i == 0){
			xArr[3] = found;
		}
		else{
			xArr[3-i] = find(xpos-i, tree);
			xArr[3+i] = find(xpos+i, tree);
		}
	}
	for(int i = 1; i < 4; i++){
		if (xArr[3-i] != NULL){
			leftcounter += 1;
		}
		else{
			break;
		}
	}
	for(int i = 1; i < 4; i++){
		if (xArr[3+i] != NULL){
			rightcounter += 1;
		}
		else{
			break;
		}
	}
	int vert = 1;
	if (found->list->size >=4){
		for (int i = 1; i < 4; i++){
			if (ypos-i < 0){
				vert = 0;
				break;
			}
			if (found->list->ypos[ypos-i] != found->list->ypos[ypos]){
				vert = 0;
				break;
			}
		}
		if (vert == 1){
			//printf("Found vertical\n");
			for (int i = 0; i < 4; i++){
				insertDelArray(xpos, ypos-i, delA, flag);
			}
		}
	}
	if (leftcounter + rightcounter >= 3){
		int usedh = 1;
		int temph[7] = {found->val};
		int usedd1 = 2;
		int tempd1[14] = {found->val, ypos+1};
		int usedd2 = 2;
		int tempd2[14] = {found->val, ypos+1};
		if (leftcounter > 0){
			int hflag = 1;
			int d1flag = 1;
			int d2flag = 1;
			for (int i = 1; i <= leftcounter; i++){
				//horizontal
				if (hflag == 1 && (xArr[3-i]->list->size > ypos && xArr[3-i]->list->ypos[ypos] == found->list->ypos[ypos])){
					temph[usedh] = xArr[3-i]->val;
					usedh += 1;
				}
				else{
					hflag = 0;
				}
				//diagonale linksoben
				if (d1flag == 1 && (ypos+i < xArr[3-i]->list->size && xArr[3-i]->list->ypos[ypos+i] == found->list->ypos[ypos])){
					tempd1[usedd1] = xArr[3-i]->val;
					tempd1[usedd1+1] = ypos+1+i;
					usedd1 += 2;
				}
				else{
					d1flag = 0;
				}
				//diagonal2 linksunten
				if (d2flag == 1 && (( ypos-i >= 0 && xArr[3-i]->list->size > ypos-i) && xArr[3-i]->list->ypos[ypos-i] == found->list->ypos[ypos])){
					tempd2[usedd2] = xArr[3-i]->val;
					tempd2[usedd2+1] = ypos+1-i;
					usedd2 += 2;
				}
				else{
					d2flag = 0;
				}
			}
		}
		if (rightcounter > 0){
			int hflag = 1;
			int d1flag = 1;
			int d2flag = 1;
			for (int i = 1; i <= rightcounter; i++){
				//horizontal
				if (hflag == 1 && (xArr[3+i]->list->size > ypos && xArr[3+i]->list->ypos[ypos] == found->list->ypos[ypos])){
					temph[usedh] = xArr[3+i]->val;
					usedh += 1;
				}
				else{
					hflag = 0;
				}
				//diagonal1 rechtsunten
				if (d1flag == 1 && (( ypos-i >= 0 && xArr[3+i]->list->size > ypos-i) && xArr[3+i]->list->ypos[ypos-i] == found->list->ypos[ypos])){
					tempd1[usedd1] = xArr[3+i]->val;
					tempd1[usedd1+1] = ypos+1-i;
					usedd1 += 2;
				}
				else{
					d1flag = 0;
				}
				//diagonal2 rechtsoben
				if (d2flag == 1 && ( ypos+i < xArr[3+i]->list->size && xArr[3+i]->list->ypos[ypos+i] == found->list->ypos[ypos])){
					tempd2[usedd2] = xArr[3+i]->val;
					tempd2[usedd2+1] = ypos+1+i;
					usedd2 += 2;
				}
				else{
					d2flag = 0;
				}
			}
		}
		if (usedh >= 4){
			//printf("Found horizontal\n");
			for (int i = 0; i < usedh; i++){
				insertDelArray(temph[i], ypos, delA, flag);
			}
		}
		if (usedd1 >= 8){
			//printf("Found diagonal1\n");
			for (int i = 0; i < usedd1; i  = i+2){
				insertDelArray(tempd1[i], tempd1[i+1]-1, delA, flag);
			}
		}
		if (usedd2 >= 8){
			//printf("Found diagonal2\n");
			for (int i = 0; i < usedd2; i  = i+2){
				insertDelArray(tempd2[i], tempd2[i+1]-1, delA, flag);
			}
		}
		return delA;
	}	
	else{
		return delA;
	}
}

/*
Funktion die überprüft ob irgendwo Steine existieren die eine mind. Viererkette bilden und falls nötig ebenjene Steine löscht
*/
void checkAll(int xpos, struct treeNode* tree, int max, int min, int* flag){
	struct treeNode* found = find(xpos, tree);
	int ypos = found->list->pos-1;
	int k = 0;
	while(1){
		struct deleteArray* delArray = newDelArray(flag);
		if (*flag == 0){
			freeDelArray(delArray);
			return;
		}
		int left = (xpos-k*3>min)?xpos-k*3:min;
		int right = (xpos+k*3<max)?xpos+k*3:max;
		int down = (ypos-k*3>0)?ypos-k*3:0;
		for (int i = left; i<=right; i++){
			struct treeNode* foundX = find(i, tree);
			if (foundX == NULL){
				continue;
			}
			for (int j = down; j < foundX->list->size; j++){
				delArray = check(tree, i, j, delArray, foundX, flag);
			}
		}
		if (*flag == 0){
			freeDelArray(delArray);
			return;
		}
		if (delArray->size == 0){
			freeDelArray(delArray);
			return;
		}
		delete(delArray, delArray->size, tree);
		freeDelArray(delArray);
		k += 1;
	}
}

int main(){
	/*
	Initialisierung von notwendigen Variablen
	*/
	char* buffer = NULL;
	size_t len = 0;
	int color, pos, num, count, length;
	char lf;
	int max, min;
	max = -1*DEFAULT_VALUE;
	min = DEFAULT_VALUE;
	int flag = 1;
	struct treeNode *xlist = NULL;
	
	/*
	Einlesen des Inputs zeilenweise in einer Schleife
	*/
	while((length = getline(&buffer, &len, stdin)) != -1){
		count = sscanf(buffer, " %n%9d %8d%c", &num,&color,&pos, &lf);
		if ((size_t)length == strlen(buffer)){
			if (count >= 2){
				if( (num == 0) &&(0<=color && color <=254) &&(-1*DEFAULT_VALUE< pos && pos < DEFAULT_VALUE) && (lf == '\n')){
					/*
					Einfügen des gelesenen Steins in die Datenstruktur, ruft den free Befehl auf, falls ein malloc oder realloc scheitern sollte
					*/
					xlist = insert(xlist, pos, color, &flag);
					if (flag == 0){
						freeTree(xlist);
						free(buffer);
						fprintf(stderr, "Memory could not be allocated.\n");
						return 1;
					}
					/*
					Überprüfen des Spielfelds, ruft den free Befehl auf, falls ein malloc oder realloc scheitern sollte
					*/
					max = (pos>max)?pos:max;
					min = (pos<min)?pos:min;
					checkAll(pos, xlist, max, min, &flag);
					if (flag == 0){
						freeTree(xlist);
						free(buffer);
						fprintf(stderr, "Memory could not be allocated.\n");
						return 1;
					}
				}
				/*
				Abbruch bei fehlerhaftem Input
				*/
				else{
					freeTree(xlist);
					free(buffer);
					fprintf(stderr, "Fehlerhafte Eingabe!\n");
					return 1;
				}
			}
			else{
					freeTree(xlist);
					free(buffer);
					fprintf(stderr, "Fehlerhafte Eingabe!\n");
					return 1;
				}
		}
		else{
			freeTree(xlist);
					free(buffer);
					fprintf(stderr, "Fehlerhafte Eingabe!\n");
					return 1;
				}
	}
	//inOrder(xlist);
	
	/*
	Ausgabe des Outputs mit anschließendem free des verwendeten Speichers
	*/
	inOrderOut(xlist);
	free(buffer);
	freeTree(xlist);
	return 0;
}