#include <stdio.h>
#include <stdlib.h>

typedef struct
{
  int colour;
  int xValue;
} stone;

typedef struct
{
  int** field;
  int height;
  int length;
  int shifts;
  struct{
    int minX;
    int minY;
    int maxX;
    int maxY;
    int notEmpty;
  }mark;
} Game;

int GameInit(Game* self){
  self->length=1;
  self->height=1;
  self->shifts=0;
  self->mark.minX=-1;
  self->mark.minY=-1;
  self->mark.maxX=-1;
  self->mark.maxY=-1;
  self->mark.notEmpty=0;
  self->field=malloc(sizeof(*self->field)*self->length);

  if(self->field==NULL){
    fprintf(stderr, "%s\n", "Es steht nicht genug Speicherplatz zur Verfuegung." );
    return -1;
  }
  for ( size_t i = 0; i < self->length; i++ ){
    self->field[i] = malloc( sizeof(*self->field[i]) * self->height );
    if(self->field[i]==NULL){
      fprintf(stderr, "%s\n", "Es steht nicht genug Speicherplatz zur Verfuegung." );
      return -1;
    }
  }
  self->field[0][0]=-1;
  return 1;
}

void Release(Game* self){
  for ( size_t i = 0; i < self->length; i++ ){
    free(self->field[i]);
  }
  free(self->field);
}

int shiftField(Game* self, stone base){
  int difference= base.xValue*(-1)-self->shifts;
  int newLength=self->length+base.xValue*(-1)-self->shifts;
  self->shifts=base.xValue*(-1);
  int **newField=malloc(sizeof(*self->field)*newLength);
  if(newField==NULL){
    fprintf(stderr, "%s\n", "Es steht nicht genug Speicherplatz zur Verfuegung." );
    Release(self);
    return -1;
  }
  for ( size_t i = 0; i < newLength; i++ ){
    newField[i] = malloc(sizeof(*self->field[i]) * self->height );
    if(newField[i]==NULL){
      fprintf(stderr, "%s\n", "Es steht nicht genug Speicherplatz zur Verfuegung." );
      Release(self);
      return -1;
    }
  }
  for (size_t i = 0; i < newLength; i++) {
    for (size_t j = 0; j < self->height; j++) {
      if(i<difference){
        newField[i][j]=-1;
      }
      else newField[i][j]=self->field[i-difference][j];
    }
  }
  Release(self);
  self->length=newLength;
  self->field=newField;
  return 1;
}

int enlargeField(Game* self, stone base){
  int newLength=base.xValue+self->shifts+1;
  int **newField=malloc(sizeof(*self->field)*newLength);
  if(newField==NULL){
    fprintf(stderr, "%s\n", "Es steht nicht genug Speicherplatz zur Verfuegung.");
    Release(self);
    return -1;
  }
  for ( size_t i = 0; i < newLength; i++ ){
    newField[i] = malloc(sizeof(*self->field[i]) * self->height );
    if(newField[i]==NULL){
      fprintf(stderr, "%s\n", "Es steht nicht genug Speicherplatz zur Verfuegung.");
      Release(self);
      return -1;
    }
  }
  for (size_t i = 0; i <newLength; i++) {
    for (size_t j = 0; j < self->height; j++) {
      if(i>=self->length){
        newField[i][j]=-1;
      }
      else{
        newField[i][j]=self->field[i][j];
      }
    }
  }
  Release(self);
  self->length=newLength;
  self->field=newField;
  return 1;
}

int heightenField(Game* self){
  int **newField=malloc(sizeof(*self->field)*self->length);
  if(newField==NULL){
    fprintf(stderr, "%s\n", "Es steht nicht genug Speicherplatz zur Verfuegung.");
    Release(self);
    return -1;
  }
  for ( size_t i = 0; i < self->length; i++ ){
    newField[i] = malloc(sizeof(*self->field[i]) * self->height+1 );
    if(newField[i]==NULL){
      fprintf(stderr, "%s\n", "Es steht nicht genug Speicherplatz zur Verfuegung.");
      Release(self);
      return -1;
    }
  }
  for (size_t i = 0; i < self->length; i++) {
    for (size_t j = 0; j < self->height+1; j++) {
      if(j==self->height){
        newField[i][j]=-1;
      }
      else newField[i][j]=self->field[i][j];
    }
  }
  Release(self);
  self->height++;
  self->field=newField;
return 1;
}

int diagLUp(Game* self, int i, int j){
  if(i-3<0 || j+4>self->height || i<0 || j<0 || self->field[i][j]<0){
    return 0;
  }
  int col= self->field[i][j];
  if(self->field[i][j]>254){
    col=col-255;
  }
  int step=0;
  while(step<4){
    int comp=self->field[i][j];
    if(self->field[i][j]>254){
      comp=comp-255;
    }
    if(comp!=col){
      return 0;
    }
    i--;
    j++;
    step++;
  }
  return 1;
}

int diagRUp(Game* self, int i, int j){
  if(i+4>self->length || j+4>self->height || i<0 || j<0 || self->field[i][j]<0){
    return 0;
  }
  int col= self->field[i][j];
  if(self->field[i][j]>254){
    col=col-255;
  }
  int step=0;
  while(step<4){
    int comp=self->field[i][j];
    if(self->field[i][j]>254){
      comp=comp-255;
    }
    if(comp!=col){
      return 0;
    }
    i++;
    j++;
    step++;
  }
  return 1;
}

int markStone(Game* self, int i, int j){
  if(self->field[i][j]<255){
    self->field[i][j]+=255;
  }
  return 1;
}

int horizontal(Game* self, int i, int j){
  if(self->length<i+4 || i<0 || self->field[i][j]<0){
    return 0;
  }
  int col= self->field[i][j];
  if(col>254){
    col=col-255;
  }
  for (size_t k=i+1; k < i+4; k++) {
    int comp=self->field[k][j];
    if(comp>254){
      comp=comp-255;
    }
    if(comp!=col){
      return 0;
    }
  }
  return 1;
}

int vertical(Game* self, int i, int j){
  //Grenzkontrolle
  if(self->height<j+4 || j<0 || self->field[i][j]<0){
    return 0;
  }
  int col= self->field[i][j];
  if(self->field[i][j]>254){
    col=col-255;
  }
  for (size_t k=j+1; k < j+4; k++) {
    int comp=self->field[i][k];
    if(self->field[i][k]>254){
      comp=comp-255;
    }
    if(comp!=col){
      return 0;
    }
  }
  return 1;
}

int adaptRange(Game* self){
  while(self->mark.minX<0){
    self->mark.minX++;
  }
  while (self->mark.maxX>self->length-1) {
    self->mark.maxX--;
  }
  while(self->mark.minY<0){
    self->mark.minY++;
  }
  return 1;
}

int trigger(Game* self, int x, int y){
  if(self->length>3){
    if(self->height>3){
      int step=0;
      int k=x-3;
      int l=y-3;
      while(step<4){
        if(k>-1 && l>-1){
          if(diagRUp(self, k, l)){
            self->mark.minX=x-3;
            self->mark.minY=y-3;
            self->mark.maxX=x+3;
            self->mark.maxY=y+3;
            self->mark.notEmpty=1;
            adaptRange(self);
            return 1;
          }
        }
        k++;
        l++;
        step++;
      }
      step=0;
      k=x+3;
      l=y-3;
      while (step<4) {
        if(k<self->length && l>-1){
          if(diagLUp(self, k, l)){
            self->mark.minX=x-3;
            self->mark.minY=y-3;
            self->mark.maxX=x+3;
            self->mark.maxY=y+3;
            self->mark.notEmpty=1;
            adaptRange(self);
            return 1;
          }
        }
        k--;
        l++;
        step++;
      }
    }
    int k=x-3;
    while(k<x+1){
      if(k>-1){
        if(horizontal(self, k, y)){
          self->mark.minX=x-3;
          self->mark.minY=y-3;
          self->mark.maxX=x+3;
          self->mark.maxY=y+3;
          self->mark.notEmpty=1;
          adaptRange(self);
          return 1;
        }
      }
      k++;
    }
  }
  if(self->height>3){
    if(vertical(self, x, y-3)){
      //nur vertikale Linie fuehrt zu keinen weiteren Linien
      self->field[x][y-3]=-1;
      self->field[x][y-2]=-1;
      self->field[x][y-1]=-1;
      self->field[x][y]=-1;
      return 0;
    }
  }
  return 0;
}

int nextFall(Game* self, stone base){
  int x=0;
  int y=0;
  if(base.xValue*(-1)>self->shifts){
    shiftField(self,base);
    x=0;
    y=0;
  }
  else if(base.xValue>self->length-self->shifts-1){
    enlargeField(self,base);
    x=self->length-1;
    y=0;
  }
  else if(self->field[base.xValue+self->shifts][0]>-1){
    for (size_t j = 0; j < self->height; j++) {
      if(self->field[base.xValue+self->shifts][j]==-1){
        x=base.xValue+self->shifts;
        y=j;
        break;
      }
      if(j==self->height-1){
        heightenField(self);
        x=base.xValue+self->shifts;
        y=self->height-1;
        break;
      }
    }
  }
  else {
    x=base.xValue+self->shifts;
    y=0;
  }
  self->field[x][y]=base.colour;
  // Ueberpruefung, ob der fallende Stein ein Aufloesen verursacht
  return trigger(self, x, y);
}
//fuer RUP und horizontale Linien
int confRange(Game* self, int i, int j){
  if(i-3<self->mark.minX){
    self->mark.minX=i-3;
  }
  if(i+6>self->mark.maxX){
    self->mark.maxX=i+6;
  }
  if(j-3<self->mark.minY){
    self->mark.minY=j-3;
  }
  self->mark.maxY=self->height-1;
  return 1;
}

int LUPconfRange(Game* self, int i, int j){
  if(i-6<self->mark.minX){
    self->mark.minX=i-6;
  }
  else if(i+3>self->mark.maxX){
    self->mark.maxX=i+3;
  }
  if(j-3<self->mark.minY){
    self->mark.minY=j-3;
  }
  self->mark.maxY=self->height-1;
  return 1;
}

int VconfRange(Game* self, int i, int j){
  if(i-3<self->mark.minX){
    self->mark.minX=i-3;
  }
  if(i+3>self->mark.maxX){
    self->mark.maxX=i+3;
  }
  if(j-3<self->mark.minY){
    self->mark.minY=j-3;
  }
  self->mark.maxY=self->height-1;
  return 1;
}

int dissolve(Game* self, int minX, int maxX, int minY, int maxY){
  int highStone;
  for (size_t i = minX; i <= maxX; i++){
      highStone=minY;
      for (size_t j = minY; j <= maxY; j++) {
          if(self->field[i][j]>254){
            self->field[i][j]=-1;
            if(self->field[i][highStone]>-1){
              highStone=j;
            }
          }
          if(self->field[i][j]>-1 && self->field[i][highStone]==-1){
            self->field[i][highStone]=self->field[i][j];
            self->field[i][j]=-1;
            highStone++;
          }
      }
  }
  return 1;
}

int dissolveLines(Game* self){
  int minX= self->mark.minX;
  int maxX= self->mark.maxX;
  int minY=self->mark.minY;
  int maxY=self->mark.maxY;
  int reset=0;
  while(self->mark.notEmpty!=0){
    self->mark.notEmpty=0;
    // Markierungen zuruecksetzen:
    reset=1;

    for (size_t i = minX; i <= maxX; i++){
      for (size_t j = minY; j <= maxY; j++) {
        if(vertical(self, i, j)!=0){
          markStone(self, i, j);
          markStone(self, i, j+1);
          markStone(self, i, j+2);
          markStone(self, i, j+3);
          self->mark.notEmpty=1;
          if(reset){
            self->mark.minX=i-3;
            self->mark.maxX=i+3;
            self->mark.minY=j-3;
            self->mark.maxY=self->height-1;
            reset=0;
          }
          else VconfRange(self, i, j);
        }
        if(diagLUp(self, i, j)!=0){
          markStone(self, i, j);
          markStone(self, i-1, j+1);
          markStone(self, i-2, j+2);
          markStone(self, i-3, j+3);
          self->mark.notEmpty=1;
          if(reset){
            self->mark.minX=i-6;
            self->mark.maxX=i+3;
            self->mark.minY=j-3;
            self->mark.maxY=self->height-1;
            reset=0;
          }
          else LUPconfRange(self, i, j);
        }
        if(diagRUp(self, i, j)!=0){
          markStone(self, i, j);
          markStone(self, i+1, j+1);
          markStone(self, i+2, j+2);
          markStone(self, i+3, j+3);
          self->mark.notEmpty=1;
          if(reset){
            self->mark.minX=i-3;
            self->mark.maxX=i+6;
            self->mark.minY=j-3;
            self->mark.maxY=self->height-1;
            reset=0;
          }
          else confRange(self, i, j);
        }
        if(horizontal(self, i, j)!=0){
          markStone(self, i, j);
          markStone(self, i+1, j);
          markStone(self, i+2, j);
          markStone(self, i+3, j);
          self->mark.notEmpty=1;
          if(reset){
            self->mark.minX=i-3;
            self->mark.maxX=i+6;
            self->mark.minY=j-3;
            self->mark.maxY=self->height-1;
            reset=0;
          }
          else confRange(self, i, j);
        }
      }
    }
    adaptRange(self);
    minX= self->mark.minX;
    maxX= self->mark.maxX;
    minY=self->mark.minY;
    maxY=self->mark.maxY;
    if(self->mark.notEmpty>0){
      dissolve(self, minX, maxX, minY, maxY);
    }
}
return 1;
}

void printField(Game* self){
  for (size_t i = 0; i < self->length; i++) {
    printf("%ld.Spalte: ",i );
    for (size_t j = 0; j < self->height; j++) {
        printf("%d ",self->field[i][j] );
        if(j==self->height-1){
          printf("%s\n","");
        }
    }
  }
  printf("Length:%d Height:%d Shifts:%d\n",self->length, self->height, self->shifts );
}

int starBlank(int* self){
  while(*self==32){
    *self=getchar();
  }
  return 1;
}

int Colour(int* self, stone* element){
  if(*self>57 || *self<48){
    fprintf(stderr, "%s\n", "Die Eingabe ist ungueltig.");
    return -1;
  }
  element->colour=0;
  //fuehrende Nullen
  while(*self==48){
    *self=getchar();
  }
  while(*self<58 && *self>47){
    element->colour=element->colour*10 +(*self-48);
    *self=getchar();
  }
  if(element->colour>254){
    fprintf(stderr, "%s\n", "Die Farbe eines Steines ist zu groesser als 254.");
    return -1;
  }
  return 1;
}

int plusBlanks(int* self){
  if(*self!=32){
    fprintf(stderr, "%s\n", "Die Eingabe ist ungueltig.");
    return -1;
  }
  while(*self==32){
    *self=getchar();
  }
  return 1;
}

int Int(int* self, stone* element){
  int sign= 1;
  if(*self==45){
    sign=-1;
    *self=getchar();
  }
  if(*self>57 || *self<48){
    fprintf(stderr, "%s\n", "Die Eingabe ist ungueltig.");
    return -1;
  }
  element->xValue=0;
  while(*self==48){
    *self=getchar();
  }
  while(*self<58 && *self>47){
    element->xValue=element->xValue*10 +(*self-48);
    *self=getchar();
  }
  element->xValue=element->xValue*sign;
  return 1;
}

int checkInput(int* self, stone* element){
  starBlank(self);
  if (Colour(self,element)!=1) {
    return -1;
  }
  if (plusBlanks(self)!=1) {
    return -1;
  }
  if (Int(self, element)!=1) {
    return -1;
  }
  starBlank(self);
  if (*self!=10 && *self!=EOF) {
    fprintf(stderr, "%s\n", "Eine Zeile enthaelt zu viele Argumente.");
    return -1;
    }
  else return 1;
}

void output(Game* self){
  for (size_t i = 0; i < self->length; i++) {
    for (size_t j = 0; j < self->height; j++) {
      if(self->field[i][j]>-1){
        printf("%d %ld %ld\n", self->field[i][j], i-self->shifts, j);
      }
    }
  }
}

int main(int argc, char *argv[]) {
  Game candy;
  GameInit(&candy);
  stone base;
  int input=getchar();
  while(input!=10 && input!=EOF){
    if(checkInput(&input, &base)==1){
    if(nextFall(&candy, base)){
      dissolveLines(&candy);
    }
    input=getchar();
    }
    else{
      Release(&candy);
      return -1;
    }
  }
  output(&candy);
  Release(&candy);
  return 0;
}
