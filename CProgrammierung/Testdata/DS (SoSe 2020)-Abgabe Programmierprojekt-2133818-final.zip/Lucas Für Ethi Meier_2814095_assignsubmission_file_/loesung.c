/* Cms: meierluc
 * Matrikelnummer: 581726
 * 
 */



#include <stdlib.h>
#include <stdio.h>



//globale variablen

// Structs
//speichert in einem array in der Reihenfolge alle Spielsteine dynamisch
struct zwischenspeicher_struct
{
	int farbe; //Zahl von 0 bis 254
	long int x_koordinate; //x koordinate
};

//speichert in einem array in sortierter reihenfolge alle x Werte
struct x_liste_struct
{
   long int x_koordinate; //x koordinate
   long int y_liste_groesse; //Wieviele Werte sind eingetragen

};

//speichert in einem array die zu loeschenden Spielsteine
struct loesch_liste_struct
{
	long int x_koordinate; //x koordinate
	long int y_koordinate; //y koordinate
};

//Initialisierung
struct zwischenspeicher_struct *zwischenspeicher = NULL;
long int zwischenspeicher_groesse = 0; //Wieviele Werte sind gespeichert , aktuell Null
long int zwischenspeicher_max = 0; //Wieviele Werte koenne maximal gespeichert werten ohne weiteres malloc

struct x_liste_struct *x_liste = NULL;
long int x_liste_groesse = 0; //Wieviele Werte sind gespeichert , aktuell Null
long int x_liste_max = 0; //Wieviele Werte koenne maximal gespeichert werten ohne weiteres malloc

int *y_liste;
long int y_liste_hoehe = 0; //Wieviele Werte sind gespeichert , aktuell Null
long int y_liste_max = 0; //Wieviele Werte koenne maximal gespeichert werten ohne weiteres malloc

struct loesch_liste_struct *loesch_liste = NULL;
long int loesch_liste_groesse = 0; //Wieviele Werte sind gespeichert , aktuell Null
long int loesch_liste_max = 0; //Wieviele Werte koenne maximal gespeichert werten ohne weiteres malloc


struct loesch_liste_struct *such_liste = NULL;
long int such_liste_groesse = 0; //Wieviele Werte sind gespeichert , aktuell Null
long int such_liste_max = 0; //Wieviele Werte koenne maximal gespeichert werten ohne weiteres malloc



//prototypen
void fehler_funktion(); //bei einem Fehler soll die Fehler Funktion das Programm beenden und eine Antwort geben
void zwischenspeicher_speicher_management(int farbe, long int x_koordinate); //organisiert den dynamischen Speicher fuer die Zwischen speicherliste und setzt die Werte fuer die x koordinate und die Farbe
void x_liste_speicher_management(long int x_koordinate);//organisiert den dynamischen Speicher fuer die X speicherliste und setzt die Werte fuer die x koordinate und die X liste groesse auf den richtigen Wert
void free_all(); // gibt den reservierten Speicher frei von allen listen
int x_liste_vergleich(const void* a, const void* b); //Hilfsfunktion fuer qsort in x_liste_formatieren gibt -1, 1 oder 0 zurueck
void x_liste_ausgeben(); //gibt die xliste auf der Komando zeile aus
void x_liste_formatieren(); //sortiert die xliste; loescht duplikate; passt den speicherbedarf fuer die xwerte an und reserviert passend grossen Speicher fuer die yliste
long int wert_eintragen(long int x_koordinate, int farbe); //Setzt die Werte in der yliste
void reihe_suche(long int id, long int y_koordinate, int farbe, int richtung_a, int richtung_b); //sucht eine Reihe anhand der Richtung in der die Farbe und Anzahl passen
void spiel_logik(); //fuehrt die Funktionen aus um die Spiellogik zu gewaehrleisten
void y_liste_ausgeben(); //gibt die yliste auf der Komando zeile aus
void loesch_liste_ausgeben();//gibt die loeschliste auf der Komando zeile aus
void element_loeschen(long int x_koordinate, long int y_koordinate); //loescht einen Spielstein
void loesch_funktion(); // fuert element loeschen aus auf der ganzen Loeschliste
int loesch_liste_vergleich(const void* a, const void* b); //Hilfsfunktion fuer qsort in loesch_liste_formatieren gibt -1, 1 oder 0 zurueck
void loesch_liste_formatieren(); //sortiert die loeschliste liste und loescht duplikate
void end_ausgabe(); //gibt das ergebnis auf der Komando zeile aus
void such_liste_speicher_management(long int x_koordinate, long int y_koordinate); //organisiert den dynamsicher Speicher fuer die suchliste um die elemente spaeter zu loeschen
void such_liste_formatieren(); //suchtliste formatieren mit selber fktweise wie loeschliste formatieren

int main()
{
    char input;
    int vorzeichen;
    int farbe_input;
    long int x_koordinate_input;
    
    do
    {
        //PHASE 0
        input = getchar();
        farbe_input = 0;
        vorzeichen = 0;
        x_koordinate_input = 0;

        //END OF FILE
        if(input == EOF)
        {
            break;
        }
        
        //PHASE 1 farbe
        //Farbe wird zeichen fuer Zeichen eingelesen und eine int Zahl erstellt
        do
        {
            //falls input keine Zahl vom Typ char ist ist es eine fehlerhafte eingabe
            if(!(input >= 48 && input <= 57)) //Zahlen 0 bis 9
            {
                fprintf(stderr,"Die Eingabe muss eine Zahl sein\n");
                fehler_funktion();
            }
            //Umwandlung in int
            farbe_input = (farbe_input * 10) + (input-48);
            //falls farbe groesser 254 ist fehlerhafte eingabe
            if (farbe_input > 254 || farbe_input < 0)
            {
                fprintf(stderr,"Die Eingabe muss eine Zahl sein im Werte Bereich von 0 bis 254\n");
                fehler_funktion();
            }
            input = getchar();
        }while(input != ' ');


        //PHASE 2 Leerzeichen
        //Leerzeichen werden ignoriert
        while(input == ' ' )
        {
            input = getchar();
        }
        
        //PHASE 3.1 -
        //ueberuefen ob x negativ ist
        if (input == '-')
        {
            vorzeichen = 1;
            input = getchar();
        }

        //PHASE 3.2 X koordinate
        //x koordinate wird zeichen fuer Zeichen eingelesen und eine long int Zahl erstellt
        do
        {
            //falls input keine Zahl vom Typ char ist ist es eine fehlerhafte eingabe
            if(!(input >= 48 && input <= 57)) //Zahlen 0 bis 9
            {
                fprintf(stderr,"Die Eingabe muss eine Zahl sein\n");
                fehler_funktion();
            }
            //Umwandlung in long int
            x_koordinate_input = (x_koordinate_input * 10) + (input-48);
            if (x_koordinate_input > 1048576 || x_koordinate_input < -1048576)
            {
                fprintf(stderr,"Die Eingabe muss eine Zahl sein im Werte Bereich von -1048576 bis 1048576\n");
                fehler_funktion();
            }
            input = getchar();
        }while(input != '\n' && input != EOF);

        //Vorzeichen setzen
        if (vorzeichen == 1)
        {
            x_koordinate_input*=-1;
        }

        
        //printf("fuege hinzu: farbe %i, x_koordinate: %li\n", farbe_input, x_koordinate_input);
        //Listen Werte zuweisung
        zwischenspeicher_speicher_management(farbe_input, x_koordinate_input);
        x_liste_speicher_management(x_koordinate_input);
        
    } while(input != EOF);


    //Liste managen
    x_liste_formatieren();
    //ausfueren der Spielmechanik
    spiel_logik();
    //y_liste_ausgeben();
    //loesch_liste_formatieren();
    //loesch_liste_ausgeben();
    //Ergebnis ausgeben
    end_ausgabe();
    //Speicher freigeben
    free_all();
}

//wird bei fehlerhafter eingabe oder fehlerhaftem Programmverhalten ausgefuehrt
void fehler_funktion()
{
    free_all();
    exit(-1);
}

//Gibt den Speicher aller listen frei bei denen Speicher allociiert wurde
void free_all()
{
	if(x_liste != NULL)
    {
    	free(x_liste);
    }
    if(y_liste != NULL)
    {
    	free(y_liste);
    }
    if(zwischenspeicher!=NULL)
    {
    	free(zwischenspeicher);
    }
    if(loesch_liste!=NULL)
    {
    	free(loesch_liste);
    }
    if(such_liste!=NULL)
    {
    	free(such_liste);
    }
}

//haelt eine liste aller Spielsteine in der Reihenfolge der Eingabe
void zwischenspeicher_speicher_management(int farbe, long int x_koordinate)
{
	if(zwischenspeicher == NULL)
	{
		if(zwischenspeicher_max == 0)
		{
            //Initialisierung
			zwischenspeicher_max = 8;
			zwischenspeicher = (struct zwischenspeicher_struct*) malloc(zwischenspeicher_max * sizeof(struct zwischenspeicher_struct));
            //ueberuefen ob malloc gescheitert ist
			if(zwischenspeicher == NULL)
			{
                fprintf(stderr,"malloc konnte keinen Speicher reservieren für den Zwischenspeicher\n");
				fehler_funktion();
				return;
			}
			zwischenspeicher_groesse=0;
		}
		else
		{
            fprintf(stderr,"Fehler bei der Berechnung der maximalen Anzahl an Elementen im Zwischenspeicher\n");
			fehler_funktion();
			return;
		}
	}
	//Platz immer verdoppeln sobald der reservierte Speicher voll ist
	else if(zwischenspeicher_groesse >= zwischenspeicher_max)
	{
		zwischenspeicher_max*=2;
		zwischenspeicher = realloc(zwischenspeicher, zwischenspeicher_max * sizeof(struct zwischenspeicher_struct));
		if(zwischenspeicher == NULL)
		{
            fprintf(stderr,"realloc konnte keinen Speicher reservieren\n");
			fehler_funktion();
			return;
		}
	}
	//Werte zuweisung
	zwischenspeicher[zwischenspeicher_groesse].x_koordinate = x_koordinate;
	zwischenspeicher[zwischenspeicher_groesse].farbe = farbe;
	zwischenspeicher_groesse++;
	return;
}

//haelt eine liste aller xkoordinaten in der Reihenfolge der Eingabe mit Duplikaten
void x_liste_speicher_management(long int x_koordinate)
{
	if(x_liste == NULL)
	{
		if(x_liste_max == 0)
		{
			x_liste_max = 8;
			x_liste = (struct x_liste_struct*) malloc(x_liste_max * sizeof(struct x_liste_struct));
            //ueberuefen ob malloc gescheitert ist
			if(x_liste == NULL)
			{
                fprintf(stderr,"malloc konnte keinen Speicher reservieren fuer die x_liste\n");
				fehler_funktion();
				return;
			}
			x_liste_groesse=0;
		}
		else
		{
            fprintf(stderr,"Fehler bei der x_liste_max Berechnung\n");
			fehler_funktion();
			return;
		}
	}
	//Platz immer verdoppeln sobald der reservierte Speicher voll ist
	else if(x_liste_groesse >= x_liste_max)
	{
		x_liste_max*=2;
		x_liste = realloc(x_liste, x_liste_max * sizeof(struct x_liste_struct));
        //ueberuefen ob malloc gescheitert ist
		if(x_liste == NULL)
		{
            fprintf(stderr,"realloc konnte keinen Speicher reservieren fuer x_liste\n");
			fehler_funktion();
			return;
		}
	}
	//Werte zuweisung
	x_liste[x_liste_groesse].x_koordinate = x_koordinate;
	x_liste_groesse++;
	return;
}


//fuer qsort muss eingabe const sein dadurch muss eingabe gecastet werden und wird dann verglichen
int x_liste_vergleich(const void* a, const void* b)
{
	struct x_liste_struct *ia = (struct x_liste_struct *)a;
	struct x_liste_struct *ib = (struct x_liste_struct *)b;

	if (ia->x_koordinate > ib->x_koordinate)
		return 1;
	else if (ia->x_koordinate < ib->x_koordinate)
		return -1;
	return 0;
}

//fuer qsort muss eingabe const sein dadurch muss eingabe gecastet werden und wird dann verglichen
int loesch_liste_vergleich(const void* a, const void* b)
{
	struct loesch_liste_struct *ia = (struct loesch_liste_struct *)a;
	struct loesch_liste_struct *ib = (struct loesch_liste_struct *)b;

	if (ia->x_koordinate > ib->x_koordinate)
		return 1;
	else if (ia->x_koordinate < ib->x_koordinate)
		return -1;

	if (ia->y_koordinate > ib->y_koordinate)
		return -1;
	else if (ia->y_koordinate < ib->y_koordinate) 
		return 1;
	return 0;
}

//sortieren der elemente des arrays loeschen von Duplikaten und anpassen des Speicherbedarfs fuer die xliste und die yliste
void x_liste_formatieren()
{
	if(x_liste == NULL)
	{
		return;
	}
	//printf("vor qsort:\n");
	//x_liste_ausgeben();
	qsort(x_liste, x_liste_groesse, sizeof(struct x_liste_struct), x_liste_vergleich);
	//printf("nach qsort:\n");
	//x_liste_ausgeben();

	long int x_koordinate_zwischenspeicher = x_liste[0].x_koordinate;
	long int anzahl_x_werte=1; 
	long int anzahl_y_werte=1; 
	long int anzahl_y_werte_max=1;

	for(long int i=1; i<x_liste_groesse; i++)
	{
		if(x_koordinate_zwischenspeicher == x_liste[i].x_koordinate)
		{
			anzahl_y_werte++;
			continue;
		}
		else
		{
			if(anzahl_y_werte>anzahl_y_werte_max)
			{
				anzahl_y_werte_max = anzahl_y_werte;
			}
			anzahl_y_werte=1;
			anzahl_x_werte++;
			x_koordinate_zwischenspeicher=x_liste[i].x_koordinate;
		}
	}
	if(anzahl_y_werte>anzahl_y_werte_max)
	{
		anzahl_y_werte_max = anzahl_y_werte;
	}

	//printf("anzahl x_werte: %li, anzahl y_werte: %li\n", anzahl_x_werte, anzahl_y_werte_max);

	struct x_liste_struct *x_liste2 = x_liste;
	long int x_liste_groesse2 = x_liste_groesse;

	x_liste = NULL;
	x_liste_groesse = 0;
	x_liste_max = anzahl_x_werte;
	x_liste = (struct x_liste_struct*) malloc(x_liste_max * sizeof(struct x_liste_struct));

	x_koordinate_zwischenspeicher=x_liste2[0].x_koordinate;
	x_liste[x_liste_groesse].x_koordinate =	x_liste2[0].x_koordinate;
	x_liste[x_liste_groesse].y_liste_groesse = 0;
	x_liste_groesse++;	
	for(long int i=1; i<x_liste_groesse2; i++)
	{
		if(x_koordinate_zwischenspeicher != x_liste2[i].x_koordinate)
		{	
			x_liste[x_liste_groesse].x_koordinate =	x_liste2[i].x_koordinate;
			x_liste[x_liste_groesse].y_liste_groesse = 0;
			x_liste_groesse++;	
			x_koordinate_zwischenspeicher=x_liste2[i].x_koordinate;
		}
	}
	free(x_liste2);
	//printf("groesse: %li, max: %li\n", x_liste_groesse, x_liste_max);

	y_liste = NULL;
	y_liste_max = anzahl_y_werte_max * anzahl_x_werte;
	y_liste_hoehe = anzahl_y_werte_max;

	y_liste = (int *) calloc(y_liste_max, sizeof(int));

	//printf("x_liste formatiert:\n");
	//x_liste_ausgeben();
}

//sortieren
void loesch_liste_formatieren()
{
	if(loesch_liste == NULL)
	{
		return;
	}
	//printf("vor qsort:\n");
	//loesch_liste_ausgeben();
	qsort(loesch_liste, loesch_liste_groesse, sizeof(struct loesch_liste_struct), loesch_liste_vergleich);
	//printf("nach qsort:\n");
	//loesch_liste_ausgeben();

	long int anzahl = 1;
	long int x_koordinate_temp = loesch_liste[0].x_koordinate;
	long int y_koordinate_temp = loesch_liste[0].y_koordinate;
	for(long int i=1; i<loesch_liste_groesse; i++)
	{
		if(x_koordinate_temp != loesch_liste[i].x_koordinate || y_koordinate_temp != loesch_liste[i].y_koordinate)
		{
			loesch_liste[anzahl].x_koordinate = loesch_liste[i].x_koordinate;
			loesch_liste[anzahl].y_koordinate = loesch_liste[i].y_koordinate;
			x_koordinate_temp = loesch_liste[i].x_koordinate;
			y_koordinate_temp = loesch_liste[i].y_koordinate;
			anzahl++;
		}
	}
	loesch_liste_groesse = anzahl;
	//printf("loesch liste nach formatieren:\n");
	//loesch_liste_ausgeben();
}

//ausgabe der xliste auf die Komandozeile
void x_liste_ausgeben()
{
	printf("x_liste:");
	for(long int i=0; i<x_liste_groesse; i++)
	{
		printf(" %li",x_liste[i].x_koordinate);
	}
	printf("\n");
}

//ausgabe der yliste auf die Komandozeile
void y_liste_ausgeben()
{
	if(x_liste != NULL && y_liste != NULL)
	{
		for(long int i = 0; i<x_liste_groesse; i++)
		{
			printf("x %li (%li):",x_liste[i].x_koordinate, x_liste[i].y_liste_groesse);
			for(long int j=0; j<x_liste[i].y_liste_groesse; j++)
			{
				printf(" %i",y_liste[i*y_liste_hoehe + j]-1);
			}
			printf("\n");
		}
	}
}

//ausgabe des Ergebisses auf die Komandozeile
void end_ausgabe()
{
	if(x_liste != NULL && y_liste != NULL)
	{
		for(long int i = 0; i<x_liste_groesse; i++)
		{
			for(long int j=0; j<x_liste[i].y_liste_groesse; j++)
			{
				printf("%i %li %li\n",y_liste[i*y_liste_hoehe + j]-1, x_liste[i].x_koordinate, j);
			}
		}
	}
}

//ausgabe der loeschliste auf die Komandozeile
void loesch_liste_ausgeben()
{
	if(loesch_liste != NULL)
	{
		printf("loesch liste\n");
		for(long int i = 0; i<loesch_liste_groesse; i++)
		{
			printf("x: %li, y: %li\n",loesch_liste[i].x_koordinate, loesch_liste[i].y_koordinate);
		}
	}
}

//Wert Zuweisung der Farben an die richtige Stelle der yliste
long int wert_eintragen(long int x_koordinate, int farbe)
{
	struct x_liste_struct key = { .x_koordinate = x_koordinate};
	struct x_liste_struct *element = bsearch(&key, x_liste, x_liste_groesse, sizeof(struct x_liste_struct), x_liste_vergleich);
	if(element == NULL)
	{
        fprintf(stderr,"Es wurde kein Wert gefunden der Eingetragen werden soll\n");
		fehler_funktion();
		return -1;
	}
	long int id =(long int)(element-x_liste);
	
	//printf("x: %li, id: %li, y: %li, y-max: %li, farbe %i\n", x_koordinate, element->y_liste_groesse, id, y_liste_hoehe, farbe);
	
	y_liste[id*y_liste_hoehe + element->y_liste_groesse] = farbe+1;
	element->y_liste_groesse++;
	return element->y_liste_groesse-1;
}

//Speichert alle zu loeschenden Spielsteine in einem dynamischen array
void loesch_liste_speicher_management(long int x_koordinate, long int y_koordinate)
{
	if(loesch_liste == NULL) 
	{
		if(loesch_liste_max == 0)
		{
			loesch_liste_max = 8;
			loesch_liste = (struct loesch_liste_struct*) malloc(loesch_liste_max * sizeof(struct loesch_liste_struct));
			if(loesch_liste == NULL)
			{
                fprintf(stderr,"malloc konnte keinen Speicher reservieren fuer loesch_liste\n");
				fehler_funktion();
				return;
			}
			loesch_liste_groesse=0;
		}
		else
		{
            fprintf(stderr,"Fehler bei der Berechnung von loesch_liste_max\n");
			fehler_funktion();
			return;
		}
	}
	//Speicher verdoppeln
	else if(loesch_liste_groesse >= loesch_liste_max)
	{
		loesch_liste_max*=2;
		loesch_liste = realloc(loesch_liste, loesch_liste_max * sizeof(struct loesch_liste_struct));
		if(loesch_liste == NULL)
		{
            fprintf(stderr,"realloc konnte keinen Speicher reservieren fuer loesch_liste\n");
			fehler_funktion();
			return;
		}
	}
	//werte zuweisung
	loesch_liste[loesch_liste_groesse].x_koordinate = x_koordinate;
	loesch_liste[loesch_liste_groesse].y_koordinate = y_koordinate;
	loesch_liste_groesse++;
	return;
}

//Speichert alle zu testenden Spielsteine in einem dynamischen array
void such_liste_speicher_management(long int x_koordinate, long int y_koordinate)
{
	if(such_liste == NULL) 
	{
		if(such_liste_max == 0)
		{
			such_liste_max = 8;
			such_liste = (struct loesch_liste_struct*) malloc(such_liste_max * sizeof(struct loesch_liste_struct));
			if(such_liste == NULL)
			{
                fprintf(stderr,"malloc konnte keinen Speicher reservieren fuer such_liste\n");
				fehler_funktion();
				return;
			}
			such_liste_groesse=0;
		}
		else
		{
            fprintf(stderr,"Fehler bei der Berechnung von such_liste_max\n");
			fehler_funktion();
			return;
		}
	}
	//Speicher verdoppeln
	else if(such_liste_groesse >= such_liste_max)
	{
		such_liste_max*=2;
		such_liste = realloc(such_liste, such_liste_max * sizeof(struct loesch_liste_struct));
		if(such_liste == NULL)
		{
            fprintf(stderr,"realloc konnte keinen Speicher reservieren fuer such_liste\n");
			fehler_funktion();
			return;
		}
	}
	//werte zuweisung
	such_liste[such_liste_groesse].x_koordinate = x_koordinate;
	such_liste[such_liste_groesse].y_koordinate = y_koordinate;
	such_liste_groesse++;
	return;
}

// Sucht von einem bestimmten Punkt Sterfoermig die Reihen in dem es in den beiden Diagonalen richtungen und Senkrecht und Wagerecht Reihensuche ausfuehrt
void stern_suche(long int x_koordinate, long int y_koordinate)
{

	long int id = x_koordinate;
	int farbe = y_liste[id*y_liste_hoehe + y_koordinate];
	if(farbe == 0)
	{
		return;
	}

	//printf("sternsuche: id: %li, y: %li\n", id, y_koordinate);
	//printf("0 1\n");
	reihe_suche(id, y_koordinate, farbe, 0, 1); //oben
	//printf("1 0\n");
	reihe_suche(id, y_koordinate, farbe, 1, 0); //rechts
	//printf("1 1\n");
	reihe_suche(id, y_koordinate, farbe, 1, 1); //oben rechts
	//printf("-1 1\n");
	reihe_suche(id, y_koordinate, farbe, 1, -1); //unten rechts
}

//sucht in tiefe 3 anhand einer bestimmten richtung eine Reihe gleicher Farbe in der Richtung und der entgegengesetzten richtung und Speichert die treffer in einer temporaeren Liste ab falls die temporaere Liste >= 4 elemente enhaelt wird es an die loeschliste uebergeben
void reihe_suche(long int id, long int y_koordinate, int farbe, int richtung_a, int richtung_b)
{
	int tiefe = 3;
	int treffer = 0;
	struct loesch_liste_struct temp_liste[7];
	
	long int zeiger_x = id;
	long int zeiger_y = y_koordinate;
	temp_liste[treffer].x_koordinate = zeiger_x;
	temp_liste[treffer].y_koordinate = zeiger_y;
	treffer++;

	for(int i=0; i<tiefe; i++)
	{
		zeiger_x+=richtung_a;
		zeiger_y+=richtung_b;
		if(zeiger_x<0 || zeiger_x>=x_liste_max)
		{
			//printf("x out of bounds\n");
			break;
		}
		long int abstand = x_liste[zeiger_x].x_koordinate - x_liste[zeiger_x-richtung_a].x_koordinate;
		abstand*=abstand;
		//printf("abstand %li\n", abstand);
		if(abstand != 1 && abstand != 0)
		{
			//printf("skipped an x\n");
			break;
		}
		else if(zeiger_y < 0 || zeiger_y >= y_liste_hoehe)
		{
			//printf("y out of bounds\n");
			break;
		}
		if(y_liste[zeiger_x*y_liste_hoehe + zeiger_y] != farbe)
		{
			//printf("falsche farbe\n");
			break;
		}

		//printf("neuer zeiger: x: %li, coor: %li, y: %li\n", zeiger_x, x_liste[zeiger_x].x_koordinate, zeiger_y);
		//Werte zuweisung in temporaerer Liste 
		temp_liste[treffer].x_koordinate = zeiger_x;
		temp_liste[treffer].y_koordinate = zeiger_y;
		treffer++;
	}

	richtung_a*=-1;
	richtung_b*=-1;
	zeiger_x = id;
	zeiger_y = y_koordinate;

	for(int i=0; i<tiefe; i++)
	{
		zeiger_x+=richtung_a;
		zeiger_y+=richtung_b;
		if(zeiger_x<0 || zeiger_x>=x_liste_max)
		{
			//printf("x out of bounds\n");
			break;
		}
		long int abstand = x_liste[zeiger_x].x_koordinate - x_liste[zeiger_x-richtung_a].x_koordinate;
		abstand*=abstand;
		//printf("abstand %li, xa: %li, xb: %li\n", abstand, x_liste[zeiger_x].x_koordinate, x_liste[zeiger_x-richtung_a].x_koordinate);
		if(abstand != 1 && abstand != 0)
		{
			//printf("skipped an x\n");
			break;
		}
		else if(zeiger_y < 0 || zeiger_y >= y_liste_hoehe)
		{
			//printf("y out of bounds\n");
			break;
		}
		if(y_liste[zeiger_x*y_liste_hoehe + zeiger_y] != farbe)
		{
			//printf("falsche farbe\n");
			break;
		}

		//printf("neuer zeiger: x: %li, coor: %li, y: %li\n", zeiger_x, x_liste[zeiger_x].x_koordinate, zeiger_y);
		temp_liste[treffer].x_koordinate = zeiger_x;
		temp_liste[treffer].y_koordinate = zeiger_y;
		treffer++;
	}

	if(treffer >= 4)
	{
		//treffer liste in loesch liste eintragen
		for(int i=0; i<treffer; i++)
		{
			//printf("x-koordinate: %li y-koordinate: %li \n", temp_liste[i].x_koordinate, temp_liste[i].y_koordinate);
			loesch_liste_speicher_management(temp_liste[i].x_koordinate, temp_liste[i].y_koordinate);
		}
	}
}

//loescht element weise alle elemente in der loeschliste
void loesch_funktion()
{
	if(loesch_liste == NULL || loesch_liste_groesse == 0)
	{
		return;
	}

	while(loesch_liste_groesse != 0)
	{
		loesch_liste_formatieren();


		for(long int i=0; i<loesch_liste_groesse; i++)
		{
			element_loeschen(loesch_liste[i].x_koordinate, loesch_liste[i].y_koordinate);
		}
		loesch_liste_groesse = 0;
        //suchliste wird formatiert
        //such_liste_formatieren();
        /*TODO
         * Idee for schleife
         * 
         * Fall : Diagonalen fuer (links und rechts) suche elemente mit iterativen ykoordinate und xwert ueber einem Bereich
         *                   
         * BeispielFall: x : 0 1 2 3 4 5 6
         *               y : 0 1 2 3 4 5 6
         * mache Sternensuche auf der Diegonalen und Sternensuche auf der senkrechten von (0,0) und (6,6)
         *
         * Fall : Senkrechte suche elemente mit iterativen ykoordinate und gleichem xwert
         *                   
         * BeispielFall: x : 0 0 0 0 0 0 0
         *               y : 0 1 2 3 4 5 6
         * starte Sternensuche ab dem kleinsten ywert
         * 
         * Fall : Wagerecht suche elemente mit gleicher ykoordinate und xwert ueber einem Bereich
         *                  loesche alle elemente ausser kleinstem xwert und groesstem xwert 
         * BeispielFall: x : 0 1 2 3 4 5 6
         *               y : 7 7 7 7 7 7 7
         * Ergebnis :    x : 0 6
         *               y : 7 7
         * mache Sternensuche auf den beiden Senkrechten
         * 
         * 
         */
        
		for(long int i=0; i<such_liste_groesse; i++)
		{
			stern_suche(such_liste[i].x_koordinate, such_liste[i].y_koordinate);
		}
		such_liste_groesse=0;
	}
	//printf("geloescht:\n");
	//y_liste_ausgeben();
}

//loescht element in der loeschliste
void element_loeschen(long int x_koordinate, long int y_koordinate)
{
	
	long int id = x_koordinate;
	if(y_liste[id*y_liste_hoehe + y_koordinate] == 0)
	{
		return;
	}
	x_liste[id].y_liste_groesse--;
	if(y_koordinate == x_liste[id].y_liste_groesse)
	{
		y_liste[id*y_liste_hoehe + y_koordinate] = 0;
		return;
	}
	for(long int i = y_koordinate; i<y_liste_hoehe-1; i++)
	{
		y_liste[id*y_liste_hoehe + i] = y_liste[id*y_liste_hoehe + i+1]; 
		such_liste_speicher_management(id, i);
		y_liste[id*y_liste_hoehe + i+1] = 0; 
	}
	y_liste[id*y_liste_hoehe + y_liste_hoehe-1] = 0; 
}

//uebergibt einzelne Spielsteine und ruft die Funktionen auf fuer die Spielmechanik
void spiel_logik()
{
	if(zwischenspeicher == NULL)
	{
		return;
	}
	long int y_koordinate;
	struct x_liste_struct *element;
	for(long int i=0; i<zwischenspeicher_groesse; i++)
	{
		//printf("\nrunde %li\n",i);
		//printf("x_koordinate: %li, farbe: %i\n", zwischenspeicher[i].x_koordinate, zwischenspeicher[i].farbe);
		y_koordinate = wert_eintragen(zwischenspeicher[i].x_koordinate, zwischenspeicher[i].farbe);	
		struct x_liste_struct key = { .x_koordinate = zwischenspeicher[i].x_koordinate};
		element = bsearch(&key, x_liste, x_liste_groesse, sizeof(struct x_liste_struct), x_liste_vergleich);
		if(element == NULL)
		{
            fprintf(stderr,"Es wird ein leeres element fuer das Spiel verwendet\n");
			fehler_funktion();
			return;
		}
		long int id =(long int)(element-x_liste);	
		stern_suche(id, y_koordinate);
		//printf("zustand:\n");
		//y_liste_ausgeben();
		loesch_funktion();
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////

//suchtliste formatieren mit selber fktweise wie loeschlisteformatieren
void such_liste_formatieren()
{
	if(such_liste == NULL)
	{
		return;
	}
	//printf("vor qsort:\n");
	//loesch_liste_ausgeben();
	qsort(such_liste, such_liste_groesse, sizeof(struct loesch_liste_struct), loesch_liste_vergleich);
	//printf("nach qsort:\n");
	//loesch_liste_ausgeben();

	long int anzahl = 1;
	long int x_koordinate_temp = such_liste[0].x_koordinate;
	long int y_koordinate_temp = such_liste[0].y_koordinate;
	for(long int i=1; i<such_liste_groesse; i++)
	{
		if(x_koordinate_temp != such_liste[i].x_koordinate || y_koordinate_temp != such_liste[i].y_koordinate)
		{
			such_liste[anzahl].x_koordinate = such_liste[i].x_koordinate;
			such_liste[anzahl].y_koordinate = such_liste[i].y_koordinate;
			x_koordinate_temp = such_liste[i].x_koordinate;
			y_koordinate_temp = such_liste[i].y_koordinate;
			anzahl++;
		}
	}
	such_liste_groesse = anzahl;
	//printf("loesch liste nach formatieren:\n");
	//loesch_liste_ausgeben();
}

