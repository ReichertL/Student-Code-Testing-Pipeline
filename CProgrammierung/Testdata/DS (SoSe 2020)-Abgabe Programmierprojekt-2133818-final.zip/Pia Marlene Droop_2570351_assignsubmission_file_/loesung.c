#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// finale Version compilieren ohne Fehler mit gcc -o loesung -O3 -std=c11 -Werror -DNDEBUG loesung.c
// Debugging compilieren mit gcc -o loesung -O3 -std=c11 -Wall -Wextra -Wpedantic -DNDEBUG loesung.c

void printPlayingField();
void freePlayingField();
void freePlayingFieldExcept(int x1, int x2);
void freePlayingFieldSpecialCase(int failedAtX, int yBefore, int yAfter);

    typedef enum BOOL { FALSE,
                        TRUE
    } BOOL;

// Structs
typedef struct Stone{
    unsigned int color;
    BOOL toDelete;
} Stone;

typedef struct Field{
    Stone*** data;
    int offset;
    int minX;
    int maxX;
    int maxY;
} Field;

// Global Variables
Field* playingField;

// initialize Functions
void createPlayingField() {
    playingField = (Field*)malloc(sizeof(Field));
    if (playingField == NULL)
    {
        fprintf(stderr, "Not enough memory.\n");
        exit(-1);
    }
    int initialXSize = 20;
    int initialYSize = 10;
    int initialOffset = 10;
    // x-values array
    playingField->data = (Stone***)calloc(initialXSize, sizeof(Stone**));
    if (playingField->data == NULL)
    {
        free(playingField);
        fprintf(stderr, "Not enough memory.\n");
        exit(1);
    }
    playingField->offset = initialOffset;
    playingField->maxX = initialXSize - initialOffset;
    playingField->minX = -initialOffset -1;
    playingField->maxY = initialYSize;
    // fill x-values with pointers to y-arrays
    for(int x = 0; x < initialXSize; x++) {
        // y-values array filled with NULL pointers
        playingField->data[x] = (Stone**)calloc(initialYSize, sizeof(Stone*));
        if (playingField->data[x] == NULL)
        {
            freePlayingField();
            fprintf(stderr, "Not enough memory.\n");
            exit(1);
        }
    }
}

Stone* createStone(unsigned int color) {
    Stone *newStone = (Stone*)malloc(sizeof(Stone));
    if (newStone == NULL)
    {
        freePlayingField();
        fprintf(stderr, "Not enough memory.\n");
        exit(1);
    }
    newStone->color = color;
    newStone->toDelete = FALSE;
    return newStone;
}

// Help Functions
Stone* getStonefromField(int x, int y) {
    if((x >= playingField->maxX) 
        || (x <= playingField->minX) 
        || (y < 0)
        || (y >= playingField->maxY)) {
            return NULL;
    }
    int xPositioninArray = (playingField->offset) + x;
    return ((playingField->data)[xPositioninArray])[y];
}
int removeStonefromField(int x, int y) {
    if ((x >= playingField->maxX) || (x <= playingField->minX) || (y < 0) || (y >= playingField->maxY)){
        return 1;
    }
    int xPositioninArray = (playingField->offset) + x;
    ((playingField->data)[xPositioninArray])[y] = NULL;
    return 0;
}

int getResizingFactor(int oldSize, int newPosition) {
    return newPosition / oldSize + 1;
}

int insertStoneAtPosition(Stone *newStone, int x, int y)
{
    if ((x <= playingField->minX) || (x >= playingField->maxX) || (y < 0) || (y >= playingField->maxY)) {
        printf("Inserting out of range at x = %d, y = %d\n", x, y);
        printf("Range is fuer -x: %d, fuer x: %d, fuer y: %d\n", playingField->minX, playingField->maxX, playingField->maxY);
        return -1;
    }
    ((playingField->data)[(playingField->offset) + x])[y] = newStone;
    return 1;
}
int insertStone(Stone* newStone, int x) {
    // need to extend playing field in -x direction
    if(x <= playingField->minX){

        int factor = getResizingFactor(playingField->offset, abs(x));

        int newSize = (factor * playingField->offset) + playingField->maxX;
        Stone*** temp = (Stone ***)realloc(playingField->data, newSize*sizeof(Stone**));
        if (temp == NULL)
        {
            freePlayingField();
            fprintf(stderr, "Not enough memory.\n");
            exit(1);
        }
        playingField->data = temp;
        // move all the pointers in +x direction
        for (int x = newSize - 1; x >= newSize - playingField->offset - playingField->maxX; x--)
        {
            int distanceMoved = newSize - (playingField->offset + playingField->maxX);
            playingField->data[x] = playingField->data[x-distanceMoved];
        }
        int upperlimit = newSize - playingField->offset - playingField->maxX;
        playingField->minX = (-playingField->offset) * factor - 1; 
        playingField->offset = factor * playingField->offset;
        for (int x = 0; x < upperlimit; x++) {
            playingField->data[x] = (Stone **)calloc(playingField->maxY, sizeof(Stone *));
            if (playingField->data[x] == NULL) {
                freePlayingFieldExcept(x, upperlimit);
                fprintf(stderr, "Not enough memory.\n");
                exit(1);
            }

        }
    }
    // need to extend playing field in +x direction
    if( x >= playingField->maxX) {
        // find out, how far we need to extend playing field to fit x
        int factor = getResizingFactor(playingField->maxX, x);
        Stone*** temp = (Stone***)realloc(playingField->data, (factor*playingField->maxX + playingField->offset) * sizeof(Stone**));
        if(temp == NULL) {
            freePlayingField();
            fprintf(stderr, "Not enough memory.\n");
            exit(1);
        }
        playingField->data = temp;
        int oldmaxX = playingField->maxX;
        playingField->maxX = playingField->maxX * factor;
        for(int x = oldmaxX + playingField->offset; x < playingField->maxX + playingField->offset; x++) {
            playingField->data[x] = (Stone **)calloc(playingField->maxY, sizeof(Stone *));
            if (playingField->data[x] == NULL)
            {
                freePlayingFieldExcept(x, playingField->maxX + playingField->offset);
                fprintf(stderr, "Not enough memory.\n");
                exit(1);
            }
        }
    }
    // finding position of stone and
    for(int y = 0; y < playingField->maxY; y++) {
        Stone* result = getStonefromField(x, y);
        if(!result) {
            insertStoneAtPosition(newStone, x, y);
            return y;
        }
    }
    // need to extend playing field in y direction ==> double size
    // printf("Extending playing field in y direction from %d\n", playingField->maxY);
    int oldMaxY = playingField->maxY;
    for (int x = 0; x < playingField->maxX + playingField->offset; x++)
    {
        Stone** temp = (Stone**)realloc(playingField->data[x], oldMaxY*2*sizeof(Stone*));
        if (playingField->data == NULL) {
            freePlayingFieldSpecialCase(x, oldMaxY, oldMaxY * 2 * sizeof(Stone *));
            fprintf(stderr, "Not enough memory.\n");
            exit(-1);
        }
        playingField->data[x] = temp;
        for (int y = oldMaxY; y < oldMaxY * 2; y++)
        {
            (playingField->data[x])[y] = NULL;
        }
    }
    playingField->maxY = oldMaxY*2;
    insertStoneAtPosition(newStone, x, oldMaxY);

    return oldMaxY;
}   

// Game Functions
BOOL checkForLinesHorizontal(int x, int y) {
    Stone* firstStone = getStonefromField(x, y);
    if(firstStone == NULL) {return FALSE;}
    Stone* secondStone = getStonefromField(x+1, y);
    if(secondStone == NULL) {return FALSE;}
    Stone* thirdStone = getStonefromField(x+2, y);
    if(thirdStone == NULL) {return FALSE;}
    Stone* fourthStone = getStonefromField(x+3, y);
    if(fourthStone == NULL) {return FALSE;}

    BOOL lineFound = (firstStone->color == secondStone->color) 
                    && (firstStone->color == thirdStone->color)
                    && (firstStone->color == fourthStone->color);
    if(lineFound) {
        firstStone->toDelete = TRUE;
        secondStone->toDelete = TRUE;
        thirdStone->toDelete = TRUE;
        fourthStone->toDelete = TRUE;
        // printf("Horizontal Line of Color %d at x=%d, y=%d found\n", firstStone->color, x, y);
    }
    return lineFound;
}
BOOL checkForLinesVertical(int x, int y) {
    Stone *firstStone = getStonefromField(x, y);
    if (firstStone == NULL){ return FALSE;}
    Stone *secondStone = getStonefromField(x, y+1);
    if (secondStone == NULL){ return FALSE;}
    Stone *thirdStone = getStonefromField(x, y+2);
    if (thirdStone == NULL){ return FALSE;}
    Stone *fourthStone = getStonefromField(x, y+3);
    if (fourthStone == NULL){ return FALSE;}

    BOOL lineFound = (firstStone->color == secondStone->color) 
                    && (firstStone->color == thirdStone->color) 
                    && (firstStone->color == fourthStone->color);
    if (lineFound)
    {
        firstStone->toDelete = TRUE;
        secondStone->toDelete = TRUE;
        thirdStone->toDelete = TRUE;
        fourthStone->toDelete = TRUE;
        // printf("Vertical Line of Color %d at x=%d, y=%d found\n", firstStone->color, x, y);
    }
    return lineFound;
}
BOOL checkForLinesDiagonal1(int x, int y) {
    Stone *firstStone = getStonefromField(x, y);
    if (firstStone == NULL){ return FALSE;}
    Stone *secondStone = getStonefromField(x + 1, y + 1);
    if (secondStone == NULL){ return FALSE;}
    Stone *thirdStone = getStonefromField(x + 2, y + 2);
    if (thirdStone == NULL){ return FALSE;}
    Stone *fourthStone = getStonefromField(x + 3, y + 3);
    if (fourthStone == NULL){ return FALSE;}

    BOOL lineFound = (firstStone->color == secondStone->color) 
                    && (firstStone->color == thirdStone->color) 
                    && (firstStone->color == fourthStone->color);
    if (lineFound)
    {
        firstStone->toDelete = TRUE;
        secondStone->toDelete = TRUE;
        thirdStone->toDelete = TRUE;
        fourthStone->toDelete = TRUE;
        // printf("Diagonal Line of Color %d at x=%d, y=%d found\n", firstStone->color, x, y);
    }
    return lineFound;
}
BOOL checkForLinesDiagonal2(int x, int y) {
    Stone *firstStone = getStonefromField(x, y);
    if (firstStone == NULL){ return FALSE;}
    Stone *secondStone = getStonefromField(x - 1, y + 1);
    if (secondStone == NULL){ return FALSE;}
    Stone *thirdStone = getStonefromField(x - 2, y + 2);
    if (thirdStone == NULL){ return FALSE;}
    Stone *fourthStone = getStonefromField(x - 3, y + 3);
    if (fourthStone == NULL){ return FALSE;}

    BOOL lineFound = (firstStone->color == secondStone->color) 
                    && (firstStone->color == thirdStone->color) 
                    && (firstStone->color == fourthStone->color);
    if (lineFound)
    {
        firstStone->toDelete = TRUE;
        secondStone->toDelete = TRUE;
        thirdStone->toDelete = TRUE;
        fourthStone->toDelete = TRUE;
        // printf("Diagonal Line of Color %d at x=%d, y=%d found\n", firstStone->color, x, y);
    }
    return lineFound;
}
BOOL checkForLines()
{
    BOOL lineFound = FALSE;
    for (int x = playingField->minX + 1; x < playingField->maxX; x++)
    {
        for (int y = 0; y < playingField->maxY; y++)
        {
            if (getStonefromField(x, y) == NULL) {break;}
            BOOL horizontalLineFound = checkForLinesHorizontal(x, y);
            BOOL verticalLineFound = checkForLinesVertical(x, y);
            BOOL diagonalLineFound1 = checkForLinesDiagonal1(x, y);
            BOOL diagonalLineFound2 = checkForLinesDiagonal2(x, y);
            lineFound = lineFound || horizontalLineFound || verticalLineFound || diagonalLineFound1 || diagonalLineFound2;
        }
    }
    return lineFound;
}

BOOL checkForLinesHorizontalAfterInsertion(int x, int y)
{
    Stone *firstStone = getStonefromField(x, y);
    if (firstStone == NULL)
    {
        return FALSE;
    }
    int color = firstStone->color;
    int rightMostOfSameColor = x;
    int leftMostOfSameColor = x;
    BOOL foundStone = TRUE;
    while(foundStone) {
        foundStone = FALSE;
        Stone *nextStone = getStonefromField(rightMostOfSameColor+1, y);
        if(nextStone != NULL) {
            if(nextStone->color == color) {
                rightMostOfSameColor++;
                foundStone = TRUE;
            }
        }
    }
    foundStone = TRUE;
    while (foundStone)
    {
        foundStone = FALSE;
        Stone *nextStone = getStonefromField(leftMostOfSameColor - 1, y);
        if (nextStone != NULL)
        {
            if (nextStone->color == color)
            {
                leftMostOfSameColor--;
                foundStone = TRUE;
            }
        }
    }

    BOOL lineFound = (rightMostOfSameColor - leftMostOfSameColor) >= 3;
    if(lineFound) {
        for(int i = leftMostOfSameColor; i <= rightMostOfSameColor; i++) {
            Stone*currentStone = getStonefromField(i, y);
            currentStone->toDelete = TRUE;
        }
    }
    return lineFound;
}
BOOL checkForLinesVerticalAfterInsertion(int x, int y)
{
    Stone *firstStone = getStonefromField(x, y);
    if (firstStone == NULL)
    {
        return FALSE;
    }
    int color = firstStone->color;
    int topMostOfSameColor = y;
    int bottomMostOfSameColor = y;
    BOOL foundStone = TRUE;
    while (foundStone)
    {
        foundStone = FALSE;
        Stone *nextStone = getStonefromField(x, topMostOfSameColor+1);
        if (nextStone != NULL)
        {
            if (nextStone->color == color)
            {
                topMostOfSameColor++;
                foundStone = TRUE;
            }
        }
    }
    foundStone = TRUE;
    while (foundStone)
    {
        foundStone = FALSE;
        Stone *nextStone = getStonefromField(x, bottomMostOfSameColor-1);
        if (nextStone != NULL)
        {
            if (nextStone->color == color)
            {
                bottomMostOfSameColor--;
                foundStone = TRUE;
            }
        }
    }

    BOOL lineFound = (topMostOfSameColor - bottomMostOfSameColor) >= 3;
    if (lineFound)
    {
        for (int i = bottomMostOfSameColor; i <= topMostOfSameColor; i++)
        {
            Stone *currentStone = getStonefromField(x, i);
            currentStone->toDelete = TRUE;
        }
    }
    return lineFound;
}
BOOL checkForLinesDiagonal1AfterInsertion(int x, int y) {
    Stone *firstStone = getStonefromField(x, y);
    if (firstStone == NULL)
    {
        return FALSE;
    }
    int color = firstStone->color;
    int widthToLeft = 0;
    int widthToRight = 0;
    BOOL foundStone = TRUE;
    while (foundStone)
    {
        foundStone = FALSE;
        Stone *nextStone = getStonefromField(x - widthToLeft - 1, y - widthToLeft - 1);
        if (nextStone != NULL)
        {
            if (nextStone->color == color)
            {
                widthToLeft++;
                foundStone = TRUE;
            }
        }
    }
    foundStone = TRUE;
    while (foundStone)
    {
        foundStone = FALSE;
        Stone *nextStone = getStonefromField(x + widthToRight + 1, y + widthToRight + 1);
        if (nextStone != NULL)
        {
            if (nextStone->color == color)
            {
                widthToRight++;
                foundStone = TRUE;
            }
        }
    }
    BOOL lineFound = (widthToLeft + widthToRight) >= 3;
    if(lineFound) {
        for(int i = 0; i <=widthToLeft; i++) {
            Stone* current = getStonefromField(x - i, y -i);
            current->toDelete = TRUE;
        }
        for (int i = 0; i <= widthToRight; i++){
            Stone *current = getStonefromField(x + i, y + i);
            current->toDelete = TRUE;
        }
    } 
    return lineFound;
}
BOOL checkForLinesDiagonal2AfterInsertion(int x, int y)
{
    Stone *firstStone = getStonefromField(x, y);
    if (firstStone == NULL)
    {
        return FALSE;
    }
    int color = firstStone->color;
    int widthToLeft = 0;
    int widthToRight = 0;
    BOOL foundStone = TRUE;
    while (foundStone)
    {
        foundStone = FALSE;
        Stone *nextStone = getStonefromField(x - widthToLeft - 1, y + widthToLeft + 1);
        if (nextStone != NULL)
        {
            if (nextStone->color == color)
            {
                widthToLeft++;
                foundStone = TRUE;
            }
        }
    }
    foundStone = TRUE;
    while (foundStone)
    {
        foundStone = FALSE;
        Stone *nextStone = getStonefromField(x + widthToRight + 1, y - widthToRight - 1);
        if (nextStone != NULL)
        {
            if (nextStone->color == color)
            {
                widthToRight++;
                foundStone = TRUE;
            }
        }
    }
    BOOL lineFound = (widthToLeft + widthToRight) >= 3;
    if (lineFound)
    {
        for (int i = 0; i <= widthToLeft; i++)
        {
            Stone *current = getStonefromField(x - i, y + i);
            current->toDelete = TRUE;
        }
        for (int i = 0; i <= widthToRight; i++)
        {
            Stone *current = getStonefromField(x + i, y - i);
            current->toDelete = TRUE;
        }
    }
    return lineFound;
}
BOOL checkForLineAfterInsertion(int x, int y) {
    BOOL horizontalLineFound = checkForLinesHorizontalAfterInsertion(x, y);
    BOOL verticalLineFound = checkForLinesVerticalAfterInsertion(x, y);
    BOOL diagonalLineFound1 = checkForLinesDiagonal1AfterInsertion(x, y);
    BOOL diagonalLineFound2 = checkForLinesDiagonal2AfterInsertion(x, y);
    return horizontalLineFound || verticalLineFound || diagonalLineFound1 || diagonalLineFound2;
}

void deleteStones(){
    for (int x = playingField->minX + 1; x < playingField->maxX; x++)
    {
        for (int y = 0; y < playingField->maxY; y++)
        {
            Stone *currentStone = getStonefromField(x, y);
            if (currentStone == NULL) {
                break;
            }
            if(currentStone->toDelete)
            {
                free(currentStone);
                Stone* voidStone = NULL;
                insertStoneAtPosition(voidStone, x, y);
            }
        }
    }
    return;
}
int slideDown() {
    deleteStones();
    for (int x = playingField->minX + 1; x < playingField->maxX; x++)
    {
        for (int y = 1; y < playingField->maxY; y++)
        {
            Stone *current = getStonefromField(x, y);
            if (current != NULL && getStonefromField(x, y - 1) == NULL) {
                int newY = y-1;
                for(int i = y-1; i >= 0; i--) {
                    if (getStonefromField(x, i) == NULL) {
                        newY = i;
                    } else {
                        break;
                    }
                }
                insertStoneAtPosition(current, x, newY);
                removeStonefromField(x, y);
            }
        }
    }
    return 0;
}

// other Functions
void printPlayingField() {
    for(int x = playingField->minX +1; x < playingField->maxX; x++) {
        printf("%03d: ", x);
        for(int y = 0; y < playingField->maxY; y++) {
            Stone* current = getStonefromField(x, y);
            if(!current) {
                printf("  ");
            }else {
                printf("%d ", current->color);
            }
        }
        printf("\n");
    }
    printf("\n");
}
void output() {
    for (int x = playingField->minX + 1; x < playingField->maxX; x++)
    {
        for (int y = 0; y < playingField->maxY; y++)
        {
            Stone *current = getStonefromField(x, y);
            if (current)
            {
                printf("%d %d %d\n", current->color, x, y);
            }
        }
    }
}

void freePlayingField() {
    for (int x = 0; x < playingField->offset + playingField->maxX; x++) {
        if(playingField->data[x] == NULL) {
            break;
        } 
        for(int y = 0; y < playingField->maxY; y++) {
            if ((playingField->data[x])[y] != NULL) {
                free((playingField->data[x])[y]);
            }
        }
        free(playingField->data[x]);
    }
    free(playingField->data);
    free(playingField);
}
void freePlayingFieldExcept(int x1, int x2) {
    for (int x = 0; x < playingField->offset + playingField->maxX; x++)
    {
        if(x >= x1 && x < x2) {break;}
        if (playingField->data[x] == NULL){
            break;
        }
        for (int y = 0; y < playingField->maxY; y++)
        {
            if ((playingField->data[x])[y] != NULL)
            {
                free((playingField->data[x])[y]);
            }
        }
        free(playingField->data[x]);
    }
    free(playingField->data);
    free(playingField);
}
// to use when memory allocation during expansion in y direction failed
void freePlayingFieldSpecialCase(int failedAtX, int yBefore, int yAfter) {
    for (int x = 0; x < playingField->offset + playingField->maxX; x++){
        if (playingField->data[x] == NULL){
            break;
        }
        if(x < failedAtX) {
            for (int y = 0; y < yBefore; y++)
            {
                if ((playingField->data[x])[y] != NULL)
                {
                    free((playingField->data[x])[y]);
                }
            }
        } else {
            for (int y = 0; y < yAfter; y++)
            {
                if ((playingField->data[x])[y] != NULL)
                {
                    free((playingField->data[x])[y]);
                }
            }
        }
        free(playingField->data[x]);
    }
    free(playingField->data);
    free(playingField);
}

int main(int argc, char** args) {
    if (argc != 1)
    {
        fprintf(stderr, "Wrong usage. This program does not take any command line parameters.\n");
        exit(1);
    }
    createPlayingField();
    int color;
    int xPos;
    int result;


    char coordinate[10];
    char colorChar[4];
    char whiteSpace[2];
    BOOL endOfFile = FALSE;

    while(!endOfFile) {

        // get color
        int currentChar = 0;
        BOOL LFfound = FALSE;
        BOOL whitespaceFound = FALSE;
        BOOL zerosFound = FALSE;
        if (!fgets(colorChar, 2, stdin))
        {
            // end of file
            break;
        }
        // get rid of leading zeros
        while (colorChar[0] == '0')
        {
            zerosFound = TRUE;
            fgets(colorChar, 2, stdin);
        }
        // what if it was a zero with leading zeros?
        if (zerosFound && (colorChar[0] == ' '))
        {
            colorChar[0] = '0';
            colorChar[1] = '\0';
            whitespaceFound = TRUE;
            currentChar = 4; // to prevent from entering the following loop
        }
        // check for number not zero
        while (currentChar < 3)
        {
            if (colorChar[currentChar] != ' ')
            {
                if (colorChar[currentChar] < '0' || colorChar[currentChar] > '9')
                {
                    freePlayingField();
                    fprintf(stderr, "wrong input format1\n");
                    exit(1);
                }
                currentChar++;
                fgets(colorChar + currentChar, 2, stdin);
            }
            else
            {
                whitespaceFound = TRUE;
                colorChar[currentChar] = '\0';
                break;
            }
        }
        // get whitespace from after color
        if (!whitespaceFound)
        {
            if (colorChar[3] != ' ')
            {
                freePlayingField();
                fprintf(stderr, "wrong input format2\n");
                exit(1);
            }
        }
        colorChar[3] = '\0';
        color = atoi(colorChar);
        if (color > 254)
        {
            freePlayingField();
            fprintf(stderr, "wrong input format. Color too big\n");
            exit(1);
        }
        // get additional whitespace
        fgets(coordinate, 2, stdin);
        while (coordinate[0] == ' ')
        {
            fgets(coordinate, 2, stdin);
        }
        // get coordinate
        if (coordinate[0] != '-' && (coordinate[0] < '0' || coordinate[0] > '9'))
        {
            freePlayingField();
            fprintf(stderr, "wrong input format3\n");
            exit(1);
        }
        BOOL negativeCoordinate = FALSE;
        if (coordinate[0] == '-')
        {
            negativeCoordinate = TRUE;
        }
        // get rid of leading zeros
        zerosFound = FALSE;
        while (coordinate[0] == '0')
        {
            zerosFound = TRUE;
            fgets(coordinate, 2, stdin);
        }
        BOOL coordinateIsZero = FALSE;
        if (zerosFound && ((coordinate[0] == 0) || (coordinate[0] == 10)))
        {
            coordinate[0] = '0';
            coordinate[1] = '\0';
            whitespaceFound = TRUE;
            LFfound = TRUE;
            if (coordinate[0] == 0)
            {
                endOfFile = TRUE;
            }
            coordinateIsZero = TRUE;
        }
        if (!coordinateIsZero)
        {
            for (int i = 1; i <= 9; i++)
            {
                fgets(&coordinate[i], 2, stdin);
                // end of line found
                if (coordinate[i] == 10 || coordinate[i] == 0)
                {
                    if (negativeCoordinate && (i == 1))
                    {
                        freePlayingField();
                        fprintf(stderr, "wrong input format4\n");
                        exit(1);
                    }
                    coordinate[i] == '\0';
                    LFfound = TRUE;
                    if (coordinate[i] == 0)
                    {
                        endOfFile = TRUE;
                    }
                    break;
                }
                if (coordinate[i] < '0' || coordinate[i] > '9')
                {
                    freePlayingField();
                    fprintf(stderr, "wrong input format5\n");
                    exit(1);
                }
            }
        }
        if (!LFfound)
        {
            freePlayingField();
            fprintf(stderr, "wrong input format6\n");
            exit(1);
        }
        xPos = atoi(coordinate);
        //
        // end of input parsing
        //

        Stone* newStone = createStone(color);
        // insertStone(newStone, xPos);
        int y = insertStone(newStone, xPos);
        // BOOL linesFound = checkForLines();
        BOOL linesFound = checkForLineAfterInsertion(xPos, y);

        // printPlayingField();
        while(linesFound) {
            slideDown();
            linesFound = checkForLines();
            // printPlayingField();
        }

    }
    output();
    freePlayingField();
}