#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/*  Programmierprojekt 2020
    Loesung von Francesca-Juliana Sylvester
    Matrikelnr.: 583159
*/

//Globale Variablen
int leer = 300;
int treffer = 400;

int min_element = 0;
int max_element = 0;
int max_offset = 0;

int **spielfeld;
int x_spielfeld = 10;
int y_spielfeld = 10;

int max_y_koordinate = 0;

int start_playing;

/*gibt das Spielfeld frei*/
 void free_spielfeld(){

    for(int j = 0; j < y_spielfeld ;j++){
        free(spielfeld[j]);
        }
    free(spielfeld);
    }


/* check_column_spielfeld und check_column_row vergroeßern wenn benoetigt das Spielfeld; column verschiebt weiterhin die Daten, wenn ein neuer Offset hinzugefügt wird*/
int check_column_spielfeld(int addition, int farbe, int position){
    int prev_x_spielfeld = x_spielfeld;
    int new_addition = x_spielfeld+addition;


    for(size_t i = 0; i<y_spielfeld; i++){
        int *tmp_spielfeld = realloc(spielfeld[i], sizeof *spielfeld[i] * (x_spielfeld + addition+1));

        if(tmp_spielfeld){
            spielfeld[i]=tmp_spielfeld;}
        else{fprintf(stderr,"Realloc failed.\n");
            free_spielfeld();
            exit(1);}

        }


        for(int i = 0; i<y_spielfeld; i++){
        for(int j = 0; j<addition+1;j++){
            spielfeld[i][x_spielfeld+j]=leer;
        }}

        //Spielfeld anpassen an Offset
        x_spielfeld = new_addition;
        int loop = x_spielfeld - prev_x_spielfeld;
        if(position < 0){
            for(int i=0; i<y_spielfeld;i++){
                for(int j = x_spielfeld -1; j >= loop;j--){

                    spielfeld[i][j] = spielfeld[i][j-loop];
                    }
                for(int k = 0; k< loop;k++){
                    spielfeld[i][k] = leer;}

            }
        }

        return 0;
}

int check_row_spielfeld(){
            int **tmp_spiel = realloc(spielfeld,sizeof(int**) *(2*y_spielfeld));

            if (tmp_spiel){
                spielfeld = tmp_spiel;
                for(size_t i = 0; i<y_spielfeld;i++){
                    spielfeld[y_spielfeld+i]=(int *) malloc(sizeof(*spielfeld[y_spielfeld+i]) * x_spielfeld);
                    for(int j = 0; j<x_spielfeld;j++){
                        spielfeld[y_spielfeld+i][j]= 300;
                        }
                    }

                y_spielfeld = 2*y_spielfeld;

                    }
            else{
                fprintf(stderr,"Realloc failed.\n");
                free_spielfeld();
                exit(1);}

    return 0;
}

/*reorganize_spiefeld simuliert das Nachrutschen; dabei schaut die Funktion sich alle Werte an in der Umgebung des Spielsteins und setzt diese dann wieder auf leer*/
int reorganize_spielfeld(int pos_y){

int reorganized = 0;
int max_x = max_element+max_offset;

//check start von pos_y

if ((pos_y-3) >= 0){pos_y= pos_y-3;}
else if ((pos_y-2) >= 0){pos_y=pos_y-2;}
else if ((pos_y-1) >= 0){pos_y=pos_y-1;}

    for(int k = pos_y; k<=max_y_koordinate;k++){
        for(int n = 0; n<=max_x;n++){
            if(spielfeld[k][n]==leer){
                if ((k+1) != y_spielfeld){
                    if(spielfeld[k+1][n]!=leer){
                        spielfeld[k][n]=spielfeld[k+1][n];
                        spielfeld[k+1][n] = leer;
                          reorganized++;}
                          }
                }
            }
    }
    if(reorganized != 0){
        reorganize_spielfeld(pos_y);}

    return 0;

}

/*Match_XXX schaut nach den Linien um den Stein. Wenn eine Linie gefunden wird, werden
die betreffenden Steine auf +400 gesetzt um zu signalisieren, dass es einen Treffer gibt*/

int match_diagonal(int row, int column, int max_y){

int match_counter = 0;
int max_rechts_oben;
int max_rechts_unten;
int max_links_oben;
int max_links_unten;

int treffer_lu_ro = 0;
int treffer_lo_ru = 0;

int j = column;


for(int i = 0; i<=max_y; i++){
    for(int h = -3; h<=3; h++){
        int helper = j+h;

        max_rechts_oben = 0;
        max_rechts_unten = 0;
        max_links_oben = 0;
        max_links_unten = 0;

        if(helper >= 0 && helper<x_spielfeld){

            if (spielfeld[i][helper]!=leer){



             //max_rechts_oben
             if((helper+1)<x_spielfeld && (i-1)>=0){
                    if(spielfeld[i][helper]== spielfeld[i-1][helper+1] || (spielfeld[i][helper]-treffer) == spielfeld[i-1][helper+1] || spielfeld[i][helper] == (spielfeld[i-1][helper+1]-treffer)){

                        max_rechts_oben = 1;
                        if((helper+2)<x_spielfeld && (i-2)>=0){
                            if(spielfeld[i][helper]== spielfeld[i-2][helper+2] || (spielfeld[i][helper]-treffer) == spielfeld[i-2][helper+2] || spielfeld[i][helper] == (spielfeld[i-2][helper+2]-treffer)){

                            max_rechts_oben = 2;
                            if((helper+3)<x_spielfeld && (i-3)>=0){
                                if(spielfeld[i][helper]== spielfeld[i-3][helper+3] || (spielfeld[i][helper]-treffer) == spielfeld[i-3][helper+3] || spielfeld[i][helper] == (spielfeld[i-3][helper+3]-treffer)){
                                max_rechts_oben = 3;

                                }
                            }
                            }
                        }
                    }
                }

            //max_rechts_unten
            if((helper+1)<x_spielfeld && (i+1)<max_y){
                    if(spielfeld[i][helper]== spielfeld[i+1][helper+1] || (spielfeld[i][helper]-treffer) == spielfeld[i+1][helper+1] || spielfeld[i][helper] == (spielfeld[i+1][helper+1]-treffer)){
                        max_rechts_unten = 1;
                        if((helper+2)<x_spielfeld && (i+2)<max_y){
                            if(spielfeld[i][helper]== spielfeld[i+2][helper+2] || (spielfeld[i][helper]-treffer) == spielfeld[i+2][helper+2] || spielfeld[i][helper] == (spielfeld[i+2][helper+2]-treffer)){
                            max_rechts_unten = 2;
                            if((helper+3)<x_spielfeld && (i+3)<max_y){
                                if(spielfeld[i][helper]== spielfeld[i+3][helper+3] || (spielfeld[i][helper]-treffer) == spielfeld[i+3][helper+3] || spielfeld[i][helper] == (spielfeld[i+3][helper+3]-treffer)){
                                max_rechts_unten = 3;
                                }
                            }
                            }
                        }
                    }
                }

                //links oben
               if((helper-1)>= 0 && (i-1)>=0){
                    if(spielfeld[i][helper]== spielfeld[i-1][helper-1] || (spielfeld[i][helper]-treffer) == spielfeld[i-1][helper-1] || spielfeld[i][helper] == (spielfeld[i-1][helper-1]-treffer)){
                        max_links_oben = -1;

                        if((helper-2)>= 0 && (i-2)>=0){
                            if(spielfeld[i][helper]== spielfeld[i-2][helper-2] || (spielfeld[i][helper]-treffer) == spielfeld[i-2][helper-2] || spielfeld[i][helper] == (spielfeld[i-2][helper-2]-treffer)){
                            max_links_oben = -2;

                            if((helper-3)>= 0 && (i-3)>=0){
                                if(spielfeld[i][helper]== spielfeld[i-3][helper-3] || (spielfeld[i][helper]-treffer) == spielfeld[i-3][helper-3] || spielfeld[i][helper] == (spielfeld[i-3][helper-3]-treffer)){
                                max_links_oben = -3;

                                }
                            }
                            }
                        }
                    }
                }

                //links unten
                if((helper-1)>= 0 && (i+1)<max_y){

                    if(spielfeld[i][helper]== spielfeld[i+1][helper-1] || (spielfeld[i][helper]-treffer) == spielfeld[i+1][helper-1] || spielfeld[i][helper] == (spielfeld[i+1][helper-1]-treffer)){
                        max_links_unten = -1;

                        if((helper-2)>= 0 && (i+2)<max_y){
                            if(spielfeld[i][helper]== spielfeld[i+2][helper-2] || (spielfeld[i][helper]-treffer) == spielfeld[i+2][helper-2] || spielfeld[i][helper] == (spielfeld[i+2][helper-2]-treffer)){
                            max_links_unten = -2;
                            if((helper-3)>= 0 && (i+3)<max_y){

                                if(spielfeld[i][helper]== spielfeld[i+3][helper-3] || (spielfeld[i][helper]-treffer) == spielfeld[i+3][helper-3] || spielfeld[i][helper] == (spielfeld[i+3][helper-3]-treffer)){
                                max_links_unten = -3;
                                }
                            }
                            }
                        }
                    }
                }


        }

        }

    treffer_lo_ru = -(max_links_oben) + max_rechts_unten;

    if(treffer_lo_ru >= 3){
            match_counter++;
            if(max_rechts_unten == 0){
                if(spielfeld[i][helper] < treffer){spielfeld[i][helper] += treffer;}
                if(spielfeld[i-1][helper-1] < treffer){spielfeld[i-1][helper-1] += treffer;}
                if(spielfeld[i-2][helper-2] < treffer){spielfeld[i-2][helper-2] += treffer;}
                if(spielfeld[i-3][helper-3] < treffer){spielfeld[i-3][helper-3] += treffer;}
                }
            else if(max_rechts_unten == 1){
                if(spielfeld[i+1][helper+1] < treffer){spielfeld[i+1][helper+1] += treffer;}
                if(spielfeld[i][helper] < treffer){spielfeld[i][helper] += treffer;}
                if(spielfeld[i-1][helper-1] < treffer){spielfeld[i-1][helper-1] += treffer;}
                if(spielfeld[i-2][helper-2] < treffer){spielfeld[i-2][helper-2] += treffer;}
                if(max_links_oben == -3){if(spielfeld[i-3][helper-3] < treffer){spielfeld[i-3][helper-3] += treffer;}}}
            else if(max_rechts_unten == 2){
                if(spielfeld[i+2][helper+2] < treffer){spielfeld[i+2][helper+2] += treffer;}
                if(spielfeld[i+1][helper+1] < treffer){spielfeld[i+1][helper+1] += treffer;}
                if(spielfeld[i][helper] < treffer){spielfeld[i][helper] += treffer;}
                if(spielfeld[i-1][helper-1] < treffer){spielfeld[i-1][helper-1] += treffer;}
                if(max_links_oben == -2){if(spielfeld[i-2][helper-2] < treffer){spielfeld[i-2][helper-2] += treffer;}
                if(max_links_oben == -3){if(spielfeld[i-3][helper-3] < treffer){spielfeld[i-3][helper-3] += treffer;}}}}
            else if(max_rechts_unten == 3){
                if(spielfeld[i+3][helper+3] < treffer){spielfeld[i+3][helper+3] += treffer;}
                if(spielfeld[i+2][helper+2] < treffer){spielfeld[i+2][helper+2] += treffer;}
                if(spielfeld[i+1][helper+1] < treffer){spielfeld[i+1][helper+1] += treffer;}
                if(spielfeld[i][helper] < treffer){spielfeld[i][helper] += treffer;}
                if(max_links_oben==-1){if(spielfeld[i-1][helper-1] < treffer){spielfeld[i-1][helper-1] += treffer;}
                if(max_links_oben == -2){if(spielfeld[i-2][helper-2] < treffer){spielfeld[i-2][helper-2] += treffer;}
                if(max_links_oben == -3){if(spielfeld[i-3][helper-3] < treffer){spielfeld[i-3][helper-3] += treffer;}}}}}
    }



    treffer_lu_ro = -(max_links_unten) + max_rechts_oben;
    if(treffer_lu_ro >= 3){
            match_counter++;
            if(max_rechts_oben == 0){
                if(spielfeld[i][helper] < treffer){spielfeld[i][helper] += treffer;}
                if(spielfeld[i+1][helper-1] < treffer){spielfeld[i+1][helper-1] += treffer;}
                if(spielfeld[i+2][helper-2] < treffer){spielfeld[i+2][helper-2] += treffer;}
                if(spielfeld[i+3][helper-3] < treffer){spielfeld[i+3][helper-3] += treffer;}
                }
            else if(max_rechts_oben == 1){
                if(spielfeld[i-1][helper+1] < treffer){spielfeld[i-1][helper+1] += treffer;}
                if(spielfeld[i][helper] < treffer){spielfeld[i][helper] += treffer;}
                if(spielfeld[i+1][helper-1] < treffer){spielfeld[i+1][helper-1] += treffer;}
                if(spielfeld[i+2][helper-2] < treffer){spielfeld[i+2][helper-2] += treffer;}
                if(max_links_unten == -3){if(spielfeld[i+3][helper-3] < treffer){spielfeld[i+3][helper-3] += treffer;}}}
            else if(max_rechts_oben == 2){
                if(spielfeld[i-2][helper+2] < treffer){spielfeld[i-2][helper+2] += treffer;}
                if(spielfeld[i-1][helper+1] < treffer){spielfeld[i-1][helper+1] += treffer;}
                if(spielfeld[i][helper] < treffer){spielfeld[i][helper] += treffer;}
                if(spielfeld[i+1][helper-1] < treffer){spielfeld[i+1][helper-1] += treffer;}
                if(max_links_unten == -2){if(spielfeld[i+2][helper-2] < treffer){spielfeld[i+2][helper-2] += treffer;}
                if(max_links_unten == -3){if(spielfeld[i+3][helper-3] < treffer){spielfeld[i+3][helper-3] += treffer;}}}}
            else if(max_rechts_oben == 3){
                if(spielfeld[i-3][helper+3] < treffer){spielfeld[i-3][helper+3] += treffer;}
                if(spielfeld[i-2][helper+2] < treffer){spielfeld[i-2][helper+2] += treffer;}
                if(spielfeld[i-1][helper+1] < treffer){spielfeld[i-1][helper+1] += treffer;}
                if(spielfeld[i][helper] < treffer){spielfeld[i][helper] += treffer;}
                if(max_links_unten==-1){if(spielfeld[i+1][helper-1] < treffer){spielfeld[i+1][helper-1] += treffer;}
                if(max_links_unten == -2){if(spielfeld[i+2][helper-2] < treffer){spielfeld[i+2][helper-2] += treffer;}
                if(max_links_unten == -3){if(spielfeld[i+3][helper-3] < treffer){spielfeld[i+3][helper-3] += treffer;}}}}}

}
}
}
return match_counter;
}

int match_vertikal(int row, int column, int max_y){
    int i = row;
    int treffer_vertikal = 0;
    int max_oben;
    int max_unten;
    int match_counter = 0;


    for(int j = 0; j <x_spielfeld;j++){
        for(int h=-3; h<= 3;h++){
            int helper =i+h;

            max_oben = 0;
            max_unten = 0;

            if (helper>= 0 && helper < y_spielfeld){

                if(spielfeld[helper][j] != leer){

                if((helper-1) >= 0){

                    if (spielfeld[helper][j] == spielfeld[helper-1][j] || (spielfeld[helper][j]-treffer) == spielfeld[helper-1][j] || spielfeld[helper][j] == (spielfeld[helper-1][j]-treffer) ){
                        max_unten = -1;
                    if((helper-2)>= 0){
                        if (spielfeld[helper][j] == spielfeld[helper-2][j] || (spielfeld[helper][j]-treffer) == spielfeld[helper-2][j] || spielfeld[helper][j] == (spielfeld[helper-2][j]-treffer) ){
                        max_unten = -2;
                        if((helper-3) >= 0){
                            if (spielfeld[helper][j] == spielfeld[helper-3][j] || (spielfeld[helper][j]-treffer) == spielfeld[helper-3][j] || spielfeld[helper][j] == (spielfeld[helper-3][j]-treffer) ){
                            max_unten = -3;
                            }
                        }
                        }
                    }
                }
        }

            if((helper+1)<max_y){
                if(spielfeld[helper][j] == spielfeld[helper+1][j] || (spielfeld[helper][j]-treffer) == spielfeld[helper+1][j] || spielfeld[helper][j] == (spielfeld[helper][j]-treffer) ){
                    max_oben = 1;

                    if((helper+2)<max_y){
                        if (spielfeld[helper][j] == spielfeld[helper+2][j] || (spielfeld[helper][j]-treffer) == spielfeld[helper+2][j] || spielfeld[helper][j] == (spielfeld[helper+2][j]-treffer) ){
                        max_oben = 2;

                    if((helper+3)<max_y){

                        if (spielfeld[helper][j] == spielfeld[helper+3][j] || (spielfeld[helper][j]-treffer) == spielfeld[helper+3][j] || spielfeld[helper][j] == (spielfeld[helper+3][j]-treffer) ){
                        max_oben = 3;
                        }
                    }
                }
            }
        }
    }

    treffer_vertikal = -(max_unten) + max_oben;


    if(treffer_vertikal >= 3){

            for(int k = max_unten; k<= max_oben;k++){
                if(spielfeld[helper+k][j] < treffer){spielfeld[helper+k][j] += treffer;
                    match_counter++;

                }
            }
        }
    }
    }
    }
    }

    return match_counter;
}

int match_horizontale(int row, int column,int max_y){
    //int comparer = spielfeld[row][column];
    int j = column;
    int treffer_horizontal = 0;
    int max_links = 0;
    int max_rechts = 0;
    int match_counter = 0;


    for(int i = 0; i<=max_y;i++){
        for(int h=-3; h<= 3;h++){
            int helper =j+h;



            max_links = 0;
            max_rechts = 0;

            //printf("IN horizontale\n");
            if (helper>= 0 && helper < x_spielfeld){

                if(spielfeld[i][helper] != leer){

                if((helper-1) >= 0){
                    if (spielfeld[i][helper] == spielfeld[i][helper-1] || (spielfeld[i][helper]-treffer) == spielfeld[i][helper-1] || spielfeld[i][helper] == (spielfeld[i][helper-1]-treffer) ){
                        max_links = -1;
                    if((helper-2)>= 0){
                        if (spielfeld[i][helper] == spielfeld[i][helper-2] || (spielfeld[i][helper]-treffer) == spielfeld[i][helper-2] || spielfeld[i][helper] == (spielfeld[i][helper-2]-treffer) ){
                        max_links = -2;
                        if((helper-3) >= 0){
                            if (spielfeld[i][helper] == spielfeld[i][helper-3] || (spielfeld[i][helper]-treffer) == spielfeld[i][helper-3] || spielfeld[i][helper] == (spielfeld[i][helper-3]-treffer) ){
                            max_links = -3;
                            }
                        }
                        }
                    }
                }
        }

            if((helper+1)<x_spielfeld){
                if(spielfeld[i][helper] == spielfeld[i][helper+1] || (spielfeld[i][helper]-treffer) == spielfeld[i][helper+1] || spielfeld[i][helper] == (spielfeld[i][helper+1]-treffer) ){
                    max_rechts = 1;
                    if((helper+2)<x_spielfeld){
                        if (spielfeld[i][helper] == spielfeld[i][helper+2] || (spielfeld[i][helper]-treffer) == spielfeld[i][helper+2] || spielfeld[i][helper] == (spielfeld[i][helper+2]-treffer) ){
                        max_rechts = 2;
                    if((helper+3)<x_spielfeld){
                        if (spielfeld[i][helper] == spielfeld[i][helper+3] || (spielfeld[i][helper]-treffer) == spielfeld[i][helper+3] || spielfeld[i][helper] == (spielfeld[i][helper+3]-treffer) ){
                        max_rechts = 3;
                        }
                    }
                }
            }
        }
    }

    treffer_horizontal = -(max_links) + max_rechts;

    if(treffer_horizontal >= 3){
            for(int k = max_links; k<= max_rechts;k++){
                if(spielfeld[i][helper+k] < treffer){spielfeld[i][helper+k] += treffer;
                    match_counter++;
                }
            }
        }
    }
    }
    }
    }

    return match_counter;
}


/*match wird durch add_to_spielfeld aufgerufen und ruft selber die einzelnen Treffer-Möglichkeiten ab; wenn einer der Möglichkeit einen Treffer gefunden hat, werden die Treffer auf leer gesetzt
und reorganize wird aufgerufen*/
void match(int max_y_koordinate, int spalte, int zeile){
    //int controller = 0;
    int max_y = max_y_koordinate;

    int x_links = spalte -6;
    int x_rechts = spalte +6;
    int y_unten = zeile -6;
    int y_oben = zeile +6;

    int test_horizontal = match_horizontale(zeile,spalte,max_y);
    int test_vertikal = match_vertikal(zeile,spalte,max_y);
    int test_diagonale = match_diagonal(zeile,spalte,max_y);


    if(test_horizontal!=0 || test_vertikal!=0 || test_diagonale!=0){

        //gucke nach horizontale
        while(x_links<0){x_links++;};
        if(x_rechts >= x_spielfeld){x_rechts = x_spielfeld;}

        while(y_unten<0){y_unten++;}
        if(y_oben >= y_spielfeld){y_oben = y_spielfeld;}

        for(int i = 0; i<y_spielfeld;i++){
            for(int j = 0; j<x_spielfeld;j++){
                if((spielfeld[i][j]-treffer)>= 0){
                    spielfeld[i][j] = leer;}}}

        if(reorganize_spielfeld(zeile)!=0);
        //aufruf nach reorganize
        for(int i = 0; i<max_y; i++){
            for(int j = 0; j<x_spielfeld;j++){
                match(max_y,j,i);}}

        }
}

/*fügt Farben dem Spielfeld hinzu und ruft match() auf*/
void add_to_spielfeld(int farbe, int x_koordinate){
    int count_y = 0;

    start_playing++;

    int tmp = spielfeld[count_y][x_koordinate];

    while (tmp != 300){
            count_y++;
            if(count_y == y_spielfeld){check_row_spielfeld();}
            tmp = spielfeld[count_y][x_koordinate];
        }

        spielfeld[count_y][x_koordinate] = farbe;

    if(max_y_koordinate<count_y){max_y_koordinate = count_y;}

    if(start_playing >= 4){
        match(max_y_koordinate,x_koordinate, count_y);
        }

}

/* ueberprüft die Eingabe und gibt Infos an add_to_spielfeld weiter, nachdem ueberprüft wird, ob genug speicher vorhanden*/
int checkline(char *line){
    size_t length_line = strlen(line);;
    char helper;
    int counter = 0;
    char* linefeed = "\r\n";

    char future_reader;
    int remember = 0;
    int anzahl_werte = 0;
    int zahl = 0;
    int remember_farbe;
    int remember_x;

    int addition;

    //int new_zeilen = 0;
    while(counter <= length_line){
        helper = line[counter];

        if (helper == '\n' || helper == '\r' || isdigit(helper) || helper == ' ' || helper == '-' || helper == *linefeed || helper == '\0'){
               if(helper == '-'){
                    remember++;}

                else if (isdigit(helper)){

                        zahl = zahl*10 + (helper-'0');
                        if(zahl > 1048576 && (zahl + zahl) <= zahl){fprintf(stderr, "Overflow, eingegebene Zahl ist zu groß.\n");
                        return 1;}
                        future_reader = line[counter+1];

                    switch(future_reader){

                            case ' ':   if(remember == 1){
                                            zahl=-(zahl);}
                                        if (zahl < 0 || zahl > 254){
                                            fprintf(stderr,"Farbwert nicht akzeptiert.\n");
                                            return 2;}
                                        remember_farbe=zahl;
                                        zahl = 0;

                                        anzahl_werte++;
                                        break;

                            default:    if(future_reader=='\n'|| future_reader == '\r' || future_reader == *linefeed){

                                                if(remember == 1){
                                                    zahl = -(zahl);}

                                            remember_x=zahl;

                                            if(min_element > zahl){
                                                    int help = -(zahl);
                                                    addition = min_element + help;

                                                    min_element = zahl;



                                                    max_offset = -(zahl);
                                                    check_column_spielfeld(addition, remember_farbe, remember_x);
                                                    add_to_spielfeld(remember_farbe, remember_x+max_offset);
                                            }
                                            else if(max_element < zahl){



                                                    max_element = zahl;
                                                    addition = max_element + 1 + max_offset - x_spielfeld;

                                                    check_column_spielfeld(addition, remember_farbe, remember_x);
                                                    add_to_spielfeld(remember_farbe, remember_x+max_offset);
                                                    }
                                            else{
                                                add_to_spielfeld(remember_farbe, remember_x+max_offset);
                                                }

                                            zahl = 0;
                                            anzahl_werte++;
                                        }
                                        break;
                            }

                }
        }
        else {
            return 3;
            }

        counter++;
            }

      if (anzahl_werte != 2){
                 return 3;
                     }

    return 0;
}


int main(int argc, char* argv[])
{

    char *buffer = NULL;
    size_t size;
    int help = 0;
    int var;

    int x_koordinate;
    int y_koordinate;
    int farbe;


    //initialise ein vorerst 6x6 Spielfeld-Array mit Startwert 300
    spielfeld = (int**) malloc(y_spielfeld * sizeof(int**));
    for(int j= 0; j<y_spielfeld; j++){
            spielfeld[j] = (int *) malloc(x_spielfeld * sizeof(int));
        }
    if(!spielfeld){
        fprintf(stderr,"Malloc failed.\n");
        free_spielfeld();
    }

    for(int l = 0; l<y_spielfeld;l++){
        for(int m = 0; m<x_spielfeld;m++){
            spielfeld[l][m] = leer;}}


    //Lese von stdin und ueberpruefe, ob richtige Datei
    while(help != 1){
        var = getline(&buffer,&size,stdin);
        if(var == EOF){break;}
            else {
                if(var != strlen(buffer)){fprintf(stderr,"Input not accepted.\n");
                free_spielfeld();
                free(buffer);
                exit(1);}

                else if (checkline(buffer) != 0){
                    fprintf(stderr, "Input not accepted.\n" );
                free_spielfeld();
                free(buffer);
                exit(1);
                }

            }
        }

    for(int b = 0; b<=max_y_koordinate;b++){
        for (int a = 0; a<x_spielfeld;a++){
            if(spielfeld[b][a] != 300){
              farbe = spielfeld[b][a];
              x_koordinate = a - max_offset;
              y_koordinate = b;

              printf("%d %d %d\n", farbe, x_koordinate, y_koordinate);}
            }}


    free(buffer);
    free_spielfeld();
    exit(0);

}
