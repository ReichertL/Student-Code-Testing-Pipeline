#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <regex.h>
#include <signal.h>

typedef struct {
    long min_column_left;
    long width;
    long height;
    unsigned char** data;
} field_type;


// creates new field with height and width of the given fieldptr
void init_field(field_type* fieldptr, long min_column_left) {
    fieldptr->data = malloc(1 * sizeof(char*));
    fieldptr->data[0] = malloc(1 * sizeof(char));
    fieldptr->data[0][0] = 255;
    
    fieldptr->width = 1;
    fieldptr->height = 1;
    fieldptr->min_column_left = min_column_left;
}

void free_field(field_type* fieldptr) {

    for (long i = 0; i < fieldptr->width; i++) {
        free(fieldptr->data[i]);
    }
    
    free(fieldptr->data);
}

unsigned char field_get(field_type* fieldptr, long input_column, long input_row) {
    if (input_row < 0 || input_row >= fieldptr->height)
        return 255;
    long mem_column = input_column - fieldptr->min_column_left;
    if ((mem_column < 0) || (mem_column >= fieldptr->width))
        return 255;
    
    return fieldptr->data[mem_column][input_row];
}

long height_of_free_cell(field_type* fieldptr, long input_column) {
    for (long r = 0; r < fieldptr->height; r++) {
        if (field_get(fieldptr, input_column, r) == 255)
            return r;
    }
    
    return fieldptr->height;
}

void delete(field_type* fieldptr, long input_column, long row);
int check_direction(field_type* fieldptr, long input_column, long row, unsigned char color, long dc, long dr) {
    int num_candies = 0;
    while (1) {
        input_column += dc;
        row += dr;
        
        if (field_get(fieldptr, input_column, row) != color)
            break;
        
        num_candies++;
    }
    
    return num_candies;
}

void delete_direction(field_type* fieldptr, long input_column, long row, unsigned char color, long dc, long dr) {
    while (1) {
        input_column += dc;
        row += dr;
        
        if (field_get(fieldptr, input_column, row) != color)
            break;
        
        delete(fieldptr, input_column, row);
    }
}

void check(field_type* fieldptr, long input_column, long row) {
    unsigned char color = field_get(fieldptr, input_column, row);
    if (color == 255)
        return;
    
    if (check_direction(fieldptr, input_column, row, color, 0, 1) + check_direction(fieldptr, input_column, row, color, 0, -1) + 1 >= 4) {
        while (field_get(fieldptr, input_column, row) == color)
            delete(fieldptr, input_column, row);
        delete_direction(fieldptr, input_column, row, color, 0, -1);
    }
    
    if (check_direction(fieldptr, input_column, row, color, 1, 1) + check_direction(fieldptr, input_column, row, color, -1, -1) + 1 >= 4) {
        delete_direction(fieldptr, input_column, row, color, 1, 1);
        delete_direction(fieldptr, input_column, row, color, -1, -1);
        delete(fieldptr, input_column, row);
    }
    
    if (check_direction(fieldptr, input_column, row, color, 1, 0) + check_direction(fieldptr, input_column, row, color, -1, 0) + 1 >= 4) {
        delete_direction(fieldptr, input_column, row, color, 1, 0);
        delete_direction(fieldptr, input_column, row, color, -1, 0);
        delete(fieldptr, input_column, row);
    }
    
    if (check_direction(fieldptr, input_column, row, color, 1, -1) + check_direction(fieldptr, input_column, row, color, -1, 1) + 1 >= 4) {
        delete_direction(fieldptr, input_column, row, color, 1, -1);
        delete_direction(fieldptr, input_column, row, color, -1, 1);
        delete(fieldptr, input_column, row);
    }
    
    
}

void delete(field_type* fieldptr, long input_column, long row) {
    long mem_column = input_column - fieldptr->min_column_left;
    
    if(row >= fieldptr->height || mem_column >= fieldptr->width || row < 0) {
        fprintf(stderr, "cell could not be deleted, out of field boundaries");
        exit(1);
    }

    fieldptr->data[mem_column][row] = 255;
    for (long r = row + 1; r < fieldptr->height; r++) {
        fieldptr->data[mem_column][r - 1] = fieldptr->data[mem_column][r];
    }
    
    for (long r = row + 1; r < fieldptr->height; r++) {
        check(fieldptr, input_column, row);
    }
}

void init_column(field_type* fieldptr, long mem_column) {
    fieldptr->data[mem_column] = malloc(fieldptr->height * sizeof(char));
    if (fieldptr->data[mem_column] == NULL) raise(SIGTRAP);
    for (long r = 0; r < fieldptr->height; r++)
        fieldptr->data[mem_column][r] = 255;
}

void add(field_type* fieldptr, unsigned char input_color, long input_column) {
    // initialisieren
    if(fieldptr->data == NULL) {
        init_field(fieldptr, input_column);
    }
        
    long mem_column = input_column - fieldptr->min_column_left;
    // nach rechts vergroessern
    if(mem_column >= fieldptr->width) {
        long new_width = mem_column + 1;
        fieldptr->data = realloc(fieldptr->data, new_width * sizeof(char*));
        for (long c = fieldptr->width; c < new_width; c++) {
            init_column(fieldptr, c);
        }
        
        fieldptr->width = new_width;
    }
    
    // nach links vergroessern
    if(mem_column < 0) {
        long additional_cols = abs(mem_column);
        long new_width = fieldptr->width + additional_cols;
        
        fieldptr->data = realloc(fieldptr->data, new_width * sizeof(char*));
        
        // shift columns to right by additional_cols
        for (long c = new_width - 1; c >= additional_cols; c--)
            fieldptr->data[c] = fieldptr->data[c - additional_cols];
        
        // init first additional_cols columns
        for (long c = 0; c < additional_cols; c++)
            init_column(fieldptr, c);
        
        
        fieldptr->width = new_width;
        fieldptr->min_column_left = input_column;
        mem_column = 0;
    }
    
    long input_row = height_of_free_cell(fieldptr, input_column);
    // nach oben vergroessern
    if (input_row >= fieldptr->height) {
        long new_height = input_row + 1;
        
        for (long c = 0; c < fieldptr->width; c++) {
            fieldptr->data[c] = realloc(fieldptr->data[c], (new_height) * sizeof(char));
            
            for (long r = fieldptr->height; r < new_height; r++) {
                fieldptr->data[c][r] = 255;
            }
        }
        
        fieldptr->height = new_height;
    }
    
    fieldptr->data[mem_column][input_row] = input_color;
    check(fieldptr, input_column, input_row);
}

void print_field(field_type* fieldptr) {
    //(Farbe, x-Koordinate, yKoordinate), getrennt durch jeweils genau ein Leerzeichen
    
    // sonderfall: noch nichts hinzugefuegt
    if (fieldptr->data == NULL) return;
    
    for (long c = 0; c < fieldptr->width; c++) {
        for (long r = 0; r < fieldptr->height; r++) {
            if(fieldptr->data[c][r] != 255)
                printf("%i %ld %ld\n", fieldptr->data[c][r], r, c + fieldptr->min_column_left);
        }
    }
}

int main() {
    field_type field;
    field.data = NULL;
    
    char buf[100];
    char whitespace[100];
    long line = 0;
    while (fgets(buf, sizeof buf, stdin) != NULL) {
        long column;
        unsigned int color;
        if (sscanf(buf, "%u%[ ]%ld", &color, whitespace, &column) < 3 || (color > 255 || abs(column) > pow(2,20))) {
            fprintf(stderr, "invalid input\n");
            free_field(&field);
            exit(1);
        }
        
        add(&field, (unsigned char) color, column);
        
        line++;
    }
    
    print_field(&field);
    free_field(&field);
    
    return 0;
}