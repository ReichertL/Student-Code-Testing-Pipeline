#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h> //_Bool


// Dynamisch wachsenes Array
struct DynArray {
    int len;
    int cap;
    int item_size;
    void* ptr;
};


// Repräsentiert das Spielfeld
struct Game {
    struct DynArray columns; // DynArray von Spalten (auch wieder DynArrays)
    int offset; // Verschiebung, Index 0 -> kleinstes x von Blöcken die eingegeben wurden
};


struct InputBlock {
    int x;
    char color;
};


struct Coordinate {
    int x;
    int y;
};

// Globale pointer, genutzt für einfache free Anwendung
struct DynArray* columns_ptr = 0;
struct DynArray* to_destroy_ptr = 0; // beinhaltet Koordinaten von zu löschenden Blöcken
_Bool* changed_lines = 0;
_Bool* cuts = 0; // Schnittstellen die beim Löschen von Blöcken entstehen

void free_all() {
    if (columns_ptr != 0) {
	struct DynArray* columns = columns_ptr->ptr;
	for (int i = 0; i < columns_ptr->len; i++) {
	    free(columns[i].ptr);
	}
	free(columns_ptr->ptr);
    }
    if (to_destroy_ptr != 0) {
	free(to_destroy_ptr->ptr);
    }
    free(changed_lines);
    free(cuts);
}

void fail_exit() {
    free_all();
    exit(-1);
}

// malloc wrapper zur sicheren Fehlerbehandlung
void* myalloc(int c) {
    void* ptr = malloc(c);
    if (ptr == 0) {
	fail_exit();
    }
    return ptr;
}

// realloc wrapper zur sicheren Fehlerbehandlung
void* mealloc(void* ptr, int c) {
    ptr = realloc(ptr, c);
    if (ptr == 0) {
	fail_exit();
    }
    return ptr;
}

// zum überprüfen der Eingabe, gibt zurück, wie viele durch Leerzeichen getrennte "Wörter" in einer Zeile sind
int check_value_count(const char *buffer, int size) {
    int i = 0;
    int spaces = 1; // gibt an, ob gerade Leerzeichen betrachtet werden oder ein Wort
    int count = 0;
    while (i < size) {
	char c = buffer[i];
	if (c == 0 || c == '\n') {
	    break;
	}
	if (spaces == 1) {
	    if (c != ' ') {
		spaces = 0;
		count += 1;
		if (count > 2) {
		    fail_exit();
		}
	    }
	}
	else {
	    if (c == ' ') {
		spaces = 1;
	    }
	}
	i += 1;
    }
    if (count == 1) {
	fail_exit();
    }
    return count;
}

// Für den Input zuständige Funktion
int get_block(struct InputBlock *block) {
    char str[100]; // In dieser Implementation ein Limit auf die Zeichen in einer Zeile, kann nach belieben erhöht werden
    char* e1 = fgets(str, sizeof(str), stdin);
    if (e1 == 0) {
	return EOF;
    }
    int num = check_value_count(str, sizeof(str));
    if (num == 0 && feof(stdin)) {
	return EOF;
    }
    int color = 0;
    int x = 0;
    int e = sscanf(str, "%d %d", &color, &x);
    if (x > 1048576 || x < -1048576) {
	fail_exit();
    }
    if (color < 0 || color > 254) {
	fail_exit();
    }
    block->color = color;
    block->x = x;
    if (e != 2) {
	fail_exit();
    }
    return 0;
}

void print_block(struct InputBlock block, int offset) {
    printf("\nNew Block: color : %d\n", block.color);
    printf("           pos   : %d\n", block.x - offset);
}

void print_column(struct DynArray* c) {
    printf("\nCurrent Column: cap : %d\n", c->cap);
    printf("                len : %d\n", c->len);
}

// Konstruktor für dynamische Arrays
struct DynArray dyn_array_init(int item_size) {
    struct DynArray arr;
    arr.len = 0;
    arr.cap = 8;
    arr.item_size = item_size;
    arr.ptr = myalloc(arr.cap * arr.item_size);
    if (arr.ptr == 0) {
	printf("Allocated null pointer");
    }
    return arr;
}

// zum freeen von dynamischen Arrays
void absolutely_demolish(struct DynArray* arr) {
    free(arr->ptr);
}

// zum Zurücksetzten von dynamischen Arrays
void absolutely_reset(struct DynArray* arr) {
    free(arr->ptr);
    arr->len = 0;
    arr->cap = 8;
    arr->ptr = myalloc(arr->cap * arr->item_size);
    if (arr->ptr == 0) {
	printf("Allocated null pointer");
    }
}

// zum Anfügen von Elementen an dynamische Arrays
int append(struct DynArray* arr, void* new_element) {
    if (arr->len == arr->cap) {
	arr->cap *= 2;
	arr->ptr = mealloc(arr->ptr, arr->cap * arr->item_size);
	if (arr->ptr == 0) {
	    fail_exit();
	}
    }
    unsigned char* ptr = arr->ptr;
    memcpy(ptr + (arr->len * arr->item_size), new_element, arr->item_size);
    arr->len += 1;
    return arr->len - 1;
}

// gibt Pointer eines Elementes zurück
void* get_raw(struct DynArray* arr, int index) {
    unsigned char* ptr = arr->ptr;
    return ptr + (index * arr->item_size);
}

// zum Einfügen von Elementen an einen bestimmten Index
int insert_at(struct DynArray* arr, void* new_element, int index) {
    if (index < 0 || index >= arr->len) {
	printf("Array OOB");
	fail_exit();
    }
    memcpy(get_raw(arr, index), new_element, arr->item_size);
    return 0;
}

// zum Erhöhen der Kapazität eines Arrays
int raw_increase_capacity(struct DynArray* arr, int min) {
    while(arr->cap <= min) {
	arr->cap *= 2;
    }
    //printf("pointer: %p\n", arr->ptr); //DEBUG
    //printf("cap: %d, item_size: %d\n", arr->cap, arr->item_size); //DEBUG
    arr->ptr = mealloc(arr->ptr, arr->cap * arr->item_size);
    if (arr->ptr == 0) {
	fail_exit();
    }
    return 0;
}

// Für leicht lesbare Ausgabe des Spielfeldes
void draw_game(struct Game* game) {
    printf("\nOffset : %d\n", game->offset);
    printf("Columns: %d\n", game->columns.len);
    struct DynArray* game_columns = game->columns.ptr;
    for (int i = 0; i < game->columns.len; i++) {
	struct DynArray* column = &game_columns[i];
	unsigned char* blocks = column->ptr;

	printf("%d|", column->len);
	for (int j = 0; j < column->len; j++) {
	    printf("%d", blocks[j]);
	}
	printf("\n");
    }
}

// Für Aufgaben-konforme Ausgabe
void output_game(struct Game* game) {
    struct DynArray* columns = game->columns.ptr;
    for (int i = 0; i < game->columns.len; i++) {
	struct DynArray* column = &columns[i];
	unsigned char* blocks = column->ptr;
	for (int j = 0; j < column->len; j++) {
	    printf("%d %d %d\n", blocks[j], i + game->offset, j);
	}
    }
}

// Erweitert das Spalten-Array nach vorne
int expand_game_forwards(struct Game* game, int x) {
    int diff = x - (game->columns.len - 1);
    for (int i = 0; i < diff; i++) {
	struct DynArray new_column = dyn_array_init(sizeof(unsigned char));
	if (append(&game->columns, &new_column) == -1) { // initialisiert alls Spalten
	    fail_exit();
	};
    }
    return 0;
}

// Erweitert das Spalten-Array nach hinten
int expand_game_backwards(struct Game* game, int x) {
    int diff = -x;
    if (raw_increase_capacity(&game->columns, game->columns.len + diff) == -1) {
	fail_exit();
    }
    unsigned char* ptr = game->columns.ptr;
    memmove(ptr + (diff * game->columns.item_size), ptr, game->columns.len * game->columns.item_size); // verschiebt alle Elemente nach hinten
    game->columns.len += diff;
    for (int i = 0; i < diff; i++) {
	struct DynArray new_column = dyn_array_init(sizeof(unsigned char));
	if (insert_at(&game->columns, &new_column, i) == -1) { // initialisiert alls Spalten
	    printf("unreachable: (expand_game_backwards) oob game column access\n");	
	    fail_exit();
	}
    }
    game->offset -= diff;
    return 0;
}

// Organisiert das Erweitern des Spalten-Arrays falls nötig
int resize_game(struct Game* game, int x) {
    if (x >= game->columns.len) {
	expand_game_forwards(game, x);
    }
    if (x < 0) {
	expand_game_backwards(game, x);
    }
    return 0;
}

// Schrumpft Spalten, nachdem einzelne Blöcke gelöscht wurden
void flatten(struct DynArray* column, int x, _Bool* cuts, struct DynArray* column_first_touched) {
    unsigned char* blocks = column->ptr;
    int skipped = 0;
    bool first_skipped = true;
    for (int i = 0; i < column->len; i++) {
	if (blocks[i] == 255) { // 255 -> Hier wurde ein Block gelöscht
	    cuts[i - skipped] = true;
	    if (first_skipped && i != column->len - 1) {
		struct Coordinate coor;
		coor.x = x;
		coor.y = i;
		append(column_first_touched, &coor);
		first_skipped = false;
	    }
	    skipped++;
	}
	else {
	    blocks[i - skipped] = blocks[i]; // verschiebt die nicht gelöschten Blöcke
	}
    }
    for (int i = column->len - skipped; i < column->len; i++) {
	blocks[i] = 255;
    }
    column->len -= skipped;
}

// Bekommt Koordinaten (to_destroy), an denen Blöcke gelöscht werden sollen, löscht diese
void empty_blocks(struct Game* game, struct DynArray* to_destroy, _Bool* changed_lines) {
    struct DynArray* columns = game->columns.ptr;
    struct Coordinate* coordinates = to_destroy->ptr;
    for (int i = 0; i < to_destroy->len; i++) {
	struct Coordinate* coor = &coordinates[i];
	unsigned char* column_blocks = columns[coor->x].ptr;
	column_blocks[coor->y] = 255;
	changed_lines[coor->x] = true;
    }
}

// Überprüft ob vertikal gelöscht werden muss bei einem new plazierten Block
void initial_vertical(struct Game* game, struct Coordinate xy, struct DynArray* to_destroy) {
    struct DynArray* columns = game->columns.ptr;
    unsigned char* column_blocks = columns[xy.x].ptr;
    unsigned char color = column_blocks[xy.y];
    int count = 1;
    for (int i = xy.y - 1; i >= 0; i--) {
	if (column_blocks[i] == color) {
	    count += 1;
	}
	else {
	    break;
	}
    }
    if (count >= 4) {
	if (count > 4) {
	    printf("unreachable: More than 4 consecutive blocks vertically on new block");
	    exit(-1);
	}
	struct Coordinate coor;
	coor.x = xy.x;
	for (int i = 0; i < 4; i++) {
	    coor.y = xy.y - i;
	    append(to_destroy, &coor);
	}
    }
}

// Überprüft ob horizontal gelöscht werden muss bei einem new plazierten Block
void initial_horizontal(struct Game* game, struct Coordinate xy, struct DynArray* to_destroy) {
    struct DynArray* columns = game->columns.ptr;
    unsigned char* blocks = columns[xy.x].ptr;
    int color = blocks[xy.y];
    int count = 1;
    for (int i = -1; i > -4; i--) {
	if (xy.x + i < 0) {
	    break;
	}
	struct DynArray* column = &columns[xy.x + i];
	if (column->len <= xy.y) {
	    break;
	}
	blocks = column->ptr;
	if (blocks[xy.y] != color) {
	    break;
	}
	count += 1;
    }
    int last = 0;
    for (int i = 1; i < 4; i++) {
	if (xy.x + i >= game->columns.len) {
	    break;
	}
	struct DynArray* column = &columns[xy.x + i];
	if (column->len <= xy.y) {
	    break;
	}
	blocks = column->ptr;
	if (blocks[xy.y] != color) {
	    break;
	}
	count += 1;
	last += 1;
    }
    if (count >= 4) {
	struct Coordinate coor;
	coor.y = xy.y;
	for (int i = 0; i < count; i++) {
	    coor.x = xy.x + last - i;
	    append(to_destroy, &coor);
	}
    }
}

// Überprüft ob diagonal gelöscht werden muss bei einem new plazierten Block
void initial_diagonal(struct Game* game, struct Coordinate xy, struct DynArray* to_destroy) {
    struct DynArray* columns = game->columns.ptr;
    unsigned char* blocks = columns[xy.x].ptr;
    int color = blocks[xy.y];
    int count = 1;
    int y = 0;
    // up left to down right first
    for (int i = -1; i > -4; i--) {
	y += 1;
	if (xy.x + i < 0) {
	    break;
	}
	struct DynArray* column = &columns[xy.x + i];
	if (column->len <= xy.y + y) {
	    break;
	}
	blocks = column->ptr;
	if (blocks[xy.y + y] != color) {
	    break;
	}
	count += 1;
    }
    int last = 0;
    y = 0;
    for (int i = 1; i < 4; i++) {
	y -= 1;
	if (xy.x + i >= game->columns.len) {
	    break;
	}
	struct DynArray* column = &columns[xy.x + i];
	if (column->len <= xy.y + y) {
	    break;
	}
	if (xy.y + y < 0) {
	    break;
	}
	blocks = column->ptr;
	if (blocks[xy.y + y] != color) {
	    break;
	}
	count += 1;
	last += 1;
    }
    if (count >= 4) {
	struct Coordinate coor;
	y = -last;
	for (int i = 0; i < count; i++) {
	    coor.x = xy.x + last - i;
	    coor.y = xy.y + y;
	    append(to_destroy, &coor);
	    y += 1;
	}
    }
    count = 1;
    y = 0;
    // then down left to up right
    for (int i = -1; i > -4; i--) {
	y -= 1;
	if (xy.x + i < 0) {
	    break;
	}
	struct DynArray* column = &columns[xy.x + i];
	//printf("dynarray len: %d, y: %d\n", column->len, xy.y + y); //DEBUG
	if (column->len <= xy.y + y) {
	    break;
	}
	if (xy.y + y < 0) {
	    break;
	}
	blocks = column->ptr;
	if (blocks[xy.y + y] != color) {
	    break;
	}
	count += 1;
    }
    last = 0;
    y = 0;
    for (int i = 1; i < 4; i++) {
	y += 1;
	if (xy.x + i >= game->columns.len) {
	    break;
	}
	struct DynArray* column = &columns[xy.x + i];
	if (column->len <= xy.y + y) {
	    break;
	}
	blocks = column->ptr;
	if (blocks[xy.y + y] != color) {
	    break;
	}
	count += 1;
	last += 1;
	//printf("\neins nach oben links\n"); //DEBUG
    }
    if (count >= 4) {
	//printf("\n DESTROY 2\n"); //DEBUG
	struct Coordinate coor;
	y = last;
	for (int i = 0; i < count; i++) {
	    coor.x = xy.x + last - i;
	    coor.y = xy.y + y;
	    append(to_destroy, &coor);
	    y -= 1;
	}
    }
}

// Zum iterativen Überprüfen, ob vertikal Blöcke gelöscht werden müssen
void general_vertical(struct DynArray* column, int x, _Bool* cuts, struct DynArray* to_destroy) {
    if (column->len < 4) {
	return;
    }
    unsigned char* blocks = column->ptr;
    for (int i = 1; i < column->len; i++) {
	if (!cuts[i]) { // Nur bei einer Schnittstelle muss überprüft werden
	    continue;
	}
	int color = blocks[i-1];
	int count = 1;
	for (int j = -2; j >= -3; j--) {
	    if (i + j < 0) {
		break;
	    }
	    if (blocks[i + j] != color) {
		break;
	    }
	    count += 1;
	}
	int last = -1;
	for (int j = 0; j < 3; j++) {
	    if (i + j >= column->len) {
		break;
	    }
	    if (blocks[i + j] != color) {
		break;
	    }
	    count += 1;
	    last += 1;
	}
	if (count >= 4) {
	    struct Coordinate coor;
	    coor.x = x;
	    for (int j = 0; j < count; j++) {
		coor.y = i + last - j;
		append(to_destroy, &coor);
	    }
	}
    }
}

// Zum iterativen Überprüfen, ob horizontal Blöcke gelöscht werden müssen
void general_horizontal(struct Game* game, struct DynArray* to_destroy, int min, int max, int real_first, int real_last) {
    int len = max - min + 1;
    int* counts = myalloc(len * sizeof(int)); // geht von links nach rechts durch, speichert wie viele gleiche hintereinander auftauchen
    memset(counts, 0, len*sizeof(int)); // memset zu 0 -> counts sind in wahrheit 1 größer
    struct DynArray* columns = game->columns.ptr;
    struct DynArray* last_column = &columns[real_first];
    for (int x = real_first + 1; x <= real_last; x++) { // +1 da erste werte bereits benutzt wurden
	struct DynArray* column = &columns[x];
	unsigned char* blocks = column->ptr;
	for (int offset_y = 0; offset_y < len; offset_y++) {
	    //printf("(%d, %d)\n", x, min + offset_y); //DEBUG
	    if (min + offset_y < column->len) {
		if (min + offset_y >= last_column->len) {
		    break;
		}
		unsigned char* last_blocks = last_column->ptr;
		if (last_blocks[min + offset_y] == blocks[min + offset_y]) {
		    counts[offset_y] += 1;
		    //printf("consecutive block placed, now %d\n", counts[offset_y]); //DEBUG
		    continue;
		}
	    }
	    if (counts[offset_y] >= 3) {
		struct Coordinate delete;
		delete.y = min + offset_y;
		for (int i = 0; i <= counts[offset_y]; i ++) {
		    delete.x = x - i - 1;
		    append(to_destroy, &delete);
		}
	    }
	    counts[offset_y] = 0;
	}
	last_column = column;
    }
    for (int offset_y = 0; offset_y < len; offset_y++) {
	if (counts[offset_y] >= 3) {
	    struct Coordinate delete;
	    delete.y = min + offset_y;
	    for (int i = 0; i <= counts[offset_y]; i ++) {
		delete.x = real_last - i;
		append(to_destroy, &delete);
	    }
	}
    }
    free(counts);
}

// um sicherzugehen, dass kein negatives Ergebnis kommen kann
int modulo(int n, int m) {
    int r = n % m;
    if (r < 0) {
	r += m;
    }
    return r;
}

// Zum iterativen Überprüfen, ob horizontal Blöcke gelöscht werden müssen
void general_diagonal(struct Game* game, struct DynArray* to_destroy, int min, int max, int real_first, int real_last, int steps) {
    min -= 3; // beim diagonalen Überprüfen kann es noch 3 Blöcke 
    if (min < 0) {
	min = 0;
    }
    if (max < 4) {
	return;
    }
    int len = max - min + 1;
    int* counts = myalloc(len * sizeof(int)); // geht von links nach rechts durch, speicher hier wie viele hintereinander jeweils gefunden wurden
    memset(counts, 0, len*sizeof(int)); // memset zu 0 -> counts sind in wahrheit 1 größer
    struct DynArray* columns = game->columns.ptr;
    struct DynArray* last_column = &columns[real_first];
    for (int y = last_column->len - min; y < len; y++) {
	counts[y] = -1;
    }
    // Iterieren über relevante Spalten
    for (int x_offset = 1; x_offset <= real_last - real_first; x_offset++) { // +1 da erste werte bereits benutzt wurden
	struct DynArray* column = &columns[real_first + x_offset];
	unsigned char* blocks = column->ptr;
	for (int counts_y = 0; counts_y < len; counts_y++) {
	    int y = min + modulo(counts_y - (steps * x_offset), len); // berechnet position auf diagonalen die hier durchgegangen wird
	    //printf("(%d, %d)\n", real_first + x_offset, y); //DEBUG
	    int old_count = counts[counts_y];
	    if (y < column->len) {
		if (counts[counts_y] == -1) {
		    counts[counts_y] = 0;
		    continue;
		}
		unsigned char* last_blocks = last_column->ptr;
		int last_y = min + modulo(counts_y - (steps * (x_offset - 1)), len);
		if (last_blocks[last_y] == blocks[y] && last_y - y == steps) { // letztere Bedingung trifft ein wenn die diagonal gerade wrapped
		    counts[counts_y] += 1;
		    //printf("consecutive block placed, now %d\n", counts[counts_y]); //DEBUG
		    continue;
		}
		else {
		    counts[counts_y] = 0; // reset, falls Farbe mit dem letzten Block auf der diagonalen nicht übereinstimmt
		}
	    }
	    else {
		counts[counts_y] = -1; // auf -1, falls der die Spalte nicht bis zu dieser Position geht
	    }
	    if (old_count >= 3) {
		struct Coordinate delete;
		for (int i = 0; i <= old_count; i++) {
		    delete.y = y + steps * i;
		    delete.x = real_last + x_offset - i;
		    append(to_destroy, &delete);
		}
	    }
	}
	last_column = column;
    }

    // Wenn eine Reihe bis zur letzten relevanten Spalte geht, so wird diese erst hier registriert
    for (int offset_y = 0; offset_y < len; offset_y++) {
	if (counts[offset_y] >= 3) {
	    int y = min + modulo(offset_y - (real_last - real_first), len);
	    struct Coordinate delete;
	    for (int i = 0; i <= counts[offset_y]; i++) {
		delete.y = y + steps * i;
		delete.x = real_last - i;
		append(to_destroy, &delete);
	    }
	}
    }
    free(counts);
}

// Vorbereitungsarbeit für general_horizontal und general_diagonal
void general_not_vertical(struct Game* game, struct DynArray* touched_columns, struct DynArray* to_destroy) {
    struct DynArray* columns = game->columns.ptr;
    struct Coordinate* first_touched = touched_columns->ptr;
    // bestimmt mit first, last, max, min rechteck um veränderte Blöcke
    int last = 0;
    for (int i = 0; i < touched_columns->len; i++) {
	//printf("BEKOMMEN: (%d, %d)\n", first_touched[i].x, first_touched[i].y); //DEBUG
    }
    for (int first = 0; first < touched_columns->len; first++) {
	last = first;
	for (int i = first + 1; i < touched_columns->len; i++) {
	    if (first_touched[i].x - first_touched[i - 1].x > 3) {
		break;
	    }
	    last += 1;
	}
	int min = first_touched[first].y;
	int max = 0;
	for (int i = first; i <= last; i++) {
	    if (first_touched[i].y < min) {
		min = first_touched[i].y;
	    }
	    if (columns[first_touched[i].x].len >= max) { //DEBUG: >= -> >
		//printf("new max on %d: %d\n", i, max); //DEBUG
		max = columns[first_touched[i].x].len;
	    }
	}
	int real_first = first_touched[first].x - 3;
	if (real_first < 0) {
	    real_first = 0;
	}
	int real_last = first_touched[last].x + 3;
	if (real_last >= game->columns.len) {
	    real_last = game->columns.len - 1;
	}
	/* //DEBUG
	printf("REALFIRST: %d\n", real_first);
	printf("REALLAST: %d\n", real_last);
	printf("MIN: %d\n", min);
	printf("MAX: %d\n", max);
	*/
	general_horizontal(game, to_destroy, min, max, real_first, real_last);
	general_diagonal(game, to_destroy, min, max, real_first, real_last, 1);
	general_diagonal(game, to_destroy, min, max, real_first, real_last, -1);
	first = last + 1;
    }
}

int main() {
    struct InputBlock new_block;

    int e = get_block(&new_block);
    if (e == EOF) {
	return 0;
    }
    if (e == -1) {
	fail_exit();
	return -1;
    }

    // Initialisierung des Spieles
    // Der erste Block legt den offset fest, wird deshalb seperat ausgelesen
    struct Game game;
    game.offset = new_block.x;
    game.columns = dyn_array_init(sizeof(struct DynArray));
    columns_ptr = &game.columns;
    struct DynArray first_column = dyn_array_init(sizeof(unsigned char));
    append(&game.columns, &first_column);

    // to_destroy beinhaltet die Koordinaten von Blöcken, welche gelöscht werden sollen
    struct DynArray to_destroy = dyn_array_init(sizeof(struct Coordinate));
    to_destroy_ptr = &to_destroy;
    
    while (21) {
	// block einfügen
	struct DynArray* columns = game.columns.ptr;
	int corrected_x = new_block.x - game.offset;
	struct DynArray* column = &columns[corrected_x];
	if (column->ptr == 0) {
	    fprintf(stderr, "unreachable: null pointer on column\n");
	    fail_exit();
	}
	int y = append(column, &new_block.color);

	struct Coordinate initial_destroyed; // initial_destroyed ist der eingefügte Block (zugegebenermaßen nicht treffende Namensgebung)
	initial_destroyed.x = corrected_x;
	initial_destroyed.y = y;
	
	absolutely_reset(&to_destroy); // resetted das Array zur Neubenutzung

	// füllen von to_destroy nach dem eingefügten block block
	initial_vertical(&game, initial_destroyed, &to_destroy);
	initial_horizontal(&game, initial_destroyed, &to_destroy);
	initial_diagonal(&game, initial_destroyed, &to_destroy);
	
	while (to_destroy.len != 0) { // Schleife die weiterläuft bis bei einem Durchlauf keine Blöcke entfernt wurden
	    changed_lines = mealloc(changed_lines, game.columns.len * sizeof(_Bool));
	    memset(changed_lines, 0, game.columns.len * sizeof(_Bool));
	    empty_blocks(&game, &to_destroy, changed_lines); // ersetzt alle Blöcke die in to_destroy erwähnt werden auf 255

	    absolutely_reset(&to_destroy); // nach Benutzung mit empty_blocks wieder resetten

	    struct DynArray column_first_touched = dyn_array_init(sizeof(struct Coordinate)); // beinhaltet die ersten Positionen an denen in einer Zeile ein Block entfernt wurde

	    struct DynArray* columns = game.columns.ptr;
	    for (int i = 0; i < game.columns.len; i++) {
		if (changed_lines[i]) {
		    struct DynArray* column = &columns[i];
		    cuts = mealloc(cuts, column->len * sizeof(_Bool));
		    memset(cuts, 0, column->len * sizeof(_Bool));
		    flatten(column, i, cuts, &column_first_touched); // vervollständigt den Lösch-Prozess, den empty_blocks angefangen hat
		    general_vertical(column, i, cuts, &to_destroy); // Prüfung auf potenzielle vertikale Löschvorgänge, füllen von to_destroy
		}
	    }
	    //draw_game(&game); //DEBUG
	    general_not_vertical(&game, &column_first_touched, &to_destroy); // Prüfung auf potenzielle horizontale und diagonale Löschvorgänge, füllen von to_destroy
	    absolutely_demolish(&column_first_touched); // free aufgrund vollständiger Nutzung
	}


	//draw_game(&game); //DEBUG

	int e = get_block(&new_block);
	if (e == EOF) { // signalisiert Ende des Datenstroms
	    output_game(&game); // ausgabe der existierenden Blöcke
	    free_all();
	    return 0;
	}
	if (e == -1) {
	    fail_exit();
	}
	//print_block(new_block, game.offset); //DEBUG
	if (resize_game(&game, new_block.x - game.offset) == -1) {
	    fail_exit();
	}
    }
} 
