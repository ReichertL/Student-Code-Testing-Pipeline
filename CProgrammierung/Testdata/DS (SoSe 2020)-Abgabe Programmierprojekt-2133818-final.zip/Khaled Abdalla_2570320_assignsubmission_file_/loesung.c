#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define XMax 1048576       //XMax =2²⁰
#define ArrayMax 100000000 //max hight of X

int XCurrent = 0, YCurrent = 0, XLimit = 1, Offset = 0, OldOffset = 0, BigestX = 0; // current x and y coordinate  delet Ylimit afterward NOTICE: XLimit = begest x + Offset
int DMax = 63;                                                                      // the biggest index for array of squers to delete
int d = 0;                                                                          // the current long for array of squers to delete

unsigned char ColorTmp = 0;
unsigned long LineFeed = 1;
long *TheYHight;

typedef struct square
{
  unsigned char color;
  int x;
  long y;

} square;
typedef struct Tmp
{
  unsigned char color;
  int x;

} Tmp;
square **DouSquarePointer;
square *Squarepointer;
/* move all th x pointers to x+Offset */
long *offset(long *HightArray)
{
  HightArray = realloc(HightArray, (XLimit + 1) * sizeof(long));
  if (!HightArray)
    exit(-1); // realloc fehler
  // the new elements = 0
  int help = Offset - OldOffset;
  for (int i = XLimit; i >= help; i--)
    HightArray[i] = HightArray[i - help]; // move all Elements
  help = Offset - OldOffset;

  for (int i = 0; i < help; i++)
    HightArray[i] = 0;

  return HightArray;
}

/* old array * 2 */
Tmp *douTmp(Tmp *dataInArray, int LineFeed)
{
  dataInArray = realloc(dataInArray, (LineFeed + 1) * sizeof(Tmp));
  if (!dataInArray)
    exit(-1); // realloc fehler
  return dataInArray;
}

square *longerSquare(square *x, int newHight)
{
  newHight += 1;
  x = realloc(x, newHight * sizeof(square));
  if (!x)
    exit(-1); // realloc fehler
  return x;
}
/* make the Array (2 * newlong) long 
 * 
 * */
long *biggerY(long *HightArray, int newLong)
{

  HightArray = realloc(HightArray, (newLong + 1) * sizeof(long)); // maybe cause a problem because of long != unsigned long
  if (!HightArray)
    exit(-1); // realloc fehler
  return HightArray;
}

square **deleteSquares(square **board, long *curX, square *delete, int d);

/*   read the Data    */
Tmp *read(Tmp *dataInArray, long *HightArray)
{
  char c;
  int i = 0, j = 0, l = 0, k = 0, count = 0; // help variables
  char cc[8];
  //errors
  // 1- 2 spaces after each other (implemented)
  // 2- "-" alone (implemented)
  // 3- unvalid color (implemented)
  // 4- just 2 numbers in a line TODO
  // 5- space then new line TODO
  //
  for (i = 0; i < 8; i++)
    cc[i] = 0; // all cc index are 0
  // if(c == NULL) exit(0);
  while ((c = getchar()) != EOF)
  { // maybe also && c != Null

    if (l == 1) //Errors
    {
      if (c == ' ')
        exit(-1); //2 spaces after each other or new line start wit a space or space after "-"
    }
    if ((c != ' ') && (c != '\n'))
    {
      cc[j] = c;
      l = 0;
      j++;
    }
    else
    {
      k = atoi(cc);
      if ((k + Offset) > XMax)
        exit(-1); // Error X is too big

      if (count % 2 == 0)
      { // fersst number is color
        if ((k < 0) && (k > 254))
          exit(-1); // Error color is not valid
        dataInArray[count / 2].color = k;
      }
      else
      { // the second number is the x cor.
        if ((count / 2) >= LineFeed)
        {
          LineFeed = 2 * LineFeed;
          dataInArray = douTmp(dataInArray, LineFeed); //bigger array  be sure it is correct
        }
        if (k < 0) // the x cor. is smaller than 0
        {
          if (Offset < abs(k))
          { // if
            Offset = abs(k);
            XLimit = (XLimit - OldOffset) + Offset;
            HightArray = offset(HightArray);
            OldOffset = Offset;
          }
          dataInArray[count / 2].x = k;
          ++HightArray[k + Offset];
        }
        else
        { // if X is a positive number

          if (k > (XLimit - Offset))
          {
            HightArray = biggerY(HightArray, k + Offset + 1); // HightArray is  bigger now :)
            XLimit = k + Offset;
          }
          dataInArray[count / 2].x = k;
          ++HightArray[k + Offset];
        }
      }
      l = 1;
      j = 0;
      for (i = 0; i < 8; i++)
        cc[i] = 0; // all cc index are 0
      count++;
    }

    if (c == '-') // maybe without if
      l = 1;      // as an error when - comes alone
    //putchar(c);
  }
  ////////////////////////////////////////////////////////////////////////////////
  // to read the last line feed

  k = atoi(cc);
  if ((k + Offset) > XMax)
    exit(-1); // Error X is too big

  if (count % 2 == 0)
  { // fersst number is color
    if ((k < 0) && (k > 254))
      exit(-1); // Error color is not valid
    dataInArray[count / 2].color = k;
  }
  else
  { // the second number is the x cor.
    if ((count / 2) >= LineFeed)
    {
      LineFeed = 2 * LineFeed;
      dataInArray = douTmp(dataInArray, LineFeed); //bigger array  be sure it is correct
    }
    if (k < 0) // the x cor. is smaller than 0
    {
      if (Offset < abs(k))
      { // if
        Offset = abs(k);
        XLimit = (XLimit - OldOffset) + Offset;
        HightArray = offset(HightArray);
        OldOffset = Offset;
      }
      dataInArray[count / 2].x = k;
      ++HightArray[k + Offset];
    }
    else
    { // if X is a positive number

      if (k >= (XLimit - Offset))
      {
        HightArray = biggerY(HightArray, k + Offset + 1); // HightArray is  bigger now :)
        XLimit = k + Offset;
      }
      dataInArray[count / 2].x = k;
      ++HightArray[k + Offset];
    }
  }
  l = 1;
  j = 0;
  for (i = 0; i < 8; i++)
    cc[i] = 0; // all cc index are 0
  count++;
  /////////////////////////////////////////////////////////////////////////////////
  ++XLimit;
  LineFeed = (count / 2);
  TheYHight = HightArray;
  return dataInArray;
}

/*

          fall 7 iii       i fall 1
                    \     /
         fall 6 ii-- Squer -- ii fall 2
                    /  |  \
            fall 5 i   |   iii fall 3
                    iv fall 4
*/
square *check(square **board, long *curX, square *delete, int x, long y)
{
  // int d = 0;
  int i = 1;
  int ii = 1;
  int iii = 1;
  int iv = 1;
  int notTwice = 0; //

  /*  fall 1 RIGHT+UP */

  for (int w = 1; w < 4; w++)
  {
    // printf("fall 1 color=%d x=%d y=%ld \n", board[x][y].color, (x + w) - Offset, (y + w));

    if ((x + w) < XLimit) // maybe <=
    {
      if ((y + w) < curX[x + w])
      {

        if (board[x][y].color == board[x + w][y + w].color)
        {
          i++;
          int q = 0;
          if (i == 4) // check
          {

            for (q = 0; q < 4; q++) // check q < 4
            {
              delete[d].x = (x + w) - q;
              delete[d].y = (y + w) - q;
              d++;
              if (d > DMax)
              {
                DMax *= 2;
                delete = longerSquare(delete, DMax);
              }

              // printf("mach color=%d x=%d y=%ld \n ", board[x][y].color, (x + w) - q, (y + w) - q);
            }
            if (notTwice == 0)
            {
              // printf(" X =%d w=%d q=3 y=%ld d=%d \n", x, w, y, d);
              delete[d].x = x;
              delete[d].y = y;
              d++;

              notTwice = 1;
            }
          }
          else if (i > 4)
          {
            delete[d].x = x + w; // maybe (x+w) -q;
            delete[d].y = y + w; // maybe (x+w) -q;
            d++;
            if (d > DMax)
            {
              DMax *= 2;
              delete = longerSquare(delete, DMax);
            }
          }
        }
        else
        {
          break;
        }
      }
      else
      {
        break;
      }
    }
    else
    {
      break;
    }
  }

  /*  fall 2 RIGHT */

  for (int w = 1; w < 4; w++)
  {
    // printf("fall 2 color=%d x=%d y=%ld \n", board[x][y].color, (x + w) - Offset, (y));

    if ((x + w) < XLimit)
    {
      if (y < curX[x + w])
      {
        if (board[x][y].color == board[x + w][y].color)
        {
          ii++;
          int q = 0;
          if (ii == 4)
          {

            for (q = 0; q < 4; q++)
            {
              delete[d].x = (x + w) - q;
              delete[d].y = y;
              d++;
              if (d > DMax)
              {
                DMax *= 2;
                delete = longerSquare(delete, DMax);
              }
              // printf("mach color=%d x=%d y=%ld \n", board[x][y].color, x + w - q, y);
            }
            if (notTwice == 0)
            {
              delete[d].x = x;
              delete[d].y = y;
              notTwice = 1;
            }
          }
          else if (ii > 4)
          {
            delete[d].x = x + w;
            delete[d].y = y;
            d++;
            if (d > DMax)
            {
              DMax *= 2;
              delete = longerSquare(delete, DMax);
            }
          }
        }
        else
        {
          break;
        }
      }
      else
      {
        break;
      }
    }
    else
    {
      break;
    }
  }

  /*  fall 3 RIGHT+down */

  for (int w = 1; w < 4; w++)
  {
    // printf("fall 3 color=%d x=%d y=%ld \n", board[x][y].color, (x + w), (y - w));

    if ((y - w) < 0)
    {
      // printf("%s \n", "break");
      break;
      // printf("%s \n", "break");
    }

    if ((x + w) < XLimit)
    {
      if ((y - w) < curX[x + w])
      {
        // printf("fall 3 after break color=%d x=%d y=%ld \n", board[x][y].color, (x + w), (y - w));
        if (board[x][y].color == board[x + w][y - w].color)
        {
          iii++;
          int q = 0;
          if (iii == 4)
          {

            for (q = 0; q < 4; q++)
            {
              delete[d].x = (x + w) - q;
              delete[d].y = (y - w) + q;
              d++;
              if (d > DMax)
              {
                DMax *= 2;
                delete = longerSquare(delete, DMax);
              }
              // printf("mach color=%d x=%d y=%ld \n", board[x][y].color, (x + w) - q, (y - w) + q);
            }
            if (notTwice == 0)
            {
              delete[d].x = x;
              delete[d].y = y;
              notTwice = 1;
            }
          }
          else if (iii > 4)
          {
            delete[d].x = x + w;
            delete[d].y = y - w;
            d++;
            if (d > DMax)
            {
              DMax *= 2;
              delete = longerSquare(delete, DMax);
            }
          }
        }
        else
        {
          break;
        }
      }
      else
      {
        break;
      }
    }
    else
    {
      break;
    }
  }

  /*  fall 4 Down */

  for (int w = 1; w < 4; w++)
  {
    // printf("fall 4 color=%d x=%d y=%ld \n", board[x][y].color, x, (y - w));

    if ((y - w) < 0)
    {
      // printf("%s \n", "break");
      break;
      // printf("%s \n", "break");
    }

    if ((y - w) < curX[x])
    {
      if (board[x][y].color == board[x][y - w].color)
      {
        iv++;
        int q = 0;
        if (iv == 4)
        {

          for (q = 0; q < 4; q++)
          {
            delete[d].x = (x);
            delete[d].y = (y - w) + q;
            d++;
            if (d > DMax)
            {
              DMax *= 2;
              delete = longerSquare(delete, DMax);
            }
            // printf("mach color=%d x=%d y=%ld \n", board[x][y].color, x, (y - w) + q);
          }
          if (notTwice == 0)
          {
            delete[d].x = x;
            delete[d].y = y;
            notTwice = 1;
          }
        }
        else if (iv > 4)
        {
          delete[d].x = x;
          delete[d].y = y + w;
          d++;
          if (d > DMax)
          {
            DMax *= 2;
            delete = longerSquare(delete, DMax);
          }
        }
      }
      else
      {
        break;
      }
    }
    else
    {
      break;
    }
  }
  /*  fall 5 Lift+down */

  for (int w = 1; w < 4; w++)
  {
    // printf("fall 5 color=%d x=%d y=%ld \n", board[x][y].color, (x - w), (y - w));

    if (((x - w) < 0) || ((y - w) < 0))
    {
      // printf("%s \n", "break");
      break;
      // printf("%s \n", "break");
    }
    if ((y - w) < curX[x - w])
    {
      if (board[x][y].color == board[x - w][y - w].color)
      {
        i++;
        int q = 0;
        if (i == 4)
        {

          for (q = 0; q < 4; q++)
          {
            delete[d].x = (x - w) + q;
            delete[d].y = (y - w) + q;
            d++;
            if (d > DMax)
            {
              DMax *= 2;
              delete = longerSquare(delete, DMax);
            }
            // printf("mach color=%d x=%d y=%ld \n", board[x][y].color, (x - w) + q, (y - w) + q);
          }
          if (notTwice == 0)
          {
            delete[d].x = x;
            delete[d].y = y;
            notTwice = 1;
          }
        }
        else if (i > 4)
        {
          delete[d].x = x - w;
          delete[d].y = y - w;
          d++;
          if (d > DMax)
          {
            DMax *= 2;
            delete = longerSquare(delete, DMax);
          }
        }
      }
      else
      {
        break;
      }
    }
    else
    {
      break;
    }
  }

  /*  fall 6 Lift */

  for (int w = 1; w < 4; w++)
  {
    // printf("fall 6 color=%d x=%d y=%ld  II=%d \n", board[x][y].color, (x - w), y, ii);
    if ((x - w) < 0)
    {
      // printf("%s \n", "break");
      break;
      // printf("%s \n", "break");
    }
        // printf("fall 6 zeil 580 color=%d x=%d y=%ld Yhight= %ld  II=%d \n", board[x][y].color, (x - w), y , curX[x-w], ii);

    if (y < curX[x - w])
    {
          // printf("fall 6 zeil 584 color=%d colorCorrint=%d x=%d y=%ld  II=%d \n", board[x][y].color,board[x-w][y].color, (x - w), y , ii);

      if (board[x][y].color == board[x-w][y].color)
      {
        ii++;
        // printf("fall 6 color=%d x=%d y=%ld  II=%d \n", board[x][y].color, (x - w), y, ii);

        int q = 0;
        if (ii == 4)
        {

          for (q = 0; q < 4; q++)
          {
            delete[d].x = (x - w) + q;
            delete[d].y = y;
            d++;
            if (d > DMax)
            {
              DMax *= 2;
              delete = longerSquare(delete, DMax);
            }
            // printf("mach color=%d x=%d y=%ld \n", board[x][y].color, (x - w) + q, y);
          }
          // if (notTwice == 0)
          // {
          //   delete[d].x = x;
          //   delete[d].y = y;
          //   notTwice = 1;
          // }
        }
        else if (ii > 4)
        {
          delete[d].x = x - w;
          delete[d].y = y;
          // printf("mach  x=%d y=%ld \n", x - w, y);
          d++;
          if (d > DMax)
          {
            DMax *= 2;
            delete = longerSquare(delete, DMax);
          }
        }
      }
      else
      {
        break;
      }
    }
    else
    {
      break;
    }
  }

  /*  fall 7 lift+up */

  for (int w = 1; w < 4; w++)
  {
    // printf("fall 7 color=%d x=%d y=%ld \n", board[x][y].color, (x - w), y + w);
    if ((x - w) < 0)
    {
      // printf("%s \n", "break");
      break;
      // printf("%s \n", "break");
    }

    if ((y + w) < curX[x - w])
    {
      if (board[x][y].color == board[x - w][y + w].color)
      {
        iii++;
        int q = 0;
        if (iii == 4)
        {

          for (q = 0; q < 4; q++)
          {
            delete[d].x = (x - w) + q;
            delete[d].y = (y + w) - q;
            d++;
            if (d > DMax)
            {
              DMax *= 2;
              delete = longerSquare(delete, DMax);
            }
            // printf("mach color=%d x=%d y=%ld", board[x][y].color, (x - w) + q, (y + w) - q);
          }
          if (notTwice == 0)
          {
            delete[d].x = x;
            delete[d].y = y;
            notTwice = 1;
          }
        }
        else if (i > 4)
        {
          delete[d].x = x - w;
          delete[d].y = y + w;
          d++;
          if (d > DMax)
          {
            DMax *= 2;
            delete = longerSquare(delete, DMax);
          }
        }
      }
      else
      {
        break;
      }
    }
    else
    {
      break;
    }
  }
  // if (d > 3)
  // {
  //   for (int m = 0; m < d; m++)
  //     // printf(" delete x=%d y=%ld ", delete[m].x, delete[m].y);

  //   // board = deleteSquares(board, curX, delete, d + 1);
  // }
  /* reset the numbers that we didnt get rong maches */
  i = 1;
  ii = 1;
  iii = 1;
  iv = 1;

  return delete;
}
/*
Delete all matches
*/
square **deleteSquares(square **board, long *curX, square *delete, int d)
{
  long y;
  int x;

  for (int i = 0; i < d - 1; i++)
  {
    for (int j = i + 1; j < d; j++)
    {
      if ((delete[i].x == delete[j].x) && (delete[i].y == delete[j].y))
        delete[j].color = 30; // because the stone is duplicated
    }
  }
  for (int i = 0; i < d; i++)
  {
    x = delete[i].x;
    y = delete[i].y;

    if (delete[i].color == 30)
    {
      // continue; // this square is already deleted
    }
    else if (y < curX[x]) // TODO maybe wrong ?
    {
      for (long n = y; n <= curX[x]; ++n)
      {
        board[x][n].color = board[x][n + 1].color;
        // board[x][n].x = board[x][n + 1].x;
        // board[x][n].y = board[x][n + 1].y;
        //
      }
      --curX[x];
    }
    else
    {
      --curX[x];
    }

    // for (int i = 0; i < d; i++)
    // {
    //   board = check(board, curX, delete[i].x, delete[i].y); // TODO  important to check all the new stones
    // }
  }
  return board;
}
//###############   MAIN   ###########################
int main()
{

  // Tmp file to save the colors and the X coordinate
  Tmp *dataIn = calloc(LineFeed, sizeof(Tmp)); // numbers und and color
  if (!dataIn)
    exit(-1);                                  // calloc fehler
  long *yHight = calloc(XLimit, sizeof(long)); // save the hight y for x for exampel yHight[x + Offset]
  if (!yHight)
    exit(-1); // calloc fehler

  //   read the data
  dataIn = read(dataIn, yHight);
  yHight = TheYHight;

  long *curX = calloc(XLimit, sizeof(long)); // save the current hight of X , written hier that XLimit is up to date
  if (!curX)
    exit(-1); // calloc fehler

  // The game field
  square **board = (square **)calloc(XLimit, sizeof(square *)); //2d array of squares    if calloc make a Problem use malloc
  if (!board)
  {
    exit(-1); // calloc fehler
  }

  for (int i = 0; i < XLimit; i++)
  {
    // if (yHight[i] > ArrayMax)
    //   yHight[i] = ArrayMax;                           // cange after the implemintation of the algo. TODO
    board[i] = (square *)calloc(128, sizeof(square)); // change here YLimit to be YLimit[x]
    if (!board[i])
    {
      // printf("%s board[%d] = %ld \n", " cannot make an array", i, yHight[i]);
      exit(-1); // calloc fehler#
    }
  }
  // printf("%s \n", " line 657");

  /*  wright the data in the board  */
  int help;
  square *delete = calloc(64, sizeof(square)); // save the stons to delete them afterwords
  square *delete1 = calloc(64, sizeof(square));
  for (int i = 0; i < LineFeed; i++)
  {
    /* save the line feed in the right squer*/
    help = dataIn[i].x + Offset;
    // printf(" Help = %d \n", dataIn[i].x + Offset);

    board[help][curX[help]].color = dataIn[i].color;
    board[help][curX[help]].x = dataIn[i].x;
    board[help][curX[help]].y = curX[help];
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // printf("add to the board color = %d X = %d help = %d  Y = %ld \n", dataIn[i].color, dataIn[i].x, help, curX[help]);

    /* check if there is a 4 stone line*/

    delete = check(board, curX, delete, help, curX[help]);
    // TheYHight=delete;
    while (d > 3)
    {
      int dd = d;
      board = deleteSquares(board, curX, delete, d); // delete the stons
      // printf("%s \n", " line 816");
      d = 0; // maybe a problem hier

      for (int i = 0; i < dd; ++i)
      {
        // printf("CHECK THE NEW STONES x=%d y=%ld and current x hight=%ld \n", delete[i].x, delete[i].y, curX[delete[i].x]);

        if (delete[i].y > curX[delete[i].x])
        {
          // printf(" geht leider weil y=%ld und Yhight=%ld und I=%d und DD=%d \n", delete[i].y, curX[delete[i].x], i, dd);
        }
        else
        {
          delete1 = check(board, curX, delete1, delete[i].x, delete[i].y);
        }
      }
      // printf("Out of the for loop d=%d \n", d);

      Squarepointer = delete;
      delete = delete1;
      delete1 = Squarepointer;
      // printf("..................................AFTER Out of the for loop d=%d \n", d);
    }
    // printf("AFTER AFTER Out of the for loop d=%d \n", d);

    ++curX[help]; // the hight of index help +1
  }
  //free(delete); // TODO hier are the whole Problems
  //free(delete1);
  // printf("%s \n", " line 263");
  // unsigned long b = 1;

  for (int i = 0; i < XLimit; i++)
  {
    long q = curX[i];
    for (long w = 0; w < q; w++)
    {
      // printf("%ld- ", b++);
      printf("%d   %d   %ld \n", board[i][w].color, board[i][w].x, board[i][w].y);
    }
  }
  // printf("%s \n", " line 286");
  /*  free the alloc memory   */
  for (int i = 0; i < XLimit; i++)
    free(board[i]); // OR *(*(arr+i)+j) = ++count
  free(curX);
  free(yHight);
  free(delete); // TODO hier are the whole Problems
  free(delete1);
  free(board);
  free(dataIn);
  return 0;
}
