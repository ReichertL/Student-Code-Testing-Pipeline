#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

/* laufzeit fixen

    remove_block() benötigt zuviel zeit
        ansatz:
            alle blöcke welche entfernt werden sollen als array an func übergeben
            -> keine for loop über den gesammten feld
            
*/

typedef struct
{
    int color;
    int x;
} field;

typedef struct
{
    field *ptr;
    int rm;
} game_field;

typedef struct
{
    int x;
    int y;
} rem;

int number_of_blocks = 0;

int32_t smallest_x = INT32_MAX;
int32_t biggest_x = INT32_MIN;

int difference;
int offset;

field *block = NULL;
game_field **a = NULL;
int *stack = NULL;

rem *check_list = NULL;

int rm_cnt = 0;
int ran = 0;
long cy, cx, cd;
int xx, yy;

bool only_y = false;

void read_stdin(void);
void add_blocks(void);

long test_x(int x, int y);
long test_y(int x, int y);
long test_d(int x, int y);

void test_lines(int x, int y);

void remove_blocks(void);

void debug_info(void);
void print_blocks(void);
void print_game_field(void);
void print_rm_game_field(void);
void print_mod_game_field(void);

int main()
{

    // reads the blocks from stdin
    read_stdin();

    if (!number_of_blocks)
    {
        free(block);
        exit(EXIT_SUCCESS);
    }

    difference = (biggest_x - smallest_x) + 1;
    offset = -smallest_x;

    //debug_info();

    //print_blocks();

    // add blocks to a gamefield
    add_blocks();

    //da y nachbarn oft geskippt werden
    remove_blocks();
    //print_mod_game_field();
    //int aa = 0;
    //ausgabe
    for (int i = 0; i < difference; i++)
    {
        for (int j = 0; j < stack[i]; j++)
        {
            printf("%d %d %d\n", a[i][j].ptr->color, i - offset, j);
            //aa++;
        }
    }
    //printf("%d\n", aa);

    //print_mod_game_field();
    free(block);
    for (int i = 0; i < difference; i++)
    {
        free(a[i]);
    }
    free(a);
    free(stack);
    free(check_list);

    return 0;
}

void read_stdin()
{
    int pos = 0;
    char input_ptr, buffer[64];
    bool block_color = true, block_x = false, start = true, negative_number = false;

    if (!(block = calloc(1, sizeof(field))))
    {
        fprintf(stderr, "alloc fail on line: %d\n", __LINE__);
        exit(EXIT_FAILURE);
    }

    while (1)
    {
        input_ptr = getchar();
        //damit letzter char auch gelesen wird
        if (input_ptr == EOF)
        {
            if (!start)
            {
                if (negative_number)
                {
                    long temp = atol(buffer);
                    if (temp > 1048576)
                    {
                        fprintf(stderr, "x too big!\n");
                        free(block);
                        exit(EXIT_FAILURE);
                    }

                    temp *= -1;
                    if (temp < smallest_x)
                    {
                        smallest_x = temp;
                    }
                    if (temp > biggest_x)
                    {
                        biggest_x = temp;
                    }

                    block[number_of_blocks - 1].x = temp;
                    // printf("set block[%d].x with %d\n", number_of_blocks - 1, block[number_of_blocks - 1].x);
                    // printf("%d\n", temp);
                }
                else
                {
                    long temp = atol(buffer);
                    if (temp > 1048576)
                    {
                        fprintf(stderr, "x too big!\n");
                        free(block);
                        exit(EXIT_FAILURE);
                    }
                    if (temp < smallest_x)
                    {
                        smallest_x = temp;
                    }
                    if (temp > biggest_x)
                    {
                        biggest_x = temp;
                    }

                    block[number_of_blocks - 1].x = temp;
                    // printf("set block[%d].x with %d\n", number_of_blocks - 1, block[number_of_blocks - 1].x);
                    // printf("%2d\n", temp);
                }
            }
            break;
        }
        if (block_color && input_ptr >= 0x30 && input_ptr <= 0x39)
        // wenn es die farbe ist und die einzelnen chars 0 bis 9 sind
        {
            if (start)
            {
                number_of_blocks++;

                if (!(block = realloc(block, number_of_blocks * sizeof(field))))
                {
                    fprintf(stderr, "realloc fail on line: %d\n", __LINE__);
                    free(block);
                    exit(EXIT_FAILURE);
                }
                /*else
                {
                    printf("----------\nrealloc with %d * %lu = %lu bytes\n", number_of_blocks, sizeof(field), number_of_blocks * sizeof(field));
                }*/
            }
            start = false;

            buffer[pos] = input_ptr;
            pos++;
        }
        else
        {
            if (block_color && input_ptr == 0x20)
            // wenn es ein leerzeichen ist
            {
                block_color = false;
                block_x = true;

                buffer[pos] = '\0';
                long temp = atol(buffer);
                if (temp > 254 || temp < 0)
                {
                    fprintf(stderr, "invalid color!\n");
                    free(block);
                    exit(EXIT_FAILURE);
                }

                block[number_of_blocks - 1].color = temp;

                // printf("%2d: %d ", number_of_blocks, temp);

                //clear buffer
                pos = 0;
                buffer[pos] = '\0';
            }
            else
            {
                if (block_x && input_ptr == 0x2d)
                // wenn die x negativ ist
                {
                    negative_number = true;
                }
                else
                {
                    if (block_x && input_ptr >= 0x30 && input_ptr <= 0x39)
                    // wenn es die x koordinate ist und die einzelnen chars 0 bis 9 sind
                    {
                        buffer[pos] = input_ptr;
                        pos++;
                    }
                    else
                    {

                        if (block_x && input_ptr == 0x0a)
                        {
                            block_color = true;
                            block_x = false;

                            buffer[pos] = '\0';
                            //                             printf("%s\n",buffer);
                            if (negative_number)
                            {
                                long temp = atol(buffer);
                                if (temp > 1048576)
                                {
                                    fprintf(stderr, "x too big!\n");
                                    free(block);
                                    exit(EXIT_FAILURE);
                                }
                                temp *= -1;
                                if (temp < smallest_x)
                                {
                                    smallest_x = temp;
                                }
                                if (temp > biggest_x)
                                {
                                    biggest_x = temp;
                                }

                                block[number_of_blocks - 1].x = temp;
                                // printf("set block[%d].x with %d\n", number_of_blocks - 1, block[number_of_blocks - 1].x);
                                // printf("%d\n", temp);
                            }
                            else
                            {
                                long temp = atol(buffer);
                                if (temp > 1048576)
                                {
                                    fprintf(stderr, "x too big!\n");
                                    free(block);
                                    exit(EXIT_FAILURE);
                                }
                                if (temp < smallest_x)
                                {
                                    smallest_x = temp;
                                }
                                if (temp > biggest_x)
                                {
                                    biggest_x = temp;
                                }

                                block[number_of_blocks - 1].x = temp;
                                //                                 printf("set block[%d].x with %d\n", number_of_blocks - 1, block[number_of_blocks - 1].x);
                                // printf("%2d\n", temp);
                            }

                            //clear buffer
                            pos = 0;
                            buffer[pos] = '\0';
                            negative_number = false;
                            start = true;
                        }
                        else
                        {
                            fprintf(stderr, "invalid format!\n");
                            free(block);
                            exit(EXIT_FAILURE);
                        }
                    }
                }
            }
        }
    }
}

void add_blocks()
{

    if (!(check_list = malloc(sizeof(rem))))
    {
        fprintf(stderr, "alloc fail on line: %d\n", __LINE__);
        free(block);
        exit(EXIT_FAILURE);
    }
    if (!(a = calloc(difference, sizeof(game_field))))
    {
        free(block);
        free(check_list);
        fprintf(stderr, "alloc fail on line: %d\n", __LINE__);
        exit(EXIT_FAILURE);
    }
    else
    {
        for (size_t i = 0; i < difference; i++)
        {
            if (!(a[i] = calloc(1, sizeof(game_field))))
            {
                free(block);
                free(check_list);
                free(a);
                fprintf(stderr, "alloc fail on line: %d\n", __LINE__);
                exit(EXIT_FAILURE);
            }
        }
    }
    if (!(stack = calloc(difference, sizeof(int))))
    {
        free(block);
        free(check_list);
        for (int i = 0; i < difference; i++)
        {
            free(a[i]);
        }
        free(a);
        fprintf(stderr, "alloc fail on line: %d\n", __LINE__);
        exit(EXIT_FAILURE);
    }

    //blöcke werden in das spielfeld gesetzt
    for (size_t i = 0; i < number_of_blocks; i++)
    {
        game_field *tmp_pnt = NULL;
        //printf("i:%zu\n",i);
        int temp = (block[i].x) + offset;
        while (1)
        {
            //printf("iteration: %ld\ta[%d][%d]\n", i, temp, stack[temp]);

            if (a[temp][stack[temp]].ptr == NULL)
            {
                //printf("\ta[%d][%d] is NULL\n", temp, stack[temp]);
                if (stack[temp] > 0 && a[temp][stack[temp] - 1].rm == 1)
                {
                    //printf("wildcard ");
                    remove_blocks();
                }
                a[temp][stack[temp]].ptr = &block[i];
                a[temp][stack[temp]].rm = 0;
            }
            else
            {
                //printf("\ta[%d][%d] is not NULL\n", temp, stack[temp]);
                stack[temp] += 1;
                if (!(tmp_pnt = realloc(a[temp], sizeof(game_field) * stack[temp] * sizeof(field))))
                {
                    free(block);
                    free(check_list);
                    free(stack);
                    for (int i = 0; i < difference; i++)
                    {
                        free(a[i]);
                    }
                    free(a);
                    fprintf(stderr, "realloc fail on line: %d\n", __LINE__);
                    exit(EXIT_FAILURE);
                }
                else
                {
                    a[temp] = tmp_pnt;
                    tmp_pnt = NULL;
                    free(tmp_pnt);
                }

                a[temp][stack[temp]].ptr = NULL;
                //printf("+stack[%d] = %d\n",temp,stack[temp]);
                //printf("round %zu\n",i);
                //print_mod_game_field();
                if (i >= 3)
                {
                    //print_mod_game_field();
                    //printf("test with %d %d\t", temp, stack[temp] - 1);
                    //teste für nachbarn
                    test_lines(temp, stack[temp] - 1);
                    //print_mod_game_field();
                }
                if (rm_cnt > 0 && !only_y)
                {
                    //entferne nachbarn
                    remove_blocks();
                }
                break;
            }
        }
    }
}

long test_y(int x, int y)
{
    int i = y;
    for (; y > 0 && (a[x][y].ptr->color == a[x][y - 1].ptr->color); y--)
    {
        //printf("%d->%d, ",y,y-1);
    }
    //printf("diff: %d\n",i+1-y);
    int result = 0;
    if (i + 1 - y > 3)
    {
        //printf("rm_cnt: %d\ni+1-y: %d\n%ld\n",i+1-y,rm_cnt,sizeof(rem)*((i+1-y)+rm_cnt));
        for (; y <= i; y++)
        {
            //printf("%d\n",y);
            a[x][y].rm = 1;
            // printf("%d->", y);
            result++;
            rm_cnt++;
        }
        //printf("rm_y set\n");
        //printf("rm_cnt :%d\n",rm_cnt);
    }
    return result;
}

long test_x(int x, int y)
{
    int i = x;

    for (; i > 0 && stack[i - 1] != 0 && y <= stack[i - 1] - 1 && (a[i][y].ptr->color == a[i - 1][y].ptr->color); i--)
    {
        // printf("%d->%d, ", i, i - 1);
    }

    // printf("test_2: i:%d, i+1: %d\nstack[i+1] = %d\ny:%d <= stack[i+1]:%d\n", i,i+1, stack[i + 1],y,stack[i+1]);

    int pre_i = i;
    for (; i < difference - 1 && (stack[i + 1] != 0 && y <= stack[i + 1] - 1) && a[i][y].ptr->color == a[i + 1][y].ptr->color; i++)
    {
        //printf("%d->%d, ", i, i + 1);
    }
    int result = 0;
    // printf("\npre_i:%d, i:%d\ndiff = %d\n", pre_i, i, i + 1 - pre_i);
    if (i + 1 - pre_i > 3)
    {

        for (; pre_i <= i; pre_i++)
        {
            // printf("%d\n",pre_i);
            a[pre_i][y].rm = 1;
            result++;
            rm_cnt++;
            //printf("%d->", pre_i);
        }
        //printf("rm_x set\n");
    }
    return result;
}

long test_d(int x, int y)
{
    int i = x, j = y;

    // down left
    for (; i > 0 && j > 0 && stack[i - 1] != 0 && (j - stack[i - 1]) < 1 && a[i][j].ptr->color == a[i - 1][j - 1].ptr->color; i--, j--)
    {
        //printf("a[%d][%d]->a[%d][%d]", i, j, i - 1, j - 1);
    }
    int m_d_i = i, m_d_j = j;
    // up right
    for (; i < difference - 1 && j < stack[i + 1] - 1 && stack[i + 1] != 0 && (j - stack[i + 1]) < 0 && a[i][j].ptr->color == a[i + 1][j + 1].ptr->color; i++, j++)
    {
        // printf("a[%d][%d]->a[%d][%d] ", i, j, i + 1, j + 1);
    }
    //printf("\n");
    long result = 0;
    //printf("m_i:%d ,m_j:%d\ni:%d ,j:%d\n",m_d_i,m_d_j,i,j);
    if (i + 1 - m_d_i > 3)
    {

        for (; m_d_i <= i; m_d_i++, m_d_j++)
        {
            a[m_d_i][m_d_j].rm = 1;
            result++;
            rm_cnt++;
        }
    }

    i = x, j = y;

    // down right

    for (; i < difference - 1 && j > 0 && stack[i + 1] != 0 && (j - stack[i + 1]) < 1 && a[i][j].ptr->color == a[i + 1][j - 1].ptr->color; i++, j--)
    {
        //printf("a[%d][%d]->a[%d][%d]", i, j, i + 1, j - 1);
    }
    m_d_i = i, m_d_j = j;

    // up left

    for (; i > 0 && j < stack[i - 1] - 1 && stack[i - 1] != 0 && (j - stack[i - 1]) < 0 && a[i][j].ptr->color == a[i - 1][j + 1].ptr->color; i--, j++)
    {
        //printf("a[%d][%d]->a[%d][%d] ", i, j, i - 1, j + 1);
    }

    //printf("\nm_i:%d ,m_j:%d\ni:%d ,j:%d\nmdi-i : %d\n",m_d_i,m_d_j,i,j,m_d_i - i);
    if (m_d_i - i + 1 > 3)
    {

        for (; i <= m_d_i; m_d_i--, m_d_j++)
        {
            a[m_d_i][m_d_j].rm = 1;
            result++;
            rm_cnt++;
        }
    }
    return result;
}

void test_lines(int x, int y)
{
    cy = 0, cx = 0, cd = 0;
    xx = x, yy = y;
    //print_mod_game_field();
    //print_game_field();
    if (y >= 3 && (a[x][y].ptr->color == a[x][y - 3].ptr->color))
    {
        //print_game_field();
        //printf("test_y: %d,%d\n", x, y);
        cy = test_y(x, y);
    }

    if (difference >= 3)
    {

        if ((x - 1 > 0 && a[x - 1][y].ptr != NULL && stack[x - 1] != 0 && y <= stack[x - 1] - 1 && a[x][y].ptr->color == a[x - 1][y].ptr->color) || (x + 1 < difference && (stack[x + 1] != 0 && y <= stack[x + 1] - 1) && a[x + 1][y].ptr != NULL && a[x][y].ptr->color == a[x + 1][y].ptr->color))
        {

            //printf("test_x: %d,%d\n", x, y);
            cx = test_x(x, y);
        }

        //print_mod_game_field();
        //printf("test_d: %d,%d\n\n", x, y);
        cd = test_d(x, y);
    }
    //printf("cy: %ld, cx: %ld, cd: %ld\n", cy, cx, cd);
    if (cy >= 0 && cx == 0 && cd == 0)
    {
        only_y = true;
        //printf("fast\t cy:%ld\tcx:%ld\tcd:%ld\n", cy, cx, cd);
    }
    else
    {
        only_y = false;
        //printf("slow\t cy:%ld\tcx:%ld\tcd:%ld\n", cy, cx, cd);
    }

    //print_mod_game_field();
}

void remove_blocks()
{
    // set every block with (.rm = 1) NULL
    //print_mod_game_field();
    //printf("rm()\n");
    // GEFUNDENe nachbarn NULL setzten
    for (size_t i = 0; i < difference; i++)
    {
        for (int j = 0; j < stack[i]; j++)
        {
            if (a[i][j].rm == 1)
            {
                a[i][j].ptr = NULL;
                a[i][j].rm = 0;
            }
        }
    }

    //print_mod_game_field();

    // nachrücken
    rm_cnt = 0;
    // alle reihen durchgehen
    for (size_t i = 0; i < difference; i++)
    {
        int red_stack = 0;

        // alle elemente einer reihe durchgehen
        for (int j = 0; j < stack[i]; j++)
        {
            bool first = true;

            // nur moven wenn der block NULL ist
            if (a[i][j].ptr == NULL)
            {
                //printf("a[%zu][%d] == NULL\n", i, j);

                // ab diesen block alle anderen nachrücken
                for (int k = j; k < stack[i]; k++)
                {
                    //printf("\ta[%zu][%d] = a[%zu][%d]\n", i, k, i, k + 1);

                    // wenn != NULL kommt
                    if (a[i][k].ptr != NULL)
                    {
                        if (first)
                        {
                            red_stack--;
                            first = false;
                        }
                    }

                    // reihe um eins nach unten rücken
                    a[i][k] = a[i][k + 1];
                    if (k + 1 == stack[i])
                    {
                        red_stack++;
                    }
                    if (a[i][k].ptr != NULL)
                    {
                        ran++;
                        if (!(check_list = realloc(check_list, sizeof(rem) * ran)))
                        {
                            free(block);
                            free(check_list);
                            for (int i = 0; i < difference; i++)
                            {
                                free(a[i]);
                            }
                            free(a);
                            free(stack);
                            fprintf(stderr, "realloc fail on line: %d\n", __LINE__);
                            exit(EXIT_FAILURE);
                        }
                        check_list[ran - 1].x = i;
                        check_list[ran - 1].y = k;
                    }
                }
                //print_mod_game_field();
                continue;
            }
        }

        //printf("s[%zu]: %d\n", i, stack[i]);
        //printf("reduce stack value:%d\n", red_stack);
        stack[i] -= red_stack;
        //printf("after_stack[%zu] = %d(%d elemente)\n", i, stack[i], stack[i] + 1);
    }

    //printf("\n\nafter\n\n");
    // print_mod_game_field();

    // wenn ein NULL block zwichendurch drinne bleibt
    for (int i = 0; i < difference; i++)
    {
        for (int j = 0; j < stack[i]; j++)
        {
            if (j != stack[i] - 1 && a[i][j].ptr == NULL)
            {
                //printf("---------------------------\n");
                remove_blocks();
            }
        }
    }

    //nachrücker testen
    if (ran > 0)
    {
        //print_mod_game_field();
        for (int i = 0; i < ran; i++)
        {
            if (!i)
            {
                //printf("ran > 0\n");
            }
            // printf("stack[%d] = %d\n", check_list[i].x, stack[check_list[i].x]);
            //printf("test %d, %d\n", check_list[i].x, check_list[i].y);
            //print_mod_game_field();
            if (check_list[i].y < stack[check_list[i].x])
            {
                //print_mod_game_field();
                test_lines(check_list[i].x, check_list[i].y);
            }
        }
        ran = 0;
        if (!only_y)
        {
            //printf("\tnachrücken");
            remove_blocks();
        }
    }
}


//prints zum debuggen
void debug_info()
{
    printf("\nnumber of blocks: %d\n", number_of_blocks);
    printf("smallest_x = %d\nbiggest_x = %d\n", smallest_x, biggest_x);
    printf("difference = %d\n", difference);
    printf("offset = %d\n\n", offset);
}

void print_blocks()
{
    for (int i = 0; i < number_of_blocks; i++)
    {
        printf("block[%2d]: block.color = %2d,block.x = %3d\n", i, block[i].color, block[i].x);
    }
}

void print_game_field()
{
    int test_C = 0;
    for (int i = 0; i < difference; i++)
    {
        if (a[i][0].ptr != NULL)
        {

            printf("\n(%2d) %2d : ", i, i - offset);
        }
        else
        {
            //printf("\nNULL");
        }

        for (size_t j = 0; j <= stack[i]; j++)
        {
            if (a[i][j].ptr != NULL)
            {
                test_C++;
                printf("%d ", a[i][j].ptr->color);
                if (a[i][j + 1].ptr == NULL)
                {
                    //printf("NULL");
                }
            }
        }
    }
    printf("\n\n%d\n\n", test_C);
}

void print_rm_game_field()
{
    printf("rm every 1\n");
    for (int i = 0; i < difference; i++)
    {
        if (a[i][0].ptr != NULL)
        {

            printf("\n(%2d) %2d : ", i, i - offset);
        }
        else
        {
            printf("\nNULL");
        }

        for (size_t j = 0; j <= stack[i]; j++)
        {
            if (a[i][j].ptr != NULL)
            {
                printf("%d ", a[i][j].rm);
            }
        }
    }
    printf("\n--------------\n");
}

void print_mod_game_field()
{
    printf("\nmod\n");
    for (int i = 0; i < difference; i++)
    {

        printf("\n(%2d) %2d : ", i, i - offset);

        for (size_t j = 0; j <= stack[i]; j++)
        {
            if (a[i][j].ptr != NULL)
            {
                if (a[i][j].rm)
                {
                    printf("%s%.3d ", "\x1B[31m", a[i][j].ptr->color);
                }
                else
                {
                    printf("%s%.3d ", "\x1B[0m", a[i][j].ptr->color);
                }
            }
            else
            {
                printf("%sNULL ", "\x1B[0m");
            }
        }
    }
    printf("\n----------\n");
}
