#include <stdio.h>
#include <stdlib.h>
#include <regex.h>
#include <string.h>
#define SIZE 10
#define BUFFSIZE 256
#define NOCOLOR 255

struct stone
{
    unsigned char color;
    unsigned char flag;
};

void freeMemory(struct stone ** pField, unsigned int row);
struct stone ** getMemory(unsigned int sizeX, unsigned int sizeY);
void initializeField(struct stone ** pField, unsigned int sizeX, unsigned int sizeY);
void removeMarkedStone(struct stone ** pField, unsigned int sizeX, unsigned int sizeY);
struct stone ** rearrangeField(struct stone ** pField,
        unsigned int offsetFlag, unsigned int sizeX,
        unsigned int sizeY, unsigned int newSizeX,
        unsigned int newSizeY);
int markSequences(struct stone ** pField, unsigned int sizeX, unsigned int sizeY);
void slideDown(struct stone ** pField, unsigned int sizeX, unsigned int sizeY);

int main()
{
    regex_t regex;
    int notValid;
    char msgbuf[BUFFSIZE];

    notValid = regcomp(&regex, "^[0-9]+ +-?[0-9]+$", REG_EXTENDED);
    if (notValid) {
        fprintf(stderr, "Could not compile regex\n");
        exit(1);
    }

    int sizeX, maxX, minX, sizeY, offset;
    sizeX = SIZE;
    maxX = sizeY = SIZE - 1;
    minX = offset = 0;

    // pField - pointer on Game Field array
    struct stone ** pField = getMemory(SIZE, SIZE);
    initializeField(pField, SIZE, SIZE);

    int color, column;
    int stopSym = 0;
    while (fgets (msgbuf, BUFFSIZE, stdin) != NULL)
    {
        for (int i = 0; i < BUFFSIZE; i++)
            if (msgbuf[i] == '\n' || msgbuf[i] == '\r')
            {
                stopSym = i;
                msgbuf[i] = '\0';
                break;
            }

        /*if (strchr(msgbuf, '\r'))
            *strchr(msgbuf, '\r') = '\0';
        else
            *strchr(msgbuf, '\n') = '\0';*/

        notValid = regexec(&regex, msgbuf, 0, NULL, 0);
        if (notValid)
        {
            fprintf(stderr, "Bad formatted input\n");
            exit(-2);
        }
        msgbuf[stopSym] = '\n';
        //*strchr(msgbuf, '\0') = '\n';

        sscanf(msgbuf, "%d %d", &color, &column);
        if (color > 254)
        {
            fprintf(stderr, "Invalid color with number %d\n", color);
            exit(-3);
        }

        if (column > maxX)
            maxX = column;
        if (column < minX)
            minX = column;

        // if the Field size should change
        if (sizeX < maxX - minX + 1)
        {
            if (offset == -minX)
                pField = rearrangeField(pField, 1, sizeX, sizeY, maxX - minX + 1, sizeY);
            else
            {
                pField = rearrangeField(pField, 0, sizeX, sizeY, maxX - minX + 1, sizeY);
                offset = -minX;
            }

            sizeX = maxX - minX + 1;
        }
        else if (pField[sizeY-1][column + offset].color != NOCOLOR)
        {
            pField = rearrangeField(pField, 0, sizeX, sizeY, sizeX, sizeY + 1);
            sizeY++;
        }

        for (int i = 0; i < sizeY; i++)
            if (pField[i][offset + column].color == NOCOLOR)
            {
                pField[i][offset + column].color = color;
                break;
            }

        while(markSequences(pField, sizeX, sizeY))
        {
            removeMarkedStone(pField, sizeX, sizeY);
            slideDown(pField, sizeX, sizeY);
        }
    }

    for (int i = 0; i < sizeX; i++)
        for (int j = 0; j < sizeY; j++)
            if (pField[j][i].color != NOCOLOR)
                fprintf(stdout, "%d %d %d\n", pField[j][i].color, i - offset, j);

    freeMemory(pField, sizeY);
    regfree(&regex);
    return 0;
}

void freeMemory(struct stone ** pField, unsigned int row)
{
    for (int i = 0; i < row; i++)
    {
        free(pField[i]);
    }
    free(pField);
}

struct stone ** getMemory(unsigned int sizeX, unsigned int sizeY)
{
    struct stone ** pField;
    pField = (struct stone **) malloc(sizeY * sizeof(struct stone *));
    if (pField == NULL)
    {
        fprintf(stderr, "Cannot allocate in RAM memory\n");
        exit(-1);
    }
    for (int i = 0; i < sizeY; i++)
    {
        pField[i] = (struct stone *) malloc(sizeX * sizeof(struct stone));
        if (pField[i] == NULL)
        {
            fprintf(stderr, "Cannot allocate in RAM memory\n");
            exit(-1);
        }
    }

    return pField;
}

void initializeField(struct stone ** pField, unsigned int sizeX, unsigned int sizeY)
{
    for (int i = 0; i < sizeY; i++)
        memset(pField[i], NOCOLOR, sizeX * 2);
}

void removeMarkedStone(struct stone ** pField, unsigned int sizeX, unsigned int sizeY)
{
    for (int i = 0; i < sizeY; i++)
        for (int j = 0; j < sizeX; j++)
        {
            if (pField[i][j].flag == 1){
                pField[i][j].color = NOCOLOR;
                pField[i][j].flag = 0;
            }
        }
}

struct stone ** rearrangeField(struct stone ** pField,
                               unsigned int offsetFlag, unsigned int sizeX,
                               unsigned int sizeY, unsigned int newSizeX,
                               unsigned int newSizeY)
{
    struct stone ** pNewField = getMemory(newSizeX, newSizeY);
    initializeField(pNewField, newSizeX, newSizeY);
    if (offsetFlag)
    {
        for (int i = 0; i < sizeY; i++)
            memcpy(pNewField[i], pField[i], sizeX * 2);
            /*for (int j = 0; j < sizeX; j++)
                pNewField[i][j] = pField[i][j];*/
    }
    else
    {
        int temp = (int)(newSizeX - sizeX);
        for (int i = 0; i < sizeY; i++)
            memcpy(&pNewField[i][temp], pField[i], sizeX * 2);
            /*for (int j = 0; j < sizeX; j++)
                pNewField[i][temp+j] = pField[i][j];*/
    }
    freeMemory(pField, sizeY);
    return pNewField;
}

int markSequences(struct stone ** pField, unsigned int sizeX, unsigned int sizeY)
{
    int result = 0;
    for (int row = 0; row < sizeY; row++)
        for (int column = 0; column < sizeX; column++)
        {
            if (pField[row][column].color != NOCOLOR)
            {
                unsigned char tempColor = pField[row][column].color;

                if ( (row + 3) < sizeY && pField[row + 1][column].color == tempColor &&
                     pField[row + 2][column].color == tempColor &&
                     pField[row + 3][column].color == tempColor)
                {
                    result = 1;
                    for (int l = row; l < sizeY; l++)
                        if (pField[l][column].color == tempColor)
                            pField[l][column].flag = 1;
                        else
                            break;
                }

                if ((column + 3) < sizeX && pField[row][column + 1].color == tempColor &&
                    pField[row][column + 2].color == tempColor &&
                    pField[row][column + 3].color == tempColor)
                {
                    result = 1;
                    for (int l = column; l < sizeX; l++)
                        if (pField[row][l].color == tempColor)
                            pField[row][l].flag = 1;
                        else
                            break;
                }

                if ((column + 3) < sizeX && (row + 3) < sizeY &&
                    pField[row + 1][column + 1].color == tempColor &&
                    pField[row + 2][column + 2].color == tempColor &&
                    pField[row + 3][column + 3].color == tempColor)
                {
                    result = 1;
                    for (int l = column, k = row; l < sizeX && k < sizeY; l++, k++)
                        if (pField[k][l].color == tempColor)
                            pField[k][l].flag = 1;
                        else
                            break;
                }

                if ((row + 3) < sizeY && (column - 3) >= 0 &&
                    pField[row + 1][column - 1].color == tempColor &&
                    pField[row + 2][column - 2].color == tempColor &&
                    pField[row + 3][column - 3].color == tempColor)
                {
                    result = 1;
                    for (int l = column, k = row; l >= 0 && k < sizeY; l--, k++)
                        if (pField[k][l].color == tempColor)
                            pField[k][l].flag = 1;
                        else
                            break;
                }
            }
        }
    return result;
}

void slideDown(struct stone ** pField, unsigned int sizeX, unsigned int sizeY)
{
    for (int column = 0; column < sizeX; column++)
    {
        for (int row = 0; row < sizeY; row++)
        {
            if (pField[row][column].color == NOCOLOR)
            {
                for (int k = row + 1; k < sizeY; k++)
                {
                    if (pField[k][column].color != NOCOLOR)
                    {
                        unsigned char color = pField[k][column].color;
                        pField[k][column].color = NOCOLOR;
                        pField[row][column].color = color;
                        break;
                    }
                }
            }
        }
    }
}
