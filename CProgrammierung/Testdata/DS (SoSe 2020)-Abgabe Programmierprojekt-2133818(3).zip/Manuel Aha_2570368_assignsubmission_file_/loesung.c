#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


int isNumber(char *str);


void main(){

    int n; // Anzahl von Inputs
    int offset = 100; 
    int i,j,color,x,y,res;
    int r = 100,c = 2*offset;
    int *arr = (int *)malloc(r * c * sizeof(int)); // 100 * 200 Spielbrett

    FILE* file = fopen("Desktop/public_testcases/example00.stdin", "r"); 
    char line[256];
    char num[2][16];
    int count;
    int index;
    int flag = 0;
    int temp;

    int p,q;

    printf("stdin%c",0x0a);
    while (fgets(line, sizeof(line), file)) { // Lesen des Inputs

        printf(line);

        memset(num[0], 0, sizeof num[0]); // Arrays erneuern
        memset(num[1], 0, sizeof num[1]);

        count = 0;
        index = 0;

        for(i=0;i<strlen(line);i++){
            if(line[i] != ' ' && line[i] != '\0'){
                num[count][index] = line[i];
                index++;
            }else if(i > 0 && (line[i-1] != ' ' && line[i-1] != '\0')){
                if(count == 1){
                    break;
                }else{
                    num[count][index] = '\0';
                    index = 0;
                    count += 1;
                }
            }
        }

         if(count == 1){ // Input prüfen

                if(isNumber(num[0]) == 1 && isNumber(num[1]) == 1){

                      color = atoi(num[0]);
                      x = atoi(num[1]);
                      if(color >= 0 && color <= 254){
                            flag = 0;
                        for(i=0;i<r;i++){
                            if(*(arr + i*c + (offset + x)) == NULL){
                                *(arr + i*c + (offset + x)) = color + 1;

                                // 4er Reihen identifizieren

                                // horizontal

                                  if((*(arr + i*c + (offset + x-3)) == *(arr + i*c + (offset + x))) && (*(arr + i*c + (offset + x-2)) == *(arr + i*c + (offset + x))) && (*(arr + i*c + (offset + x-1)) == *(arr + i*c + (offset + x)))){

                                    *(arr + i*c + (offset + x-3)) = NULL;
                                    *(arr + i*c + (offset + x-2)) = NULL;
                                    *(arr + i*c + (offset + x-1)) = NULL;
                                    *(arr + i*c + (offset + x)) = NULL;

                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x-3)) != NULL)){
                                        *(arr + p*c + (offset + x-3)) = *(arr + (p-1)*c + (offset + x-3));
                                        p++;
                                     }
                                     *(arr + (p-1)*c + (offset + x-3)) = NULL;

                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x-2)) != NULL)){
                                        *(arr + p*c + (offset + x-2)) = *(arr + (p-1)*c + (offset + x-2));
                                        p++;
                                     }
                                      *(arr + (p-1)*c + (offset + x-2)) = NULL;

                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x-1)) != NULL)){
                                        *(arr + p*c + (offset + x-1)) = *(arr + (p-1)*c + (offset + x-1));
                                     }
                                     *(arr + (p-1)*c + (offset + x-1)) = NULL;

                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x)) != NULL)){
                                        *(arr + p*c + (offset + x)) = *(arr + (p-1)*c + (offset + x));
                                     }
                                     *(arr + (p-1)*c + (offset + x)) = NULL;

                                }else  if((*(arr + i*c + (offset + x-2)) == *(arr + i*c + (offset + x))) && (*(arr + i*c + (offset + x-1)) == *(arr + i*c + (offset + x))) && (*(arr + i*c + (offset + x+1)) == *(arr + i*c + (offset + x)))){

                                    *(arr + i*c + (offset + x-2)) = NULL;
                                    *(arr + i*c + (offset + x-1)) = NULL;
                                    *(arr + i*c + (offset + x)) = NULL;
                                    *(arr + i*c + (offset + x+1)) = NULL;


                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x+1)) != NULL)){
                                        *(arr + p*c + (offset + x+1)) = *(arr + (p-1)*c + (offset + x+1));
                                        p++;
                                     }
                                     *(arr + (p-1)*c + (offset + x+1)) = NULL;

                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x-2)) != NULL)){
                                        *(arr + p*c + (offset + x-2)) = *(arr + (p-1)*c + (offset + x-2));
                                        p++;
                                     }
                                      *(arr + (p-1)*c + (offset + x-2)) = NULL;

                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x-1)) != NULL)){
                                        *(arr + p*c + (offset + x-1)) = *(arr + (p-1)*c + (offset + x-1));
                                     }
                                     *(arr + (p-1)*c + (offset + x-1)) = NULL;

                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x)) != NULL)){
                                        *(arr + p*c + (offset + x)) = *(arr + (p-1)*c + (offset + x));
                                     }
                                     *(arr + (p-1)*c + (offset + x)) = NULL;

                                }else  if((*(arr + i*c + (offset + x-1)) == *(arr + i*c + (offset + x))) && (*(arr + i*c + (offset + x+1)) == *(arr + i*c + (offset + x))) && (*(arr + i*c + (offset + x+2)) == *(arr + i*c + (offset + x)))){

                                    *(arr + i*c + (offset + x-1)) = NULL;
                                    *(arr + i*c + (offset + x)) = NULL;
                                    *(arr + i*c + (offset + x+1)) = NULL;
                                    *(arr + i*c + (offset + x+2)) = NULL;


                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x+1)) != NULL)){
                                        *(arr + p*c + (offset + x+1)) = *(arr + (p-1)*c + (offset + x+1));
                                        p++;
                                     }
                                     *(arr + (p-1)*c + (offset + x+1)) = NULL;

                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x+2)) != NULL)){
                                        *(arr + p*c + (offset + x+2)) = *(arr + (p-1)*c + (offset + x+2));
                                        p++;
                                     }
                                      *(arr + (p-1)*c + (offset + x+2)) = NULL;

                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x-1)) != NULL)){
                                        *(arr + p*c + (offset + x-1)) = *(arr + (p-1)*c + (offset + x-1));
                                     }
                                     *(arr + (p-1)*c + (offset + x-1)) = NULL;

                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x)) != NULL)){
                                        *(arr + p*c + (offset + x)) = *(arr + (p-1)*c + (offset + x));
                                     }
                                     *(arr + (p-1)*c + (offset + x)) = NULL;

                                }else  if((*(arr + i*c + (offset + x+1)) == *(arr + i*c + (offset + x))) && (*(arr + i*c + (offset + x+2)) == *(arr + i*c + (offset + x))) && (*(arr + i*c + (offset + x+3)) == *(arr + i*c + (offset + x)))){

                                    *(arr + i*c + (offset + x+1)) = NULL;
                                    *(arr + i*c + (offset + x+2)) = NULL;
                                    *(arr + i*c + (offset + x+3)) = NULL;
                                    *(arr + i*c + (offset + x)) = NULL;

                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x+1)) != NULL)){
                                        *(arr + p*c + (offset + x+1)) = *(arr + (p-1)*c + (offset + x+1));
                                        p++;
                                     }
                                     *(arr + (p-1)*c + (offset + x+1)) = NULL;

                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x+2)) != NULL)){
                                        *(arr + p*c + (offset + x+2)) = *(arr + (p-1)*c + (offset + x+2));
                                        p++;
                                     }
                                      *(arr + (p-1)*c + (offset + x+2)) = NULL;

                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x+3)) != NULL)){
                                        *(arr + p*c + (offset + x+3)) = *(arr + (p-1)*c + (offset + x+3));
                                     }
                                     *(arr + (p-1)*c + (offset + x+3)) = NULL;

                                     p = i + 1;
                                     while((*(arr + p*c + (offset + x)) != NULL)){
                                        *(arr + p*c + (offset + x)) = *(arr + (p-1)*c + (offset + x));
                                     }
                                     *(arr + (p-1)*c + (offset + x)) = NULL;



                                // vertikal
                                }else if((i >= 3) && (*(arr + (i-3)*c + (offset + x)) == *(arr + i*c + (offset + x))) && (*(arr + (i-2)*c + (offset + x)) == *(arr + i*c + (offset + x))) && (*(arr + (i-1)*c + (offset + x)) == *(arr + i*c + (offset + x)))){

                                    *(arr + (i-3)*c + (offset + x)) = NULL;
                                    *(arr + (i-2)*c + (offset + x)) = NULL;
                                    *(arr + (i-1)*c + (offset + x)) = NULL;
                                    *(arr + i*c + (offset + x)) = NULL;
                                }else  if((i >= 2) && (*(arr + (i-2)*c + (offset + x)) == *(arr + i*c + (offset + x))) && (*(arr + (i-1)*c + (offset + x)) == *(arr + i*c + (offset + x))) && (*(arr + (i+1)*c + (offset + x)) == *(arr + i*c + (offset + x)))){

                                    *(arr + (i+1)*c + (offset + x)) = NULL;
                                    *(arr + (i-2)*c + (offset + x)) = NULL;
                                    *(arr + (i-1)*c + (offset + x)) = NULL;
                                    *(arr + i*c + (offset + x)) = NULL;
                                }else  if((i >= 1) && ((*(arr + (i-1)*c + (offset + x)) == *(arr + i*c + (offset + x))) && (*(arr + (i+1)*c + (offset + x)) == *(arr + i*c + (offset + x))) && (*(arr + (i+2)*c + (offset + x)) == *(arr + i*c + (offset + x))))){

                                    *(arr + (i+1)*c + (offset + x)) = NULL;
                                    *(arr + (i+2)*c + (offset + x)) = NULL;
                                    *(arr + (i-1)*c + (offset + x)) = NULL;
                                    *(arr + i*c + (offset + x)) = NULL;
                                }else  if((*(arr + (i+1)*c + (offset + x+1)) == *(arr + i*c + (offset + x))) && (*(arr + (i+2)*c + (offset + x)) == *(arr + i*c + (offset + x))) && (*(arr + (i+3)*c + (offset + x)) == *(arr + i*c + (offset + x)))){

                                   *(arr + (i+1)*c + (offset + x)) = NULL;
                                    *(arr + (i+2)*c + (offset + x)) = NULL;
                                    *(arr + (i+3)*c + (offset + x)) = NULL;
                                    *(arr + i*c + (offset + x)) = NULL;
                                }

                                 break;
                            }
                        }
                    }else{
                        fprintf(stderr, "Invalid Color  Range!\n");
                    }

                }else{
                   fprintf(stderr,"A symbol is used other than a integer!\n");
                }

        }else{
            fprintf(stderr,"Row does not include exactly two integers!\n");
        }

    }


    fclose(file); // schließen des Dokuments

    printf("%c%cstdout %c",0x0a,0x0a,0x0a);
    for(i=0;i<r;i++){
        for(j=0;j<c;j++){
           if(*(arr + i*c + j) != NULL){
             printf("%d %d %d\n",*(arr + i*c + j)-1,i,j-offset);

            }
        }
    }

}

// function to check whether the string is a number
int isNumber(char *str){
    int i;
    for(i=0;i<strlen(str);i++){
        if(!((str[i] >= '0' && str[i] <= '9') || (str[i] == '-') || (str[i] == '\0') || (str[i] == '\n'))){
            return 0;
        }
    }
    return 1;
}
